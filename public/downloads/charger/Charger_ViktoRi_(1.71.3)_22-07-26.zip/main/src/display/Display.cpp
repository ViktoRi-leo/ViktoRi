#include "Display.h"
#include "../core/Battery.h"
#include "../hardware/DCDC.h"
#include "../hardware/INA226int.h"
#include "../core/global.h"

LiquidCrystal_I2C lcd(ADDRDISP, DISPLAYx, DISPLAYy);

// символы аккумулятора и заряда
const char simb_array[8][8] PROGMEM = {
    {0x0E, 0x11, 0x11, 0x11, 0x11, 0x11, 0x11, 0x1F}, // akb 0
    {0x0E, 0x11, 0x11, 0x11, 0x11, 0x11, 0x1F, 0x1F}, // akb 1
    {0x0E, 0x11, 0x11, 0x11, 0x11, 0x1F, 0x1F, 0x1F}, // akb 2
    {0x0E, 0x11, 0x11, 0x11, 0x1F, 0x1F, 0x1F, 0x1F}, // akb 3
    {0x0E, 0x11, 0x11, 0x1F, 0x1F, 0x1F, 0x1F, 0x1F}, // akb 4
    {0x0E, 0x11, 0x1F, 0x1F, 0x1F, 0x1F, 0x1F, 0x1F}, // akb 5
    {0x0E, 0x1F, 0x1F, 0x1F, 0x1F, 0x1F, 0x1F, 0x1F}, // akb 6
    {0x03, 0x06, 0x0C, 0x18, 0x1F, 0x06, 0x0C, 0x18}, // заряд 7
};

// загрузка в память дисплея своих символов(состояние акб)
void setDisplaySimbol(void) {
  for (uint8_t x = 0; x < 8; x++)
    lcd.createChar(x, &simb_array[x][0]);
}

// Приветствие. Версия прошивки и тип контроллера
// *    ViktoRi     *
// *  1.61.1-328p   *
void print_version(void) {
  lcd.setCursor((uint8_t)((DISPLAYx - 7) / 2), (uint8_t)(DISPLAYy / 2 - 1));
  lcd.print(F(txt_ViktoRi));
  lcd.setCursor((uint8_t)((DISPLAYx - 12) / 2),
                (uint8_t)(DISPLAYy / 2)); 
  lcd.print(F(VER));
}

// если время подсветки берется из настроек скетча
// #define LIGHTTIME ((uint32_t)TIME_LIGHT * 60000)
// _light_tm заменить на LIGHTTIME
// void Display::Light_setTime(void) удалить везде
// в void Display::Light_low(void) удалить - "eepGetService_num(TIMELIGHT) and"

// установить время подсветки
void Display::Light_setTime(void) {
  _light_tm = (uint32_t)eepGetService_num(TIMELIGHT) * 60000;
}

// включение подсветки
void Display::Light_high(void) {
  lcd.setBacklight(true);                 // включение подсветки
  _light_time = millis_sys() + _light_tm; // старт отсчета времени подсветки
}

// отключение подсветки через 3 минуты, если разрешено
void Display::Light_low(void) {
  if (eepGetService_num(TIMELIGHT) and (millis_sys() >= _light_time)) {
    _light_time = millis_sys() + _light_tm;
    // если разрешено отключение подсветки и время вышло отключение подсветки
    lcd.setBacklight(false);
  }
}

// функция отключает подсветку если отключилось питание от сети
void Display::Light_power(void) {
  if (!sysFlagGetBits(FlagsName::POWERON))
    Light_low();
}

// функция для печати из PROGMEM
void Display::printFromPGM(int charMap) {
  // получаем адрес из таблицы ссылок
  uint16_t ptr = pgm_read_word(charMap);
  while (true) {
    char c = pgm_read_byte(ptr++);
    if (c == '\0')
      break;
    // выводим в монитор или куда нам надо // всю строку до нулевого символа
    lcd.write(c);
  }
}

Display disp;

// вывод значения в тысячных долях (мВ, мА, мВт) с x знаками после запятой
// целочисленный эквивалент lcd.print(v / 1000.0, x) с округлением
void print_milli(int32_t v, uint8_t x) {
  if (v < 0) {
    lcd.write('-');
    v = -v;
  }
  // прибавка для округления до x знаков
  static const uint16_t rnd[4] PROGMEM = {500, 50, 5, 0};
  uint32_t u = (uint32_t)v + pgm_read_word(&rnd[x]);
  lcd.print(u / 1000); // целая часть
  if (x) {
    lcd.write('.');
    uint16_t f = (uint16_t)(u % 1000);
    uint8_t d = 100;
    do {
      lcd.write('0' + (uint8_t)((f / d) % 10));
      d /= 10;
    } while (--x);
  }
}

// вывод Ач и Втч (значение в миллионных долях)
// целочисленный эквивалент lcd.print(fl / 1000000.0, (fl < 1000000) ? 2 : 1)
void print_floatA(int32_t fl) {
  print_milli(fl / 1000, (fl < 1000000) ? 2 : 1);
}

// Вывод напряжения
void print_volt(uint16_t volt, uint8_t x) {
  print_milli(volt, x);
  lcd.print(F(TXT_V));
}

// Вывод тока
void print_current(int16_t amp, uint8_t x) {
  print_milli(amp, x);
  lcd.print(F(TXT_A));
}

// вывод напряжения и тока
void print_volt_current(uint16_t volt, int16_t amp, uint8_t x) {
  print_volt(volt, x);
  print_current(amp, x);
}

// вывод Ач
void print_Ah(int32_t Ah) {
  print_floatA(Ah);
  lcd.print(F(TXT_AH));
}

// вывод Втч
void print_Wh(int32_t Wh) {
  print_floatA(Wh);
  lcd.print(F(TXT_WH));
}

// вывод сопротивления - mOm (значение в сотых долях мОм: 1000 = 10.00 mOm)
// целочисленный эквивалент lcd.print(R_mOm) с двумя знаками после запятой
void print_resist(int32_t centi) {
  print_milli(centi * 10, 2);
  lcd.print(F(TXT_MOM));
}

// вывод - часы
void print_hour(uint8_t hour) {
  lcd.print(hour);
  lcd.print(F(TXT_H));
}

// вывод - секунды
void print_sec(uint8_t sec) {
  lcd.print(sec);
  lcd.print(F(TXT_S));
}

// пробел
void print_space(void) { lcd.write(' '); }

void pr_tm(uint16_t tm) {
  if (tm < 10)
    lcd.print(0);
  lcd.print(tm);
}

// функция расчета текущего времени и вывод на дисплей
#if defined(__LGT8FX8P__)
void Print_time(uint32_t time_real, uint8_t x, uint8_t y) {
  lcd.setCursor(x, y);
  // остаток от деления DA = DA/DY, DY = DA%DY
  DSC_MOD(time_real, (uint16_t)3600);
  pr_tm(DA_get_int()); // часы
  lcd.write(':');
  // остаток от деления DA = DA/DY, DY = DA%DY
  DSC_MOD((uint32_t)DY_get(), (uint16_t)60);
  pr_tm(DA_get_int()); // минуты
  lcd.write(':');
  pr_tm(DY_get()); // секунды
}
#else
void Print_time(uint32_t time_real, uint8_t x, uint8_t y) {
  lcd.setCursor(x, y);
  pr_tm((uint16_t)(time_real / 3600ul)); // часы
  lcd.write(':');
  uint32_t t = (time_real % 3600ul);
  pr_tm((uint16_t)(t / 60ul)); // минуты
  lcd.write(':');
  pr_tm((uint16_t)(t % 60ul)); // секунды
}
#endif

void setCursorx(void) { lcd.setCursor(0, 0); }
void setCursory(void) { lcd.setCursor(0, 1); }

#if (SENSTEMP1 or SENSTEMP2)

// печать температуры транзистора или акб
void print_tr(void) {
#if (SENSTEMP1 and SENSTEMP2)
  // если подключены 2 датчика температуры
  if (getTempStatus(sens_temp::q1) and getTempStatus(sens_temp::akb)) {
    static uint8_t _tmr = 0;
    static char _tmp = 'c'; // c
    if (++_tmr >= 3) {
      _tmr = 0;
      _tmp = (_tmp == 'c') ? 'C' : 'c';
      lcd.print((_tmp == 'C') ? temp_Q1 : temp_akb);
      lcd.write(_tmp);
      ClearStr(2);
    }
  } else if (getTempStatus(sens_temp::q1)) {
    lcd.print(temp_Q1);
    lcd.print(F(TXT_DEG)); // суффикс градусов из языкового файла
  } else if (getTempStatus(sens_temp::akb)) {
    lcd.print(temp_akb);
    lcd.print(F(TXT_DEG));
  }

#endif

#if (SENSTEMP1 > 0 and SENSTEMP2 == 0)
  // если подключен только датчик транзистора
  if (getTempStatus(sens_temp::q1)) {
    lcd.print(temp_Q1);
    lcd.print(F(TXT_DEG));
  }

#endif

#if (SENSTEMP1 == 0 and SENSTEMP2 > 0)
  // если подключен только датчик акб
  if (getTempStatus(sens_temp::akb)) {
    lcd.print(temp_akb);
    lcd.print(F(TXT_DEG));
  }
#endif
}

#if (SENSTEMP1 and SENSTEMP2)
// Вывод температур в одну строку
void print_tr_split(void) {
  if (getTempStatus(sens_temp::q1)) {
    lcd.setCursor(7, 0);
    lcd.print(temp_Q1);
    lcd.print(F(TXT_DEG)); // суффикс градусов из языкового файла
    ClearStr(2);
  }
  if (getTempStatus(sens_temp::akb)) {
    lcd.setCursor(DISPLAYx - 4, 0);
    lcd.print(temp_akb);
    lcd.print(F(TXT_DEG_AKB)); // суффикс градусов акб (в ru - строчная c)
    print_space();
  }
}
#endif

#endif

// экран ошибки напряжения БП
void print_power_error(void) {
#if (TIME_LIGHT)
  // disp.Light_high();  // включение подсветки
#endif

  lcd.clear();
  lcd.print(F(txt4)); // "Power "
  print_mode(ERROR);  // error
  setCursory();
  print_volt(getPower());
}

void print_temp_error(void) {
  lcd.clear();
  lcd.print(F(txt9)); // "Temp akb:"
  lcd.setCursor(9, 0);
  lcd.print(temp_akb);
  print_space();
  setCursory();
  print_volt_current(ina.voltsec, ina.ampersec, 3);
}

uint8_t op_window = 0; // номер экрана
uint8_t ns_disp = 0;   // время отображения

// изменение номера экрана
void window_change(uint8_t window_max) {
  // выбрать следующее окно
  op_window = constrain_my(op_window, 0, window_max, butt.tick); // WINDC
  ns_disp = (op_window) ? TIME_DISP : 0;
  lcd.clear();
}

// обратный отсчет время отображения экрана
void disp_time(void) {
  if (op_window) {
    if (ns_disp) {
      if (--ns_disp == 0) {
        lcd.clear();
        op_window = 0;
      }
    }
  } else {
    ns_disp = 0;
  }
}

bool akbzn = true;
// функция вывод на дисплей
#if ((DISPLAYx == 16 and DISPLAYy == 2) or (DISPLAYx == 20 and DISPLAYy == 2))
void Display_print(int32_t Ah, int32_t Wh, uint32_t time_real, uint8_t prc) {
  switch (op_window) {
  case 0: {
    // 0 строка
    setCursorx();
    print_volt(ina.voltsec,
               (ina.voltsec < (uint16_t)10000) ? (uint8_t)3 : (uint8_t)2);
    print_Ah(Ah);
    // вывод режима работы
    lcd.setCursor(DISPLAYx - 1, 0);
    lcd.print((char)pgm_read_byte(&regimr[regims]));
    // 1 строка
    setCursory();
    int16_t curr = abs(ina.ampersec);
    print_current(curr, (curr < (int16_t)10000) ? (uint8_t)3 : (uint8_t)2);
    Print_time(time_real, 7, 1);
    lcd.setCursor(DISPLAYx - 1, 1);
    // знак акб:  пробел - значек заряда
    lcd.write((akbzn ? map_my(prc, 0, 100, 0, 6)
                     : ((regims == Regims::REGIM_DISCHARGE) ? ' ' : 7)));
    akbzn = !akbzn;
  } break;

  case 1:
    // *Charge-AddChar  *
    // *Charge 45%      *
    setCursorx();
    print_mode(MODE); // режим работы
    setCursory();
    // текущий режим работы
    disp.printFromPGM((int)(&regims_txt[regims - 1]));
    print_space();
    lcd.print(prc); // процент заряда Акб
    lcd.write('%');
    print_space();
    break;

  case 2:
    setCursorx();
    print_Wh(Wh);
    // вывод значения ШИМ заряда
    lcd.print(dcdc.getTok());
    lcd.print(F(TXT_PWM));

    setCursory();
#if (VOLTIN == 1)
    // вывод напряжения БП
    print_volt(getPower());
#endif

#if (SENSTEMP1 or SENSTEMP2)
    print_tr(); // температура транзистора или акб
#endif
    printCykl(); // вывод цикла заряда
    print_space();
    break;

  case 3:
    setCursorx();
    print_mode(TYPE_AKB); // вывод типа акб
    setCursory();
    print_Capacity(); // вывод емкости акб
    print_space();
    print_mode(VOLTAGE); // вывод напряжения акб
    break;

  case 4:
    setCursorx();
    lcd.print(F(txt15));
    setCursory();
    print_volt_current(ina.volt_aver, ina.curr_aver, 3);
    break;
  }
}
// *14.81V 0.01Ah Ch*  0
// *10.55A 01:01:01 *  1

// 1 - используется диспплей 20*4
#elif (DISPLAYx == 20 and DISPLAYy == 4)
// функция вывод на дисплей 20*4
void Display_print(int32_t Ah, int32_t Wh, uint32_t time_real, uint8_t prc) {
  switch (op_window) {
  case 0: {
    // 0 строка
    setCursorx();
    print_mode(MODE); // режим работы
    // 1 строка
    lcd.setCursor(0, 1);
    Print_time(time_real, 0, 1);
    print_space();
    // текущий режим работы
    disp.printFromPGM((int)(&regims_txt[regims - 1]));
    ClearStr(8);
    // 2 строка
    lcd.setCursor(0, 2);
    print_Ah(Ah);
    print_Wh(Wh);
    lcd.print(prc); // процент заряда Акб
    lcd.print(F("%  "));
    // 3 строка
    lcd.setCursor(0, 3);
    print_volt(ina.voltsec,
               (ina.voltsec < (uint16_t)10000) ? (uint8_t)3 : (uint8_t)2);
    int16_t curr = abs(ina.ampersec);
    print_current(curr, (curr < 10000) ? 3 : 2); // вывести Ампер

#if (SENSTEMP1 or SENSTEMP2)
    print_tr(); // температура транзистора или акб
#endif
    lcd.setCursor(DISPLAYx - 1, 3);
    lcd.write((akbzn ? map_my(prc, 0, 100, 0, 6)
                     : ((regims == Regims::REGIM_DISCHARGE) ? 32 : 7)));
    akbzn = !akbzn;
  } break;
  case 1:
    // 0 строка
    setCursorx();
    print_mode(TYPE_AKB); // вывод типа акб
    print_space();
    print_Capacity();    // вывод емкости акб
    print_mode(VOLTAGE); // вывод напряжения акб
    // 1 строка
    lcd.setCursor(0, 1);
    printCykl();
    lcd.setCursor(0, 3);
    print_milli(ina.getsPower(), 2); // мощность, Вт
    lcd.write('W');
    break;
  case 2:
    // 0 строка
    setCursorx();
    lcd.print(F(txt15));
    // 1 строка
    setCursory();
    print_volt_current(ina.volt_aver, ina.curr_aver, 3);
    break;
  }
}
// *PB Ca/Ca 60Ah 12.6V *  0
// *01:01:01 Zaryad>Doza*  1
// *60.56Ah 220.56Wh 56%*  2
// *14.81V 6.555A 35C  ~*  3

// 1 - используется диспплей 16*4
#elif (DISPLAYx == 16 and DISPLAYy == 4)
// функция вывод на дисплей 20*4
void Display_print(int32_t Ah, int32_t Wh, uint32_t time_real, uint8_t prc) {
  switch (op_window) {
  case 0: {
    // 0 строка
    setCursorx();
    print_mode(MODE); // режим работы
    print_space();
    // текущий режим работы
    disp.printFromPGM((int)(&regims_txt[regims - 1]));
    // 1 строка
    lcd.setCursor(0, 1);
    Print_time(time_real, 0, 1);
    print_space();
    lcd.print(prc);
    lcd.print(F("% "));
#if (SENSTEMP1 or SENSTEMP2)
    print_tr(); // температура транзистора или акб
#endif
    // 2 строка
    lcd.setCursor(0, 2);
    print_Ah(Ah);
    print_Wh(Wh);
    // 3 строка
    lcd.setCursor(0, 3);
    // if (ina.voltsec < 10000) lcd.print(0);
    print_volt(ina.voltsec,
               (ina.voltsec < (uint16_t)10000) ? (uint8_t)3 : (uint8_t)2);
    int16_t curr = abs(ina.ampersec);
    print_current(curr, (curr < (int16_t)10000) ? (uint8_t)3 : (uint8_t)2);
    lcd.setCursor(DISPLAYx - 1, 3);
    lcd.write((akbzn ? map_my(prc, 0, 100, 0, 6)
                     : ((regims == Regims::REGIM_DISCHARGE) ? ' ' : 7)));
    akbzn = !akbzn;

  } break;
  case 1:
    // 0 строка
    setCursorx();
    print_mode(TYPE_AKB); // вывод типа акб
    print_space();
    print_Capacity();    // вывод емкости акб
    print_mode(VOLTAGE); // вывод напряжения акб
    // 1 строка
    lcd.setCursor(0, 1);
    printCykl();
    lcd.setCursor(0, 3);
    print_milli(ina.getsPower(), 2); // мощность, Вт
    lcd.write('W');
    break;

  case 2:
    // 0 строка
    setCursorx();
    lcd.print(F(txt15));
    // 1 строка
    setCursory();
    print_volt_current(ina.volt_aver, ina.curr_aver, 3);
    break;
  }
}
// *60Ah 12.6V Zarya*
// *01:01:01 52% 35C*
// *60.56Ah 220.56Wh*
// *14.81V 6.555A  ~*

#endif

// вывести на дисплей - вкл/откл
void PrintOnOff(bool i) {
  lcd.print((i ? F(txt13) : F(txt14))); // вкл  / откл
}

// вывод на дисплей > или пробел
void Write_x(bool x) {
  lcd.write((x ? '>' : ' ')); // > or  пробел
}
/*
// вывод на дисплей
enum DispRgb: uint8_t {
  MODE,      // 0 режим работы
  TYPE_AKB,  // 1 тип акб
  ERROR,     // 2 ошибка
  SETTING,   // 3 настройки
  VOLTAGE,   // 4 напряжение во float
};
*/

// вывод на дисплей: 0-режим работы, 1-тип акб
void print_mode(uint8_t i) {
  switch (i) {
  case MODE:
    disp.printFromPGM((int)(&modeTxt[profil.Regim]));
    if (profil.Regim == Modes::CHARGE and
        bitRead(profil.flags, Pr_flags::CHARGE_ADD)) {
      lcd.write('-');
      disp.printFromPGM((int)(&modeTxt[Modes::ADDCHARGE]));
    }
    break;
  case TYPE_AKB:
    disp.printFromPGM((int)(&akb_name_list[profil.akb.type]));
    break;
  case ERROR:
    lcd.print(F(txt21)); // "error"
    break;
  case SETTING:
    disp.printFromPGM((int)(&menuTxt[5])); // "Settings"
    break;
  case VOLTAGE:
    print_milli(bat_volt(profil.akb.type), 1); // напряжение
    lcd.write('V');
    break;
  }
}

void print_Capacity(void) {
  lcd.print(profil.akb.capacity);
  lcd.print(F(TXT_AH));
}

void printCykl(void) {
  lcd.write('C');
  lcd.print(eeGetRound());
}

// Функция вывода напряжения акб и количество банок
void Vout(void) {
  print_mode(VOLTAGE); // 12.6V
  lcd.write('(');
  lcd.print(profil.akb.cell);
  lcd.write(')');
  ClearStr(4); // очистить поле
  lcd.setCursor(3, 0);
}

// функция очистки строки дисплея (i символов)
void ClearStr(uint8_t i) {
  while (i--)
    lcd.write(' ');
}
/*
void print_otval_akb(void) {
  setCursorx();
  lcd.print(F("Akb"));
  lcd.print(F(txt21));
  PrintVA()
}
*/
/*
// вывод свободной оперативки
void print_memoryFree(void) {
  lcd.setCursor(0, 0);
  lcd.print(memoryFree());
  lcd.write(' ');
}
*/
/*
// Переменные, создаваемые процессом сборки,
// когда компилируется скетч
extern int __bss_end;
extern void *__brkval;

// Функция, возвращающая количество свободного ОЗУ (RAM)
int memoryFree(void) {
  int freeValue;
  if ((int)__brkval == 0)
    freeValue = ((int)&freeValue) - ((int)&__bss_end);
  else
    freeValue = ((int)&freeValue) - ((int)__brkval);
  return freeValue;
}
*/
