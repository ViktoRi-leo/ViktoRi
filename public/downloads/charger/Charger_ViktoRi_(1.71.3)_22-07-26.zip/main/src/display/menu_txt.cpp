// Определения PROGMEM-массивов текстов меню.
// Строки-элементы определены в языковых файлах lang/
// и эмитируются во flash только здесь - в единственном экземпляре.
#include "menu_txt.h"
#include "../core/Battery.h"

const char* const menuTxt[MENUTXT_SIZE] PROGMEM = {
  menu_profil,        // 0
  menu_akb_capacity,  // 1
  menu_akb_type,      // 2
  menu_akb_volt,      // 3
  menu_mode,          // 4
  menu_settings,      // 5
  menu_system,        // 6
#if (STATISTIC == 1)
  menu_statistic,     // 7
#endif
#if (RESIST == 1)
  menu_resist_akb,    // 8
#endif
  //menu_sensors,       // 9
};

const char* const modeTxt[8] PROGMEM = {
  mode_charge,
  mode_addcharge,
  mode_discharge,
  mode_storage,
  mode_asimm,
  mode_ktc,
  mode_bufer,
  mode_branimir,
};

const char* const systema[SYSTEMA_SIZE] PROGMEM = {
#if (KALIBROVKA > 0)
  system_calibration,
#endif
#if (SERVICE == 1)
  system_setting,
#endif
  system_reset
};


// пункты меню настроек
const char* const settings_charge[SETTINGS_SIZE] PROGMEM = {
    // Заряд
    sett_volt,
    sett_curr,
    sett_curr_min,
    sett_time,
    sett_voltDecrCurr,
    sett_precharge,
    sett_precharge_vc,
    sett_precharge_vc,
    sett_charge_oscil,
    mode_addcharge,
    // Дозаряд
    sett_volt,
    sett_curr,
    sett_curr_min,
    sett_time,
    // Разряд
    sett_volt,
    sett_curr,
    sett_curr_min,
    // Хранение
    sett_volt,
    sett_curr,
    // Асиметричный заряд
    sett_volt,
    mode_charge,    // sett_curr,
    mode_discharge, // sett_discharge_curr,
    sett_asym_period_charge,
    sett_asym_period_discharge,
    sett_asym_pause,
    sett_time,
#if (BUFFER)
    // Буфер
    sett_volt,
    sett_curr,
#endif
    sett_round,
};


// пункты текущего режима
const char* const regims_txt[REGIMS_TXT_SIZE] PROGMEM = {
  sett_precharge,     /*предзаряд*/
  mode_charge,        /*заряд*/
  sett_charge_oscil,  /*качели*/
  mode_addcharge,     /*дозаряд*/
  mode_discharge,     /*разряд*/
#if (BRRANIMIR)
  boiling,            /*кипение*/
#endif
  mode_pause,         /*Пауза*/
};

// пункты сброса настроек
const char* const reset_txt[5] PROGMEM = {
  reset_exit, reset_all, reset_profils, reset_calibr, system_setting
};


const char* const calibr[3] PROGMEM = { namc1, namc2, namc3 };


// архив с названиями типов аккумуляторов (строки - в lang/common.h)
// порядок должен совпадать с enum Akb_type (core/Battery.h)
const char* const akb_name_list[AKB_TYPES] PROGMEM = {
    akb_pb_caca, akb_pb_casur, akb_pb_sur, akb_pb_agm, akb_pb_gel,
    akb_li_ion,  akb_li_pol,   akb_li_fer, akb_li_tit, akb_ni_cd, akb_ni_mg
};


#if (DISPLAYy == 2)
// символы вывода режима работы - Предзаряд, Заряд, Качели, Дозаряд,
// Разряд, Кипение (Бурление), Ожидание (пауза)
// содержимое задается языковым файлом (REGIMR_STR)
const char regimr[] PROGMEM = REGIMR_STR;
#endif
