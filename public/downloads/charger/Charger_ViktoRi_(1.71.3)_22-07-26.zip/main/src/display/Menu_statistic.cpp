#include "../core/Battery.h"
#include "Display.h"
#include "Menu.h"
#include "../core/global.h"
#include <EEPROM.h>

// печать статистики
void Statistics_print(int i, uint32_t time_i, int32_t Ah, int32_t Wh) {
  disp.printFromPGM(i);
#if (DISPLAYx == 16)
  Print_time(time_i, DISPLAYx - 5, 0);
#else
  Print_time(time_i, DISPLAYx - 8, 0);
#endif
  setCursory();
  print_Ah(Ah);
  print_Wh(Wh);
}

// #if (STATISTIC == 1)
//  вывод статистики
void Statistics_point(uint8_t point) {
  switch (point) {
  case 0:
    // Заряд
    // *Zaryad     24:42*
    // *55.36Ah 366.35Wh*
    Statistics_print((int)(&modeTxt[Modes::CHARGE]), profil.charge.stat.time,
                     profil.charge.stat.ah, profil.charge.stat.wh);
    break;
  case 1:
    //  Дозаряд
    // *Add charge 24:42*
    // *55.36Ah 366.35Wh*
    Statistics_print((int)(&modeTxt[Modes::ADDCHARGE]), profil.add.stat.time,
                     profil.add.stat.ah, profil.add.stat.wh);
    break;
  case 2:
    // Разряд
    // *Razryad    24:42*
    // *55.36Ah 366.35Wh*
    Statistics_print((int)(&modeTxt[Modes::DISCHARGE]), profil.disch.stat.time,
                     profil.disch.stat.ah, profil.disch.stat.wh);
    break;
  case 3:
    // Асссиметричный заряд
    Statistics_print((int)(&modeTxt[Modes::ASYMMETRIC]), profil.asym.stat.time,
                     profil.asym.stat.ah, profil.asym.stat.wh);
    break;
  default:
    // вывод значений емкости КТЦ
    {
      uint16_t m = eeGetKtcRounds(); // фактическое число кругов КТЦ
      m -= (point - 4);
      // архив Ah_discharge, Wh_discharge, Ah_charge, Wh_charge,
      int32_t KTC[4]{0};
#if defined(__LGT8FX8P__)
      // считать из памяти значения разряда, заряда round-цикла КТЦ
      const uint16_t eeAddr = (m << 4) - 16 + MEM_KTC;
      //  lgt_eeprom_read_block(((uint8_t *)&KTC), ((m << 4) - 16 + MEM_KTC),
      //  sizeof(KTC));
      lgt_eeprom_readSWM(eeAddr, ((uint32_t *)&KTC),
                         (uint16_t)(sizeof(KTC) / sizeof(uint32_t)));
#else
      // считать из памяти значения разряда, заряда m-цикла КТЦ
      const int16_t eeAddr = (m << 4) - 16 + MEM_KTC;
      EEPROM.get(eeAddr, KTC);
#endif
      lcd.print(point - 3); // 1
      lcd.print(F("D:"));   // 1D:
      print_Ah(KTC[0]);     // 1D:65.3Ah
      print_Wh(KTC[1]);     // 1D:65.3Ah 255Wh
      setCursory();
      lcd.print(point - 3); // 1
      lcd.print(F("C:"));   // 1C:
      print_Ah(KTC[2]);     // 1C:65.3Ah
      print_Wh(KTC[3]);     // 1C:65.3Ah 255Wh
      break;
    }
  }
}
// #endif

/*
*                *
------------------
*1D:65.3Ah 255Wh *
*1C:66.4AH 257Wh *
------------------
*/
