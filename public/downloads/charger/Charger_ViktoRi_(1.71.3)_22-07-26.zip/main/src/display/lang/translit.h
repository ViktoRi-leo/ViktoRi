#pragma once
// =====================================================================
//  Тексты интерфейса: ТРАНСЛИТ
//  Не включать напрямую - подключается через menu_txt.h по INTERFACE.
// =====================================================================

// пункты меню
const char menu_profil[] PROGMEM = "Pr:";
const char menu_akb_capacity[] PROGMEM = "Emkost akb";
const char menu_akb_type[] PROGMEM = "Tip akb";
const char menu_akb_volt[] PROGMEM = "Napryagenie akb";
const char menu_mode[] PROGMEM = "Regim raboti";
const char menu_settings[] PROGMEM = "Nastroiki";
const char menu_resist_akb[] PROGMEM = "Soprot. akb";
const char menu_statistic[] PROGMEM = "Statistika";
const char menu_system[] PROGMEM = "System";

// пункты меню режимов работы
const char mode_charge[] PROGMEM = "Zaryad";
const char mode_addcharge[] PROGMEM = "Dozaryad";
const char mode_asimm[] PROGMEM = "Asymmetric";
const char mode_discharge[] PROGMEM = "Razryad";
const char mode_storage[] PROGMEM = "Hranenie";
const char mode_bufer[] PROGMEM = "Bufer";
const char mode_ktc[] PROGMEM = "KTC";
const char mode_branimir[] PROGMEM = "Branimir";
#if (BRRANIMIR)
// Кипение (перемешивание)
const char boiling[] PROGMEM = "Peremeshiv.";
#endif
const char mode_pause[] PROGMEM = "Pauza";  // Пауза

// пункты меню Система
const char system_calibration[] PROGMEM = "Kalibrovka";
const char system_setting[] PROGMEM = "!system param!";
const char system_reset[] PROGMEM = "Cbros nastroek";

// пункты меню настроек
// Напряжение
const char sett_volt[] PROGMEM = "Volt";
// Ток
const char sett_curr[] PROGMEM = "Tok";
// минимальный ток
const char sett_curr_min[] PROGMEM = "Min. tok";
// Время часы
const char sett_time[] PROGMEM = "Vremya";
//  Напряжение при котором начинает снижаться ток (Напр. сниж. тока)
const char sett_voltDecrCurr[] PROGMEM = "Snigenie";
// Предзаряд
const char sett_precharge[] PROGMEM = "Predzaryad";
const char sett_precharge_vc[] PROGMEM = "Predzar.";
// Качели
const char sett_charge_oscil[] PROGMEM = "Kacheli";
// Период заряда
const char sett_asym_period_charge[] PROGMEM = "Zaryad sek";
//  Период разряда
const char sett_asym_period_discharge[] PROGMEM = "Razryad sek";
//  Пауза
const char sett_asym_pause[] PROGMEM = "Pause sek";
//  Цикл
const char sett_round[] PROGMEM = "Cycle";

// пункты меню калибровок
const char namc1[] PROGMEM = "Volt/Curr akb";
const char namc2[] PROGMEM = "Volt Power";
const char namc3[] PROGMEM = "INA Volt";

// пункты сброса настроек
const char reset_exit[] PROGMEM = "Exit";              // Выход
const char reset_all[] PROGMEM = "Vse";                // Всё
const char reset_profils[] PROGMEM = "Profili";        // Профили
const char reset_calibr[] PROGMEM = "Kalibrovki";      // Калибровки

// символы вывода режима работы (дисплей 1602):
// Предзаряд, Заряд, Качели, Дозаряд, Разряд, [Кипение], Ожидание (пауза)
#if (BRRANIMIR)
#define REGIMR_STR " PZKDRBO"
#else
#define REGIMR_STR " PZKDRO"
#endif

// суффиксы градусов: транзистор Q1 и акб (\xDF - знак градуса на дисплее)
#define TXT_DEG     "\xDF"
#define TXT_DEG_AKB "\xDF"

// текстовые строки
#define txt3 " sohr."
#define txt4 "Power "
#define txt6 "INA226 error"
#define txt9 "Temp akb:"
#define txt11 "Podkluchi AKB"
#define txt111 "Podkluchi BP"
#define txt13 "Vkl."
#define txt14 "Otkl."
#define txt15 "Korrect OK"
#define txt16 "Pause"
#define txt17 "< OK >"
#define txt18 "Regim BP"
#define txt19 "<Stop>"
#define txt20 " min "
#define txt21 " error"
#define txt24 "!-PROBIT Q1-!"
