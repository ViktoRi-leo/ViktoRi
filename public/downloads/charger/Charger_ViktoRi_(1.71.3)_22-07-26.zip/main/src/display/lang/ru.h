#pragma once
// =====================================================================
//  Тексты интерфейса: РУССКИЙ (!для дисплеев с поддержкой русского языка!)
//  Не включать напрямую - подключается через menu_txt.h по INTERFACE.
//  Строки в кодировке знакогенератора дисплея (не win1251/utf8).
// =====================================================================

// пункты главного меню
const char menu_profil[] PROGMEM = "Pr:";                                                         //  0   Профиль
const char menu_akb_capacity[] PROGMEM = "\x45\xBC\xBA\x6F\x63\xBF\xC4 \x41\x4B\xA0";             //  1   Емкость  // АКБ
const char menu_akb_type[] PROGMEM = "\x54\xB8\xBE \x41\x4B\xA0";                                 //  2   Тип АКБ
const char menu_akb_volt[] PROGMEM = "\x48\x61\xBE\x70\xC7\xB6\x65\xBD\xB8\x65 \x41\x4B\xA0";     //  3   Напряжение АКБ
const char menu_mode[] PROGMEM = "\x50\x65\xB6\xB8\xBC \x70\x61\xB2\x6F\xBF\xC3";                 //  4   Режим работы
const char menu_settings[] PROGMEM = "\x48\x61\x63\xBF\x70\x6F\xB9\xBA\xB8";                      //  5   Настройки
const char menu_resist_akb[] PROGMEM = "\x43\x6F\xBE\x70\x6F\xBF\x2E\x41\x4B\xA0";                //  6   Сопрот. АКБ
const char menu_statistic[] PROGMEM = "\x43\xBF\x61\xBF\xB8\x63\xBF\xB8\xBA\x61";                 //  7   Статистика
const char menu_system[] PROGMEM = "\x43\xB8\x63\xBF\x65\xBC\x61";                                //  8   Система

// пункты меню режима работы
const char mode_charge[] PROGMEM = "\xA4\x61\x70\xC7\xE3";                                          //  0   Заряд
const char mode_addcharge[] PROGMEM = "\xE0\x6F\xB7\x61\x70\xC7\xE3";                               //  1   Дозаряд
const char mode_discharge[] PROGMEM = "\x50\x61\xB7\x70\xC7\xE3";                                   //  2   Разряд
const char mode_storage[] PROGMEM = "\x58\x70\x61\xBD\x65\xBD\xB8\x65";                             //  3   Хранение АКБ
const char mode_asimm[] PROGMEM = "Acc\xB8\xBC. \xB7\x61\x70\xC7\xE3";                              //  4   Aссиметричный заряд
const char mode_ktc[] PROGMEM = "KT\xE5";                                                           //  5   КТЦ (Разр>Зар>Дозар)
const char mode_bufer[] PROGMEM = "\xA0\x79\xE4\x65\x70";                                           //  6   Буф.режим
const char mode_branimir[] PROGMEM = "\xA0\x70\x61\xBD\xB8\xBC\xB8\x70\x61";                        //  7   Заряд Бранимир
#if (BRRANIMIR)
const char boiling[] PROGMEM = "Boiling";  // Кипение (перемешивание)
#endif
const char mode_pause[] PROGMEM = "\xA8\x61\x79\xB7\x61";  // Пауза

// пункты меню Система
// Калибровка
const char system_calibration[] PROGMEM = "\x4B\x61\xBB\xB8\xB2\x70\x6F\xB3\xBA\x61";
// Системные параметры
const char system_setting[] PROGMEM = "\x21\x43\xB8\x63\xBF\x65\xBC\x2E\x20\xBE\x61\x70\x61\xBC\x21";
// Сброс настроек
const char system_reset[] PROGMEM = "\x43\xB2\x70\x6F\x63 \xBD\x61\x63\xBF\x70\x6F\x65\xBA";

// пункты меню настроек
// Напряжение
const char sett_volt[] PROGMEM = "\x48\x61\xBE\x70.";
// Ток
const char sett_curr[] PROGMEM = "\x54\x6F\xBA";
// минимальный ток
const char sett_curr_min[] PROGMEM = "\x4D\xB8\xBD. \xBF\x6F\xBA";
// Время часы
const char sett_time[] PROGMEM = "\x42\x70\x65\xBC\xC7";
//  Напряжение при котором начинает снижаться ток (Напр. сниж. тока)
const char sett_voltDecrCurr[] PROGMEM = "\x43\xBD\xB8\xB6\x65\xBD\xB8\x65";
// Предзаряд
const char sett_precharge[] PROGMEM = "\xA8\x70\x65\xE3\xB7\x61\x70\xC7\xE3";
const char sett_precharge_vc[] PROGMEM = "\xA8\x70\x65\xE3\xB7\x61\x70";
// Качели
const char sett_charge_oscil[] PROGMEM = "\x4B\x61\xC0\x65\xBB\xB8";
// Период заряда
const char sett_asym_period_charge[] PROGMEM = "\xA4\x61\x70\xC7\xE3 cek";
//  Период разряда
const char sett_asym_period_discharge[] PROGMEM = "\x50\x61\xB7\x70\xC7\xE3 cek";
//  Пауза
const char sett_asym_pause[] PROGMEM = "\xA8\x61\x79\xB7\x61 cek";
//  Цикл
const char sett_round[] PROGMEM = "\xE1\xB8\xBA\xBB";

// пункты калибровок
const char namc1[] PROGMEM = "\x48\x61\xBE\x70\xC7\xB6/\x54\x6F\xBA \x41\xBA\xB2";  // Напряж/ток акб
const char namc2[] PROGMEM = "\x48\x61\xBE\x70\xC7\xB6 \xA0\xA8";                   // Напряж. БП
const char namc3[] PROGMEM = "INA Volt";

// пункты сброса настроек
const char reset_exit[] PROGMEM = "\x42\xC3\x78\x6F\xE3"; // Выход
const char reset_all[] PROGMEM = "\x42\x63\xA2";          // Всё
const char reset_profils[] PROGMEM = "\xA8\x70\x6F\xE4\xB8\xBB\xB8"; // Профили
const char reset_calibr[] PROGMEM = "\x4B\x61\xBB\xB8\xB2\x70\x6F\xB3\xBA\xB8"; // Калибровки

// символы вывода режима работы (дисплей 1602):
// Предзаряд, Заряд, Качели, Дозаряд, Разряд, [Кипение], Ожидание (пауза)
#if (BRRANIMIR)
#define REGIMR_STR " \xA8\xA4\x4B\xE0\x50\xA0\x4F"
#else
#define REGIMR_STR " \xA8\xA4\x4B\xE0\x50\x4F"
#endif

// суффиксы градусов: транзистор Q1 и акб
// (дисплей с русским знакогенератором не имеет знака градуса)
#define TXT_DEG     "C "
#define TXT_DEG_AKB "c "

// текстовые строки
#define txt3 " \x63\x6F\x78\x70\x21"            //  сохр!
#define txt4 "\x42\x78\x2E\x20\xA0\xA8 "        //  "Вх. БП "
#define txt6 "INA226 \x6F\xC1\xB8\xB2\xBA\x61"  //  INA226 ошибка
#define txt9 "Temp akb:"                                       //  температура акб
#define txt11 "\xA8\x6F\xE3\xBA\xBB\xC6\xC0\xB8 \x41\x4B\xA0"  //  Подключи АКБ
#define txt111 "\xA8\x6F\xE3\xBA\xBB\xC6\xC0\xB8 \xA0\xA8"     //  Подключи БП
#define txt13 "\x42\xBA\xBB\x2E "                              //  Вкл.
#define txt14 "\x4F\xBF\xBA\xBB\x2E"                           //  Откл.
#define txt15 "\x4B\x6F\x70\x70\x65\xBA\xBF OK"                // Коррект OK
#define txt16 "\xA8\x61\x79\xB7\x61"  //  Пауза
#define txt17 "\x3C \x4F\x4B \x3E"    // "< OK >"
#define txt18 "Pe\xB6\xB8\xBC \xA0\xA8"          //  Режим БП
#define txt19 "\x3C\x43\xBF\x6F\xBE\x3e"         //  "<Стоп>"
#define txt20 " \xBC\xB8\xBD "                   //  мин
#define txt21 " \x6F\xC1\xB8\xB2\xBA\x61"        //  ошибка
#define txt24 "!-\xA8\x50\x4F\xA0\xA5\x54 Q1-!"  //  !-ПРОБИТ Q1-!
