#pragma once
// =====================================================================
//  Тексты, общие для всех языков интерфейса.
//  Не включать напрямую - подключается через menu_txt.h.
//  Здесь можно переименовать типы аккумуляторов и единицы измерения.
// =====================================================================

// названия типов аккумуляторов
// порядок должен совпадать с enum Akb_type (core/Battery.h)
const char akb_pb_caca[] PROGMEM  = "PB_Ca/Ca";
const char akb_pb_casur[] PROGMEM = "PB_CA+";
const char akb_pb_sur[] PROGMEM  = "PB_Sur";
const char akb_pb_agm[] PROGMEM = "PB_AGM";
const char akb_pb_gel[] PROGMEM  = "PB_GEL";
const char akb_li_ion[] PROGMEM  = "Li-Ion";
const char akb_li_pol[] PROGMEM  = "Li-Pol";
const char akb_li_fer[] PROGMEM = "LI_Fer";
const char akb_li_tit[] PROGMEM = "Li-Tit";
const char akb_ni_cd[] PROGMEM = "NI_Cd";
const char akb_ni_mg[] PROGMEM  = "NI_Mg";

// единицы измерения (суффиксы после чисел)
#define TXT_V   "V "    // вольты
#define TXT_A   "A "    // амперы
#define TXT_AH  "Ah "   // ампер-часы
#define TXT_WH  "Wh "   // ватт-часы
#define TXT_MOM "mOm "  // миллиомы
#define TXT_H   "h "    // часы
#define TXT_S   "s "    // секунды
#define TXT_PWM "pwm "  // значение ШИМ
