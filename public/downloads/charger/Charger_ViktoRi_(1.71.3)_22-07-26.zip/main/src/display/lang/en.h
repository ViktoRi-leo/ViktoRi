#pragma once
// =====================================================================
//  Тексты интерфейса: АНГЛИЙСКИЙ
//  Не включать напрямую - подключается через menu_txt.h по INTERFACE.
// =====================================================================

// пункты главного меню
const char menu_profil[] PROGMEM = "Pr:";
const char menu_akb_capacity[] PROGMEM = "Capacity Akb";
const char menu_akb_type[] PROGMEM = "Type Akb";
const char menu_akb_volt[] PROGMEM = "Voltage Akb";
const char menu_mode[] PROGMEM = "Operating mode";
const char menu_settings[] PROGMEM = "Settings";
const char menu_resist_akb[] PROGMEM = "Resist. akb";
const char menu_statistic[] PROGMEM = "Statistics";
const char menu_system[] PROGMEM = "System";

// пункты меню режимов работы
const char mode_charge[] PROGMEM = "Charge";
const char mode_addcharge[] PROGMEM = "Addcharge";
const char mode_asimm[] PROGMEM = "Asymmetric";
const char mode_discharge[] PROGMEM = "Discharge";
const char mode_storage[] PROGMEM = "Storage";
const char mode_bufer[] PROGMEM = "Buffer";
const char mode_ktc[] PROGMEM = "Training cycle";
const char mode_branimir[] PROGMEM = "Branimir";
#if (BRRANIMIR)
// Кипение (перемешивание)
const char boiling[] PROGMEM = "Boiling";
#endif
const char mode_pause[] PROGMEM = "Pause";  // Пауза

// пункты меню Система
const char system_calibration[] PROGMEM = "Calibration";
const char system_setting[] PROGMEM = "!system param!";
const char system_reset[] PROGMEM = "Reset settings";

// пункты меню настроек
// Напряжение
const char sett_volt[] PROGMEM = "Volt";
// Ток
const char sett_curr[] PROGMEM = "Current";
// минимальный ток
const char sett_curr_min[] PROGMEM = "Curr. min";
// Время часы
const char sett_time[] PROGMEM = "Time";
//  Напряжение при котором начинает снижаться ток (Напр. сниж. тока)
const char sett_voltDecrCurr[] PROGMEM = "Derease";
// Предзаряд
const char sett_precharge[] PROGMEM = "Precharge";
const char sett_precharge_vc[] PROGMEM = "Precharg";
// Качели
const char sett_charge_oscil[] PROGMEM = "Oscill.";
// Период заряда
const char sett_asym_period_charge[] PROGMEM = "Charge sec";
//  Период разряда
const char sett_asym_period_discharge[] PROGMEM = "Disch. sec";
//  Пауза
const char sett_asym_pause[] PROGMEM = "Pause sec";
//  Цикл
const char sett_round[] PROGMEM = "Cycle";

// пункты меню калибровки
const char namc1[] PROGMEM = "Volt/Curr akb";
const char namc2[] PROGMEM = "Volt Power";
const char namc3[] PROGMEM = "INA Volt";

// пункты сброса настроек
const char reset_exit[] PROGMEM = "Exit";              // Выход
const char reset_all[] PROGMEM = "All";                // Всё
const char reset_profils[] PROGMEM = "Profils";        // Профили
const char reset_calibr[] PROGMEM = "Calibrations";    // Калибровки

// символы вывода режима работы (дисплей 1602):
// Предзаряд, Заряд, Качели, Дозаряд, Разряд, [Кипение], Ожидание (пауза)
#if (BRRANIMIR)
#define REGIMR_STR " PCOADKBO"
#else
#define REGIMR_STR " PCOADKO"
#endif

// суффиксы градусов: транзистор Q1 и акб (\xDF - знак градуса на дисплее)
#define TXT_DEG     "\xDF"
#define TXT_DEG_AKB "\xDF"

// текстовые строки
#define txt3 " saved"
#define txt4 "Power "
#define txt6 "INA226 error"
#define txt9 "Temp akb:"  //  температура акб
#define txt11 "Connect batt"
#define txt111 "Connect power"
#define txt13 "On "
#define txt14 "Off "
#define txt15 "Korrect OK"
#define txt16 "Pause"
#define txt17 "< OK >"
#define txt18 "Regim BP"
#define txt19 "<Stop>"
#define txt20 " min "
#define txt21 " error"
#define txt24 "!-BROKEN Q1-!"
