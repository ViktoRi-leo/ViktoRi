#include <Arduino.h>

// Меню для дисплея LCD1602
void Menu1602(void);

// изменение сервисных параметров
//void serviceparam(void);

// вывод статистики
void Statistics_point(uint8_t point);


/* Новые настройки 3 */

// флаг циклов
extern bool fl_round;

// все настройки
void Settings_pre(int8_t x, bool modify);

// установить пункт настроек в начало
void SettPointToStart(void);