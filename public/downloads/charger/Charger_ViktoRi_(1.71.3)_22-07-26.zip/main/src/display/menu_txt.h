#pragma once
#include <Arduino.h>
#include "../core/User_Setup_Loader.h"

/*
  Тексты интерфейса. Каждый язык лежит в своем файле в папке lang/:
    lang/ru.h       - русский (кодировка знакогенератора дисплея)
    lang/en.h       - английский
    lang/translit.h - транслит
  Новый язык: скопируй один из файлов, переведи строки, добавь ветку сюда.
  Состав файла проверяется при компиляции: недостающая строка-константа
  даст ошибку в menu_txt.cpp, недостающий txt-макрос - #error ниже.
*/
#if (INTERFACE == 0)
#include "lang/ru.h"
#elif (INTERFACE == 1)
#include "lang/en.h"
#elif (INTERFACE == 2)
#include "lang/translit.h"
#else
#error "Не правильный номер языка интерфейса"
#endif

// тексты, общие для всех языков (имена типов акб, единицы измерения)
#include "lang/common.h"

// проверка комплектности набора txt-макросов языкового файла
#if !defined(txt3) or !defined(txt4) or !defined(txt6) or !defined(txt9) or    \
    !defined(txt11) or !defined(txt111) or !defined(txt13) or                  \
    !defined(txt14) or !defined(txt15) or !defined(txt16) or                   \
    !defined(txt17) or !defined(txt18) or !defined(txt19) or                   \
    !defined(txt20) or !defined(txt21) or !defined(txt24) or                   \
    !defined(REGIMR_STR) or !defined(TXT_DEG) or !defined(TXT_DEG_AKB)
#error "В языковом файле не хватает txt-макросов (см. lang/en.h как образец)"
#endif

enum Menu_main {
  main_profil,        // 0
  main_akb_capacity,  // 1
  main_akb_type,      // 2
  main_akb_voltage,   // 3
  main_mode,          // 4
  main_settings,      // 5
  main_system,        // 6
#if (STATISTIC == 1)
  main_statistic,     // 7
#endif
#if (RESIST == 1)
  main_resist_akb,    // 8
#endif
};

// число элементов menuTxt: 7 базовых + статистика + сопротивление
#define MENUTXT_SIZE (7 + (STATISTIC == 1) + (RESIST == 1))
extern const char* const menuTxt[MENUTXT_SIZE] PROGMEM;

extern const char* const modeTxt[8] PROGMEM;

// номера пунктов меню Система (пункты выключенных опций скрываются из меню)
enum Sys_menu : uint8_t {
#if (KALIBROVKA > 0)
  SYS_CALIBR,   // калибровка
#endif
#if (SERVICE == 1)
  SYS_SERVICE,  // системные параметры
#endif
  SYS_RESET,    // сброс настроек
};

// число пунктов меню Система: сброс + калибровка и сист. параметры если включены
#define SYSTEMA_SIZE (1 + (KALIBROVKA > 0) + (SERVICE == 1))
extern const char* const systema[SYSTEMA_SIZE] PROGMEM;

// пункты меню настроек: 27 базовых + 2 буферного режима
#define SETTINGS_SIZE (27 + ((BUFFER) ? 2 : 0))
extern const char* const settings_charge[SETTINGS_SIZE] PROGMEM;

// пункты текущего режима: 6 базовых + Бранимир
#define REGIMS_TXT_SIZE (6 + ((BRRANIMIR) ? 1 : 0))
extern const char* const regims_txt[REGIMS_TXT_SIZE] PROGMEM;

// пункты сброса настроек
extern const char* const reset_txt[5] PROGMEM;

extern const char* const calibr[3] PROGMEM;

#if (DISPLAYy == 2)
// символы вывода режима работы - Предзаряд, Заряд, Качели, Дозаряд,
// Разряд, Кипение (Бурление), Ожидание (пауза)
extern const char regimr[] PROGMEM;
#endif

// число пунктов Меню - 0-9
#define POINTMENU (uint8_t)(sizeof(menuTxt) / sizeof(menuTxt[0]) - 1)

// число пунктов Режимов работы - 0-7
#define POINTMODE (uint8_t)(sizeof(modeTxt) / sizeof(modeTxt[0]) - 1)

// число пунктов Калибровок 0-2
#define POINTCALIBRS (uint8_t)(sizeof(calibr) / sizeof(calibr[0]) - 1)

// система 0-2
#define POINTSYSTEM (uint8_t)(sizeof(systema) / sizeof(systema[0]) - 1)

// число пунктов меню настроек
#define POINTSETTINGS (uint8_t)(sizeof(settings_charge) / sizeof(settings_charge[0]) - 1)

// число пунктов сброса настроек
#define POINTRESET (uint8_t)(sizeof(reset_txt) / sizeof(reset_txt[0]) - 1)
