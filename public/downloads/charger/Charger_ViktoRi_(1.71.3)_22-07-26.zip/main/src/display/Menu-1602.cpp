#include "../core/global.h"
#include "../core/Battery.h"
#include "Display.h"
#include "../hardware/INA226int.h"
#include "Menu.h"
#include "../core/Protections.h"
#include <EEPROM.h>

// список доступных режимов работы (в profil.Regim хранится номер из enum Modes)
const uint8_t modeList[] = {
    Modes::CHARGE,
    Modes::ADDCHARGE,
#if (DISCHAR == 1)
    Modes::DISCHARGE,
#endif
    Modes::STORAGE,
    Modes::ASYMMETRIC,
#if (DISCHAR == 1)
    Modes::KTCycle,
#endif
#if (BUFFER == 1)
    Modes::BUFER,
#endif
#if (BRRANIMIR)
    Modes::BRANIMIR,
#endif
};

#define MODELIST_SIZE (uint8_t)(sizeof(modeList) / sizeof(modeList[0]))

// шаг по списку доступных режимов
static uint8_t mode_step(uint8_t regim, int8_t x) {
  uint8_t i = 0;
  for (uint8_t n = 0; n < MODELIST_SIZE; n++) {
    if (modeList[n] == regim) {
      i = n;
      break;
    }
  }
  i = constrain_my(i, 0, MODELIST_SIZE - 1, x);
  return modeList[i];
}

// Меню версии 4.21 для дисплея LCD1602
void Menu1602(void) {
  if (bitRead(profil.flags, Pr_flags::ACTIVITI))
    return; // если флаг заряда установлен true то выйти иначе выполнять Menu
  regims = Regims::REGIM_OFF;
#if (TIME_LIGHT)
  disp.Light_high(); // включение подсветки
#endif
#if (FAN > 0)
  // автоматический режим кулера
  fan.ONonse(false);
#endif
  butt.tick = 0;
  eepSavedStruct();          // сохранить настройки
  uint8_t menu_level = 0;    // три уровня меню
  uint8_t point_main = 0;    // номер пункта главного меню
  uint8_t point_submenu = 0; // номер пунктов подменю
  bool printx = true;        // флаг вывода на дисплей
  // изменить пункт меню или заначение параметра на величину x
  int8_t x = 0;

  ina.start(); // старт замеров INA
  do {
    // цикл меню
    switch (menu_level) {
    // основное меню menu_level
    case 0:
      point_submenu = 0;
      // вывод меню
      if (printx) {
        printx = false;
        if (x)
          // линейное меню
          point_main = constrain_my(point_main, 0, POINTMENU + 1, x);
        // реализация кругового меню
        /*  point_main =
              (point_main == 0 and x < 0)
                  ? POINTMENU
                  : ((point_main == POINTMENU + 1 and x > 0) ? 0 : point_main +
           x); */
        lcd.clear();
        if (point_main <= POINTMENU) {
          disp.printFromPGM((int)(&menuTxt[point_main]));
          setCursory();
        }

        switch (point_main) {
        case Menu_main::main_profil:
          // профиль
          print_Capacity();
          Vout();                // *Pr:0 Pb CA/Ca   *
          lcd.print(vkr.profil); // *60Ah 12.60V(6)  *
          lcd.setCursor(5, 0);
          print_mode(TYPE_AKB); // вывод типа акб
#if (DISPLAYy == 4)
          lcd.setCursor(0, 2);
          print_mode(MODE); // режим работы
#endif
          break;

        case Menu_main::main_akb_capacity:
          print_Capacity(); // емкость акб
          break;

        case Menu_main::main_akb_type:
          print_mode(TYPE_AKB); // вывод типа акб
          break;

        case Menu_main::main_akb_voltage:
          Vout(); // напряжение
          break;

        case Menu_main::main_mode:
          print_mode(MODE); //  режим
          break;

#ifdef BP_vc
        case POINTMENU + 1:
          if (butt.tick == Butt::OKHELD)
            BP_vvcc(); // включить режим БП
          break;
#endif
        }
      }

      if (point_main <= POINTMENU) {
        if (butt.tick == Butt::OKCLICK) {
          menu_level = (point_main < 5) ? 2 : 1;
          point_submenu = 0;
          printx = true;
          SettPointToStart();
          break;
        }

        // удержание Пуск или Энкодера запускает заряд
        if (butt.tick == Butt::OKHELD) {
          // запустить работу режима, выйти из цикла меню
          bitSet(profil.flags, Pr_flags::ACTIVITI);
          printx = true;
        }
      }
      break; // ...основное меню

    case 1:
      // menu_level 1 - подменю
      switch (point_main) {
      case Menu_main::main_profil:
        eepSavedStruct(); // сохранить настройки
        menu_level = 0;
        printx = true;
        break;
      case Menu_main::main_akb_capacity:
        // емкость акб
      case Menu_main::main_akb_type:
        // тип  акб
      case Menu_main::main_akb_voltage:
        // напряжение акб
        calcProfile();
      case Menu_main::main_mode:
        menu_level = 0;
        printx = true;
        break;
      case Menu_main::main_settings:
        // настройки
        if (printx) {
          printx = false;
          lcd.clear();
          Settings_pre(x, false);
        }

        switch (butt.tick) {
        case Butt::STOPCLICK:
        case Butt::OKHELD:
          menu_level = 0;
          fl_round = false;
          printx = true;
          eepSavedStruct(); // сохранить настройки
          lcd.clear();
          print_mode(SETTING); // "Settings"
          lcd.print(F(txt3));  // saved
          Delay(1000);
          break;
        case Butt::OKCLICK:
          menu_level = 2;
          printx = true;
          break;
        }
        break;

      case Menu_main::main_system:
        // система...
        if (printx) {
          printx = false;
          lcd.clear();
          if (x)
            point_submenu = constrain_my(point_submenu, 0, POINTSYSTEM, x);
          disp.printFromPGM((int)(&systema[point_submenu]));
        }

        switch (butt.tick) {
        case Butt::STOPCLICK:
        case Butt::OKHELD:
          menu_level = 0;
          point_submenu = 0;
          printx = true;
          break;
        case Butt::OKCLICK:
          switch (point_submenu) {
#if (KALIBROVKA > 0)
          case Sys_menu::SYS_CALIBR:
            // калибровка
            menu_level = 2;
            point_submenu = 0;
            break;
#endif

#if (SERVICE == 1)
          case Sys_menu::SYS_SERVICE:
            // системные пaраметры
            serviceparam(); // изменение системныx параметров
            lcd.clear();
            menu_level = 1;
            break;
#endif

          case Sys_menu::SYS_RESET:
            // сброс настроек
            Reset_settings(0);
            lcd.clear();
            menu_level = 1;
            break;
          }
          printx = true;
          break;
        }
        break;

#if (STATISTIC == 1)
      case Menu_main::main_statistic:
        // статистика
        if (printx) {
          printx = false;
          if (x)
            point_submenu =
                constrain_my(point_submenu, 0, (uint8_t)3 + eeGetKtcRounds(), x);
          lcd.clear();
          Statistics_point(point_submenu); // вывод статистики
        }
        switch (butt.tick) {
        case Butt::OKCLICK:
        case Butt::STOPCLICK:
          menu_level = 0;
          point_submenu = 0;
          printx = true;
          break;
        }
        break;
#endif

#if (RESIST == 1)
      case Menu_main::main_resist_akb:
        // измерение сопротивления
        Resist();
        menu_level = 0;
        printx = true;
        break;
#endif
      }
      break;

    case 2:
      // menu_level -  изменение параметров
      if (printx) {
        printx = false;
        setCursory();

        if (point_main > 0 and point_main < 5)
          lcd.write('<');

        switch (point_main) {
        case Menu_main::main_profil:
          // выбор профиля
          vkr.profil = constrain_my(vkr.profil, 0, PROFIL, x);
          // считать структуру profil
          eeGet_profil();
          print_Capacity();
          Vout();
          lcd.write('<'); // *Pr:<0>Pb CA/Ca  *
          lcd.print(vkr.profil);
          lcd.print('>');
          print_mode(TYPE_AKB); // вывод типа акб
          ClearStr(4);          // очистить поле
          break;

        case Menu_main::main_akb_capacity:
          // емкость
          // 255 максимальная емкость акб Ач
          profil.akb.capacity = constrain_my(profil.akb.capacity, 1, 255, x);
          lcd.print(profil.akb.capacity);
          break;

        case Menu_main::main_akb_type:
          // выбор типа аккумулятора
          profil.akb.type =
              constrain_my(profil.akb.type, 0, (uint8_t)AKB_COUNT, x);
          print_mode(TYPE_AKB); // вывод типа акб
          break;

        case Menu_main::main_akb_voltage:
          // напряжение, количество ячеек
          // 26 - максимальное количество ячеек акб
          profil.akb.cell = constrain_my(profil.akb.cell, 1, 26, x);
          print_mode(VOLTAGE); // 12.6V
          lcd.write('(');
          lcd.print(profil.akb.cell);
          lcd.write(')');
          break;

        case Menu_main::main_mode:
          // выбор режима
          profil.Regim = mode_step(profil.Regim, x);
          print_mode(MODE);
          break;

        case Menu_main::main_settings:
          // настройки
          // изменение пунктов настроек
          Settings_pre(x, true);
          break;

        case Menu_main::main_system:
          // система
          lcd.clear();
#if (DISPLAYy == 2)
          if (x)
            point_submenu = constrain_my(point_submenu, 0, POINTCALIBRS, x);
          disp.printFromPGM((int)(&calibr[point_submenu]));
          ClearStr(6);
#endif

#if (DISPLAYy == 4)
          // вывести все пункты
          for (uint8_t i = 0; i <= POINTCALIBRS; i++) {
            lcd.setCursor(1, i);
            disp.printFromPGM((int)(&calibr[i]));
          }
          if (x)
            point_submenu = constrain_my(point_submenu, 0, POINTCALIBRS, x);
          // вывести указатель на пункт
          lcd.setCursor(0, point_submenu);
          lcd.print('>');
#endif

          switch (butt.tick) {
          case Butt::STOPCLICK:
          case Butt::OKHELD:
            menu_level = 1;
            printx = true;
            point_submenu = 0;
            break;
          case Butt::OKCLICK:
#if (KALIBROVKA > 0)
            Korrect(point_submenu);
#endif
            menu_level = 1;
            printx = true;
            point_submenu = 0;
            break;
          }
          break;
        }

        if (point_main > 0 and point_main < 5) {
          lcd.print('>');
          ClearStr(10); // очистить поле
        }
      }

      if (butt.tick == Butt::OKCLICK or butt.tick == Butt::STOPCLICK) {
        menu_level = 1;
        printx = true;
      }
      break; // изменение параметров menu_level = 2
    }
    // -- меню
    x = 0;
    // ожидание действий пользователя
    do {
      sensor_survey();
      if (get_second()) {
        // если прошла секунда

        // вывод на дисплей напряжения, тока, температуры раз в одну секунду
        if (point_main == POINTMENU + 1) {
          // *24.12V 25C 20C   *
          // *12.652V 0.061A  *
#if (VOLTIN == 1)
          // напряжение от БП
          setCursorx();
          print_volt(getPower());
#endif
#if (SENSTEMP1 and SENSTEMP2 and POWER != 1)
          print_tr_split(); // температура транзистора и акб одной строкой
#else
#if (SENSTEMP1 or SENSTEMP2)
          lcd.setCursor(7, 0);
          print_tr(); // температура транзистора или акб
#endif
#if (POWER == 1)
          lcd.setCursor(DISPLAYx - 4, 0);
          lcd.print(relay_timer); // вывод времени до отключения ЗУ
          print_space();
#endif
#endif
          setCursory();
          // print_volt_current(ina.voltsec, ina.ampersec, 3);// *12.361V
          // -0.253A *
          print_volt_current(ina.volt_aver, ina.curr_aver, 3);
        }
#if (TIME_LIGHT)
        disp.Light_power();
#endif
      }
      // --- выполнить раз в секунду

    } while (!butt.tick and !printx);
    // --- ожидание действий пользователя

    if (butt.tick <= 1)
      x = butt.tick;
    printx = true;
  } while (BitIsClear(profil.flags, Pr_flags::ACTIVITI)); // цикл меню

  switch (profil.Regim) {
  case Modes::CHARGE:
#if (BRRANIMIR)
  case Modes::BRANIMIR:
#endif
    Res_mem_char();
    if (BitIsClear(profil.flags, Pr_flags::CHARGE_ADD)) {
      break;
    }
  case Modes::ADDCHARGE:
    Res_mem_addchar();
    break;
  case Modes::ASYMMETRIC:
    Res_mem_asym();
    break;
  case Modes::DISCHARGE:
    Res_mem_dischar();
    break;
  case Modes::KTCycle:
    Res_ktc();
    eeSetKtcRounds(profil.round);
    break;
  }

  regim_end = Reason::begin;
  eeSetModeNumber(1);       // номер операции
  eeSetRound(profil.round); // количество циклов

  eepSavedStruct();

  // сохранить в EEPROM выбранный режим работы
  eeSetMode();
}
