#include "DCDC.h"
//#include "../core/User_Setup_Loader.h"
#include "INA226int.h"
#include "../core/global.h"


enum DCDC_FLAGS : uint8_t {
  Pause,  // пауза
  Smooth, // плавный пуск
  Mode,   // режим (заряд/ разряд)
  stabil, // стабилизация
};

// установить частоту работы ШИМ
void DCDC::Freq(const uint8_t frq) {
  if (frq <= FREQTABLE_SIZE) {
    uint8_t val = pgm_read_byte(&FreqTable[frq]);
    TCCR2B = (val >> 4);   // старший байт
    TCCR2A = (val & 0x0F); // младший байт
  }
}

// рестарт работы DCDC
void DCDC::restart(void) {
   _cur_max = CURRMAXINT;
  _err_pred = 0;
  _Integral = 0;
  _cur_charge = 0;
  _pwm = 0;
  // флаги:
  // 0 - пауза
  // 1 - плавный пуск
  // 2 - режим (заряд/ разряд)
  // 3 - стабилизация
  _flags = 0b00001011;  
  _time_sec = 300;
}

// режим работы DCDC (заряд/разряд)
void DCDC::start(bool mods) {
  DCDC::Freq(eepGetService_num(mods ? FREQCHARGE : FREQDISCHAR));
  DCDC::restart();
  // установить режим работы заряд/разряд
  bitWrite(_flags, DCDC_FLAGS::Mode, mods);  
}

// плавный пуск - вызывать после start() и перед begin()
void DCDC::Smooth_off(bool x) { bitWrite(_flags, DCDC_FLAGS::Smooth, x); }

// задать максимальные значения напряжения и тока заряда
void DCDC::begin(uint16_t volt_charge, int16_t cur_charge) {
  _volt_charge = volt_charge;
  _cur_charge_max = cur_charge;
  if (cur_charge <= 800)
    _cur_charge = _cur_charge_max;
  else
    _cur_charge = bitRead(_flags, DCDC_FLAGS::Smooth) ? _cur_charge_max >> 3
                                                      : _cur_charge_max;
}

// величина ошибки
int16_t DCDC::Err(void) {
  // величина ошибки по напряжению
  int16_t volt_err = bitRead(_flags, DCDC_FLAGS::Mode)
                         ? difference(_volt_charge, ina.voltms)
                         : difference(ina.voltms, _volt_charge);
  // величина ошибки по току
  int16_t amp_err = _cur_charge - abs(ina.amperms);
  // регулируем напряжение или ток
  return (volt_err < amp_err) ? volt_err : amp_err;
}

// регулировка напряжения и тока заряда
void DCDC::Control(void) {
  if (bitRead(_flags, DCDC_FLAGS::Pause) and
      bitRead(_flags, DCDC_FLAGS::stabil)) {
#if (VOLTIN == 1)
    // если включен заряд а напряжения от БП нет
    if (bitRead(_flags, DCDC_FLAGS::Mode) and
        !sysFlagGetBits(FlagsName::POWERON))
      return;
#endif
    if (abs(ina.amperms) > _cur_max and _pwm > 0)
      _pwm--;
    else {

      if (--_time_sec == 0) {
        _time_sec = 300;
        // плавный пуск - плавное увеличение тока заряда/разряда
        if (bitRead(_flags, DCDC_FLAGS::Smooth)) {
          _cur_charge += (_cur_charge_max >> 3);
          _cur_charge = constrain(_cur_charge, 0, _cur_charge_max);
          // отключить плавный пуск
          if (_cur_charge == _cur_charge_max)
            bitClear(_flags, DCDC_FLAGS::Smooth);
        }
#if (SENSTEMP1 > 0 and GUARDTEMP > 0)
        else {
          // если превышена температура то уменьшаем ток иначе увеличиваем
          _cur_charge += (sysFlagGetBits(FlagsName::TR_Q1_ERR) ? -10 : 10);
          _cur_charge =
              constrain(_cur_charge, _cur_charge_max >> 1, _cur_charge_max);
        }
#endif
      }

      int16_t err = Err();
      if (err == 0)
        return;

      // ПИ-регулятор в целых числах, формат Q16: 66/65536 ≈ 0.001
      int32_t P = (int32_t)err * 66;
      _Integral += P;
      // ограничение сверху - защита int32 от переполнения
      if (_Integral > ((int32_t)1 << 30))
        _Integral = ((int32_t)1 << 30);
      if (_Integral > 0) {

        P += _Integral;
        P += (int32_t)(_err_pred - err) * 33; // 33/65536 ≈ 0.0005
        _err_pred = err;

        // округление и переход из Q16 в целое
        int32_t t = (P + 32768) >> 16;
#if (MCP4725DAC)
        _pwm = bitRead(_flags, DCDC_FLAGS::Mode)
                   ? (uint16_t)constrain(t, (int32_t)0, (int32_t)4095)
                   : (uint16_t)constrain(
                         (int32_t)((_Integral + 32768) >> 16), (int32_t)0,
                         (int32_t)255);
#else
        _pwm = (uint8_t)constrain(t, (int32_t)0, (int32_t)255);
#endif
      } else {
        _Integral = 0;
        _pwm = 0;
        _err_pred = 0;
      }
    }
#if (MCP4725DAC)
    bitRead(_flags, DCDC_FLAGS::Mode) ? dac.setVoltage(_pwm)
                                      : analogWrite_my(PWMDCH_PIN, _pwm);
#else
    analogWrite_my((bitRead(_flags, DCDC_FLAGS::Mode) ? PWMCH_PIN : PWMDCH_PIN),
                   _pwm);
#endif
  }
}

void DCDC::pause(bool x) {
  bitWrite(_flags, DCDC_FLAGS::Pause, x);
#if (MCP4725DAC)
  bitRead(_flags, Mode)
      ? dac.setVoltage(x ? _pwm : 0)
      : analogWrite_my(PWMDCH_PIN, (x ? _pwm : 0)); // отключаем заряд/разряд
#else
  // отключить/включить заряд/разряд
  analogWrite_my((bitRead(_flags, DCDC_FLAGS::Mode) ? PWMCH_PIN : PWMDCH_PIN),
                 (x ? _pwm : 0));
#endif
}

// отключить заряд, разряд.
void DCDC::Off(void) {
  pause(LOW);
  // включить плавный пуск
  Smooth_off(HIGH);
  _Integral = 0;
  _err_pred = 0;
}

// стабилизация
void DCDC::stabilization(bool x) { bitWrite(_flags, DCDC_FLAGS::stabil, x); }

void DCDC::setVolt_charge(uint16_t v) { _volt_charge = v; }

void DCDC::setCur_charge(int16_t v) {
  _cur_charge_max = v;
  _cur_charge = v;
}

uint16_t DCDC::getVolt_charge(void) { return _volt_charge; }

int16_t DCDC::getCur_charge(void) { return _cur_charge_max; }

uint16_t DCDC::getTok(void) { return _pwm; }

bool DCDC::get_pause(void) { return bitRead(_flags, DCDC_FLAGS::Pause); }

bool DCDC::get_stabilization(void) {
  return bitRead(_flags, DCDC_FLAGS::stabil);
}

DCDC dcdc;