#pragma once

#include <Arduino.h>

/*======== АЦП ========*/

void ADC_begin(void);

/*======== замер напряжения БП ========*/

void Power_begin(void);

void Power_sample(void);

uint16_t getPower(void);

void Power_check(void);

/*======== Температура транзистора и акб ========*/

// Температура транзистора
extern int8_t temp_Q1;
// Температура аккумулятора
extern int8_t temp_akb;
// Статус аккумулятора
// extern uint8_t temp_status;
enum sens_temp : uint8_t { q1, akb };
// вернуть статус датчика температуры
bool getTempStatus(sens_temp num);

/*======== Датчики температуры DS18B20 ========*/
void temp_Q1_begin(void);

void temp_akb_begin(void);

/*======== Чтение данных с датчиков температуры NTC (вызывать совместно с INA и
 * dcdc) ========*/

// считать данные с датчика NTC транзистора Q1
void ntc_Q1_sample(void);

// считать данные с датчика NTC транзистора акб
void ntc_akb_sample(void);

/*======== Расчет (NTC), считывание (DS18B20) реальной температуры ========*/

// чтение температуры транзистора, вызывать раз в секунду
void temp_Q1_compute(void);

// чтение температуры акб, вызывать раз в секунду
void temp_akb_compute(void);

