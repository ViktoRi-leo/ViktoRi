#pragma once
#include <Arduino.h>
#include "../core/User_Setup_Loader.h"

#define DCDC_CHARGE true      // заряд
#define DCDC_DISCHARGE false  // разряд

/**
 * @brief Таблица настроек частоты ШИМ для пинов D3 и D11
 * Формат: старший байт - TCCR2B, младший байт - TCCR2A
 */
const uint8_t PROGMEM FreqTable[] = {
    0b00000101 << 4 | 0b00000001, // 0: 245 Гц   - x128, phase correct
    0b00000100 << 4 | 0b00000001, // 1: 490 Гц   - x64,  phase correct
    0b00000011 << 4 | 0b00000001, // 2: 980 Гц   - x32,  phase correct
    0b00000011 << 4 | 0b00000011, // 3: 2 кГц    - x32,  fast pwm
    0b00000010 << 4 | 0b00000001, // 4: 4 кГц    - x8,   phase correct
    0b00000010 << 4 | 0b00000011, // 5: 8 кГц    - x8,   fast pwm
    0b00000001 << 4 | 0b00000001, // 6: 31.4 кГц - x1,   phase correct
    0b00000001 << 4 | 0b00000011  // 7: 62.5 кГц - x1,   fast pwm
};

// количество элементов в таблице FreqTable
#define FREQTABLE_SIZE (uint8_t)(sizeof(FreqTable) / sizeof(FreqTable[0]) - 1)

// класс управления DC-DC модулем
class DCDC {
public:
  // DCDC(void){};

  // установить частоту работы ШИМ
  void Freq(const uint8_t frq);

  // рестарт работы DCDC
  void restart(void);

  // режим работы DCDC (заряд/разряд)
  void start(bool mods);

  // отключить плавный пуск - вызывать после start() и перед begin()
  void Smooth_off(bool x);

  // задать максимальные значения напряжения и тока заряда
  void begin(uint16_t volt_charge, int16_t cur_charge);

  // величина ошибки
  int16_t Err(void);

  // регулировка напряжения и тока заряда
  void Control(void);
  
  // пауза
  void pause(bool x);

  // отключить заряд, разряд
  void Off(void);

  // стабилизация
  void stabilization(bool x);

  // напряжение
  void setVolt_charge(uint16_t v);

  // ток
  void setCur_charge(int16_t v);

  // вернуть напряжение
  uint16_t getVolt_charge(void);
  
  // вернуть ток
  int16_t getCur_charge(void);
  
  // вернуть ЩИМ
  uint16_t getTok(void);
  // вернуть состояние паузы
  bool get_pause(void);
  // вернуть состояние стабилизации
  bool get_stabilization(void);

private:
  // список членов для использования внутри класса
  uint16_t _volt_charge;    // напряжение заряда
  int16_t _cur_max;         // предельный ток зарядника
  int16_t _cur_charge_max;  // максимальный ток заряда
  int16_t _cur_charge;      // текущий ток заряда
#if (MCP4725DAC)
  uint16_t _pwm = 0;         // значение ШИМ
#else
  uint8_t _pwm = 0;         // значение ШИМ
#endif
  

  int16_t _err_pred;
  int32_t _Integral; // интегральная составляющая, формат Q16
  uint16_t _time_sec;

  uint8_t _flags = 0b00000000;  // флаги  
};

extern DCDC dcdc;