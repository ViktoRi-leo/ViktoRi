#include "cooler.h"
#include "sensors.h"
#include "INA226int.h"
#include "../core/global.h"
#include <GyverIO.h>

/*======== Кулер ========*/

// класс управления кулером
// инициализация
void Cooler::begin(void) {
  // Пины D9 и D10 - 30 Гц для вентилятора
  // Настройка таймера 1 для ШИМ
  TCCR1A = 0b00000001; // 8bit
  TCCR1B = 0b00000101; // x1024 phase correct
  _kul = 0;            // значение ШИМ кулера
}

void Cooler::ONonse(bool x) {
  onse = x;
  digitalWrite_speed(PWMKUL_PIN, x);
}

void Cooler::control(void) {
  if (onse)
    return;

  int16_t amp = abs(ina.ampersec); // чтение тока
  switch ((uint8_t)eepGetService_flag(Serviceflags::FLAG_FANMODE)) {
  case 0:
    // управление кулером ШИМ
    if (temp_Q1 >= (uint8_t)FAN_DEG_MAX)
      _kul = 255;
    else
      _kul = (getTempStatus(sens_temp::q1))
                 ? ((temp_Q1 >= (int8_t)FAN_DEG_ON)
                        ? (_kul ? map_my(temp_Q1, FAN_DEG_OFF, FAN_DEG_MAX, 70,
                                         255)
                                : 150)
                        : _kul)
                 : ((amp >= (int16_t)FAN_CUR_ON)
                        ? (_kul ? map_my(amp, FAN_CUR_OFF, FAN_CUR_MAX, 70, 255)
                                : (uint8_t)150)
                        : _kul);
    // если кулер включен
    if (_kul) {
      _kul = (getTempStatus(sens_temp::q1))
                 ? ((temp_Q1 <= (uint8_t)FAN_DEG_OFF) ? 0 : _kul)
                 : ((amp <= (int16_t)FAN_CUR_OFF) ? 0 : _kul);
    }
    analogWrite_my(PWMKUL_PIN, _kul);
    break;

  case 1:
    // управление кулером вкл/откл
    // если кулер включен
    if (_kul) {
      _kul = (getTempStatus(sens_temp::q1))
                 ? (temp_Q1 <= (uint8_t)FAN_DEG_OFF ? false : _kul)
                 : ((amp <= (int16_t)FAN_CUR_OFF) ? false : _kul);
    } else {
      // если кулер отключен
      _kul = (getTempStatus(sens_temp::q1))
                 ? (temp_Q1 >= (uint8_t)FAN_DEG_ON ? true : _kul)
                 : ((amp >= (int16_t)FAN_CUR_ON) ? true : _kul);
    }
    gio::write(PWMKUL_PIN, _kul);
    break;
  }
}

Cooler fan;

