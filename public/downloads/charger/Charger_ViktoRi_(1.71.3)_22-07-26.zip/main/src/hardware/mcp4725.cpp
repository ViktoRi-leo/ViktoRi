#include "mcp4725.h"
#include "../core/User_Setup_Loader.h"

#if (MCP4725DAC)
/*======== ЦАП MCP4725 ========*/
// библиотека для работы с ЦАП MCP4725
// просто отправляет значение 0-4095 напряжения в MCP4725
#include <microWire.h>

// Запись 16-ти битного регистра MCP4725
void MCP4725::setVoltage(uint16_t data) {
  // Начинаем передачу
  Wire.beginTransmission(_address);
  // передаем контрольный байт (010-Sets in Write mode)
  Wire.write(0b01000000);
  // Upper data bits (D11.D10.D9.D8.D7.D6.D5.D4)Отправляем старший байт
  Wire.write((uint8_t)(data >> 4));
  // Lower data bits (D3.D2.D1.D0.x.x.x.x));
  // Отправляем младший байт
  // Wire.write((uint8_t)((data % 12) << 4));
  Wire.write((uint8_t)((data & 0x0F) << 4));
  Wire.endTransmission(); // Заканчиваем передачу
}

// Проверка присутствия
bool MCP4725::testConnection(void) {
  Wire.beginTransmission(_address);     // Начинаем передачу
  return (bool)!Wire.endTransmission(); // Сразу заканчиваем
}

MCP4725 dac = MCP4725(ADDR4725);
#endif