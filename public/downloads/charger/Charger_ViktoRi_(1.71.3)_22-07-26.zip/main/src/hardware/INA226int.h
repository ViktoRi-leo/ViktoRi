#pragma once
#include <Arduino.h>

/* Public-определения (константы) */
#define INA226_VBUS true     // Канал АЦП, измеряющий напряжение шины (0-36в)
#define INA226_VSHUNT false  // Канал АЦП, измеряющий напряжение на шунте

// Время выборки (накопления сигнала для оцифровки)
#define INA226_CONV_140US 0b000
#define INA226_CONV_204US 0b001
#define INA226_CONV_332US 0b010
#define INA226_CONV_588US 0b011
#define INA226_CONV_1100US 0b100
#define INA226_CONV_2116US 0b101
#define INA226_CONV_4156US 0b110
#define INA226_CONV_8244US 0b111

// Встроенное усреднение (пропорционально увеличивает время оцифровки)
#define INA226_AVG_X1 0b000
#define INA226_AVG_X4 0b001
#define INA226_AVG_X16 0b010
#define INA226_AVG_X64 0b011
#define INA226_AVG_X128 0b100
#define INA226_AVG_X256 0b101
#define INA226_AVG_X512 0b110
#define INA226_AVG_X1024 0b111

/* Private-определения (адреса) */
#define INA226_CFG_REG_ADDR 0x00
#define INA226_SHUNT_REG_ADDR 0x01
#define INA226_VBUS_REG_ADDR 0x02
#define INA226_POWER_REG_ADDR 0x03
#define INA226_CUR_REG_ADDR 0x04
#define INA226_CAL_REG_ADDR 0x05

#define INA226_REG_MASKENABLE 0x06
#define INA226_REG_ALERTLIMIT 0x07

#define INA226_BIT_AFF 0x0010  // (бит 4)  // Чтение регистра срабатывания Alert

#define INA226_BIT_SOL (1 << 15)  //0x8000  // (бит 15)Shunt Voltage Over-Voltage. Установка в 1 этого бита конфигурирует установку ножки Alert, если измеренное напряжение шунта превысило значение, запрограммированное в Alert Limit Register.
//#define INA226_BIT_SUL        0x4000  // (бит 14)Shunt Voltage Under-Voltage. Установка в 1 этого бита конфигурирует установку ножки Alert, если измеренное напряжение шунта упало ниже значения, запрограммированного в Alert Limit Register.
//#define INA226_BIT_BOL        0x2000  // (бит 13) Bus Voltage Over-Voltage. Установка в 1 этого бита конфигурирует установку ножки Alert, если измеренное напряжение VBUS превысило значение, запрограммированное в Alert Limit Register.
//#define INA226_BIT_BUL        0x1000  // (бит 12)Bus Voltage Under-Voltage. Установка в 1 этого бита конфигурирует установку ножки Alert, если измеренное напряжение VBUS упало ниже значения, запрограммированного в Alert Limit Register.
//#define INA226_BIT_POL        0x0800  // (бит 11)Power Over-Limit. Установка в 1 этого бита конфигурирует установку ножки Alert, если вычисленная мощность после измерения напряжения VBUS превысило значение, запрограммированное в Alert Limit Register.
//#define INA226_BIT_CNVR       0x0400  // (бит 10)Conversion Ready. Установка в 1 этого бита конфигурирует установку ножки Alert, когда установится Conversion Ready Flag (бит 3), показывая тем самым готовность к следующему преобразованию.
//#define INA226_BIT_AFF        0x0010  // (бит 4)Alert Function Flag. Хотя в любой момент времени ножкой Alert может отслеживаться только одна функция Alert, ножкой Alert также может отслеживаться и флаг Conversion Ready. Чтение Alert Function Flag после события alert дает возможность пользователю определить, была ли источником этого события функция Alert.
//#define INA226_BIT_CVRF       0x0008  // (бит 3)Conversion Ready Flag, чтобы помочь координировать однократные преобразования (или triggered-преобразования). Бит Conversion Ready Flag установится после завершения всех преобразований, усреднений и умножений.
//#define INA226_BIT_OVF        0x0004  // (бит 2)Math Overflow Flag. Этот бит установится в 1, если арифметическая операция привела к ошибке переполнения. Это показывает, что данные тока и мощности могут быть недостоверными.
//#define INA226_BIT_APOL       0x0002  // (бит 1)Alert Polarity bit. Этот бит устанавливает полярность активации ножки Alert. 1 = инвертированная полярность (открытый коллектор с активной лог. 1). 0 = нормальная полярность (открытый коллектор с активным лог. 0, настройка по умолчанию).
//#define INA226_BIT_LEN        0x0001  // (бит 0)Alert Latch Enable - Конфигурирует разрешение защелкивания функции ножки Alert и бит Alert Flag. 1 = защелкивание разрешено (режим Latch). 0 = прозрачный режим (режим Transparent, настройка по умолчанию).

/*
время выборки (накопления сигнала для оцифровки)
INA226_CONV_140US // 140 мкс
INA226_CONV_204US // 204 мкс
INA226_CONV_332US // 332 мкс
INA226_CONV_588US // 588 мкс
INA226_CONV_1100US // 1100 мкс
INA226_CONV_2116US // 2116 мкс
INA226_CONV_4156US // 4156 мкс
INA226_CONV_8244US // 8244 мкс
*/


class INA226 {
public:
  // INA226(void){}

  // Инициализация и проверка
  bool begin(void);

  // Установка встроенного усреднения выборок
  void setAveraging(uint8_t avg);

  // Установка разрешения для выбранного канала
  void setSampleTime(bool ch, uint8_t mode);

  // Чтение напряжения, mV
  uint16_t getVoltage(void);

  // Чтение тока, mA
  int16_t getCurrent(void);

  // возвращает милливатты
  int32_t getsPower(void);

  // Чтение регистра срабатывания Alert
  bool isAlert(void);

  //********* вычисление среднего ***********
  uint16_t voltms = 0;     // реальное значение
  int16_t amperms = 0;     // реальное значение
  uint16_t voltsec = 0;    // усредненное значение
  int16_t ampersec = 0;    // усредненное значение
  uint16_t volt_aver = 0;  // еще более усредненное значение
  int16_t curr_aver = 0;   // еще более усредненное значение

  void start(void);

  int32_t average(int32_t aver, int32_t val);

  void sample(void);

  // преобразование промежуточных средних значений тока и напряжения в реальные значения
  void calc(void);

private:
  const uint8_t _iic_address = 0x40;  // Адрес на шине I2c
  volatile int16_t _current_lsb_int;  // LSB для тока

  /********* вычисление среднего **********/
  int32_t _vs : 24;
  int32_t _as : 24;
  // длинные средние в формате Q8 (значение * 256)
  int32_t _as_aver;
  int32_t _vs_aver;
  //uint8_t _se_aver;

  // Запись 16-ти битного регистра INA226
  void writeRegister(uint8_t address, uint16_t data);

  // Чтение 16-ти битного регистра INA226
  uint16_t readRegister(uint8_t address);

  // Проверка присутствия
  bool testConnection(void);
};
extern INA226 ina;
