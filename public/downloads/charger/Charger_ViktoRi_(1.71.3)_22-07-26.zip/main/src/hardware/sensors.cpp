#include "sensors.h"
#include "INA226int.h"
#include "../core/global.h"
#include <GyverIO.h>

/*======== АЦП ========*/

// разрядность АЦП (1024 по умолчанию)
// #define BITRATE 1024
#if defined(__LGT8FX8P__)
#define BITRATE 4096
#endif

#include <ADCaverage.h>

void ADC_begin(void) {
  // настройка АЦП
  // DIVIDER 64  // делитель частоты АЦП (2, 4, 8, 16, 32, 64, 128),
  // Выбрать источник опорного напряжения АЦП (ADC_1V1, ADC_AREF, ADC_VCC)
  ADC_init(DIVIDER, ADC_VCC);
}

#if (VOLTIN == 1)
// замер напряжения БП
VoltRead adc_v(POWER_ADC_PIN, DIV_R1, DIV_R2);
// максимальное напряжение от БП
uint16_t _vmax;

void Power_begin(void) {
  // Максимально допустимое напряжение от БП
  _vmax = (uint16_t)eepGetService_num(POWERMAX) * 1000;
}

// замер напряжения БП
void Power_sample(void) {
  // считываем данные с АЦП с накоплением и усреднением
  adc_v.sample();
}

uint16_t getPower(void) { return adc_v.volt; }

// корректировка напряжения БП
void Power_korrect(void) {
#if defined(__LGT8FX8P__)
  if (vkr.Vref != 1000) {
    DSC_MUL((uint16_t)adc_v.volt, (uint16_t)vkr.Vref); // умножить
    DA_DIV((uint16_t)1000);                            // разделить на 1000
    adc_v.volt = DA_get_int();
  }
#else
  if (vkr.Vref != 1000)
    adc_v.volt = (uint16_t)((uint32_t)adc_v.volt * vkr.Vref / 1000);
#endif
}

// проверить напряжение БП на наличие и на превышение
void Power_check(void) {
  static uint8_t _k = 0;
  // рассчитать среднее напряжение БП  20 мкс
  adc_v.compute();
#ifdef VKORRECT
  // корректировка напряжения БП
  Power_korrect();
#endif
  // если есть питание от БП (если напряжение от БП превышает напряжение на АКБ)
  if ((adc_v.volt > ina.voltsec + 1000))
    sysFlagSetBits(FlagsName::POWERON);
  else
    sysFlagClearBits(FlagsName::POWERON);

  if (adc_v.volt > _vmax) {
    // если напряжение превысит максимальное проводим 4 проверок
    if (++_k > 3) {
      _k = 0;
      // Напряжение от БП превышено
      sysFlagSetBits(FlagsName::POWERHIGH);
    }
  } else {
    _k = 0;
    // Напряжение от БП в норме
    sysFlagClearBits(FlagsName::POWERHIGH);
  }

#if (POWER == 2)
  // индикатор включения БП в сеть
  gio::write(POWER_PIN, sysFlagGetBits(FlagsName::POWERON));
#endif
}

#endif

/*======== Температура транзистора и акб ========*/

// Температура транзистора
int8_t temp_Q1 = 0;
// Температура аккумулятора
int8_t temp_akb = 0;
// Статус аккумулятора
uint8_t temp_status = 0b00000000;
// вернуть статус датчика температуры
bool getTempStatus(sens_temp num) { return bitRead(temp_status, num); }

/*======== Датчики температуры DS18B20 ========*/

// Библиотека датчика температуры DS18B20.
#include <microDS18B20.h>

#if (SENSTEMP1 == 1)

#ifdef DS18B20_PIN
// Уникальные адреса датчиков - считать можно в примере address_read
uint8_t ds_Q1_addr[] = DS_Q1_ADDR;

// Создаем термометр с адресацией
MicroDS18B20<DS18B20_PIN, ds_Q1_addr> tr_Q1;
#else
// датчик температуры силового транзистора на отдельном пине
MicroDS18B20<Q1_DS18_PIN> tr_Q1;
#endif

void temp_Q1_begin(void) {
  // датчик температуры DS18B20
  if (tr_Q1.online()) {
    // Установить разрешение термометра 9-12 бит,
    // разрешающей способность - 0,5 (1/2) °C, 0,25 (1/4) °C,
    // 0,125 (1/8) °C и 0,0625 (1/16) °C
    tr_Q1.setResolution(9);
    // Запросить новое преобразование температуры
    tr_Q1.requestTemp();
    bitSet(temp_status, q1);
  } else {
    temp_Q1 = (int8_t)(-127); // значение при отключенном датчике
    bitClear(temp_status, q1);
  }
}

// чтение температуры транзистора, вызывать раз в секунду
void temp_Q1_compute(void) {
  if (getTempStatus(sens_temp::q1)) {
    if (tr_Q1.readTemp()) {
      temp_Q1 = tr_Q1.getTempInt();
      tr_Q1.requestTemp(); // Запросить новое преобразование температуры
    }

// если подключен датчик температуры и разрешено уменьшать ток при превышении
// температуры транзистора
#if (GUARDTEMP > 0)
    // если превышена температура
    if (temp_Q1 > eepGetService_num(TEMPCUR)) {
      sysFlagSetBits(FlagsName::TR_Q1_ERR);
      // температура Q1 снизилась на 5 гр.
    } else if (sysFlagGetBits(FlagsName::TR_Q1_ERR) and
               temp_Q1 < eepGetService_num(TEMPCUR) - 5) {
      sysFlagClearBits(FlagsName::TR_Q1_ERR);
    }
#endif
  } else {
    temp_Q1_begin();
  }
}
#endif

#if (SENSTEMP2 == 1)
#ifdef DS18B20_PIN
// Уникальные адреса датчиков - считать можно в примере address_read
uint8_t ds_akb_addr[] = DS_AKB_ADDR;

// Создаем термометр с адресацией
MicroDS18B20<DS18B20_PIN, ds_akb_addr> tr_akb;
#else
// датчик температуры аккумулятора на отдельном пине
MicroDS18B20<AKB_DS18_PIN> tr_akb;
#endif

void temp_akb_begin(void) {
  // датчик температуры DS18B20
  if (tr_akb.online()) {
    // Установить разрешение термометра 9-12 бит,
    // разрешающей способность - 0,5 (1/2) °C, 0,25 (1/4) °C,
    // 0,125 (1/8) °C и 0,0625 (1/16) °C
    tr_akb.setResolution(9);
    tr_akb.requestTemp(); // Запросить новое преобразование температуры
    bitSet(temp_status, akb);
  } else {
    temp_akb = (int8_t)(-127); // значение при отключенном датчике
    bitClear(temp_status, akb);
  }
}

// чтение температуры акб, вызывать раз в секунду
void temp_akb_compute(void) {
  if (getTempStatus(sens_temp::akb)) {
    if (tr_akb.readTemp()) {
      temp_akb = tr_akb.getTempInt();
      tr_akb.requestTemp(); // Запросить новое преобразование температуры
    }
  } else {
    temp_akb_begin();
  }
}
#endif

/*======== Датчик температуры NTC транзистора ========*/

#define BITRATEGATE (uint16_t)(BITRATE - (BITRATE / 100))

#if (SENSTEMP1 == 2)
// датчик температуры NTC транзистора Q1
NTCRead ntc_q(Q1_NTC_PIN, NTCR1, NTCRS1, NTCB1, TEMPBASE1);

void temp_Q1_begin(void) {
  uint32_t t = millis_sys() + 300;
  do {
    ntc_Q1_sample();
  } while ((millis_sys() < t));
}

void ntc_Q1_sample(void) {
  // считываем данные с АЦП с накоплением и усреднением
  if (ntc_q.sample()) {
    if (ADC_read() > BITRATEGATE) {
      bitClear(temp_status, q1);
    } else {
      bitSet(temp_status, q1);
    }
  }
}

// температура NTC транзистора
void temp_Q1_compute(void) {
  // рассчитать температуру термистора 300 мкс
  if (getTempStatus(sens_temp::q1)) {
    ntc_q.compute();
    temp_Q1 = ntc_q.temp;

    // если подключен датчик температуры и разрешено уменьшать ток при
    // превышении температуры транзистора
#if (GUARDTEMP > 0)
    // если превышена температура
    if (temp_Q1 > eepGetService_num(TEMPCUR))
      sysFlagSetBits(FlagsName::TR_Q1_ERR); // превышена температура Q1
    else if (sysFlagGetBits(FlagsName::TR_Q1_ERR) and
             temp_Q1 < eepGetService_num(TEMPCUR) - 5)
      sysFlagClearBits(
          FlagsName::TR_Q1_ERR); // температура Q1 снизилась на 5 гр.
#endif
  } else {
    temp_Q1 = (int8_t)(-127); // значение при отключенном датчике
  }
}
#endif

#if (SENSTEMP2 == 2)
// датчик температуры NTC аккумулятора
NTCRead ntc_akb(AKB_NTC_PIN, NTCR2, NTCRS2, NTCB2, TEMPBASE2);

void temp_akb_begin(void) {
  uint32_t t = millis_sys() + 300;
  do {
    ntc_akb_sample();
  } while ((millis_sys() < t));
}

void ntc_akb_sample(void) {
  if (ntc_akb.sample()) {
    // если датчик NTC отключить то АЦП выдас максимум
    if (ADC_read() > BITRATEGATE) {
      bitClear(temp_status, akb);
    } else {
      bitSet(temp_status, akb);
    }
  }
}

// температура NTC аккумулятора
void temp_akb_compute(void) {
  if (getTempStatus(sens_temp::akb)) {
    // рассчитать температуру термистора 300 мкс
    ntc_akb.compute();
    temp_akb = ntc_akb.temp;
  } else {
    temp_akb = (int8_t)(-127); // значение при отключенном датчике
  }
}
#endif

