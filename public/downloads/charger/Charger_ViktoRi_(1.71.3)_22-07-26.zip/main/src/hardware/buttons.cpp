#include "buttons.h"
#include "../core/global.h"
#include "../display/Display.h"

/*======== Энкодер, кнопки ========*/

// void setEncType(uint8_t type);
#define EB_DEB_TIME 50    // таймаут гашения дребезга кнопки (кнопка)
#define EB_CLICK_TIME 500 // таймаут ожидания кликов (кнопка)
#define EB_HOLD_TIME 1000 // таймаут удержания (кнопка)
#define EB_STEP_TIME 200  // таймаут импульсного удержания (кнопка)
#define EB_FAST_TIME 30   // таймаут быстрого поворота (энкодер)
#define EB_NO_CALLBACK    // отключить обработчик событий attach
// отключить счётчик энкодера [VirtEncoder, Encoder,EncButton]
#define EB_NO_COUNTER
// отключить буферизацию энкодера (экономит 2 байта оперативки)
// #define EB_NO_BUFFER

// более сильная функция для замены в библиотеке EncButton
uint32_t EB_uptime() { return (uint32_t)millis_sys(); }

// Библиотека энкодера и кнопок
#include <EncButton.h>

#if (ENCBUTT == 0)
// 0 - только энкодер с кнопкой
EncButtonT<ENC_S2, ENC_S1, ENC_KL> enc(INPUT_PULLUP, INPUT_PULLUP);
#elif (ENCBUTT == 1)
// 1 - только кнопки
ButtonT<PUSK> OK(INPUT_PULLUP);     // кнопка - Пуск
ButtonT<MINUS> Minus(INPUT_PULLUP); // кнопка - Минус
ButtonT<PLUS> Plus(INPUT_PULLUP);   // кнопка - Плюс
ButtonT<STOP> Stop(INPUT_PULLUP);   // кнопка - Стоп
#elif (ENCBUTT == 2)
// 2 - энкодер + OK + Stop
EncButtonT<ENC_S2, ENC_S1, ENC_KL> enc(INPUT_PULLUP, INPUT_PULLUP);
ButtonT<PUSK> OK(INPUT_PULLUP);
ButtonT<STOP> Stop(INPUT_PULLUP);
#elif (ENCBUTT == 3)
// 3 - энкодер + все кнопки
EncButtonT<ENC_S2, ENC_S1, ENC_KL> enc(INPUT_PULLUP, INPUT_PULLUP);
ButtonT<PUSK> OK(INPUT_PULLUP);
ButtonT<MINUS> Minus(INPUT_PULLUP);
ButtonT<PLUS> Plus(INPUT_PULLUP);
ButtonT<STOP> Stop(INPUT_PULLUP);
#else
#error "ENCBUTT must be 0, 1, 2 or 3"
#endif

void Enbutt::begin(void) {
#if (ENCBUTT == 0 or ENCBUTT == 2 or ENCBUTT == 3)
  enc.setEncType(EBSTEP);
#endif
}

// функция опрашивает энкодер и кнопки.
void Enbutt::Tick(void) {
  tick = 0;
// -1 - left, 1 - right, 16 - click, 2 - hold, 4 - step
#if (ENCBUTT == 0)
  // 0 - только энкодер
  if (enc.tick()) {
    if (enc.turn())
      tick = enc.dir(); // -1 - left, 1 - right,
    else {
      if (enc.click())
        tick = Butt::OKCLICK;
      if (enc.hold())
        tick = Butt::OKHELD;
    }
  }
#elif (ENCBUTT == 1)
  // 1 - только кнопки
  if (OK.tick()) {
    if (OK.click())
      tick = Butt::OKCLICK;
    if (OK.hold())
      tick = Butt::OKHELD;
  }
  if (Stop.tick()) {
    if (Stop.click())
      tick = Butt::STOPCLICK;
    if (Stop.hold())
      tick = Butt::STOPHELD;
  }
  if (Plus.tick()) {
    if (Plus.click() or Plus.step())
      tick = Butt::RIGHT;
  }
  if (Minus.tick()) {
    if (Minus.click() or Minus.step())
      tick = Butt::LEFT;
  }
#elif (ENCBUTT == 2)
  // 2 - энкодер + OK + Stop
  if (enc.tick()) {
    if (enc.turn())
      tick = enc.dir(); // -1 - left, 1 - right,
    else {
      if (enc.click())
        tick = Butt::OKCLICK;
      if (enc.hold())
        tick = Butt::OKHELD;
    }
  }
  if (OK.tick()) {
    if (OK.click())
      tick = Butt::OKCLICK;
    if (OK.hold())
      tick = Butt::OKHELD;
  }
  if (Stop.tick()) {
    if (Stop.click())
      tick = Butt::STOPCLICK;
    if (Stop.hold())
      tick = Butt::STOPHELD;
  }
#elif (ENCBUTT == 3)
  // 3 - энкодер + все кнопки
  if (enc.tick()) {
    if (enc.turn())
      tick = enc.dir(); // -1 - left, 1 - right,
    else {
      if (enc.click())
        tick = Butt::OKCLICK;
      if (enc.hold())
        tick = Butt::OKHELD;
    }
  }
  if (OK.tick()) {
    if (OK.click())
      tick = Butt::OKCLICK;
    if (OK.hold())
      tick = Butt::OKHELD;
  }
  if (Stop.tick()) {
    if (Stop.click())
      tick = Butt::STOPCLICK;
    if (Stop.hold())
      tick = Butt::STOPHELD;
  }
  if (Plus.tick()) {
    if (Plus.click() or Plus.step())
      tick = Butt::RIGHT;
  }
  if (Minus.tick()) {
    if (Minus.click() or Minus.step())
      tick = Butt::LEFT;
  }
#endif
#if (TIME_LIGHT)
  if (tick)
    disp.Light_high();
#endif
}

// функция проверяет три клика энкодера или ОК
bool Enbutt::Click3(void) {
  bool flag = false;

#if (ENCBUTT == 0 or ENCBUTT == 3)
  if (enc.clicks == 3)
    flag = true;
#endif

#if (ENCBUTT == 1 or ENCBUTT == 2 or ENCBUTT == 3)
  if (OK.clicks == 3)
    flag = true;
#endif

  return flag;
}

Enbutt butt;
// Enbutt butt = Enbutt();

