#pragma once

#include <Arduino.h>

/*======== Энкодер, кнопки ========*/

// настройка команд энкодера и кнопок
enum Butt : int8_t {
  LEFT = -1,
  RIGHT = 1,
  OKCLICK = 2,
  STOPCLICK = 3,
  OKHELD = 4,
  STOPHELD = 5
};

class Enbutt {
public:
  // Enbutt(void){};

  int8_t tick;

  void begin(void);

  // функция опрашивает энкодер и кнопки.
  void Tick(void);

  // функция проверяет три клика энкодера или ОК
  bool Click3(void);
};
extern Enbutt butt;

