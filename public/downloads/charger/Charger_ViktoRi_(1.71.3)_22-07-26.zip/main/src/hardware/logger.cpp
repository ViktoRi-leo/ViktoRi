#include "logger.h"
#include "sensors.h"
#include "INA226int.h"
#include "../core/global.h"

#if (LOGGER > 0)
/*======== отправка значений в сетевой порт ========*/

#if (LOGGER == 1)
// буфер отправки - байт
#define MU_TX_BUF 16
#elif (LOGGER == 2 or LOGGER == 3 or LOGGER == 4)
// буфер отправки - байт
#define MU_TX_BUF 30
#else
// буфер отправки - байт
#define MU_TX_BUF 4
#endif
// буфер приема - байт
#define MU_RX_BUF 4
#if (LOGGER == 2 or LOGGER == 3)
// подключить Print.h
#define MU_PRINT
#endif

#include <MicroUART.h>
MicroUART mSerial;

void serial_begin(void) {
  mSerial.begin(SERIAL_SPEED); // 9600   115200
}

// вернуть мАч, мВтч
int32_t get_mAmW(int32_t x) {
#if defined(__LGT8FX8P__)
  // Полученная_отданная емкость АКБ (А/ч)) /1000
  x = x ? DSC_DIV_get((int32_t)(x + 500), (uint16_t)1000) : 0;
#else
  // Полученная_отданная емкость АКБ (А/ч)) /1000
  x = x ? (x + 500) / 1000 : 0;
#endif
  return x;
}

// формируем основные данные
void Serial_Out::create(void) {
  send_str.volt = ina.volt_aver;
  send_str.amper = ina.curr_aver;

  switch (profil.Regim) {
  case Modes::CHARGE:
#if (BRRANIMIR)
  case Modes::BRANIMIR:
#endif
    send_str.Achas = get_mAmW(profil.charge.stat.ah);
    break;
  case Modes::ADDCHARGE:
    send_str.Achas = get_mAmW(profil.add.stat.ah);
    break;
  case Modes::ASYMMETRIC:
    send_str.Achas = get_mAmW(profil.asym.stat.ah);
    break;
  case Modes::DISCHARGE:
    send_str.Achas = -get_mAmW(profil.disch.stat.ah);
    break;
  default:
    send_str.Achas = 0;
    break;
  }

#if (VOLTIN == 1)
  send_str.volt_in = getPower(); // напряжение от БП (милливольт) /1000
#endif
#if (SENSTEMP1 > 0)
  send_str.tQ1 = temp_Q1; // Температура на Q1 (градусы)
#endif
#if (SENSTEMP2 > 0)
  send_str.tAkb = temp_akb; // 6 Температура АКБ (градусы)
#endif
}

// Расширенные данные LOGGER = 4
void Serial_Out::create_advanced(void) {
  send_str_adv.volt = ina.volt_aver;
  send_str_adv.amper = ina.curr_aver;

  switch (profil.Regim) {
  case Modes::CHARGE:
#if (BRRANIMIR)
  case Modes::BRANIMIR:
#endif
    send_str_adv.Achas = get_mAmW(profil.charge.stat.ah);
    send_str_adv.Wh_charge = get_mAmW(profil.charge.stat.wh);
    send_str_adv.time_charge = profil.charge.stat.time;
    break;
  case Modes::ADDCHARGE:
    send_str_adv.Achas = get_mAmW(profil.add.stat.ah);
    send_str_adv.Wh_charge = get_mAmW(profil.add.stat.wh);
    send_str_adv.time_charge = profil.add.stat.time;
    break;
  case Modes::ASYMMETRIC:
    send_str_adv.Achas = get_mAmW(profil.asym.stat.ah);
    send_str_adv.Wh_charge = get_mAmW(profil.asym.stat.wh);
    send_str_adv.time_charge = profil.asym.stat.time;
    break;
  case Modes::DISCHARGE:
    send_str_adv.Achas = -get_mAmW(profil.disch.stat.ah);
    send_str_adv.Wh_charge = -get_mAmW(profil.disch.stat.wh);
    send_str_adv.time_charge = profil.disch.stat.time;
    break;
  default:
    send_str_adv.Achas = 0;
    send_str_adv.Wh_charge = 0;
    send_str_adv.time_charge = get_second_usr(); // get_second_usr()
    break;
  }

#if (VOLTIN == 1)
  send_str_adv.volt_in = getPower();
#endif
#if (SENSTEMP1 > 0)
  send_str_adv.tQ1 = temp_Q1;
#endif
#if (SENSTEMP2 > 0)
  send_str_adv.tAkb = temp_akb;
#endif

  // Дополнительные данные
  send_str_adv.mode = profil.Regim;
  send_str_adv.type_akb = profil.akb.type;
  send_str_adv.capacity = profil.akb.capacity;
  send_str_adv.active_flag = bitRead(profil.flags, Pr_flags::ACTIVITI);
  send_str_adv.round_current = eeGetRound();
  send_str_adv.profil = vkr.profil;  
  send_str_adv.regim_end = (uint8_t)regim_end;
  send_str_adv.regims = (uint8_t)regims;
}

// Вывод логов в сетевой порт. Вызывать постоянно раз в секунду
void Serial_Out::Serial_out(void) {
  if (--_tm == 0) {
    _tm = LOGGTIME;

#if (LOGGER == 1)
    send_str.crc = 0;
    for (uint8_t i = 0; i < sizeof(Log_get) - 1; i++) {
      send_str.crc += ptr[i]; // Расчет контрольной суммы
      mSerial.write(ptr[i]);  // передать данные
    }
    mSerial.write(ptr[sizeof(Log_get) - 1]); // передать символ CRC

#elif (LOGGER == 2)
    _time += LOGGTIME;
    mSerial.print(F(txt_ViktoRi)); // ViktoRi  // начало посылки
    mSerial.write(';');
    mSerial.print(_time); // время
    mSerial.write(';');
    serial_print(send_str.volt, 3);
    serial_print(send_str.amper, 3);
    serial_print(send_str.Achas, 4);
    serial_print(send_str.volt_in, 3);      // напряжение от БП Вольт
    mSerial.print((int16_t)send_str.tQ1);   // Температура на Q1 (градусы)
    mSerial.write(';');
    mSerial.print((int16_t)send_str.tAkb);  // 6 Температура АКБ (градусы)
    mSerial.write(';');
    mSerial.println();                      // конец посылки

#elif (LOGGER == 3)
    mSerial.write('$'); // начало посылки
    serial_print(send_str.volt);
    serial_print(send_str.amper);
    serial_print(send_str.Achas);
    serial_print(send_str.volt_in); // напряжение от БП (милливольт)/1000
    serial_print(send_str.tQ1);     // Температура на Q1 (градусы)
    serial_print(send_str.tAkb);    // 6 Температура АКБ (градусы)
    mSerial.write(';');             // конец посылки

#elif (LOGGER == 4)
    // Расширенный лог
    send_str_adv.crc = 0;
    for (uint8_t i = 0; i < sizeof(Log_get_advanced) - 1; i++) {
      send_str_adv.crc += ptr_adv[i]; // Расчет контрольной суммы
      mSerial.write(ptr_adv[i]);      // передать данные
    }
    // передать символ CRC
    mSerial.write(ptr_adv[sizeof(Log_get_advanced) - 1]);
#endif
  }
}

#if (LOGGER == 2)
// вывод значения в тысячных долях (мВ -> В, мА -> А, мАч -> Ач) с y знаками
// после запятой и разделителем ';'
// целочисленный эквивалент mSerial.print(x / 1000.0, y)
void Serial_Out::serial_print(int32_t x, uint8_t y) {
  if (x < 0) {
    mSerial.write('-');
    x = -x;
  }
  mSerial.print((uint32_t)(x / 1000)); // целая часть
  if (y) {
    mSerial.write('.');
    uint16_t f = (uint16_t)(x % 1000);
    uint16_t d = 100;
    while (y--) {
      // после третьего знака разрядность исчерпана - дописываются нули
      mSerial.write('0' + (uint8_t)(d ? (f / d) % 10 : 0));
      d /= 10;
    }
  }
  mSerial.write(';');
}
#endif

#if (LOGGER == 3)
void Serial_Out::serial_print(int32_t x) {
  mSerial.print(x);
  mSerial.write(' ');
}
#endif

Serial_Out Sout;
#endif

