#pragma once

#include <Arduino.h>

/*======== класс управления кулером ========*/

class Cooler {
public:
  // Cooler(void) {}

  // инициализация
  void begin(void);

  bool onse;
  // принудительно включить/выключить кулер
  void ONonse(bool x);

  void control(void);

private:
  uint8_t _kul; // значение ШИМ кулера
};

extern Cooler fan;

