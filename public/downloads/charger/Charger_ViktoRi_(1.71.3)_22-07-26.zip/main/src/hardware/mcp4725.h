#pragma once

#include <Arduino.h>

// библиотека для работы с ЦАП MCP4725
// просто отправляет значение 0-4095 напряжения в MCP4725
class MCP4725 {
public:
  // инициализация
  MCP4725(uint8_t addr) : _address(addr) {}

  // Запись 16-ти битного регистра MCP4725
  void setVoltage(uint16_t data);

  // Проверка присутствия
  bool testConnection(void);

private:
  const uint8_t _address;
};

extern MCP4725 dac;
