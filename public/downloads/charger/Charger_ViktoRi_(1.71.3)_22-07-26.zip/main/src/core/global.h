#pragma once
#include <Arduino.h>
#include "system.h"
#include "global_profils.h"
#include "User_Setup_Loader.h"
#include "Functions.h"
#include "../hardware/sensors.h"
#include "../hardware/cooler.h"
#include "../hardware/buttons.h"
#include "../hardware/logger.h"
#include "../hardware/mcp4725.h"
#include "../display/menu_txt.h"
// #include <EEPROM.h>

#include "Service_parameters.h"

// версия структуры в EPPROM
#define MEMVER 109

// функция reset 
[[noreturn]] inline void resetFunc() {
  asm volatile("jmp 0" ::: "memory");
  __builtin_unreachable();
}

// флаги системы
enum FlagsName : uint8_t {
  // напряжение блока питания:
  POWERHIGH, // выше максимального (false - в норме)
  POWERLOW,  // ниже минимального  (false - в норме)
  POWERON,   // питание от БП поступает (true - в норме)
  TR_Q1_ERR, // превышена температура на силовом транзисторе (false - в норме)
  RELEY_OFF, // разрешено отключать реле  (true - в норме)
  TEMP_AKB,  // температура акб (false - в норме)
  SECOND     // флаг секунды (false)
};

// флаги системы
extern uint8_t sysFlag;

void sysFlagsBegin(void);

// получить флаги системы
#define sysFlagGetBits(bitt) ((sysFlag >> bitt) & 0x01)

// установить флаги системы
#define sysFlagSetBits(bitt) (sysFlag |= (1 << bitt))

// сбросить флаги системы
#define sysFlagClearBits(bitt) (sysFlag &= ~(1 << bitt))

// вернуть ошибки системы
bool sysFlagsError(void);

// номера режимов работы
enum Modes : uint8_t {
  CHARGE,      // Заряд
  ADDCHARGE,   // Дозаряд
  DISCHARGE,   // Разряд
  STORAGE,     // Режим хранения акб
  ASYMMETRIC,  // ассиметричный заряд
  KTCycle,     // Контрольно тренировочный цикл
  BUFER,       // Буферный режим
  BRANIMIR,    // Заряд по Бранимиру
  KALIBRATION, // калибровка
  RESISTENSE,  // замер сопротивления
  POWEROUT,    // блок питания
};

// текущий режим работы
enum Regims : uint8_t {
  REGIM_OFF = 0,   // Выключен
  REGIM_PRECHARGE, // Предзаряд (в режиме Заряд включен предзаряд)
  REGIM_CHARGE,    // Заряд
  REGIM_OSCIL,     // осциляция(качели) (в режиме Заряд включен режим осциляции)
  REGIM_ADDCHARGE, // Дозаряд
  REGIM_DISCHARGE, // Разряд
#if (BRRANIMIR)
  REGIM_MIXING,    // перемешивание для Бранимира
#endif
  WAIT,            // ожидание
};

extern Regims regims;

// причина завершения заряда
enum Reason : uint8_t {
  begin,           // 0
  out_time,        // 1 закончилось время
  volt_maxCur_min, // 2 напряжение достигло максимума ток минимума
  cur_stop,        // 3 напряжение достигло максимума, ток перестал уменьшаться
  volt_decreased,  // 4 напряжение стало уменьшаться
  curr_increased,  // 5 ток стал увеличиваться
  disconnect_batt, // 6 акб отключена
  batt_temp_error, // 7 температура акб вышла за пределы
};

// номер причины завершения заряда
extern Reason regim_end;


// 8 байт
struct Intls {
  uint8_t Ohms;   // кооффициент коррекции напряжения 0-255 (сопротивление линии
                  // до акб)
  uint8_t profil; // текущий профиль
  uint16_t Vref;  // коэффициент для калибровки напряжения БП - VKORRECT
  uint16_t shunt; // значение сопротивления шунта (1000 это 10.00 мОм)
  uint16_t inaKoof; // коэффициент для калибровки напряжения INA226
};
extern Intls vkr;

extern Profils profil;

// функция рассчета профиля по параметрам аккумулятора
void calcProfile();

// напряжение аккумулятора
uint16_t bat_volt(uint8_t bat_type);

// считать из EEPROM номер операции
uint8_t eeGetModeNumber(void);

// сохранить в EEPROM номер операции
void eeSetModeNumber(uint8_t mode);

// считать из EEPROM текущий круг
uint8_t eeGetRound(void);

// сохранить в EEPROM текущий круг
void eeSetRound(uint8_t round);

// считать из EEPROM число кругов последнего КТЦ
uint8_t eeGetKtcRounds(void);

// сохранить в EEPROM число кругов последнего КТЦ
void eeSetKtcRounds(uint8_t rounds);

// сохранить в EEPROM выбранный режим работы
void eeSetMode(void);

// считать из EEPROM выбранный режим работы
void eeGetMode(void);

// флаг секунды
bool get_second(void);

// ждать N секунд
void delay_sec(uint8_t sec);

// сохранить структуру vkr
void eeSave_vkr(void);

// считать структуру vkr
void eeGet_vkr(void);

// сохранить структуру profil
void eeSave_profil(uint8_t profil_number);

// считать структуру profil
void eeGet_profil(void);

// сохранение структур в EEPROM
void eepSavedStruct(void);

// чтение структур из EEPROM
void eepGetStruct(void);


/* ******** EEPROM ******** */

// адрес начальной ячейки памяти для значения сброса настроек
#define MEM_RESET 0
// адрес начальной ячейки памяти для структуры vkr
#define MEM_VKR 1
// адрес начальной ячейки памяти для сервисных параметров
#define MEM_SERV 10
// адрес начальной ячейки памяти для структуры profil
#define MEM_PAM 30
// адрес начальной ячейки памяти для результатов замера емкости КТЦ.
#define MEM_KTC 903
// адрес ячейки памяти для режима работы выбранного в меню
#define MEM_MODE 1021
// адрес ячейки памяти для числа кругов последнего КТЦ
#define MEM_KTC_ROUNDS 1020
// адрес ячейки памяти для оставшегося количество циклов
#define MEM_ROUND 1022
// адрес ячейки памяти для номер операции
#define MEM_NUMBER 1023

/*
Карта организации памяти EPRROM
0	- значение сброса настроек
1	  9	- struct vkr 8 байт
10	25	- архив 16 байт сервисные параметры зарядника
30	126	Профиль 0
127	223	Профиль 1
224	320	Профиль 2
321	417	Профиль 3
418	514	Профиль 4
515	611	Профиль 5
612	708	Профиль 6
709	805	Профиль 7
806	902	Профиль 8
903	919	КТЦ-1
920	936	КТЦ-2
937	953	КТЦ-3
954	970	КТЦ-4
971	987	КТЦ-5
988 - 1019 резерв 32 байта
1020	число кругов последнего КТЦ
1021	текущий режим работы
1022		текущий круг
1023		номер операции
*/

uint16_t volt_step(uint16_t volt, int8_t x);

#if defined(__LGT8FX8P__)
void lgt_eeprom_update_byte(uint16_t address, uint8_t value);

void lgt_eeprom_update_block(uint8_t *pbuf, uint16_t address, uint16_t len);
#endif

// пошаговое изменение значения с ограничением диапазоном [low, high]:
// на границе шаг наружу игнорируется, иначе возвращается amt + x.
// (бывший макрос constrain_my; функция экономит flash на ~35 вызовах)
int16_t constrain_my(int16_t amt, int16_t low, int16_t high, int16_t x);


int16_t difference(int32_t diff_1, int32_t diff_2);

// функция быстрого переключения "ног"
void digitalWrite_speed(uint8_t pin, bool x);

void analogWrite_my(uint8_t pin, uint16_t duty);

#if defined(__LGT8FX8P__)
int16_t map_my(int16_t x, int16_t in_min, int16_t in_max, int16_t out_min,
               int16_t out_max);
#else
int16_t map_my(int32_t x, int16_t in_min, int16_t in_max, int16_t out_min,
               int16_t out_max);
#endif

//  nvBit(tmp,6);    //инвертировать шестой бит переменной tmp
#define InvBit(reg, bit) reg ^= (1 << bit)
#define BitIsClear(reg, bit) ((reg & (1 << bit)) == 0)
// if  (BitIsClear(PIND, 0)) {   //если очищен нулевой бит в регистре PIND
// //выполнить блок
/*
#if ((float)CURR_MAX > (float)(0.08192f / (float)SHUNT))
#error "Указанное значение тока не может быть больше чем позволяет шунт."
#endif
*/

#if (PROFIL > 8)
#error "Максимальное количество профилей не может быть больше 8"
#endif


#if defined(BUFER_PIN) and (BUFER_PIN == PROTECT_OPEN_PIN)
#error "Пин буфера (BUFER_PIN) и пина защиты открытия (PROTECT_OPEN_PIN) совпадают."
#endif

static_assert(SHUNT >= 0.001f, "Сопротивление ШУНТА должно быть больше 0,001 Ом");
