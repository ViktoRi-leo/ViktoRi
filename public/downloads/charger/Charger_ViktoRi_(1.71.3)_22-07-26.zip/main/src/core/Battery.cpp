#include "Battery.h"

// Стандартные параметры АКБ

// 0 Свинцово-кислотная АКБ PB_CACA
const Battery PROGMEM PB_caca{
    /*напряжение одной ячейки АКБ*/
    .volt_cell = 2100,
    /*напряжение заряда ячейки АКБ*/
    .volt_cell_charge = 2450,
    /*напряжение дозаряда ячейки АКБ - только для свинцово-кислотных*/
    .volt_cell_add_charge = 2710,
    /*напряжение разряда ячейки АКБ*/
    .volt_cell_discharge = 1850,

    /*ток заряда ячейки АКБ, указано в процентах от емкости АКБ*/
    .curr_cell_charge = 10,
    /*ток дозаряда ячейки АКБ*/
    .curr_cell_addcharge = 2,
    /*ток разряда ячейки АКБ*/
    .curr_cell_discharge = 4,
};

// 1 Свинцово-кислотная АКБ Pb_CA+
const Battery PROGMEM PB_casur{
    /*напряжение одной ячейки АКБ*/
    .volt_cell = 2100,
    /*напряжение заряда ячейки АКБ*/
    .volt_cell_charge = 2430,
    /*напряжение дозаряда ячейки АКБ - только для свинцово-кислотных*/
    .volt_cell_add_charge = 2730,
    /*напряжение разряда ячейки АКБ*/
    .volt_cell_discharge = 1850,

    /*ток заряда ячейки АКБ, указано в процентах от емкости АКБ*/
    .curr_cell_charge = 10,
    /*ток дозаряда ячейки АКБ*/
    .curr_cell_addcharge = 2,
    /*ток разряда ячейки АКБ*/
    .curr_cell_discharge = 4,
};

// 2 Свинцово-кислотная АКБ PB_SUR
const Battery PROGMEM PB_sur{
    /*напряжение одной ячейки АКБ*/
    .volt_cell = 2100,
    /*напряжение заряда ячейки АКБ*/
    .volt_cell_charge = 2410,
    /*напряжение дозаряда ячейки АКБ - только для свинцово-кислотных*/
    .volt_cell_add_charge = 2500,
    /*напряжение разряда ячейки АКБ*/
    .volt_cell_discharge = 1850,

    /*ток заряда ячейки АКБ, указано в процентах от емкости АКБ*/
    .curr_cell_charge = 10,
    /*ток дозаряда ячейки АКБ*/
    .curr_cell_addcharge = 2,
    /*ток разряда ячейки АКБ*/
    .curr_cell_discharge = 4,
};

// 3 Свинцово-кислотная АКБ PB_AGM
const Battery PROGMEM PB_agm{
    /*напряжение одной ячейки АКБ*/
    .volt_cell = 2100,
    /*напряжение заряда ячейки АКБ*/
    .volt_cell_charge = 2430,
    /*напряжение дозаряда ячейки АКБ - только для свинцово-кислотных*/
    .volt_cell_add_charge = 2600,
    /*напряжение разряда ячейки АКБ*/
    .volt_cell_discharge = 1850,

    /*ток заряда ячейки АКБ, указано в процентах от емкости АКБ*/
    .curr_cell_charge = 10,
    /*ток дозаряда ячейки АКБ*/
    .curr_cell_addcharge = 2,
    /*ток разряда ячейки АКБ*/
    .curr_cell_discharge = 4,
};

// 4 Свинцово-кислотная АКБ PB_GEL
const Battery PROGMEM PB_gel{
    /*напряжение одной ячейки АКБ*/
    .volt_cell = 2100,
    /*напряжение заряда ячейки АКБ*/
    .volt_cell_charge = 2350,
    /*напряжение дозаряда ячейки АКБ - только для свинцово-кислотных*/
    .volt_cell_add_charge = 2400,
    /*напряжение разряда ячейки АКБ*/
    .volt_cell_discharge = 1850,

    /*ток заряда ячейки АКБ, указано в процентах от емкости АКБ*/
    .curr_cell_charge = 10,
    /*ток дозаряда ячейки АКБ*/
    .curr_cell_addcharge = 1,
    /*ток разряда ячейки АКБ*/
    .curr_cell_discharge = 4,
};

// 5 Литий-ионная АКБ  LI_ION
const Battery PROGMEM Li_ion{
    /*напряжение одной ячейки АКБ*/
    .volt_cell = 3650,
    /*напряжение заряда ячейки АКБ*/
    .volt_cell_charge = 4200,
    /*напряжение дозаряда ячейки АКБ - только для свинцово-кислотных*/
    .volt_cell_add_charge = 0,
    /*напряжение разряда ячейки АКБ*/
    .volt_cell_discharge = 2750,

    /*ток заряда ячейки АКБ, указано в процентах от емкости АКБ*/
    .curr_cell_charge = 50,
    /*ток дозаряда ячейки АКБ*/
    .curr_cell_addcharge = 0,
    /*ток разряда ячейки АКБ*/
    .curr_cell_discharge = 50,
};

// 6 Литий-полимерная АКБ  LI_POL
const Battery PROGMEM Li_pol{
    /*напряжение одной ячейки АКБ*/
    .volt_cell = 3650,
    /*напряжение заряда ячейки АКБ*/
    .volt_cell_charge = 4200,
    /*напряжение дозаряда ячейки АКБ - только для свинцово-кислотных*/
    .volt_cell_add_charge = 0,
    /*напряжение разряда ячейки АКБ*/
    .volt_cell_discharge = 2800,

    /*ток заряда ячейки АКБ, указано в процентах от емкости АКБ*/
    .curr_cell_charge = 50,
    /*ток дозаряда ячейки АКБ*/
    .curr_cell_addcharge = 0,
    /*ток разряда ячейки АКБ*/
    .curr_cell_discharge = 50,
};

// 7 Литий-железофосфатная АКБ  LI_FER
const Battery PROGMEM Li_ferr{
    /*напряжение одной ячейки АКБ*/
    .volt_cell = 3200,
    /*напряжение заряда ячейки АКБ*/
    .volt_cell_charge = 3650,
    /*напряжение дозаряда ячейки АКБ - только для свинцово-кислотных*/
    .volt_cell_add_charge = 0,
    /*напряжение разряда ячейки АКБ*/
    .volt_cell_discharge = 2800,

    /*ток заряда ячейки АКБ, указано в процентах от емкости АКБ*/
    .curr_cell_charge = 100,
    /*ток дозаряда ячейки АКБ*/
    .curr_cell_addcharge = 0,
    /*ток разряда ячейки АКБ*/
    .curr_cell_discharge = 50,
};

// 8 Литий-железофосфатная АКБ  LI_TIT
const Battery PROGMEM Li_tit{
    /*напряжение одной ячейки АКБ*/
    .volt_cell = 2400,
    /*напряжение заряда ячейки АКБ*/
    .volt_cell_charge = 2700,
    /*напряжение дозаряда ячейки АКБ - только для свинцово-кислотных*/
    .volt_cell_add_charge = 0,
    /*напряжение разряда ячейки АКБ*/
    .volt_cell_discharge = 1600,

    /*ток заряда ячейки АКБ, указано в процентах от емкости АКБ*/
    .curr_cell_charge = 100,
    /*ток дозаряда ячейки АКБ*/
    .curr_cell_addcharge = 0,
    /*ток разряда ячейки АКБ*/
    .curr_cell_discharge = 50,
};

// 9 Литий-железофосфатная АКБ  NI_CD
const Battery PROGMEM NI_cd{
    /*напряжение одной ячейки АКБ*/
    .volt_cell = 1250,
    /*напряжение заряда ячейки АКБ*/
    .volt_cell_charge = 1600,
    /*напряжение дозаряда ячейки АКБ - только для свинцово-кислотных*/
    .volt_cell_add_charge = 0,
    /*напряжение разряда ячейки АКБ*/
    .volt_cell_discharge = 1000,

    /*ток заряда ячейки АКБ, указано в процентах от емкости АКБ*/
    .curr_cell_charge = 100,
    /*ток дозаряда ячейки АКБ*/
    .curr_cell_addcharge = 0,
    /*ток разряда ячейки АКБ*/
    .curr_cell_discharge = 50,
};

// 10 Литий-железофосфатная АКБ  NI_MG
const Battery PROGMEM NI_mg{
    /*напряжение одной ячейки АКБ*/
    .volt_cell = 1250,
    /*напряжение заряда ячейки АКБ*/
    .volt_cell_charge = 1600,
    /*напряжение дозаряда ячейки АКБ - только для свинцово-кислотных*/
    .volt_cell_add_charge = 0,
    /*напряжение разряда ячейки АКБ*/
    .volt_cell_discharge = 1000,

    /*ток заряда ячейки АКБ, указано в процентах от емкости АКБ*/
    .curr_cell_charge = 100,
    /*ток дозаряда ячейки АКБ*/
    .curr_cell_addcharge = 0,
    /*ток разряда ячейки АКБ*/
    .curr_cell_discharge = 50,
};

// Массив структур аккумуляторов
const Battery PROGMEM batteries[] = {
    PB_caca, PB_casur, PB_sur, PB_agm, PB_gel, Li_ion, Li_pol, Li_ferr, Li_tit, NI_cd, NI_mg,
};

/*PB_CACA, Pb Ca+, PB_SUR, PB_AGM, PB_GEL, LI_ION, LI_POL, LI_FER, LI_TIT, NI_CD, NI_MG,*/

