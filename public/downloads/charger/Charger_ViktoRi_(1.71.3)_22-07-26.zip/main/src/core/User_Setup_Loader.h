#pragma once
// =====================================================================
//  Системный файл. НЕ редактировать.
//  Подключает личные настройки (0_My_Setup.h) поверх 1_User_Setup.h.
//  0_My_Setup.h может отсутствовать
// =====================================================================

#if defined(__has_include)
#  if __has_include("../../0_My_Setup.h")
#    include "../../0_My_Setup.h"
#  endif
#endif

#include "../../1_User_Setup.h"

#if defined(__has_include)
#  if __has_include("../../0_My_Setup.h")
#    include "../../0_My_Setup.h"
#  endif
#endif
