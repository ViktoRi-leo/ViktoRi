#include <Arduino.h>

// Таймер 0 в режиме CTC (Count-to-Compare)
// генерирует прерывание каждые 1 мс
void timer0_init(void);

// Прерывание Timer0 (обработчик события)
ISR(TIMER0_COMPA_vect);

unsigned long millis_sys(void);

unsigned long micros_sys(void);

void delay_sys(uint16_t ms);

// вернуть флаг 2мс
bool get_ina_flag_sys(void);

// вернуть флаг 1 секунды
bool get_second_flag_sys(void);

// сброс счетчика секунды
void secondReset(void);

// счет секунд пользователя
unsigned long get_second_usr(void);

// запустить счет секунд пользователя
void start_second_usr(void);

// остановить счет секунд пользователя
void stop_second_usr(void);

// пауза счета секунд пользователя
void pause_second_usr(bool pause);

// включить/отключить вывод сигнала 500 Гц
void Timer0_outputPin6(bool state);

#if defined(__LGT8FX8P__)
// использовать таймер 3 в программе (раскомментировать если нужен)
// #define LGT8_TIMER3
#include "system_lgt8.h"
#include <LGT8_uDSC.h>
#endif

