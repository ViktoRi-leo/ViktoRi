#pragma once
#include <Arduino.h>

#include <LGT8_uDSC.h>

// START CHANGE BY DBUEZAS & SEISFELD & JG1UAA
void lgt8fx8x_clk_src();

// включить выходной ток пина 80 мА
void current_80mA(uint8_t pin);

#ifdef LGT8_TIMER3

// Таймер 3 в режиме 1 секунда
inline void timer3_init();

ISR(TIMER3_vect);

unsigned long t3_get_second_usr(void) ;

void t3_start_second_usr(void);
#endif