/* ******* сервисные параметры ****** */
#pragma once
#include <Arduino.h>


/* ******* системные параметры ****** */
// 0 - 19 максимум
const char service_security[] PROGMEM = "SECURITY";          // флаг работы защит тока и напряжения в Заряде
const char service_currreduct[] PROGMEM = "CURR_REDUCT";     // CURRENT_REDUCTION
const char service_fanmode[] PROGMEM = "FAN_MODE";           // тип управления вентилятором
const char service_pow[] PROGMEM = "POWER";                  // напряжение от БП 
const char service_powmax[] PROGMEM = "POWER_MAX";           // максимально допустимое напряжение от БП
const char service_currmax[] PROGMEM = "CURR_MAX";           // максимальный ток зарядника 25.5А
const char service_timelight[] PROGMEM = "TIME_LIGHT";       // время подсветки дисплея в минутах 
const char service_tempcur[] PROGMEM = "TEMPCURR";           // температура при которой уменьшается ток заряда
const char service_freqgharge[] PROGMEM = "FREQ_CHARGE";     // частота силового модуля 
const char service_freqdisgharge[] PROGMEM = "FREQ_DISCHAR"; // частота разрядного модуля 
const char service_currcritical[] PROGMEM = "CUR_CRIT";      // Curr_Critical_mA, десятки мА
const char service_voltcritical[] PROGMEM = "VLT_DROP";      // Volt_Critical_mV, десятки мВ (со знаком -)


// 0 - 19 максимум
const char* const servicc[] PROGMEM = {
  service_security,       // 0
  service_currreduct,     // 1
  service_fanmode,        // 2
  service_pow,            // 3
  service_powmax,         // 4
  service_currmax,        // 5  
  service_timelight,      // 6
  service_tempcur,        // 7
  service_freqgharge,     // 8
  service_freqdisgharge,  // 9
  service_currcritical,   // 10
  service_voltcritical,   // 11  
};

#define POINTSERVICE (uint8_t)(sizeof(servicc) / sizeof(servicc[0]))

// количество флагов
#define SERVICE_FLAG_SISE 3

enum Serviceflags : uint8_t {
  FLAG_SECURITY,  // 0 флаг работы защит тока и напряжения в Заряде
  FLAG_CURREDUCT, // 1 флаг включения функции снижения тока в Заряде
  FLAG_FANMODE,   // 2 режим работы кулера
};

// номера ячеек сервисных параметров в EEPROM
// 0 - 19 максимум
enum eepService_num : uint8_t {
  SERVICE_FLAG, // 0 сервисные флаги
  POWERIN,      // 1 напряжение от БП
  POWERMAX,     // 2 максимально допустимое напряжение от БП
  CURRMAX,      // 3 максимальный ток
  TIMELIGHT,    // 4 время подсветки дисплея в минутах
  TEMPCUR,      // 5 температура при которой уменьшается ток заряда
  FREQCHARGE,   // 6 частота работы силовогомодуля
  FREQDISCHAR,  // 7 частота работы разрядного модуля
  CURRCRIT,     // 8 критический ток, десятки мА
  VOLTDROP      // 9 критическое напряжение
};

bool eepGetService_flag(uint8_t nomer);
uint8_t eepGetService_num(uint8_t nomer);

// напряжение от БП
#define POWERINT ((uint16_t)eepGetService_num(eepService_num::POWERIN) * 1000)
// максимальный ток
#define CURRMAXINT ((int16_t)eepGetService_num(eepService_num::CURRMAX) * 100)

// чтение сервисных параметров
void eepGetService(void);

// сброс сервисных параметров
void eepResetService(void);

// изменение сервисных параметров
void serviceparam(void);