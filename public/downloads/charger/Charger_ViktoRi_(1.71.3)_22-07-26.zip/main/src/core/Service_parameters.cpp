#include "Service_parameters.h"
#include "global.h"
#include "../hardware/DCDC.h"
#include "../display/Display.h"
#include "../display/Menu.h"
#include <EEPROM.h>

// Вспомогательный макрос для проверки значения (0 или 1)
#define CHECK_FLAG(x) ((x) & 1)

#if (FAN > 0)
#define FANMODS (FAN - 1)
#else
#define FANMODS 0
#endif

// флаги сервисных настроек
// 0 - флаг работы защит тока и напряжения в Заряде (1 по умолчанию)
// 1 - CURRENT_REDUCTION
// 2 - режим работы вентилятора 
#define SERVICE_FLAGS                                                          \
  ((CHECK_FLAG(1) << 0) | (CHECK_FLAG(CURRENT_REDUCTION) << 1) |               \
   (CHECK_FLAG(FANMODS) << 2))

// сервисные параметры по умолчанию
const uint8_t PROGMEM service_default[] = {
    SERVICE_FLAGS,
    POWER_IN,                        // напряжение от БП
    POWER_MAX,                       // максимально допустимое напряжение от БП
    (uint8_t)((float)CURR_MAX * 10), // Максимальный ток зарядника 25.5А    
    TIME_LIGHT,                      // время подсветки дисплея в минутах
    DEG_CUR,        // температура при которой уменьшается ток заряда
    FREQ_CHARGE,    // частота силового модуля
    FREQ_DISCHARGE, // частота разрядного модуля
    // 8  CURRCRIT:     300 мА → 30 (на дисплее 30 = 300 мА)
    (uint8_t)(Curr_Critical_mA / 10),
    // 9  VOLTDROP:     |-300| → 30 (на дисплее 30 = 300 мВ)
    (uint8_t)(abs(Volt_Critical_mV) / 10),
};

// сброс сервисных параметров
void eepResetService(void) {
#if defined(__LGT8FX8P__)
  for (byte i = 0; i < sizeof(service_default); i++) {
    lgt_eeprom_update_byte(MEM_SERV + i, pgm_read_byte(&service_default[i]));
  }
#else
  for (uint8_t i = 0; i < sizeof(service_default); i++) {
    EEPROM.update((int)MEM_SERV + i, pgm_read_byte(&service_default[i]));
  }
#endif
}

// кэш сервисных параметров в RAM.
// Заполняется один раз при старте (eepGetService).
// Кэш не устаревает: после изменения параметров (serviceparam) и после
// сброса настроек (Reset_settings) выполняется resetFunc().
static uint8_t service_ram[10];

// чтение сервисных параметров из EEPROM в RAM (вызывать при старте)
void eepGetService(void) {
#if defined(__LGT8FX8P__)
  lgt_eeprom_read_block(service_ram, MEM_SERV, sizeof(service_ram));
#else
  EEPROM.get((int)MEM_SERV, service_ram);
#endif
}

bool eepGetService_flag(uint8_t nomer) {
  return bitRead(service_ram[eepService_num::SERVICE_FLAG], nomer);
}

// чтение отдельных сеpвисных параметров
uint8_t eepGetService_num(uint8_t nomer) { return service_ram[nomer]; }


/* ******* изменение сервисных параметров ******* */
void serviceparam(void) {
  lcd.clear();
  uint8_t service[10];
  // рабочая копия параметров из RAM-кэша (он заполнен при старте)
  memcpy(service, service_ram, sizeof(service));
  uint8_t arrowPos = 0;      // номер пункта меню
  bool controlState = false; // меняем пункты/режим редактирования
  uint8_t screenPos = 0;     // номер "экрана"
  uint8_t lastScreen = 0;    // предыдущий номер "экрана"
  bool ext = true;
  do {
    screenPos = arrowPos / DISPLAYy; // ищем номер экрана (0..3 - 0, 4..7 - 1)
    if (lastScreen != screenPos)
      lcd.clear(); // если экран сменился - очищаем
    lastScreen = screenPos;
    // для всех строк
    for (byte i = 0; i < DISPLAYy; i++) {
      lcd.setCursor(0, i); // курсор в начало
      // если курсор находится на выбранной строке
      uint8_t arr = DISPLAYy * screenPos + i;
      // рисуем стрелку или пробел
      lcd.write((arrowPos == arr) ? (controlState ? '>' : (char)0x7E) : ' ');      
      // если пункты меню закончились, покидаем цикл for
      if (arr == POINTSERVICE)
        break;
      // выводим имя и значение пункта меню
      disp.printFromPGM((int)(&servicc[arr]));
      lcd.print(F(": "));
      if (arr < SERVICE_FLAG_SISE) {
        // вывод флагов
        lcd.print((uint8_t)bitRead(service[0], arr));
      } else {
        lcd.print(service[arr - (uint8_t)(SERVICE_FLAG_SISE - 1)]);
      }
      print_space();
    }
    pauses(); // ожидание действий пользователя

    switch (butt.tick) {
    case Butt::RIGHT:
    case Butt::LEFT:
      if (!controlState) {
        // двигаем курсор // ограничиваем
        arrowPos = constrain_my(arrowPos, 0, POINTSERVICE - 1, butt.tick);
      } else {
        if (arrowPos < SERVICE_FLAG_SISE) {
          // флаги сервисных параметров
          InvBit(service[0], arrowPos);
        } else {
           uint8_t pos = arrowPos - (uint8_t)(SERVICE_FLAG_SISE - 1);
          switch (pos) {
          case eepService_num::CURRMAX: {
            uint8_t cur = (uint8_t)(81920 / vkr.shunt);
            // установка ограничения максимального тока. Не может
            // быть больше чем рассчетное значение с шунтом.
            service[pos] =
                constrain_my(service[pos], 1, cur, butt.tick);
          } break;

          case eepService_num::FREQCHARGE:
          case eepService_num::FREQDISCHAR:
            // изменение частоты заряда
            // изменение частоты разряда
            service[pos] =
                constrain_my(service[pos], 0, FREQTABLE_SIZE, butt.tick);
            break;

          default:
            service[pos] =
                constrain_my(service[pos], 0, 255, butt.tick);
            break;
          }
        }
      }

      break;
    case Butt::OKCLICK:
      // двигать курсор / изменять данныые
      controlState = !controlState;
      break;
    case Butt::STOPCLICK:
    case Butt::OKHELD:
      // выйти из цикла
      ext = false;
      break;
    }
  } while (ext);
  lcd.clear();
  print_mode(SETTING);
  lcd.print(F(txt3));
  lcd.write('?');
  if (Choice(30, false)) {
#if defined(__LGT8FX8P__)
    lgt_eeprom_update_block(((uint8_t *)&service), MEM_SERV, sizeof(service));
    /* lgt_eeprom_writeSWM((uint16_t)MEM_SERV, ((uint32_t *)&service),
                         (uint16_t)4); */
#else
    EEPROM.put((int)MEM_SERV, service);
#endif
    resetFunc();
  }
}
