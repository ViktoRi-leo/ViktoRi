#pragma once
/*
Типы акб
*/
#include <Arduino.h>
#include "User_Setup_Loader.h"

enum Akb_type: uint8_t {
  PB_CACA, PB_CASUR, PB_SUR, PB_AGM, PB_GEL, LI_ION, LI_POL, LI_FER, LI_TIT, NI_CD, NI_MG,
};

// количество типов акб (совпадает с числом элементов enum Akb_type)
#define AKB_TYPES 11

// архив с названиями типов аккумуляторов
// строки заданы в display/lang/common.h, массив определен в menu_txt.cpp
extern const char* const akb_name_list[AKB_TYPES] PROGMEM;

// максимальный номер типа акб
#define AKB_COUNT (uint8_t)(sizeof(akb_name_list) / sizeof(akb_name_list[0]) - 1)

struct Battery {
  /*напряжение одной ячейки АКБ*/ 
  uint16_t volt_cell;  
  /*напряжение заряда ячейки АКБ*/ 
  uint16_t volt_cell_charge; 
  /*напряжение дозаряда ячейки АКБ - только для свинцово-кислотных*/ 
  uint16_t volt_cell_add_charge;  
  /*напряжение разряда ячейки АКБ*/ 
  uint16_t volt_cell_discharge;

  /*ток заряда ячейки АКБ, указано в процентах от емкости АКБ*/ 
  uint8_t curr_cell_charge;
  /*ток дозаряда ячейки АКБ*/ 
  uint8_t curr_cell_addcharge;
  /*ток разряда ячейки АКБ*/ 
  uint8_t curr_cell_discharge;
};

// Массив структур аккумуляторов
extern const Battery PROGMEM batteries[];

// диапазон рабочих температур для разных типов акб
// значения задаются в 1_User_Setup.h (TEMP_RANGE_*)
const int8_t PROGMEM temp_count[][2]{
    TEMP_RANGE_PB,    // PB_CACA
    TEMP_RANGE_PB,    // PB_CASUR
    TEMP_RANGE_PB,    // PB_SUR
    TEMP_RANGE_PB,    // PB_AGM
    TEMP_RANGE_PB,    // PB_GEL
    TEMP_RANGE_LI,    // LI_ION
    TEMP_RANGE_LI,    // LI_POL
    TEMP_RANGE_LIFE,  // LI_FER
    TEMP_RANGE_LITIT, // LI_TIT
    TEMP_RANGE_NI,    // NI_CD
    TEMP_RANGE_NI,    // NI_MG
};


/*
// названия типов аккумуляторов для Menu
const char akb_name[] =
    "PB_Ca/Ca;PB_CA/SUR;PB_Sur;PB_AGM;PB_GEL;Li-Ion;Li-Pol;LI_Fer;Li-Tit;NI_Cd;NI_Mg";
*/    