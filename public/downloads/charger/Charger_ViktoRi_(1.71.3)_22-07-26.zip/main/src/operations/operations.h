#pragma once
// #include "User_Setup_Loader.h"
#include "../core/global.h"
#include "../core/Protections.h"

void Operations(void);

// обработка общих кнопок режима работы:
// удержание Стоп/ОК на главном экране - завершение режима,
// поворот/клики влево-вправо - переключение экранов (0..window_max)
void op_buttons(uint8_t window_max);

// Функция заряда.
// напряжение заряда (мВ), ток заряда (мА), минимальный ток заряда (мА),
// ограничение времени заряда в часах
void Charge(uint16_t volt_charge_init, int16_t curr_charge_init,
            int16_t curr_min, uint32_t time_charge);

// Функция разряда аккумулятора
void Discharge(void);

// функция Дозаряда
void AddCharge(uint16_t volt_charge_init, int16_t curr_charge_init,
               int16_t curr_min, uint32_t time_charge);

#if (BRRANIMIR)
// функция заряда по Бранимиру
void Branimir(void);
#endif

// функция Асимметричного заряда
void Asymmetric(void);

// Хранение
void Storage(void);

// Буферный режим
void Buffer(void);

