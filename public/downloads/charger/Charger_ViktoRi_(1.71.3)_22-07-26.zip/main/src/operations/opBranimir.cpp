#include "../core/global.h"
#include "../display/Display.h"
#include "../hardware/DCDC.h"
#include "../hardware/INA226int.h"
#include "operations.h"

#if (BRRANIMIR)

/*
  Заряд по Бранимиру.
  Медленный заряд током 1% емкости с ограничением напряжения заряда.
  Когда напряжение достигнет напряжения заряда - выдержка 20 часов,
  затем на 1 час включается перемешивание электролита: повышенное
  напряжение (напряжение дозаряда) и ток 3% емкости. После - снова заряд.
  И так, пока ток заряда при удержании напряжения не упадет до 0,1% емкости.

  При включении режима ток аккумулятора может постепенно расти от нуля до
  максимального (сульфаты растворяются).
  До тех пор пока ток не поднимется выше (CURR_OFF_CHARGE * 2) защита от
  отключения аккумулятора не работает.
  До тех пор пока ток не поднимется выше (curr_min + curr_min / 2):
  - будет работать таймер 10 часов, если в течении этого времени ток не
  поднимется выше curr_min то работа будет отключена;
  - не будет работать условие - Когда напряжение достигнет напряжения заряда -
  выдержка 20 часов.
*/

// пересчет настроек из 1_User_Setup.h в секунды
#define BRANIMIR_HOLD ((uint32_t)BRANIMIR_HOLD_HOURS * 3600UL)
#define BRANIMIR_MIX ((uint32_t)BRANIMIR_MIX_MINUTES * 60UL)
#define BRANIMIR_LIMIT ((uint32_t)BRANIMIR_LIMIT_DAYS * 86400UL)

// функция заряда по Бранимиру
void Branimir(void) {
#if (PROTECT_BLOCK)
  Protect::Guard();
#endif

  // фаза заряда: напряжение заряда, ток 1% емкости
  const uint16_t volt_charge = profil.charge.voltage;
  const int16_t curr_charge =
      constrain((int16_t)profil.akb.capacity * 10, CUR_CHARGE_MIN, CURRMAXINT);
  // фаза перемешивания: напряжение дозаряда, ток 3% емкости
  const uint16_t volt_mix = profil.add.voltage;
  const int16_t curr_mix =
      constrain((int16_t)profil.akb.capacity * 30, CUR_CHARGE_MIN, CURRMAXINT);
  // ток завершения режима 0,1% емкости
  const int16_t curr_min =
      constrain((int16_t)profil.akb.capacity, CURMIN, CURRMAXINT);

  // вывод напряжения и тока заряда
  print_volt_current(volt_charge, curr_charge);

  TimeCount tyme;
  // время заряда
  tyme.local = profil.charge.stat.time;

  // флаг активности режима
  bool activiti = true;
  // счет выдержки при максимальном напряжении, сек
  uint32_t t_hold = 0;
  // счет времени перемешивания, сек
  uint32_t t_mix = 0;
  // 10 мин
  uint16_t sec_600 = 600;
  // шаги
  uint8_t step = 0;

  Volt_max_check vmax;
#ifdef TYME_OFF_CHARGE
  Disconnect_battery dbat;
#endif
  // флаг - ток превысил минимальный
  bool flag_min_current = false;
  // флаг ток не поднимется выше (CURR_OFF_CHARGE * 2)
  bool flg_curr_up_too_much = false;
  // таймер 10 часов
  uint16_t timer10 = 10 * 3600;

  regims = Regims::REGIM_CHARGE;

  Delay(3000);
  dcdc.start(DCDC_CHARGE);
  dcdc.begin(volt_charge, curr_charge);

  lcd.clear();

  // старт счета времени
  start_second_usr();
  // цикл заряда
  while (activiti and bitRead(profil.flags, Pr_flags::ACTIVITI)) {
    sensor_survey();

    if (butt.tick) {
      // если кнопка нажата - общие кнопки режима
      op_buttons(2);
    }

    // выполнить раз в секунду...
    if (get_second()) {
      step = 1;
      if (sysFlagsError()) {
        // если чтото не так, то выходим
        activiti = false;
        step = 0;
      }
    } // ... выполнить раз в секунду

    // выполнить раз в секунду шаги...
    switch (step) {
    case 0:
      // пустой шаг
      _NOP();
      break;

    case 1:
      // рассчитать количество всех секунд заряда
      tyme.cal_real_tm();
      // статистика
      profil.charge.stat.time = tyme.real_tm;
      profil.charge.stat.ah += Calc_AhWh((int32_t)ina.ampersec);
      profil.charge.stat.wh += Calc_AhWh(ina.getsPower());

      if (tyme.real_tm > BRANIMIR_LIMIT) {
        // предохранительный лимит времени режима
        activiti = false;
        regim_end = Reason::out_time;
      }
      break;

    case 2:
      // вывод на дисплей
      Display_print(profil.charge.stat.ah, profil.charge.stat.wh, tyme.real_tm,
                    Percentage(curr_min));
      break;

    case 3:
      // выполнить раз в 600 сек
      if (--sec_600 == 0) {
        sec_600 = 600;
        // сохранить настройки и статистику в EEPROM
        eepSavedStruct();
      }
      break;

    case 4:
#if (TIME_LIGHT > 0)
      disp.Light_low();
#endif

#if (PROTECT_BLOCK)
      Protect::Guard();
#endif

      if (!flag_min_current) {
        if (ina.curr_aver >= (curr_min + (curr_min >> 1)))
          flag_min_current = true;

        // таймер 10 часов
        if (ina.curr_aver <= curr_min and --timer10 == 0) {
          regim_end = Reason::out_time;
          activiti = false;
          break;
        }
      }

      if (!flg_curr_up_too_much and ina.curr_aver >= (CURR_OFF_CHARGE * 2))
        flg_curr_up_too_much = true;

#ifdef TYME_OFF_CHARGE
      // контроль подключения акб
      if (flg_curr_up_too_much) {
        switch (dbat.check(ina.ampersec)) {
        case 1:
          // сбросить значения
          vmax.volt_max = false;
          break;

        case 2:
          // отключить заряд
          bitClear(profil.flags, Pr_flags::ACTIVITI);
          break;
        }
      }
#endif
      break;

    case 5:
      if (regims == Regims::REGIM_MIXING) {
        // фаза перемешивания
        if (++t_mix >= BRANIMIR_MIX) {
          // перемешивание завершено - вернуться к заряду, окно выдержки заново
          t_mix = 0;
          t_hold = 0;
          vmax.volt_max = false;
          regims = Regims::REGIM_CHARGE;
          dcdc.begin(volt_charge, curr_charge);
        }
        break;
      }

      // фаза заряда
      // когда напряжение достигнет максимального то устанавливается
      // соответствующий флаг, если снизилось на 200 мВ - флаг снимается
      vmax.max_volt_check(volt_charge, ina.volt_aver, ina.curr_aver);

      if (flag_min_current and vmax.volt_max) {
        if (ina.curr_aver <= curr_min) {
          // ток упал до 0,1% емкости - акб готова, завершить режим
          regim_end = Reason::volt_maxCur_min;
          activiti = false;
          break;
        }
        if (++t_hold >= BRANIMIR_HOLD) {
          // выдержка завершена - включить перемешивание
          t_mix = 0;
          vmax.volt_max = false;
          regims = Regims::REGIM_MIXING;
          dcdc.begin(volt_mix, curr_mix);
          break;
        }
      }
      break;
    } // ...выполнить раз в секунду шаги

    if (step) {
      if (++step > 5)
        step = 0;
    }
  }
  // цикл заряда

  dcdc.Off();       // отключить заряд, разряд.
  eepSavedStruct(); // сохранить настройки
#if (PROTECT_BLOCK)
  Protect::Open(false);
#endif
}
#endif
