# Charger_ViktoRi

Зарядное устройство на микроконтроллере Atmega328(LGT8f328p).


## Документация

Полная документация: схемы, режимы работы, калибровка, сборка
https://viktori-leo.github.io/ViktoRi/