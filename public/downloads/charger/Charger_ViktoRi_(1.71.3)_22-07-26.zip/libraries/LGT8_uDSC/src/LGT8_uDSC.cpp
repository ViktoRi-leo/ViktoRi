#include "LGT8_uDSC.h"

#if defined(__LGT8FX8P__)

// функция map() для преобразования числа из одного диапазона в другой
// (время работы около 2 мкс). Требования: in_max > in_min, out_max > out_min.
// Выход ограничивается диапазоном [out_min, out_max] (без экстраполяции).
uint16_t uDSC_map(uint16_t x, uint16_t in_min, uint16_t in_max, uint16_t out_min,
                  uint16_t out_max)
{
    if (x >= in_max)
        return out_max; // ограничение выхода
    if (x <= in_min)
        return out_min; // ограничение выхода
    // дальше x строго внутри (in_min, in_max), поэтому делитель >= 1
    DSC_MUL((uint16_t)(x - in_min), (uint16_t)(out_max - out_min)); // DA = (x - in_min) * (out_max - out_min)
    uint32_t p = DA_get_long();
    if (p & 0x80000000UL)
        uDSC_udiv32_wide(p, (uint16_t)(in_max - in_min)); // произведение >= 2^31
    else
    {
        uDSC_y_op((uint16_t)(in_max - in_min), divd); // DA /= (in_max - in_min)
        uDSC_div_wait();
    }
    return out_min + DA_get_int(); // частное < (out_max - out_min), переполнения нет
}

int16_t uDSC_map_int(int16_t x, int16_t in_min, int16_t in_max, int16_t out_min,
                     int16_t out_max)
{
    if (x >= in_max)
        return out_max; // ограничение выхода
    if (x <= in_min)
        return out_min; // ограничение выхода
    // разности диапазонов int16 могут превышать 32767, но всегда помещаются
    // в uint16 - считаем в беззнаковой (модульной) арифметике
    uint16_t dx = (uint16_t)x - (uint16_t)in_min;
    uint16_t span_out = (uint16_t)out_max - (uint16_t)out_min;
    uint16_t span_in = (uint16_t)in_max - (uint16_t)in_min;
    DSC_MUL(dx, span_out); // DA = dx * span_out
    uint32_t p = DA_get_long();
    if (p & 0x80000000UL)
        uDSC_udiv32_wide(p, span_in); // произведение >= 2^31
    else
    {
        uDSC_y_op(span_in, divd); // DA /= span_in (делитель >= 1, см. выше)
        uDSC_div_wait();
    }
    return (int16_t)((uint16_t)out_min + DA_get_int());
}

#endif // __LGT8FX8P__
