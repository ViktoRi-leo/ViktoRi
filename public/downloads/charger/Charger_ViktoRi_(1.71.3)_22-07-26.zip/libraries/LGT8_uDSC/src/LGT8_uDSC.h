/*
Функции работы с ускорителем вычислений uDSC, встроенным в LGT8F328P.
Сверено с даташитом (LGT8FX8P databook, раздел 4 "Ускоритель вычислений uDSC").

Ускоритель работает с тремя регистрами. Регистры работают как на запись, так и на чтение:
1) DA - регистр 32-бит (аккумулятор), в него сохраняются результаты вычислений;
2) DX - регистр 16-бит, первый операнд;
3) DY - регистр 16-бит, второй операнд.

Регистры uDSC (адрес ввода/вывода):
  DSCR 0x00 - регистр состояния/управления (DSUEN, MM, D1, D0, N, Z, C)
  DSIR 0x01 - регистр инструкций (запись опкода запускает операцию)
  DSSD 0x02 - 16-битный результат переполнения аккумулятора DA
  DSDX 0x10 - операнд DX, 16-битный доступ на чтение/запись
  DSDY 0x11 - операнд DY, 16-битный доступ на чтение/запись
  DSAL 0x38 - аккумулятор DA[15:0],  16-битный доступ
  DSAH 0x39 - аккумулятор DA[31:16], 16-битный доступ

Все операции, кроме деления, выполняются за 1 такт. Деление - 8 тактов,
завершение отслеживается по флагу D1 регистра DSCR (D0 - флаг деления на ноль).

ВНИМАНИЕ (атомарность): регистры uDSC - общее аппаратное состояние.
Последовательность "запись операндов -> операция -> чтение результата" не атомарна.
НЕ используйте функции uDSC внутри прерываний (ISR), если они используются
в основном цикле - результаты будут молча испорчены.

Деление на ноль: программно перехватывается, DA сбрасывается в 0,
функции *_get возвращают 0.

Инструкции uDSC (кодировка DSIR по даташиту):
- сложение.............................. (0x05) DA = DX + DY
- вычитание............................. (0x01) DA = DX - DY
- присвоение............................ (0x1D) DA = DY (без знака)
- присвоение с инверсией................ (0x19) DA = -DY
- инкремент............................. (0x17) DA = DA + DY
- декремент............................. (0x13) DA = DA - DY
- умножение............................. (0x44) DA = DX * DY
- умножение с инверсией................. (0x40) DA = -DX * DY
- умножение со сдвигом.................. (0x4C) DA = (DX * DY) >> 1
- умножение с инверсией со сдвигом...... (0x48) DA = (-DX * DY) >> 1
- умножение с накоплением............... (0x46) DA = DA + DX * DY
- умножение с накоплением со сдвигом.... (0x4E) DA = (DA + DX * DY) >> 1
- умножение с уменьшением............... (0x42) DA = DA - DX * DY
- умножение с уменьшением со сдвигом.... (0x4A) DA = (DA - DX * DY) >> 1
- сброс................................. (0x80) DA = 0
- смена знака........................... (0x84) DA = NEG(DA)
- возведение в квадрат.................. (0x88) DA = DX^2
- возведение в квадрат.................. (0x8A) DA = DY^2
- модуль числа.......................... (0xA0) DA = ABS(DA)
- деление............................... (0xB0) DA = DA / DY
- деление с остатком.................... (0xB1) DA = DA / DY, DY = DA % DY
- сдвиг влево (1-15).................... (0xC0 | n) DA = DA << n
- сдвиг вправо логический (1-15)........ (0xD0 | n) DA = DA >> n
- сдвиг вправо арифметический (1-15).... (0xF0 | n) DA = DA >> n (со знаком)

Знаковые биты-модификаторы опкода (по даташиту):
- класс ADD/SUB (0x05/0x01/0x19/0x17/0x13): бит 5 (sig_S) - знаковая операция;
- класс MAC/MSC (0x4x): бит 5 (sig_S) - знак DX, бит 4 (sig_S0) - знак DY,
  бит 0 (sig_Sa) - знаковое накопление;
- MISC (NEG/ABS/квадраты): бит 0 (sig_Sa) - знаковая операция;
- сдвиг вправо: бит 5 (sig_S) - арифметический сдвиг.

ОСОБЕННОСТИ КРЕМНИЯ (выявлены тестами на железе 2026-07-07..08, три раунда;
см. examples/uDSC_test_verify, examples/uDSC_test_probe и
documents/LGT8_uDSC_AUDIT.md):
- ГЛАВНЫЙ ЭРРАТУМ: у вторичного порта чтения регистрового файла, которым
  16-битный out читает старший байт пары (rN+1), нет байпаса write-back.
  Если инструкция непосредственно перед "out rN" в регистры uDSC пишет
  в rN+1 (типично: компилятор загружает старший байт операнда последним),
  старший байт записывается испорченным. В даташите не документирован.
  Защита библиотеки: nop первой инструкцией каждого asm-блока с 16-битным
  out (+1 такт на операцию), DX_write/DY_write пишут дважды из разных
  регистров (второй out всегда чист), барьеры разнесения регистров
  для равных операндов;
- аппаратный делитель знаково-модульный: делимое фактически 31-битное,
  DA >= 2^31 делится неверно. Библиотека обходит это программной
  реконструкцией (uDSC_udiv32_wide) - для пользователя прозрачно.
  Флаг D1 сбрасывается сразу при запуске деления и взводится через
  7-8 тактов (подтверждено потактовой пробой);
- опкоды -DX*DY (0x40/0x70) и DA = -DY без знака (0x19) дают 0
  (насыщение). Библиотека считает их программно через рабочие опкоды;
- знаковые формы операций "со сдвигом >> 1" (например msc_R 0x7B)
  вставляют неверный старший бит. Библиотека выполняет базовую операцию
  и отдельный арифметический сдвиг (0xF0, подтверждён);
- знаковый MAC (0x77) даёт неверный результат (0x66/0x76 в пробе считали
  верно, но семантика бита S0 не доказана) - знаковые/смешанные MAC
  эмулируются программно. Знаковый MSC (0x73) работает;
- беззнаковый MSC при отрицательном результате насыщается к 0;
- регистр DSSD - это результат, насыщенный до знаковых 16 бит
  (0x7FFF/0x8000 при выходе за диапазон int16).
*/

#ifndef uDSC_h
#define uDSC_h
#include <Arduino.h>

#if defined(__LGT8FX8P__)

/*
UDSC_MUL_SIGN_FIX - коррекция знака после знакового умножения.

ПОДТВЕРЖДЕНО тестом на железе 2026-07-07: знаковое умножение возвращает
корректный результат в дополнительном коде ((-3)*2 = -6), коррекция
не нужна - оставляйте UDSC_MUL_SIGN_FIX = 0. Переключатель сохранён на
случай других ревизий кремния.
*/
#ifndef UDSC_MUL_SIGN_FIX
#define UDSC_MUL_SIGN_FIX 0
#endif

// Все коды операций uDSC (единый enum, кодировка сверена с даташитом)
enum DSCop : uint8_t {
  // класс ADD/SUB: бит 5 (sig_S) - знаковая операция
  add = 0x05,       // сложение   DA = DX + DY
  sub = 0x01,       // вычитание  DA = DX - DY
  da_dy = 0x1D,     // присвоение DA = DY; знаковая форма 0x3D расширяет знак
                    // (обе подтверждены пробой)
  da_neg_dy = 0x19, // присвоение с инверсией DA = -DY; беззнаковая форма 0x19
                    // на кремнии даёт 0 (насыщение), рабочая - знаковая 0x39
  inc = 0x17,       // инкремент DA = DA + DY
  dec = 0x13,       // декремент DA = DA - DY
  // класс MAC/MSC: бит 5 - знак DX, бит 4 - знак DY, бит 0 - знаковое накопление
  mul = 0x44,       // умножение DA = DX * DY
  mul_neg = 0x40,   // DA = -DX * DY; НА КРЕМНИИ НЕ РАБОТАЕТ (даёт 0),
  mul_R = 0x4C,     // умножение со сдвигом DA = (DX * DY) >> 1
  mul_neg_R = 0x48, // DA = (-DX * DY) >> 1; НА КРЕМНИИ НЕ РАБОТАЕТ,
                    // библиотека считает mul_neg программно (mul + neg_da)
  mac = 0x46,       // умножение с накоплением DA = DA + DX * DY; знаковая
                    // форма 0x77 на кремнии неверна - см. DSC_MAC
  mac_R = 0x4E,     // (DA + DX * DY) >> 1; НЕ ИСПОЛЬЗУЕТСЯ: знаковые формы
                    // "со сдвигом" вставляют неверный старший бит - библиотека
                    // делает базовую операцию + отдельный сдвиг
  msc = 0x42,       // умножение с уменьшением DA = DA - DX * DY; знаковая
                    // форма 0x73 подтверждена; беззнаковая насыщается к 0
  msc_R = 0x4A,     // (DA - DX * DY) >> 1; НЕ ИСПОЛЬЗУЕТСЯ - см. mac_R
  // класс MISC: бит 0 - знаковая операция
  reset_da = 0x80,  // сброс DA = 0
  neg_da = 0x84,    // DA = NEG(DA) изменяет знак числа на противоположный
  square_dx = 0x88, // DA = DX^2; НА КРЕМНИИ НЕ РАБОТАЕТ (обрезает операнд),
  square_dy = 0x8A, // DA = DY^2; НА КРЕМНИИ НЕ РАБОТАЕТ - см. DSC_SQR (через mul)
  abs_da = 0xA0,    // DA = ABS(DA) убирает знак числа
  divd = 0xB0,      // деление DA = DA / DY (8 тактов); делимое ограничено
  mod = 0xB1,       // 31 битом (кремний) - см. uDSC_udiv32_wide
                    // деление с остатком DA = DA / DY, DY = DA % DY
  // класс SHIFT: младшие 4 бита - величина сдвига 1..15
  shl = 0xC0,     // сдвиг DA = DA << n
  shr = 0xD0,     // сдвиг DA = DA >> n (логический)
  shr_int = 0xF0, // сдвиг DA = DA >> n (арифметический, со знаком)
  // биты-модификаторы (см. шапку файла)
  sig_S = 0x20,  // знак операции (ADD/SUB, сдвиг вправо) / знак DX (MAC/MSC)
  sig_S0 = 0x10, // знак DY (класс MAC/MSC)
  sig_Sa = 0x01, // знаковое накопление (MAC/MSC) / знаковая операция (MISC)
};

/******************* БАЗОВЫЕ ПРИМИТИВЫ *******************/

// Включить ускоритель вычислений uDSC
inline void uDSC_ON(void) { DSCR |= (1 << DSUEN); }

// Выключить ускоритель вычислений uDSC (энергосбережение)
inline void uDSC_OFF(void) { DSCR &= ~(1 << DSUEN); }

// выполнение любой операции uDSC (запись опкода в DSIR)
inline void uDSC_op(uint8_t operation)
{
    __asm__ __volatile__("out %[pi], %[opc] \n\t" ::[pi] "I"(_SFR_IO_ADDR(DSIR)),
                         [opc] "r"(operation));
}

// записать число 16-бит в регистр DX.
// Двойная запись из разных регистров - самовосстановление от эрратума
// записи rN+1 (см. комментарий над uDSC_xy_op): даже если первый out
// испорчен записью регистра в предыдущей инструкции, второй out идёт
// сразу за out (записей регистров нет) и переписывает значение целиком
inline void DX_write(uint16_t dx)
{
    uint16_t dx2 = dx;
    __asm__ __volatile__("" : "+r"(dx2)); // гарантировать отдельный регистр
    __asm__ __volatile__("out %[px], %[v] \n\t"
                         "out %[px], %[v2] \n\t" ::[px] "I"(_SFR_IO_ADDR(DSDX)),
                         [v] "r"(dx), [v2] "r"(dx2));
}

// записать число 16-бит в регистр DY (двойная запись - см. DX_write)
inline void DY_write(uint16_t dy)
{
    uint16_t dy2 = dy;
    __asm__ __volatile__("" : "+r"(dy2)); // гарантировать отдельный регистр
    __asm__ __volatile__("out %[py], %[v] \n\t"
                         "out %[py], %[v2] \n\t" ::[py] "I"(_SFR_IO_ADDR(DSDY)),
                         [v] "r"(dy), [v2] "r"(dy2));
}

// записать число 32-бит в регистр DA.
// nop защищает первую запись (DSAL) от эрратума записи rN+1; третья
// запись - страховка DSAH из отдельного регистра (проверена на железе)
inline void DA_write_long(uint32_t da)
{
    uint16_t hi = (uint16_t)(da >> 16);
    __asm__ __volatile__("" : "+r"(hi)); // гарантировать отдельный регистр
    __asm__ __volatile__("nop \n\t"
                         "out %[pl], %A[v] \n\t"
                         "out %[ph], %C[v] \n\t"
                         "out %[ph], %[h2] \n\t" ::[pl] "I"(_SFR_IO_ADDR(DSAL)),
                         [ph] "I"(_SFR_IO_ADDR(DSAH)), [v] "r"(da), [h2] "r"(hi));
}

// выгрузить результат вычислений из регистра DA (32-битное число)
inline uint32_t DA_get_long(void)
{
    uint32_t result;
    __asm__ __volatile__("in %A[res], %[pl] \n\t"
                         "in %C[res], %[ph] \n\t"
                         : [res] "=r"(result)
                         : [pl] "I"(_SFR_IO_ADDR(DSAL)), [ph] "I"(_SFR_IO_ADDR(DSAH)));
    return result;
}
inline int32_t DA_get_longt(void) { return (int32_t)DA_get_long(); }

// выгрузить результат вычислений из регистра DA (младшие 16 бит)
inline uint16_t DA_get_int(void)
{
    uint16_t result;
    __asm__ __volatile__("in %[res], %[pl] \n\t"
                         : [res] "=r"(result)
                         : [pl] "I"(_SFR_IO_ADDR(DSAL)));
    return result;
}
inline int16_t DA_get_intt(void) { return (int16_t)DA_get_int(); }

// выгрузить значение регистра DY (16-битное число)
inline uint16_t DY_get(void)
{
    uint16_t result;
    __asm__ __volatile__("in %[res], %[py] \n\t"
                         : [res] "=r"(result)
                         : [py] "I"(_SFR_IO_ADDR(DSDY)));
    return result;
}
inline int16_t DY_get_int(void) { return (int16_t)DY_get(); }

// выгрузить значение регистра DX (16-битное число)
inline uint16_t DX_get(void)
{
    uint16_t result;
    __asm__ __volatile__("in %[res], %[px] \n\t"
                         : [res] "=r"(result)
                         : [px] "I"(_SFR_IO_ADDR(DSDX)));
    return result;
}
inline int16_t DX_get_int(void) { return (int16_t)DX_get(); }

// выгрузить регистр DSSD: результат последней операции, насыщенный до
// знаковых 16 бит (0x7FFF/0x8000 при выходе за диапазон int16 - проба)
inline uint16_t DSSD_get(void)
{
    uint16_t result;
    __asm__ __volatile__("in %[res], %[ps] \n\t"
                         : [res] "=r"(result)
                         : [ps] "I"(_SFR_IO_ADDR(DSSD)));
    return result;
}

/************** ВНУТРЕННИЕ ХЕЛПЕРЫ (не API) **************/

/*
Эрратум кремния (выведен по трём раундам тестов, см. AUDIT): у вторичного
порта чтения регистрового файла, которым 16-битный out читает старший байт
пары (rN+1), нет байпаса write-back. Если инструкция НЕПОСРЕДСТВЕННО перед
"out rN" пишет в rN+1, старший байт уходит в регистр uDSC испорченным.
Защита: nop первой инструкцией asm-блока - тогда перед первым out
гарантированно нет записи регистров, независимо от кодогенерации.
Последующие out внутри блока безопасны сами по себе (out ничего не пишет
в регистровый файл). Цена - 1 такт на операцию.
*/

// операция над DX, DY: запись операндов + запуск опкода одним asm-блоком.
// Барьер дополнительно гарантирует dy в отдельном регистре от dx
// (при равных операндах компилятор дал бы им один регистр)
inline void uDSC_xy_op(uint16_t dx, uint16_t dy, uint8_t op)
{
    __asm__ __volatile__("" : "+r"(dy));
    __asm__ __volatile__("nop \n\t" // защита от эрратума записи rN+1 (см. выше)
                         "out %[px], %[dx] \n\t"
                         "out %[py], %[dy] \n\t"
                         "out %[pi], %[opc] \n\t" ::[px] "I"(_SFR_IO_ADDR(DSDX)),
                         [py] "I"(_SFR_IO_ADDR(DSDY)), [pi] "I"(_SFR_IO_ADDR(DSIR)),
                         [dx] "r"(dx), [dy] "r"(dy), [opc] "r"(op));
}

// операция над DA, DY: запись операндов + запуск опкода одним asm-блоком
inline void uDSC_ay_op(uint32_t da, uint16_t dy, uint8_t op)
{
    __asm__ __volatile__("" : "+r"(dy));
    __asm__ __volatile__("nop \n\t" // защита от эрратума записи rN+1
                         "out %[pl], %A[da] \n\t"
                         "out %[ph], %C[da] \n\t"
                         "out %[py], %[dy] \n\t"
                         "out %[pi], %[opc] \n\t" ::[pl] "I"(_SFR_IO_ADDR(DSAL)),
                         [ph] "I"(_SFR_IO_ADDR(DSAH)), [py] "I"(_SFR_IO_ADDR(DSDY)),
                         [pi] "I"(_SFR_IO_ADDR(DSIR)), [da] "r"(da), [dy] "r"(dy),
                         [opc] "r"(op));
}

// операция над DY (DA уже содержит значение): запись DY + запуск опкода
inline void uDSC_y_op(uint16_t dy, uint8_t op)
{
    __asm__ __volatile__("nop \n\t" // защита от эрратума записи rN+1
                         "out %[py], %[dy] \n\t"
                         "out %[pi], %[opc] \n\t" ::[py] "I"(_SFR_IO_ADDR(DSDY)),
                         [pi] "I"(_SFR_IO_ADDR(DSIR)), [dy] "r"(dy), [opc] "r"(op));
}

// ожидание завершения деления (8 тактов): D1 - готово, D0 - деление на ноль.
// Два nop - страховка от опроса до фактического сброса флага D1 аппаратурой
// (деление всё равно занимает 8 тактов, времени это не добавляет)
inline void uDSC_div_wait(void)
{
    __asm__ __volatile__("nop \n\t"
                         "nop \n\t");
    while ((DSCR & ((1 << DSD1) | (1 << DSD0))) == 0)
        ;
}

// модуль 16/32-битного числа без переполнения на INT_MIN
inline uint16_t uDSC_mag16(int16_t v) { return (v < 0) ? (uint16_t)(-(uint16_t)v) : (uint16_t)v; }
inline uint32_t uDSC_mag32(int32_t v) { return (v < 0) ? (uint32_t)(-(uint32_t)v) : (uint32_t)v; }

// Беззнаковое деление для делимого >= 2^31: аппаратный делитель
// знаково-модульный (делимое фактически 31-битное, кремний), поэтому делим
// аппаратно da/2 с остатком и программно реконструируем полный результат.
// Частное записывается в DA, возврат - остаток. Вызывать при dy != 0.
inline uint16_t uDSC_udiv32_wide(uint32_t da, uint16_t dy)
{
    uDSC_ay_op(da >> 1, dy, mod); // DA = (da/2)/dy, DY = (da/2)%dy
    uDSC_div_wait();
    uint32_t q = DA_get_long() << 1;                    // 2 * q1
    uint32_t t = ((uint32_t)DY_get() << 1) | (da & 1);  // 2 * r1 + младший бит
    if (t >= dy)
    {
        q++;
        t -= dy;
    }
    DA_write_long(q); // контракт функций деления: частное в DA
    return (uint16_t)t;
}

// Беззнаковое деление с остатком (любое 32-битное делимое):
// частное в DA, возврат - остаток. Остаток НЕ полагается на чтение/запись
// регистра DY снаружи (запись в DY на кремнии ненадёжна).
inline uint16_t uDSC_umod32(uint32_t da, uint16_t dy)
{
    if (dy == 0)
    {
        uDSC_op(reset_da); // защита от деления на ноль: DA = 0
        return 0;
    }
    if (da & 0x80000000UL)
        return uDSC_udiv32_wide(da, dy);
    uDSC_ay_op(da, dy, mod);
    uDSC_div_wait();
    return DY_get();
}

// коррекция знака после знакового умножения (см. UDSC_MUL_SIGN_FIX)
inline void uDSC_mul_sign_fix(void)
{
#if UDSC_MUL_SIGN_FIX
    if (DSCR & (1 << DSN))
        uDSC_op(neg_da); // DA = NEG(DA)
#endif
}

/****************** УМНОЖЕНИЕ DA = DX * DY ******************/

// умножение целых чисел. Запись результата в DA.
inline void DSC_MUL(uint16_t dx, uint16_t dy) { uDSC_xy_op(dx, dy, mul); }
inline void DSC_MUL(int16_t dx, int16_t dy)
{
    uDSC_xy_op((uint16_t)dx, (uint16_t)dy, mul | sig_S | sig_S0);
    uDSC_mul_sign_fix();
}
inline void DSC_MUL(uint16_t dx, int16_t dy)
{
    uDSC_xy_op(dx, (uint16_t)dy, mul | sig_S0);
    uDSC_mul_sign_fix();
}
inline void DSC_MUL(int16_t dx, uint16_t dy)
{
    uDSC_xy_op((uint16_t)dx, dy, mul | sig_S);
    uDSC_mul_sign_fix();
}

// умножение целых чисел. Возврат 32-битного результата из DA.
inline uint32_t DSC_MUL_get(uint16_t dx, uint16_t dy) { DSC_MUL(dx, dy); return DA_get_long(); }
inline int32_t DSC_MUL_get(int16_t dx, int16_t dy) { DSC_MUL(dx, dy); return DA_get_longt(); }
inline int32_t DSC_MUL_get(uint16_t dx, int16_t dy) { DSC_MUL(dx, dy); return DA_get_longt(); }
inline int32_t DSC_MUL_get(int16_t dx, uint16_t dy) { DSC_MUL(dx, dy); return DA_get_longt(); }

/*********** УМНОЖЕНИЕ СО СДВИГОМ DA = (DX * DY) >> 1 ***********/
// беззнаковый опкод 0x4C подтверждён железом; знаковые формы "со сдвигом"
// на кремнии вставляют неверный старший бит (как msc_R 0x7B), поэтому
// знаковые варианты - рабочее умножение + арифметический сдвиг

inline void DSC_MUL_R(uint16_t dx, uint16_t dy) { uDSC_xy_op(dx, dy, mul_R); }
inline void DSC_MUL_R(int16_t dx, int16_t dy) { DSC_MUL(dx, dy); uDSC_op(shr_int | 1); }
inline void DSC_MUL_R(uint16_t dx, int16_t dy) { DSC_MUL(dx, dy); uDSC_op(shr_int | 1); }
inline void DSC_MUL_R(int16_t dx, uint16_t dy) { DSC_MUL(dx, dy); uDSC_op(shr_int | 1); }

inline uint32_t DSC_MUL_R_get(uint16_t dx, uint16_t dy) { DSC_MUL_R(dx, dy); return DA_get_long(); }
inline int32_t DSC_MUL_R_get(int16_t dx, int16_t dy) { DSC_MUL_R(dx, dy); return DA_get_longt(); }
inline int32_t DSC_MUL_R_get(uint16_t dx, int16_t dy) { DSC_MUL_R(dx, dy); return DA_get_longt(); }
inline int32_t DSC_MUL_R_get(int16_t dx, uint16_t dy) { DSC_MUL_R(dx, dy); return DA_get_longt(); }

/*********** УМНОЖЕНИЕ С ИНВЕРСИЕЙ DA = -DX * DY ***********/
// аппаратные опкоды 0x40/0x70 на кремнии дают 0 - считаем программно:
// рабочее умножение + аппаратная смена знака (итого 2 такта)

inline void DSC_MUL_NEG(uint16_t dx, uint16_t dy) { DSC_MUL(dx, dy); uDSC_op(neg_da); }
inline void DSC_MUL_NEG(int16_t dx, int16_t dy) { DSC_MUL(dx, dy); uDSC_op(neg_da); }
inline void DSC_MUL_NEG(uint16_t dx, int16_t dy) { DSC_MUL(dx, dy); uDSC_op(neg_da); }
inline void DSC_MUL_NEG(int16_t dx, uint16_t dy) { DSC_MUL(dx, dy); uDSC_op(neg_da); }

inline int32_t DSC_MUL_NEG_get(uint16_t dx, uint16_t dy) { DSC_MUL_NEG(dx, dy); return DA_get_longt(); }
inline int32_t DSC_MUL_NEG_get(int16_t dx, int16_t dy) { DSC_MUL_NEG(dx, dy); return DA_get_longt(); }
inline int32_t DSC_MUL_NEG_get(uint16_t dx, int16_t dy) { DSC_MUL_NEG(dx, dy); return DA_get_longt(); }
inline int32_t DSC_MUL_NEG_get(int16_t dx, uint16_t dy) { DSC_MUL_NEG(dx, dy); return DA_get_longt(); }

/***** УМНОЖЕНИЕ С ИНВЕРСИЕЙ СО СДВИГОМ DA = (-DX * DY) >> 1 *****/
// программно: mul + neg_da + арифметический сдвиг (0xF0 подтверждён железом)

inline void DSC_MUL_NEG_R(uint16_t dx, uint16_t dy) { DSC_MUL_NEG(dx, dy); uDSC_op(shr_int | 1); }
inline void DSC_MUL_NEG_R(int16_t dx, int16_t dy) { DSC_MUL_NEG(dx, dy); uDSC_op(shr_int | 1); }
inline void DSC_MUL_NEG_R(uint16_t dx, int16_t dy) { DSC_MUL_NEG(dx, dy); uDSC_op(shr_int | 1); }
inline void DSC_MUL_NEG_R(int16_t dx, uint16_t dy) { DSC_MUL_NEG(dx, dy); uDSC_op(shr_int | 1); }

inline int32_t DSC_MUL_NEG_R_get(uint16_t dx, uint16_t dy) { DSC_MUL_NEG_R(dx, dy); return DA_get_longt(); }
inline int32_t DSC_MUL_NEG_R_get(int16_t dx, int16_t dy) { DSC_MUL_NEG_R(dx, dy); return DA_get_longt(); }
inline int32_t DSC_MUL_NEG_R_get(uint16_t dx, int16_t dy) { DSC_MUL_NEG_R(dx, dy); return DA_get_longt(); }
inline int32_t DSC_MUL_NEG_R_get(int16_t dx, uint16_t dy) { DSC_MUL_NEG_R(dx, dy); return DA_get_longt(); }

/****** УМНОЖЕНИЕ С НАКОПЛЕНИЕМ DA = DA + DX * DY (MAC) ******/
// беззнаковый вариант (0x46) подтверждён железом; знаковый аппаратный (0x77)
// на кремнии даёт неверный результат, поэтому знаковые/смешанные варианты
// эмулируются программно (чтение DA + mul + сложение в C + запись DA,
// ~12 тактов) до выяснения через examples/uDSC_test_probe

inline void DSC_MAC(uint16_t dx, uint16_t dy) { uDSC_xy_op(dx, dy, mac); }
inline void DSC_MAC(int16_t dx, int16_t dy)
{
    int32_t acc = DA_get_longt();
    DSC_MUL(dx, dy);
    DA_write_long((uint32_t)(acc + DA_get_longt()));
}
inline void DSC_MAC(uint16_t dx, int16_t dy)
{
    int32_t acc = DA_get_longt();
    DSC_MUL(dx, dy);
    DA_write_long((uint32_t)(acc + DA_get_longt()));
}
inline void DSC_MAC(int16_t dx, uint16_t dy)
{
    int32_t acc = DA_get_longt();
    DSC_MUL(dx, dy);
    DA_write_long((uint32_t)(acc + DA_get_longt()));
}

inline uint32_t DSC_MAC_get(uint16_t dx, uint16_t dy) { DSC_MAC(dx, dy); return DA_get_long(); }
inline int32_t DSC_MAC_get(int16_t dx, int16_t dy) { DSC_MAC(dx, dy); return DA_get_longt(); }
inline int32_t DSC_MAC_get(uint16_t dx, int16_t dy) { DSC_MAC(dx, dy); return DA_get_longt(); }
inline int32_t DSC_MAC_get(int16_t dx, uint16_t dy) { DSC_MAC(dx, dy); return DA_get_longt(); }

/* умножение с накоплением со сдвигом DA = (DA + DX * DY) >> 1.
   Аппаратные формы "со сдвигом" не используются (неверный старший бит):
   базовая операция + отдельный сдвиг */
inline void DSC_MAC_R(uint16_t dx, uint16_t dy) { DSC_MAC(dx, dy); uDSC_op(shr | 1); }
inline void DSC_MAC_R(int16_t dx, int16_t dy) { DSC_MAC(dx, dy); uDSC_op(shr_int | 1); }
inline void DSC_MAC_R(uint16_t dx, int16_t dy) { DSC_MAC(dx, dy); uDSC_op(shr_int | 1); }
inline void DSC_MAC_R(int16_t dx, uint16_t dy) { DSC_MAC(dx, dy); uDSC_op(shr_int | 1); }

inline uint32_t DSC_MAC_R_get(uint16_t dx, uint16_t dy) { DSC_MAC_R(dx, dy); return DA_get_long(); }
inline int32_t DSC_MAC_R_get(int16_t dx, int16_t dy) { DSC_MAC_R(dx, dy); return DA_get_longt(); }
inline int32_t DSC_MAC_R_get(uint16_t dx, int16_t dy) { DSC_MAC_R(dx, dy); return DA_get_longt(); }
inline int32_t DSC_MAC_R_get(int16_t dx, uint16_t dy) { DSC_MAC_R(dx, dy); return DA_get_longt(); }

/****** УМНОЖЕНИЕ С УМЕНЬШЕНИЕМ DA = DA - DX * DY (MSC) ******/
// беззнаковый (0x42) и знаковый (0x73) варианты подтверждены железом

inline void DSC_MSC(uint16_t dx, uint16_t dy) { uDSC_xy_op(dx, dy, msc); }
inline void DSC_MSC(int16_t dx, int16_t dy) { uDSC_xy_op((uint16_t)dx, (uint16_t)dy, msc | sig_S | sig_S0 | sig_Sa); }
inline void DSC_MSC(uint16_t dx, int16_t dy) { uDSC_xy_op(dx, (uint16_t)dy, msc | sig_S0 | sig_Sa); }
inline void DSC_MSC(int16_t dx, uint16_t dy) { uDSC_xy_op((uint16_t)dx, dy, msc | sig_S | sig_Sa); }

inline uint32_t DSC_MSC_get(uint16_t dx, uint16_t dy) { DSC_MSC(dx, dy); return DA_get_long(); }
inline int32_t DSC_MSC_get(int16_t dx, int16_t dy) { DSC_MSC(dx, dy); return DA_get_longt(); }
inline int32_t DSC_MSC_get(uint16_t dx, int16_t dy) { DSC_MSC(dx, dy); return DA_get_longt(); }
inline int32_t DSC_MSC_get(int16_t dx, uint16_t dy) { DSC_MSC(dx, dy); return DA_get_longt(); }

/* умножение с уменьшением со сдвигом DA = (DA - DX * DY) >> 1 (Апроксимация).
   Аппаратная знаковая форма 0x7B на кремнии вставляет неверный старший бит
   (тест round 2: 600 | 0x80000000): базовая операция + отдельный сдвиг */
inline void DSC_MSC_R(uint16_t dx, uint16_t dy) { DSC_MSC(dx, dy); uDSC_op(shr | 1); }
inline void DSC_MSC_R(int16_t dx, int16_t dy) { DSC_MSC(dx, dy); uDSC_op(shr_int | 1); }
inline void DSC_MSC_R(uint16_t dx, int16_t dy) { DSC_MSC(dx, dy); uDSC_op(shr_int | 1); }
inline void DSC_MSC_R(int16_t dx, uint16_t dy) { DSC_MSC(dx, dy); uDSC_op(shr_int | 1); }

inline uint32_t DSC_MSC_R_get(uint16_t dx, uint16_t dy) { DSC_MSC_R(dx, dy); return DA_get_long(); }
inline int32_t DSC_MSC_R_get(int16_t dx, int16_t dy) { DSC_MSC_R(dx, dy); return DA_get_longt(); }
inline int32_t DSC_MSC_R_get(uint16_t dx, int16_t dy) { DSC_MSC_R(dx, dy); return DA_get_longt(); }
inline int32_t DSC_MSC_R_get(int16_t dx, uint16_t dy) { DSC_MSC_R(dx, dy); return DA_get_longt(); }

/****************** СЛОЖЕНИЕ DA = DX + DY ******************/

// сложение целых чисел без знака. Запись результата в DA.
inline void DSC_ADD(uint16_t dx, uint16_t dy) { uDSC_xy_op(dx, dy, add); }
// сложение целых чисел со знаком (один знаковый бит на всю операцию, по даташиту)
inline void DSC_ADD(int16_t dx, int16_t dy) { uDSC_xy_op((uint16_t)dx, (uint16_t)dy, add | sig_S); }
// смешанные типы: у операции ADD один знаковый бит, поэтому беззнаковый операнд
// расширяется в DA программно, знаковый прибавляется инкрементом
inline void DSC_ADD(uint16_t dx, int16_t dy) { uDSC_ay_op((uint32_t)dx, (uint16_t)dy, inc | sig_S); }
inline void DSC_ADD(int16_t dx, uint16_t dy) { uDSC_ay_op((uint32_t)(int32_t)dx, dy, inc); }

// сложение DA = da + dy (32-битный операнд + 16-битный)
inline void DSC_ADD(uint32_t da, uint16_t dy) { uDSC_ay_op(da, dy, inc); }
inline void DSC_ADD(int32_t da, int16_t dy) { uDSC_ay_op((uint32_t)da, (uint16_t)dy, inc | sig_S); }
inline void DSC_ADD(uint32_t da, int16_t dy) { uDSC_ay_op(da, (uint16_t)dy, inc | sig_S); }
inline void DSC_ADD(int32_t da, uint16_t dy) { uDSC_ay_op((uint32_t)da, dy, inc); }

// сложение. Возврат 32-битного результата из DA.
inline uint32_t DSC_ADD_get(uint16_t dx, uint16_t dy) { DSC_ADD(dx, dy); return DA_get_long(); }
inline int32_t DSC_ADD_get(int16_t dx, int16_t dy) { DSC_ADD(dx, dy); return DA_get_longt(); }
inline int32_t DSC_ADD_get(uint16_t dx, int16_t dy) { DSC_ADD(dx, dy); return DA_get_longt(); }
inline int32_t DSC_ADD_get(int16_t dx, uint16_t dy) { DSC_ADD(dx, dy); return DA_get_longt(); }
inline uint32_t DSC_ADD_get(uint32_t da, uint16_t dy) { DSC_ADD(da, dy); return DA_get_long(); }
inline int32_t DSC_ADD_get(int32_t da, int16_t dy) { DSC_ADD(da, dy); return DA_get_longt(); }
inline int32_t DSC_ADD_get(uint32_t da, int16_t dy) { DSC_ADD(da, dy); return DA_get_longt(); }
inline int32_t DSC_ADD_get(int32_t da, uint16_t dy) { DSC_ADD(da, dy); return DA_get_longt(); }

/****************** ВЫЧИТАНИЕ DA = DX - DY ******************/

// вычитание целых чисел без знака. Запись результата в DA.
inline void DSC_SUB(uint16_t dx, uint16_t dy) { uDSC_xy_op(dx, dy, sub); }
// вычитание целых чисел со знаком (один знаковый бит на всю операцию, по даташиту)
inline void DSC_SUB(int16_t dx, int16_t dy) { uDSC_xy_op((uint16_t)dx, (uint16_t)dy, sub | sig_S); }
// смешанные типы: через программное расширение первого операнда в DA + декремент
inline void DSC_SUB(uint16_t dx, int16_t dy) { uDSC_ay_op((uint32_t)dx, (uint16_t)dy, dec | sig_S); }
inline void DSC_SUB(int16_t dx, uint16_t dy) { uDSC_ay_op((uint32_t)(int32_t)dx, dy, dec); }

// вычитание DA = da - dy (32-битный операнд - 16-битный)
inline void DSC_SUB(uint32_t da, uint16_t dy) { uDSC_ay_op(da, dy, dec); }
inline void DSC_SUB(int32_t da, int16_t dy) { uDSC_ay_op((uint32_t)da, (uint16_t)dy, dec | sig_S); }
inline void DSC_SUB(uint32_t da, int16_t dy) { uDSC_ay_op(da, (uint16_t)dy, dec | sig_S); }
inline void DSC_SUB(int32_t da, uint16_t dy) { uDSC_ay_op((uint32_t)da, dy, dec); }

// вычитание. Возврат 32-битного результата из DA.
inline uint32_t DSC_SUB_get(uint16_t dx, uint16_t dy) { DSC_SUB(dx, dy); return DA_get_long(); }
inline int32_t DSC_SUB_get(int16_t dx, int16_t dy) { DSC_SUB(dx, dy); return DA_get_longt(); }
inline int32_t DSC_SUB_get(uint16_t dx, int16_t dy) { DSC_SUB(dx, dy); return DA_get_longt(); }
inline int32_t DSC_SUB_get(int16_t dx, uint16_t dy) { DSC_SUB(dx, dy); return DA_get_longt(); }
inline uint32_t DSC_SUB_get(uint32_t da, uint16_t dy) { DSC_SUB(da, dy); return DA_get_long(); }
inline int32_t DSC_SUB_get(int32_t da, int16_t dy) { DSC_SUB(da, dy); return DA_get_longt(); }
inline int32_t DSC_SUB_get(uint32_t da, int16_t dy) { DSC_SUB(da, dy); return DA_get_longt(); }
inline int32_t DSC_SUB_get(int32_t da, uint16_t dy) { DSC_SUB(da, dy); return DA_get_longt(); }

/**************** ДЕЛЕНИЕ DA = da / dy (8 тактов) ****************/
// при dy == 0: DA сбрасывается в 0, *_get возвращает 0

// деление целых чисел без знака. Запись результата в DA.
inline void DSC_DIV(uint32_t da, uint16_t dy)
{
    if (dy == 0)
    {
        uDSC_op(reset_da); // защита от деления на ноль: DA = 0
        return;
    }
    if (da & 0x80000000UL)
    {
        uDSC_udiv32_wide(da, dy); // делимое >= 2^31: обход ограничения кремния
        return;
    }
    uDSC_ay_op(da, dy, divd);
    uDSC_div_wait();
}
// деление целых чисел со знаком: аппаратный делитель беззнаковый,
// знак обрабатывается программно
inline void DSC_DIV(int32_t da, int16_t dy)
{
    bool neg = (da < 0) ^ (dy < 0);
    DSC_DIV(uDSC_mag32(da), uDSC_mag16(dy));
    if (neg)
        uDSC_op(neg_da); // DA = NEG(DA)
}
inline void DSC_DIV(uint32_t da, int16_t dy)
{
    bool neg = (dy < 0);
    DSC_DIV(da, uDSC_mag16(dy));
    if (neg)
        uDSC_op(neg_da);
}
inline void DSC_DIV(int32_t da, uint16_t dy)
{
    bool neg = (da < 0);
    DSC_DIV(uDSC_mag32(da), dy);
    if (neg)
        uDSC_op(neg_da);
}

// деление. Возврат 32-битного результата из DA.
inline uint32_t DSC_DIV_get(uint32_t da, uint16_t dy) { DSC_DIV(da, dy); return DA_get_long(); }
inline int32_t DSC_DIV_get(int32_t da, int16_t dy) { DSC_DIV(da, dy); return DA_get_longt(); }
inline int32_t DSC_DIV_get(uint32_t da, int16_t dy) { DSC_DIV(da, dy); return DA_get_longt(); }
inline int32_t DSC_DIV_get(int32_t da, uint16_t dy) { DSC_DIV(da, dy); return DA_get_longt(); }

/******** ДЕЛЕНИЕ С ОСТАТКОМ DA = da / dy, остаток = da % dy ********/
// при dy == 0: DA сбрасывается в 0, *_get возвращает 0.
// ВНИМАНИЕ: надёжный способ получить остаток - возврат из DSC_MOD_get.
// Регистр DY после void-вариантов содержит МОДУЛЬ остатка только при
// делимом < 2^31 (запись в DY на кремнии ненадёжна, знак в него не пишется).

// остаток от деления целых чисел без знака. Частное в DA.
inline void DSC_MOD(uint32_t da, uint16_t dy) { uDSC_umod32(da, dy); }
// остаток от деления целых чисел со знаком (семантика C:
// знак остатка = знак делимого, знак частного = XOR знаков). Частное в DA.
inline void DSC_MOD(int32_t da, int16_t dy)
{
    bool negQ = (da < 0) ^ (dy < 0);
    uDSC_umod32(uDSC_mag32(da), uDSC_mag16(dy));
    if (negQ)
        uDSC_op(neg_da); // частное: DA = NEG(DA)
}
inline void DSC_MOD(uint32_t da, int16_t dy)
{
    bool negQ = (dy < 0);
    uDSC_umod32(da, uDSC_mag16(dy));
    if (negQ)
        uDSC_op(neg_da);
}
inline void DSC_MOD(int32_t da, uint16_t dy)
{
    bool negQ = (da < 0);
    uDSC_umod32(uDSC_mag32(da), dy);
    if (negQ)
        uDSC_op(neg_da);
}

// остаток от деления. Возврат остатка (частное остаётся в DA).
inline uint16_t DSC_MOD_get(uint32_t da, uint16_t dy) { return uDSC_umod32(da, dy); }
inline int16_t DSC_MOD_get(int32_t da, int16_t dy)
{
    bool negR = (da < 0);
    bool negQ = negR ^ (dy < 0);
    uint16_t r = uDSC_umod32(uDSC_mag32(da), uDSC_mag16(dy));
    if (negQ)
        uDSC_op(neg_da); // частное: DA = NEG(DA)
    return negR ? -(int16_t)r : (int16_t)r; // остаток со знаком делимого
}
inline uint16_t DSC_MOD_get(uint32_t da, int16_t dy)
{
    bool negQ = (dy < 0);
    uint16_t r = uDSC_umod32(da, uDSC_mag16(dy));
    if (negQ)
        uDSC_op(neg_da);
    return r;
}
inline int16_t DSC_MOD_get(int32_t da, uint16_t dy)
{
    bool negR = (da < 0);
    uint16_t r = uDSC_umod32(uDSC_mag32(da), dy);
    if (negR)
        uDSC_op(neg_da);
    return negR ? -(int16_t)r : (int16_t)r;
}

/*************** ОПЕРАЦИИ НАД АККУМУЛЯТОРОМ DA ***************/

// Инкремент регистра DA += dy
inline void DA_INC(uint16_t dy) { uDSC_y_op(dy, inc); }
inline void DA_INC(int16_t dy) { uDSC_y_op((uint16_t)dy, inc | sig_S); }
inline uint32_t DA_INC_get(uint16_t dy) { DA_INC(dy); return DA_get_long(); }
inline int32_t DA_INC_get(int16_t dy) { DA_INC(dy); return DA_get_longt(); }

// Декремент регистра DA -= dy
inline void DA_DEC(uint16_t dy) { uDSC_y_op(dy, dec); }
inline void DA_DEC(int16_t dy) { uDSC_y_op((uint16_t)dy, dec | sig_S); }
inline uint32_t DA_DEC_get(uint16_t dy) { DA_DEC(dy); return DA_get_long(); }
inline int32_t DA_DEC_get(int16_t dy) { DA_DEC(dy); return DA_get_longt(); }

// Деление регистра DA /= dy. DA трактуется БЕЗ знака (при dy == 0: DA = 0)
inline void DA_DIV(uint16_t dy)
{
    if (dy == 0)
    {
        uDSC_op(reset_da); // защита от деления на ноль: DA = 0
        return;
    }
    uint32_t da = DA_get_long();
    if (da & 0x80000000UL)
    {
        uDSC_udiv32_wide(da, dy); // делимое >= 2^31: обход ограничения кремния
        return;
    }
    uDSC_y_op(dy, divd);
    uDSC_div_wait();
}
// Деление регистра DA /= dy. DA трактуется СО знаком (при dy == 0: DA = 0)
inline void DA_DIV(int16_t dy)
{
    int32_t da = DA_get_longt();
    bool neg = (da < 0) ^ (dy < 0);
    uint16_t udy = uDSC_mag16(dy);
    if (udy == 0)
    {
        uDSC_op(reset_da);
        return;
    }
    uint32_t uda = uDSC_mag32(da);
    if (uda & 0x80000000UL)
        uDSC_udiv32_wide(uda, udy); // |INT32_MIN| = 2^31: обход ограничения
    else
    {
        uDSC_op(abs_da); // DA = ABS(DA)
        uDSC_y_op(udy, divd);
        uDSC_div_wait();
    }
    if (neg)
        uDSC_op(neg_da); // DA = NEG(DA)
}
inline uint32_t DA_DIV_get(uint16_t dy) { DA_DIV(dy); return DA_get_long(); }
inline int32_t DA_DIV_get(int16_t dy) { DA_DIV(dy); return DA_get_longt(); }

// Присвоение DA = значение
inline void DA_SET(uint32_t da) { DA_write_long(da); }
inline void DA_SET(int32_t da) { DA_write_long((uint32_t)da); }
inline void DA_SET(uint16_t dy) { uDSC_y_op(dy, da_dy); }         // аппаратное DA = DY
inline void DA_SET(int16_t dy) { uDSC_y_op((uint16_t)dy, da_dy | sig_S); } // 0x3D: знаковое, подтверждено пробой

// Присвоение с инверсией DA = -dy.
// Беззнаковый вариант - программно: аппаратный опкод 0x19 на кремнии
// насыщает отрицательный результат к нулю. Знаковый (0x39) подтверждён.
inline void DA_SET_NEG(uint16_t dy) { DA_write_long(0UL - (uint32_t)dy); }
inline void DA_SET_NEG(int16_t dy) { uDSC_y_op((uint16_t)dy, da_neg_dy | sig_S); }

// Возведение в квадрат DA = d^2 (всегда неотрицателен).
// Через рабочее умножение: аппаратные опкоды квадрата (0x88/0x8A)
// на кремнии обрезают операнд
inline void DSC_SQR(uint16_t d) { DSC_MUL(d, d); }
inline void DSC_SQR(int16_t d)
{
    uint16_t m = uDSC_mag16(d);
    DSC_MUL(m, m);
}
inline uint32_t DSC_SQR_get(uint16_t d) { DSC_SQR(d); return DA_get_long(); }
inline uint32_t DSC_SQR_get(int16_t d) { DSC_SQR(d); return DA_get_long(); }

// Сброс DA = 0
inline void DA_RESET(void) { uDSC_op(reset_da); }
// Смена знака DA = NEG(DA)
inline void DA_NEG(void) { uDSC_op(neg_da); }
// Модуль DA = ABS(DA)
inline void DA_ABS(void) { uDSC_op(abs_da); }

// сдвиг DA >> shift, логический (1 - 15)
inline void DA_shiftR(uint8_t shift) { uDSC_op(shr | (shift & 0x0F)); }
// сдвиг DA >> shift, арифметический - со знаком (1 - 15)
inline void DA_shiftR_int(uint8_t shift) { uDSC_op(shr_int | (shift & 0x0F)); }
// сдвиг DA << shift (1 - 15)
inline void DA_shiftL(uint8_t shift) { uDSC_op(shl | (shift & 0x0F)); }

/************************* map() *************************/

// функция map() для преобразования числа из одного диапазона в другой
// (время работы около 2 мкс). Требования: in_max > in_min, out_max > out_min.
// Выход ограничивается диапазоном [out_min, out_max] (без экстраполяции).
uint16_t uDSC_map(uint16_t x, uint16_t in_min, uint16_t in_max, uint16_t out_min,
                  uint16_t out_max) __attribute__((noinline));

int16_t uDSC_map_int(int16_t x, int16_t in_min, int16_t in_max, int16_t out_min,
                     int16_t out_max) __attribute__((noinline));

#endif // __LGT8FX8P__

#endif // uDSC_h
