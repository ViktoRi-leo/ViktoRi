/*
Проверочный скетч библиотеки LGT8_uDSC на железе (LGT8F328P).
Каждый тест сравнивает результат uDSC с эталоном, посчитанным компилятором,
и печатает OK/FAIL.

Round 1 (2026-07-07): 47 PASS / 10 FAIL - выявлены особенности кремния
(знаково-модульный делитель, нерабочие опкоды -DX*DY / -DY без знака,
аномалия знакового MAC). Библиотека обходит их программно; знаковое
умножение подтверждено корректным (UDSC_MUL_SIGN_FIX = 0).

Round 2 (2026-07-07): 67 PASS / 2 FAIL + проба: найдены нерабочие знаковые
формы "со сдвигом" (0x7B и т.п.), подтверждён 0x3D, снят вопрос тайминга
деления.

Round 3 (2026-07-08): 68 PASS / 3 FAIL - выведен истинный механизм всех
аномалий записи: у вторичного порта чтения регистрового файла (старший байт
rN+1 при 16-битном out) нет байпаса write-back. Если инструкция прямо перед
"out rN" пишет rN+1 - старший байт портится (подтверждено дизассемблером
всех трёх фейлов, включая точное совпадение DX = 0xFF0B -> -97937).
Защита: nop первой инструкцией каждого asm-блока с 16-битным out.
После round 3 фиксов ожидается 0 FAIL.
*/

#include <Arduino.h>
// #define UDSC_MUL_SIGN_FIX 1  // раскомментировать по результату теста
#include <LGT8_uDSC.h>

uint16_t pass = 0, fail = 0;

void check(const char *name, int32_t got, int32_t expected) {
  bool ok = (got == expected);
  ok ? pass++ : fail++;
  Serial.print(ok ? F("OK   ") : F("FAIL "));
  Serial.print(name);
  Serial.print(F(": got "));
  Serial.print(got);
  Serial.print(F(", expected "));
  Serial.println(expected);
}

void checkU(const char *name, uint32_t got, uint32_t expected) {
  bool ok = (got == expected);
  ok ? pass++ : fail++;
  Serial.print(ok ? F("OK   ") : F("FAIL "));
  Serial.print(name);
  Serial.print(F(": got "));
  Serial.print(got);
  Serial.print(F(", expected "));
  Serial.println(expected);
}

void setup() {
  Serial.begin(115200);
  delay(500);
  uDSC_ON();

  Serial.println(F("=== LGT8_uDSC verify ==="));

  // ---------- MUL (вопрос UDSC_MUL_SIGN_FIX) ----------
  Serial.println(F("-- MUL --"));
  checkU("MUL uu 40000*50000", DSC_MUL_get((uint16_t)40000, (uint16_t)50000), 2000000000UL);
  check("MUL ss -3*2      ", DSC_MUL_get((int16_t)-3, (int16_t)2), -6);       // ключевой тест!
  check("MUL ss -300*-200 ", DSC_MUL_get((int16_t)-300, (int16_t)-200), 60000L);
  check("MUL us 50000*-2  ", DSC_MUL_get((uint16_t)50000, (int16_t)-2), -100000L);
  check("MUL su -2*50000  ", DSC_MUL_get((int16_t)-2, (uint16_t)50000), -100000L);

  // ---------- ADD / SUB 16-бит ----------
  Serial.println(F("-- ADD/SUB 16 --"));
  checkU("ADD uu 60000+30000", DSC_ADD_get((uint16_t)60000, (uint16_t)30000), 90000UL);
  check("ADD ss -100+-200 ", DSC_ADD_get((int16_t)-100, (int16_t)-200), -300);
  check("ADD ss 100+-200  ", DSC_ADD_get((int16_t)100, (int16_t)-200), -100);
  check("ADD us 50000+-100", DSC_ADD_get((uint16_t)50000, (int16_t)-100), 49900L);
  check("ADD su -100+50000", DSC_ADD_get((int16_t)-100, (uint16_t)50000), 49900L);
  check("SUB ss -100-200  ", DSC_SUB_get((int16_t)-100, (int16_t)200), -300);
  check("SUB us 50000--100", DSC_SUB_get((uint16_t)50000, (int16_t)-100), 50100L);
  check("SUB su -100-50000", DSC_SUB_get((int16_t)-100, (uint16_t)50000), -50100L);
  checkU("SUB uu 100-30    ", DSC_SUB_get((uint16_t)100, (uint16_t)30), 70UL);

  // ---------- ADD / SUB c 32-битным DA (были сломаны) ----------
  Serial.println(F("-- ADD/SUB 32 --"));
  checkU("ADD au 100000+5000", DSC_ADD_get((uint32_t)100000, (uint16_t)5000), 105000UL);
  check("ADD as -100000+-5 ", DSC_ADD_get((int32_t)-100000, (int16_t)-5), -100005L);
  check("ADD as 100000+-5  ", DSC_ADD_get((uint32_t)100000, (int16_t)-5), 99995L);
  check("ADD au -100000+5  ", DSC_ADD_get((int32_t)-100000, (uint16_t)5), -99995L);
  checkU("SUB au 100000-5000", DSC_SUB_get((uint32_t)100000, (uint16_t)5000), 95000UL);
  check("SUB as -100000--5 ", DSC_SUB_get((int32_t)-100000, (int16_t)-5), -99995L);
  check("SUB as 100000--5  ", DSC_SUB_get((uint32_t)100000, (int16_t)-5), 100005L);
  check("SUB au -100000-5  ", DSC_SUB_get((int32_t)-100000, (uint16_t)5), -100005L);

  // ---------- DIV / MOD ----------
  Serial.println(F("-- DIV/MOD --"));
  checkU("DIV uu 3000000000/7", DSC_DIV_get(3000000000UL, (uint16_t)7), 428571428UL);
  check("DIV ss -100000/7  ", DSC_DIV_get((int32_t)-100000, (int16_t)7), -14285L);
  check("DIV ss -100000/-7 ", DSC_DIV_get((int32_t)-100000, (int16_t)-7), 14285L);
  check("DIV us 100000/-7  ", DSC_DIV_get((uint32_t)100000, (int16_t)-7), -14285L);
  checkU("DIV /0 -> 0       ", DSC_DIV_get((uint32_t)12345, (uint16_t)0), 0UL);
  checkU("MOD uu 100 % 7    ", DSC_MOD_get((uint32_t)100, (uint16_t)7), 2U);
  check("MOD ss -7 % 3     ", DSC_MOD_get((int32_t)-7, (int16_t)3), -1); // семантика C
  check("MOD ss  7 % -3    ", (int32_t)(int16_t)DSC_MOD_get((int32_t)7, (int16_t)-3), 1);
  check("MOD quotient 7/-3 ", DA_get_longt(), -2); // частное в DA после MOD выше
  DSC_MOD((int32_t)-7, (int16_t)3);
  check("MOD quotient -7/3 ", DA_get_longt(), -2);
  checkU("MOD wide 3e9 % 7  ", DSC_MOD_get(3000000000UL, (uint16_t)7), 4U); // делимое >= 2^31
  check("MOD wide quotient ", DA_get_longt(), 428571428L);

  // ---------- DA_INC / DA_DEC / DA_DIV ----------
  Serial.println(F("-- DA ops --"));
  DA_SET((uint32_t)1000);
  check("DA_INC -300       ", DA_INC_get((int16_t)-300), 700L);
  DA_SET((uint32_t)1000);
  check("DA_DEC -300       ", DA_DEC_get((int16_t)-300), 1300L);
  DA_SET(3000000000UL); // > 2^31: беззнаковое деление (раньше ломалось)
  checkU("DA_DIV u 3e9/3    ", DA_DIV_get((uint16_t)3), 1000000000UL);
  DA_SET(2147483647UL); // границы 2^31: быстрый и обходной пути
  checkU("DA_DIV u (2^31-1)/2", DA_DIV_get((uint16_t)2), 1073741823UL);
  DA_SET(2147483648UL);
  checkU("DA_DIV u 2^31/2   ", DA_DIV_get((uint16_t)2), 1073741824UL);
  DA_SET((int32_t)-100000);
  check("DA_DIV s -1e5/7   ", DA_DIV_get((int16_t)7), -14285L);
  DA_SET((int32_t)-32768);
  check("DA_SET int16 -32768", DA_get_longt(), -32768L);
  DA_SET_NEG((int16_t)-32768);
  check("DA_SET_NEG -32768 ", DA_get_longt(), 32768L);
  DA_SET_NEG((uint16_t)5);
  check("DA_SET_NEG u 5    ", DA_get_longt(), -5L);

  // ---------- одиночные записи регистров (кремний: фиксация старшего байта) ----------
  Serial.println(F("-- reg writes --"));
  DX_write(0x1234);
  DY_write(0x0002);
  uDSC_op(mul); // DA = 0x1234 * 2
  checkU("DX/DY_write standalone", DA_get_long(), 0x2468UL);
  uint16_t same = 60000; // равные операнды - компилятор даёт им один регистр
  checkU("MUL uu x*x (60000)", DSC_MUL_get(same, same), 3600000000UL);

  // ---------- сдвиги ----------
  Serial.println(F("-- SHIFT --"));
  DA_SET((uint32_t)1000);
  DA_shiftL(3);
  checkU("SHL 1000<<3       ", DA_get_long(), 8000UL);
  DA_SET(3000000000UL);
  DA_shiftR(2);
  checkU("SHR 3e9>>2 (лог.) ", DA_get_long(), 750000000UL);
  DA_SET((int32_t)-1000);
  DA_shiftR_int(2);
  check("SHR -1000>>2 (ар.)", DA_get_longt(), -250L);

  // ---------- MAC / MSC / MUL_NEG / SQR ----------
  Serial.println(F("-- MAC/MSC/NEG/SQR --"));
  DA_SET((uint32_t)1000);
  checkU("MAC uu 1000+10*20 ", DSC_MAC_get((uint16_t)10, (uint16_t)20), 1200UL);
  DA_SET((int32_t)1000);
  check("MAC ss 1000+-10*20", DSC_MAC_get((int16_t)-10, (int16_t)20), 800L);
  DA_SET((int32_t)1000);
  check("MAC us 1000+10*-20", DSC_MAC_get((uint16_t)10, (int16_t)-20), 800L);
  DA_SET((int32_t)1000);
  check("MAC su 1000+-10*20", DSC_MAC_get((int16_t)-10, (uint16_t)20), 800L);
  DA_SET((int32_t)1000);
  check("MAC_R ss (1000-200)>>1", DSC_MAC_R_get((int16_t)-10, (int16_t)20), 400L);
  DA_SET((uint32_t)1000);
  checkU("MSC uu 1000-10*20 ", DSC_MSC_get((uint16_t)10, (uint16_t)20), 800UL);
  DA_SET((int32_t)1000);
  check("MSC ss 1000--10*20", DSC_MSC_get((int16_t)-10, (int16_t)20), 1200L);
  DA_SET((int32_t)1000);
  check("MSC us 1000-10*-20", DSC_MSC_get((uint16_t)10, (int16_t)-20), 1200L);
  DA_SET((int32_t)1000);
  check("MSC su 1000--10*20", DSC_MSC_get((int16_t)-10, (uint16_t)20), 1200L);
  DA_SET((int32_t)1000);
  check("MSC_R ss (1000+200)>>1", DSC_MSC_R_get((int16_t)-10, (int16_t)20), 600L);
  check("MUL_NEG uu 10*20  ", DSC_MUL_NEG_get((uint16_t)10, (uint16_t)20), -200L);
  check("MUL_NEG ss -10*20 ", DSC_MUL_NEG_get((int16_t)-10, (int16_t)20), 200L);
  check("MUL_NEG_R uu 11*3 ", DSC_MUL_NEG_R_get((uint16_t)11, (uint16_t)3), -17L); // (-33)>>1 арифм.
  checkU("MUL_R uu 11*3>>1  ", DSC_MUL_R_get((uint16_t)11, (uint16_t)3), 16UL);
  checkU("SQR u 60000^2     ", DSC_SQR_get((uint16_t)60000), 3600000000UL);
  checkU("SQR s -200^2      ", DSC_SQR_get((int16_t)-200), 40000UL);
  checkU("SQR s -32768^2    ", DSC_SQR_get((int16_t)-32768), 1073741824UL);

  // ---------- map ----------
  Serial.println(F("-- map --"));
  checkU("map 512:0-1023->0-255 ", uDSC_map(512, 0, 1023, 0, 255), 127U);
  checkU("map 40000 wide (2^31+)", uDSC_map(40000, 0, 65535, 0, 65535), 40000U); // раньше ломалось
  check("map_int -500:-1000..1000->0..100", uDSC_map_int(-500, -1000, 1000, 0, 100), 25);
  check("map_int wide -30000..30000     ", uDSC_map_int(0, -30000, 30000, -20000, 20000), 0);
  check("map_int wide product (>=2^31)  ", uDSC_map_int(20000, -30000, 30000, -32000, 32000), 21333);
  check("map_int clamp low              ", uDSC_map_int(-2000, -1000, 1000, 0, 100), 0);

  // ---------- итог ----------
  Serial.println(F("========================"));
  Serial.print(F("PASS: "));
  Serial.print(pass);
  Serial.print(F("  FAIL: "));
  Serial.println(fail);
#if UDSC_MUL_SIGN_FIX
  Serial.println(F("UDSC_MUL_SIGN_FIX = 1 (коррекция знака MUL включена)"));
#else
  Serial.println(F("UDSC_MUL_SIGN_FIX = 0 (по даташиту, без коррекции)"));
  Serial.println(F("Если 'MUL ss -3*2' дал +6 - включите UDSC_MUL_SIGN_FIX 1"));
#endif
}

void loop() {}
