#include <Arduino.h>
/* библиотека для работы с АЦП - https://github.com/GyverLibs/directADC  */
#include <directADC_lgt8.h>

/*
#if defined(__LGT8FX8P__)
#include <LGT8_uDSC.h>
#endif
*/
/*
Библиотека ADCaverage для чтения аналоговых данных и усреднения значений с разных пинов.
Чтение данных с АЦП не блокирует выполение кода.
При вызове sample() проверяется занятость АЦП. Если она свободна, то вызывается функция ADC_startConvert() и запускается преобразование.
Устанавливается флаг занятости АЦП.
Когда преобразование завершено, считываются данные АЦП (ADC_read()) и усредняются.
Сбрасывается флаг занятости АЦП.
Если создано несколько объектов (ADCaverage), то вызывается метод sample() последовательно у всех объектов.

Пример использования:
ADCaverage adc(ADC_A0); // создаем объект для чтения и усреднения аналоговых данных с пина ADC_A0
void setup() {
  ADC_init();            // инициализация АЦП
}
void loop() {
  adc.sample();           // вызываем метод sample() в основном цикле как можно чаще
  float volt = (float)adc.getValue() / BITRATE * ((float)REF / 1000); // получаем значение усреднения аналоговых данных (getValue() с пина ADC_A0 . Используем данное значение в своих расчетах.
}
*/

/*
С помощью класса VoltRead можно считывать напряжение в мВ с разных пинов на которые напряжение подается через делитель напряжения на резисорах.
Класс VoltRead наследует от класса ADCaverage.

Пример использования:
VoltRead volt(ADC_A0); // создаем объект для чтения и усреднения аналоговых данных с пина ADC_A0
void setup() {
  ADC_init();            // инициализация АЦП
}
void loop() {
  volt.sample();           // вызываем метод sample() в основном цикле как можно чаще
  uint16_t volt = volt.getValue(); // получаем значение усреднения аналоговых данных в мВ
  Serial.println(volt);
}
*/

/*
С помощью класса NTCRead можно считывать температуру в Градусах Цельсия с датчиков NTC.
Класс NTCRead наследует от класса ADCaverage.

Пример использования:
NTCRead ntc(ADC_A0); // создаем объект для чтения и усреднения аналоговых данных с пина ADC_A0
void setup() {
  ADC_init();            // инициализация АЦП
}
void loop() {
  ntc.sample();             // вызываем метод sample() в основном цикле как можно чаще
  Serial.println(ntc.temp); // получаем значение усреднения температуры в градусах Цельсия
}
*/

 // опорное напряжение мВ
#ifndef REF
#define REF 5000
#endif

 // делитель частоты АЦП (2, 4, 8, 16, 32, 64, 128)
#ifndef DIVIDER
#define DIVIDER 64
#endif

 // разрядность АЦП
#ifndef BITRATE
#define BITRATE 1024
#endif

// значение усреднения (1, 2, 3, 4, 5, 6, 7, 8) не более 8 // 2^6=64  1/64=0,015625
#ifndef AVER
#define AVER 6 
#endif

// инициализация, настройка АЦП
void ADC_init(uint8_t divider, ADC_reference mode);

class ADCaverage
{
public:
    ADCaverage(uint8_t pin) : pin(pin) {}

    // считывает сырые данные с пинов и суммирует скользящее среднее. Вызывается постоянно.
    bool sample(void);

    uint16_t getValue(void);

    int32_t value : 24;
    const uint8_t pin;
};

class VoltRead : public ADCaverage
{
public:
    VoltRead(uint8_t pin, uint16_t r1, uint16_t r2) : ADCaverage(pin), _r12((uint32_t)r1 + r2), _r2(r2) {}

     // реальное напряжение в мВ
    uint16_t volt = 0;

    // рассчитать среднее напряжение БП   (20 мкс - Atmega328 16МГц)
    void compute(void);

private:
    const uint32_t _r12; // r1 + r2
    const uint16_t _r2;
};

class NTCRead : public ADCaverage
{
public:
    // r1 - сопротивление термистора при базовой температуре, Ом
    // rs2 - сопротивление подтягивающего резистора (к VCC), Ом
    // b1 - коэффициент B термистора
    // temp - базовая температура термистора, °C (при ней сопротивление термистора равно r1)
    // соотношение rs2/r1 должно быть не более 8
    NTCRead(uint8_t pin, uint16_t r1, uint16_t rs2, uint16_t b1, uint8_t temp) : ADCaverage(pin), _r1(r1), _rs2(rs2), _b1(b1), _tempBase(temp) {
        recalc();
    }

     // температура в градусах Цельсия
    int8_t temp = 0;

    // рассчитать среднюю температуру термистора   (~120 мкс - Atmega328 16МГц)
    void compute(void);

    // ввести сопротивление термистора в Ом
    void setR1(uint16_t r1);

    // ввести сопротивление резистора в Ом
    void setRS2(uint16_t rs2);

    // ввести базовую температуру термистора
    void setTempBase(uint8_t temp);

private:
    uint16_t _r1, _rs2;
    uint16_t _b1;
    uint8_t _tempBase;
    uint32_t _kdiv;   // коэффициент делителя (rs2/r1) в формате Q16
    uint32_t _invT0;  // 2^24 / (базовая температура в Кельвинах)

    // пересчет констант из номиналов
    void recalc(void);

    /*  функция для работы с NTC термисторами по B-уравнению (упрощенный Стейнхарт-Харт).  */
    // целочисленный расчет температуры термистора по сигналу АЦП   (~120 мкс - Atmega328 16МГц)
    int8_t NTC_compute(uint16_t analog);
};
