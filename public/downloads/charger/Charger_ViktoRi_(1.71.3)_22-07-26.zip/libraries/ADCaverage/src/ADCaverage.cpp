#include "ADCaverage.h"


// инициализация, настройка АЦП
void ADC_init(const uint8_t divider, ADC_reference mode) {
  // вызывается обязательно
  ADC_enable();
  // Выбрать делитель частоты АЦП (2, 4, 8, 16, 32, 64, 128)
  ADC_setPrescaler(divider);
  // Выбрать источник опорного напряжения АЦП (ADC_1V1, ADC_AREF, ADC_VCC)
  ADC_setReference(mode);
}

 // занятость АЦП  - 1 свободен // нельзя трогать эту переменную из основной программы!!!
static int8_t adc_busy = -1;

bool ADCaverage::sample(void) {
  bool flag = false;
  // если ацп свободен
  if (adc_busy == (int8_t)(-1)) {
    // Аналоговый вход (ADC_A0-ADC_A7)
    setAnalogMux((ADC_modes)pin);
    // ручной старт преобразования
    ADC_startConvert();
    // ацп занят
    adc_busy = (int8_t)(pin);
  } else if (adc_busy == (int8_t)(pin) and ADC_available()) {
    // суммируем скользящее среднее
    value += ((((int32_t)ADC_read() << AVER) - value) >> AVER);
    adc_busy = (int8_t)(-1);
    flag = true;
  }
  return flag;
}

// получить значение усреднения
uint16_t ADCaverage::getValue(void) { return (uint16_t)(value >> AVER); }

// рассчитать среднее напряжение БП
// мВ = value * (r1+r2)/r2 * REF/BITRATE, целочисленно с округлением
void VoltRead::compute(void) {
  uint32_t v = ((uint32_t)getValue() * _r12 + (_r2 >> 1)) / _r2;
  volt = (uint16_t)((v * REF + (BITRATE >> 1)) / BITRATE);
}

// рассчитать температуру термистора
void NTCRead::compute(void) {
  temp = NTC_compute(getValue());
}

// пересчет констант из номиналов
void NTCRead::recalc(void) {
  // коэффициент делителя (rs2/r1) в формате Q16, с округлением
  _kdiv = (((uint32_t)_rs2 << 16) + (_r1 >> 1)) / _r1;
  // 2^24 / T0,  T0 - базовая температура в сотых долях Кельвина
  uint32_t t0 = (uint32_t)_tempBase * 100 + 27315;
  _invT0 = (1677721600UL + (t0 >> 1)) / t0;
}

// ввести сопротивление термистора в Ом
void NTCRead::setR1(uint16_t r1) {
  if (r1 > 0) {
    _r1 = r1;
    recalc();
  }
}

// ввести сопротивление резистора в Ом
void NTCRead::setRS2(uint16_t rs2){
    if (rs2 > 0) {
      _rs2 = rs2;
      recalc();
    }
}

// ввести базовую температуру термистора
void NTCRead::setTempBase(uint8_t temp){
      _tempBase = temp;
      recalc();
}

/*
Целочисленный расчет температуры по B-уравнению:
  1/T = 1/T0 + ln(Rt/R0) / B
Термистор подключен между пином и землей, подтягивающий резистор - к VCC:
  Rt/R0 = (Rs/R0) * adc / (BITRATE-1 - adc)
Логарифм считается через двоичный log2 с фиксированной точкой (13 бит дроби),
1/T хранится в формате Q24. Погрешность расчета ~0.005 гр: значение может
отличаться на 1 градус от расчета во float только на кодах АЦП, где точная
температура лежит вплотную к границе целого градуса.
*/
int8_t NTCRead::NTC_compute(uint16_t analog) {
  // граничные случаи: замыкание датчика - перегрев, обрыв - минимум
  if (analog == 0)
    return 127;
  if (analog >= (BITRATE - 1))
    return -128;

  // отношение сопротивлений Rt/R0 в формате Q16, с округлением
  uint16_t d = (uint16_t)((BITRATE - 1) - analog);
  uint32_t r = (_kdiv * analog + (d >> 1)) / d;

  // нормализация мантиссы в [1, 2): Rt/R0 = m * 2^s, m в Q16
  int8_t s = 0;
  while (r >= 0x20000UL) {
    r >>= 1;
    s++;
  }
  while (r < 0x10000UL) {
    r <<= 1;
    s--;
  }

  // дробная часть log2 (13 бит) методом последовательного возведения в квадрат
  uint16_t x = (uint16_t)(r >> 1); // мантисса [1, 2) в Q15
  uint16_t frac = 0;
  for (uint8_t i = 0; i < 13; i++) {
    uint32_t xx = ((uint32_t)x * x) >> 15;
    frac <<= 1;
    if (xx >= 0x10000UL) {
      xx >>= 1;
      frac |= 1;
    }
    x = (uint16_t)xx;
  }
  // округление младшего бита дроби: мантисса выше sqrt(2) в Q15
  if (x >= 46341U)
    frac++;
  // log2(Rt/R0) в формате Q13 (перенос из frac складывается корректно)
  int32_t L = ((int32_t)s << 13) + frac;

  // 1/T в формате Q24:  1/T0 + log2(r)*ln(2)/B,  5678 = ln(2)*2^13
  // L*5678 имеет формат Q26, поэтому делитель B*4
  int32_t t = L * 5678L;
  int32_t div = (int32_t)_b1 << 2;
  // деление с округлением (симметричное для знака)
  int32_t S = (int32_t)_invT0 +
              (t + ((t >= 0) ? (div >> 1) : -(div >> 1))) / div;
  if (S <= 0)
    return 127; // за пределами формулы - перегрев

  // температура в сотых долях Кельвина, деление с округлением
  int32_t tc =
      ((int32_t)((1677721600UL + ((uint32_t)S >> 1)) / (uint32_t)S) - 27315L) /
      100;

  // ограничение диапазоном int8
  if (tc > 127)
    tc = 127;
  if (tc < -128)
    tc = -128;
  return (int8_t)tc;
}
