#include "LGT8_uDSC.h"

#if defined(__LGT8FX8P__)

// Включить ускоритель вычислений uDSC
void uDSC_ON(void)
{
    DSCR = 1 << DSUEN; // Включить uDSC
}

// выгрузить результат вычислений из регистра DA (32-битное число).
uint32_t DA_get_long(void)
{
    uint32_t result = 0; // Создаем переменную для возврата результата
    asm volatile(
        "in %A[res], 0x38;" // Читаем младшие 2 байта из DA в result
        "\n\t"
        "in %C[res], 0x39;" // Читаем старшие 2 байта из DA в result
        "\n\t"
        : [res] "=r"(result) // выходные данные
        :                    // входные данные
    );
    return result; // Возвращаем полученный результат
}

// выгрузить результат вычислений из регистра DA (32-битное число).
int32_t DA_get_longt(void)
{
    int32_t result = 0; // Создаем переменную для возврата результата
    asm volatile(
        "in %A[result], 0x38;"
        "\n\t" // Читаем младшие 2 байта из DA в result
        "in %C[result], 0x39;"
        "\n\t"                  // Читаем старшие 2 байта из DA в result
        : [result] "=r"(result) // выходные данные
        :                       // входные данные
    );
    return result; // Возвращаем полученный результат
}

// выгрузить результат вычислений из регистра DA (16-битное число).
uint16_t DA_get_int(void)
{
    uint16_t result = 0; // Создаем переменную для возврата результата
    asm volatile(
        "in %[res], 0x38;"
        "\n\t"               // Читаем младшие 2 байта из DA в result
        : [res] "=r"(result) // выходные данные
        :                    // входные данные
    );
    return result; // Возвращаем полученный результат
}

// выгрузить результат вычислений из регистра DA (16-битное число).
int16_t DA_get_intt(void)
{
    int16_t result = 0; // Создаем переменную для возврата результата
    asm volatile(
        "in %[result], 0x38;"
        "\n\t"                  // Читаем младшие 2 байта из DA в result
        : [result] "=r"(result) // выходные данные
        :                       // входные данные
    );
    return result; // Возвращаем полученный результат
}

// выгрузить результат вычислений из регистра DY (16-битное число).
uint16_t DY_get(void)
{
    uint16_t result = 0; // Создаем переменную для возврата результата
    asm volatile(
        "in %[res], 0x11;"
        "\n\t"               // Читаем младшие 2 байта из DY в result
        : [res] "=r"(result) // выходные данные
        :                    // входные данные
    );
    return result; // Возвращаем полученный результат
}

// выгрузить результат вычислений из регистра DY (16-битное число).
int16_t DY_get_int(void)
{
    int16_t result = 0; // Создаем переменную для возврата результата
    asm volatile(
        "in %[result], 0x11;"
        "\n\t"                  // Читаем младшие 2 байта из DY в result
        : [result] "=r"(result) // выходные данные
        :                       // входные данные
    );
    return result; // Возвращаем полученный результат
}

// выгрузить результат вычислений из регистра DX (16-битное число).
uint16_t DX_get(void)
{
    uint16_t result = 0; // Создаем переменную для возврата результата
    asm volatile(
        "in %[res], 0x10;"
        "\n\t"               // Читаем младшие 2 байта из DX в result
        : [res] "=r"(result) // выходные данные
        :                    // входные данные
    );
    return result; // Возвращаем полученный результат
}

// выгрузить результат вычислений из регистра DX (16-битное число).
int16_t DX_get_int(void)
{
    int16_t result = 0; // Создаем переменную для возврата результата
    asm volatile(
        "in %[result], 0x10;"
        "\n\t"                  // Читаем младшие 2 байта из DX в result
        : [result] "=r"(result) // выходные данные
        :                       // входные данные
    );
    return result; // Возвращаем полученный результат
}

/*-------------------------------------------------------*/
/********************* НОВЫЕ ФУНКЦИИ *********************/
/*-------------------------------------------------------*/

// умножение целых чисел без знака (unsigned integer). Запись результата в DA.
void DSC_MUL(uint16_t dx, uint16_t dy)
{
    asm volatile(
        "out 0x10, %[dsdx];" // Устанавливаем первое число (dx)
        "\n\t"
        "out 0x11, %[dsdy];" // Устанавливаем второе число (dy)
        "\n\t"
        "out 0x01, %[opc];" // Выполняем операцию
        "\n\t"
        :                                                // выходные данные
        : [dsdx] "r"(dx), [dsdy] "r"(dy), [opc] "r"(mul) // входные данные
    );
}

// умножение целых чисел со знаком (signed integer). Запись результата в DA.
void DSC_MUL(int16_t dx, int16_t dy)
{
    uint8_t oper = mul;
    oper |= (1 << 5) | (1 << 4); // записать знаковый бит dx, записать знаковый бит dy в операцию
    asm volatile(
        "out 0x10, %[dsdx];" // Устанавливаем первое число (dx)
        "\n\t"
        "out 0x11, %[dsdy];" // Устанавливаем второе число (dy)
        "\n\t"
        "out 0x01, %[opc];" // Выполняем операцию
        "\n\t"
        :                                                 // выходные данные
        : [dsdx] "r"(dx), [dsdy] "r"(dy), [opc] "r"(oper) // входные данные
    );
    if (bitRead(DSCR, DSN))
        uDSC_op(nec_da); // DA = NEG(DA) изменяет знак числа на противоположный
}

void DSC_MUL(uint16_t dx, int16_t dy)
{
    uint8_t oper = mul;
    oper |= (1 << 4); // записать знаковый бит dy в операцию
    asm volatile(
        "out 0x10, %[dsdx];" // Устанавливаем первое число (dx)
        "\n\t"
        "out 0x11, %[dsdy];" // Устанавливаем второе число (dy)
        "\n\t"
        "out 0x01, %[opc];" // Выполняем операцию
        "\n\t"
        :                                                 // выходные данные
        : [dsdx] "r"(dx), [dsdy] "r"(dy), [opc] "r"(oper) // входные данные
    );
    if (bitRead(DSCR, DSN))
        uDSC_op(nec_da); // DA = NEG(DA) изменяет знак числа на противоположный
}

void DSC_MUL(int16_t dx, uint16_t dy)
{
    uint8_t oper = mul;
    oper |= (1 << 5); // записать знаковый бит dx в операцию
    asm volatile(
        "out 0x10, %[dsdx];" // Устанавливаем первое число (dx)
        "\n\t"
        "out 0x11, %[dsdy];" // Устанавливаем второе число (dy)
        "\n\t"
        "out 0x01, %[opc];" // Выполняем операцию
        "\n\t"
        :                                                 // выходные данные
        : [dsdx] "r"(dx), [dsdy] "r"(dy), [opc] "r"(oper) // входные данные
    );
    if (bitRead(DSCR, DSN))
        uDSC_op(nec_da); // DA = NEG(DA) изменяет знак числа на противоположный
}

// умножение целых чисел без знака (unsigned integer). Запись результата в DA. Возврат результата 32-битного числа из DA.
uint32_t DSC_MUL_get(uint16_t dx, uint16_t dy)
{
    asm volatile(
        "out 0x10, %[dsdx];" // Устанавливаем первое число (dx)
        "\n\t"
        "out 0x11, %[dsdy];" // Устанавливаем второе число (dy)
        "\n\t"
        "out 0x01, %[opc];" // Выполняем операцию
        "\n\t"
        :                                                // выходные данные
        : [dsdx] "r"(dx), [dsdy] "r"(dy), [opc] "r"(mul) // входные данные
    );
    return DA_get_long();
}

// умножение целых чисел со знаком (signed integer). Запись результата в DA. Возврат результата 32-битного числа из DA.
int32_t DSC_MUL_get(int16_t dx, int16_t dy)
{
    DSC_MUL(dx, dy);       // Выполнить операцию умножения
    return DA_get_longt(); // DA = NEG(DA) изменяет знак числа на противоположный
}

int32_t DSC_MUL_get(uint16_t dx, int16_t dy)
{
    DSC_MUL(dx, dy);       // Выполнить операцию умножения
    return DA_get_longt(); // DA = NEG(DA) изменяет знак числа на противоположный
}

int32_t DSC_MUL_get(int16_t dx, uint16_t dy)
{
    DSC_MUL(dx, dy);       // Выполнить операцию умножения
    return DA_get_longt(); // DA = NEG(DA) изменяет знак числа на противоположный
}

// сложение целых чисел без знака (unsigned integer). Запись результата в DA.
void DSC_ADD(uint16_t dx, uint16_t dy)
{
    asm volatile(
        "out 0x10, %[dsdx];" // Устанавливаем первое число (dx)
        "\n\t"
        "out 0x11, %[dsdy];" // Устанавливаем второе число (dy)
        "\n\t"
        "out 0x01, %[opc];" // Выполняем операцию
        "\n\t"
        :                                                // выходные данные
        : [dsdx] "r"(dx), [dsdy] "r"(dy), [opc] "r"(add) // входные данные
    );
}

// сложение целых чисел со знаком (unsigned integer). Запись результата в DA.
void DSC_ADD(int16_t dx, int16_t dy)
{
    uint8_t oper = add;
    oper |= (1 << 5); // записать знаковый бит
    asm volatile(
        "out 0x10, %[dsdx];" // Устанавливаем первое число (dx)
        "\n\t"
        "out 0x11, %[dsdy];" // Устанавливаем второе число (dy)
        "\n\t"
        "out 0x01, %[opc];" // Выполняем операцию
        "\n\t"
        :                                                 // выходные данные
        : [dsdx] "r"(dx), [dsdy] "r"(dy), [opc] "r"(oper) // входные данные
    );
}
void DSC_ADD(uint16_t dx, int16_t dy)
{
    uint8_t oper = add;
    oper |= (1 << 5); // записать знаковый бит
    asm volatile(
        "out 0x10, %[dsdx];" // Устанавливаем первое число (dx)
        "\n\t"
        "out 0x11, %[dsdy];" // Устанавливаем второе число (dy)
        "\n\t"
        "out 0x01, %[opc];" // Выполняем операцию
        "\n\t"
        :                                                 // выходные данные
        : [dsdx] "r"(dx), [dsdy] "r"(dy), [opc] "r"(oper) // входные данные
    );
}

void DSC_ADD(int16_t dx, uint16_t dy)
{
    uint8_t oper = add;
    oper |= (1 << 5); // записать знаковый бит
    asm volatile(
        "out 0x10, %[dsdx];" // Устанавливаем первое число (dx)
        "\n\t"
        "out 0x11, %[dsdy];" // Устанавливаем второе число (dy)
        "\n\t"
        "out 0x01, %[opc];" // Выполняем операцию
        "\n\t"
        :                                                 // выходные данные
        : [dsdx] "r"(dx), [dsdy] "r"(dy), [opc] "r"(oper) // входные данные
    );
}

// сложение целых чисел без знака (unsigned integer). Запись результата в DA.
void DSC_ADD(uint32_t da, uint16_t dy)
{
    asm volatile(
        "out 0x38, %A[dsda];" // Записать младшие 2 байта da в DA
        "\n\t"
        "out 0x39, %C[dsda];" // Записать старшие 2 байта da в DA
        "\n\t"
        "out 0x11, %[dsdy];" // Записать второе число (dy) в DY
        "\n\t"
        "out 0x01, %[opc];" // Выполняем операцию
        "\n\t"
        :                                                // выходные данные
        : [dsda] "r"(da), [dsdy] "r"(dy), [opc] "r"(add) // входные данные
    );
}
// сложение целых чисел со знаком (signed integer). Запись результата в DA.
void DSC_ADD(int32_t da, int16_t dy)
{
    uint8_t oper = add;
    oper |= (1 << 5); // записать знаковый бит
    asm volatile(
        "out 0x38, %A[dsda];" // Записать младшие 2 байта da в DA
        "\n\t"
        "out 0x39, %C[dsda];" // Записать старшие 2 байта da в DA
        "\n\t"
        "out 0x11, %[dsdy];" // Записать второе число (dy) в DY
        "\n\t"
        "out 0x01, %[opc];" // Выполняем операцию
        "\n\t"
        :                                                 // выходные данные
        : [dsda] "r"(da), [dsdy] "r"(dy), [opc] "r"(oper) // входные данные
    );
}
void DSC_ADD(uint32_t da, int16_t dy)
{
    uint8_t oper = add;
    oper |= (1 << 5); // записать знаковый бит
    asm volatile(
        "out 0x38, %A[dsda];" // Записать младшие 2 байта da в DA
        "\n\t"
        "out 0x39, %C[dsda];" // Записать старшие 2 байта da в DA
        "\n\t"
        "out 0x11, %[dsdy];" // Записать второе число (dy) в DY
        "\n\t"
        "out 0x01, %[opc];" // Выполняем операцию
        "\n\t"
        :                                                 // выходные данные
        : [dsda] "r"(da), [dsdy] "r"(dy), [opc] "r"(oper) // входные данные
    );
}
void DSC_ADD(int32_t da, uint16_t dy)
{
    uint8_t oper = add;
    oper |= (1 << 5); // записать знаковый бит
    asm volatile(
        "out 0x38, %A[dsda];" // Записать младшие 2 байта da в DA
        "\n\t"
        "out 0x39, %C[dsda];" // Записать старшие 2 байта da в DA
        "\n\t"
        "out 0x11, %[dsdy];" // Записать второе число (dy) в DY
        "\n\t"
        "out 0x01, %[opc];" // Выполняем операцию
        "\n\t"
        :                                                 // выходные данные
        : [dsda] "r"(da), [dsdy] "r"(dy), [opc] "r"(oper) // входные данные
    );
}

// сложение целых чисел без знака (unsigned integer). Запись результата в DA.  Возврат результата 32-битного числа из DA.
uint32_t DSC_ADD_get(uint16_t dx, uint16_t dy)
{
    asm volatile(
        "out 0x10, %[dsdx];" // Устанавливаем первое число (dx)
        "\n\t"
        "out 0x11, %[dsdy];" // Устанавливаем второе число (dy)
        "\n\t"
        "out 0x01, %[opc];" // Выполняем операцию
        "\n\t"
        :                                                // выходные данные
        : [dsdx] "r"(dx), [dsdy] "r"(dy), [opc] "r"(add) // входные данные
    );
    return DA_get_long();
}

// сложение целых чисел со знаком (signed integer). Запись результата в DA. Возврат результата 32-битного числа из DA.
int32_t DSC_ADD_get(int16_t dx, int16_t dy)
{
    DSC_ADD(dx, dy);       // Выполнить операцию сложения
    return DA_get_longt(); // DA = NEG(DA) изменяет знак числа на противоположный
}
int32_t DSC_ADD_get(uint16_t dx, int16_t dy)
{
    DSC_ADD(dx, dy);       // Выполнить операцию сложения
    return DA_get_longt(); // DA = NEG(DA) изменяет знак числа на противоположный
}
int32_t DSC_ADD_get(int16_t dx, uint16_t dy)
{
    DSC_ADD(dx, dy);       // Выполнить операцию сложения
    return DA_get_longt(); // DA = NEG(DA) изменяет знак числа на противоположный
}

// сложение целых чисел без знака (unsigned integer). Запись результата в DA. Возврат результата 32-битного числа из DA.
uint32_t DSC_ADD_get(uint32_t da, uint16_t dy)
{
    asm volatile(
        "out 0x38, %A[dsda];" // Записать младшие 2 байта da в DA
        "\n\t"
        "out 0x39, %C[dsda];" // Записать старшие 2 байта da в DA
        "\n\t"
        "out 0x11, %[dsdy];" // Записать второе число (dy) в DY
        "\n\t"
        "out 0x01, %[opc];" // Выполняем операцию
        "\n\t"
        :                                                // выходные данные
        : [dsda] "r"(da), [dsdy] "r"(dy), [opc] "r"(add) // входные данные
    );
    return DA_get_long();
}

// сложение целых чисел со знаком (signed integer). Запись результата в DA. Возврат результата 32-битного числа из DA.
int32_t DSC_ADD_get(int32_t da, int16_t dy)
{
    DSC_ADD(da, dy); // Выполнить операцию сложения
    return DA_get_longt();
}
int32_t DSC_ADD_get(uint32_t da, int16_t dy)
{
    DSC_ADD(da, dy); // Выполнить операцию сложения
    return DA_get_longt();
}
int32_t DSC_ADD_get(int32_t da, uint16_t dy)
{
    DSC_ADD(da, dy); // Выполнить операцию сложения
    return DA_get_longt();
}

// вычитание целых чисел без знака (unsigned integer). Запись результата в DA.
void DSC_SUB(uint16_t dx, uint16_t dy)
{
    asm volatile(
        "out 0x10, %[dsdx];" // Устанавливаем первое число (dx)
        "\n\t"
        "out 0x11, %[dsdy];" // Устанавливаем второе число (dy)
        "\n\t"
        "out 0x01, %[opc];" // Выполняем операцию
        "\n\t"
        :                                                // выходные данные
        : [dsdx] "r"(dx), [dsdy] "r"(dy), [opc] "r"(sub) // входные данные
    );
}

// вычитание целых чисел со знаком (signed integer). Запись результата в DA.
void DSC_SUB(int16_t dx, int16_t dy)
{
    uint8_t oper = sub;
    oper |= (1 << 5); // записать знаковый бит dx
    asm volatile(
        "out 0x10, %[dsdx];" // Устанавливаем первое число (dx)
        "\n\t"
        "out 0x11, %[dsdy];" // Устанавливаем второе число (dy)
        "\n\t"
        "out 0x01, %[opc];" // Выполняем операцию
        "\n\t"
        :                                                 // выходные данные
        : [dsdx] "r"(dx), [dsdy] "r"(dy), [opc] "r"(oper) // входные данные
    );
}
void DSC_SUB(uint16_t dx, int16_t dy)
{
    uint8_t oper = sub;
    oper |= (1 << 5); // записать знаковый бит dx
    asm volatile(
        "out 0x10, %[dsdx];" // Устанавливаем первое число (dx)
        "\n\t"
        "out 0x11, %[dsdy];" // Устанавливаем второе число (dy)
        "\n\t"
        "out 0x01, %[opc];" // Выполняем операцию
        "\n\t"
        :                                                 // выходные данные
        : [dsdx] "r"(dx), [dsdy] "r"(dy), [opc] "r"(oper) // входные данные
    );
}
void DSC_SUB(int16_t dx, uint16_t dy)
{
    uint8_t oper = sub;
    oper |= (1 << 5); // записать знаковый бит dx
    asm volatile(
        "out 0x10, %[dsdx];" // Устанавливаем первое число (dx)
        "\n\t"
        "out 0x11, %[dsdy];" // Устанавливаем второе число (dy)
        "\n\t"
        "out 0x01, %[opc];" // Выполняем операцию
        "\n\t"
        :                                                 // выходные данные
        : [dsdx] "r"(dx), [dsdy] "r"(dy), [opc] "r"(oper) // входные данные
    );
}

// вычитание целых чисел без знака (unsigned integer). Запись результата в DA.
void DSC_SUB(uint32_t da, uint16_t dy)
{
    asm volatile(
        "out 0x38, %A[dsda];" // Записать младшие 2 байта da в DA
        "\n\t"
        "out 0x39, %C[dsda];" // Записать старшие 2 байта da в DA
        "\n\t"
        "out 0x11, %[dsdy];" // Записать второе число (dy) в DY
        "\n\t"
        "out 0x01, %[opc];"                              // Выполняем операцию
        :                                                // выходные данные
        : [dsda] "r"(da), [dsdy] "r"(dy), [opc] "r"(sub) // входные данные
    );
}
// вычитание целых чисел со знаком (signed integer). Запись результата в DA.
void DSC_SUB(int32_t da, int16_t dy)
{
    uint8_t oper = sub;
    oper |= (1 << 5); // записать знаковый бит dx
    asm volatile(
        "out 0x38, %A[dsda];" // Записать младшие 2 байта da в DA
        "\n\t"
        "out 0x39, %C[dsda];" // Записать старшие 2 байта da в DA
        "\n\t"
        "out 0x11, %[dsdy];" // Записать второе число (dy) в DY
        "\n\t"
        "out 0x01, %[opc];"                               // Выполняем операцию
        :                                                 // выходные данные
        : [dsda] "r"(da), [dsdy] "r"(dy), [opc] "r"(oper) // входные данные
    );
}
void DSC_SUB(uint32_t da, int16_t dy)
{
    uint8_t oper = sub;
    oper |= (1 << 5); // записать знаковый бит dx
    asm volatile(
        "out 0x38, %A[dsda];" // Записать младшие 2 байта da в DA
        "\n\t"
        "out 0x39, %C[dsda];" // Записать старшие 2 байта da в DA
        "\n\t"
        "out 0x11, %[dsdy];" // Записать второе число (dy) в DY
        "\n\t"
        "out 0x01, %[opc];"                               // Выполняем операцию
        :                                                 // выходные данные
        : [dsda] "r"(da), [dsdy] "r"(dy), [opc] "r"(oper) // входные данные
    );
}
void DSC_SUB(int32_t da, uint16_t dy)
{
    uint8_t oper = sub;
    oper |= (1 << 5); // записать знаковый бит dx
    asm volatile(
        "out 0x38, %A[dsda];" // Записать младшие 2 байта da в DA
        "\n\t"
        "out 0x39, %C[dsda];" // Записать старшие 2 байта da в DA
        "\n\t"
        "out 0x11, %[dsdy];" // Записать второе число (dy) в DY
        "\n\t"
        "out 0x01, %[opc];"                               // Выполняем операцию
        :                                                 // выходные данные
        : [dsda] "r"(da), [dsdy] "r"(dy), [opc] "r"(oper) // входные данные
    );
}

// вычитание целых чисел без знака (unsigned integer). Запись результата в DA. Возврат результата 32-битного числа из DA.
uint32_t DSC_SUB_get(uint16_t dx, uint16_t dy)
{
    asm volatile(
        "out 0x10, %[dsdx];" // Устанавливаем первое число (dx)
        "\n\t"
        "out 0x11, %[dsdy];" // Устанавливаем второе число (dy)
        "\n\t"
        "out 0x01, %[opc];" // Выполняем операцию
        "\n\t"
        :                                                // выходные данные
        : [dsdx] "r"(dx), [dsdy] "r"(dy), [opc] "r"(sub) // входные данные
    );
    return DA_get_long();
}

// вычитание целых чисел со знаком (signed integer). Запись результата в DA. Возврат результата 32-битного числа из DA.
int32_t DSC_SUB_get(int16_t dx, int16_t dy)
{
    DSC_SUB(dx, dy);       // Выполнить операцию вычитания
    return DA_get_longt(); // DA = NEG(DA) изменяет знак числа на противоположный
}
int32_t DSC_SUB_get(uint16_t dx, int16_t dy)
{
    DSC_SUB(dx, dy);       // Выполнить операцию вычитания
    return DA_get_longt(); // DA = NEG(DA) изменяет знак числа на противоположный
}
int32_t DSC_SUB_get(int16_t dx, uint16_t dy)
{
    DSC_SUB(dx, dy);       // Выполнить операцию вычитания
    return DA_get_longt(); // DA = NEG(DA) изменяет знак числа на противоположный
}

// вычитание целых чисел без знака (unsigned integer). Запись результата в DA. Возврат результата 32-битного числа из DA.
uint32_t DSC_SUB_get(uint32_t da, uint16_t dy)
{
    DSC_SUB(da, dy); // Выполнить операцию вычитания
    return DA_get_long();
}
// вычитание целых чисел со знаком (signed integer). Запись результата в DA. Возврат результата 32-битного числа из DA.
int32_t DSC_SUB_get(int32_t da, int16_t dy)
{
    DSC_SUB(da, dy); // Выполнить операцию вычитания
    return DA_get_longt();
}
int32_t DSC_SUB_get(uint32_t da, int16_t dy)
{
    DSC_SUB(da, dy); // Выполнить операцию вычитания
    return DA_get_longt();
}
int32_t DSC_SUB_get(int32_t da, uint16_t dy)
{
    DSC_SUB(da, dy); // Выполнить операцию вычитания
    return DA_get_longt();
}

// деление целых чисел без знака (unsigned integer). Запись результата в DA.
void DSC_DIV(uint32_t da, uint16_t dy)
{
    asm volatile(
        "out 0x38, %A[dsda];" // Записать младшие 2 байта da в DA
        "\n\t"
        "out 0x39, %C[dsda];" // Записать старшие 2 байта da в DA
        "\n\t"
        "out 0x11, %[dsdy];" // Записать второе число (dy) в DY
        "\n\t"
        "out 0x01, %[opc];" // Выполняем операцию
        "\n\t"
        :                                                 // выходные данные
        : [dsda] "r"(da), [dsdy] "r"(dy), [opc] "r"(divd) // входные данные
    );
    while ((((DSCR) >> (DSD1)) & 0x01) == 0)
        ; // ждем результат деления - 8 тактов
}


// деление целых чисел со знаком (signed integer). Запись результата в DA.
void DSC_DIV(int32_t da, int16_t dy)
{
    bool i = (da < 0) ^ (dy < 0); // ^ - операция XOR - исключающее ИЛИ
    da = abs(da);
    dy = abs(dy);
    asm volatile(
        "out 0x38, %A[dsda];" // Записать младшие 2 байта da в DA
        "\n\t"
        "out 0x39, %C[dsda];" // Записать старшие 2 байта da в DA
        "\n\t"
        "out 0x11, %[dsdy];" // Записать второе число (dy) в DY
        "\n\t"
        "out 0x01, %[opc];" // Выполняем операцию
        "\n\t"
        :                                                   // выходные данные
        : [dsda] "r"(da), [dsdy] "r"(dy), [opc] "r"(divd)); // входные данные
    while ((((DSCR) >> (DSD1)) & 0x01) == 0)
        ; // ждем результат деления - 8 тактов
    if (i)
    {
        uDSC_op(nec_da); // DA = NEG(DA) изменяет знак числа на противоположный
    }
}
void DSC_DIV(uint32_t da, int16_t dy)
{
    bool i = (dy < 0);
    dy = abs(dy);
    asm volatile(
        "out 0x38, %A[dsda];" // Записать младшие 2 байта da в DA
        "\n\t"
        "out 0x39, %C[dsda];" // Записать старшие 2 байта da в DA
        "\n\t"
        "out 0x11, %[dsdy];" // Записать второе число (dy) в DY
        "\n\t"
        "out 0x01, %[opc];" // Выполняем операцию
        "\n\t"
        :                                                   // выходные данные
        : [dsda] "r"(da), [dsdy] "r"(dy), [opc] "r"(divd)); // входные данные
    while ((((DSCR) >> (DSD1)) & 0x01) == 0)
        ; // ждем результат деления - 8 тактов
    if (i)
    {
        uDSC_op(nec_da); // DA = NEG(DA) изменяет знак числа на противоположный
    }
}
void DSC_DIV(int32_t da, uint16_t dy)
{
    bool i = (da < 0);
    da = abs(da);
    asm volatile(
        "out 0x38, %A[dsda];" // Записать младшие 2 байта da в DA
        "\n\t"
        "out 0x39, %C[dsda];" // Записать старшие 2 байта da в DA
        "\n\t"
        "out 0x11, %[dsdy];" // Записать второе число (dy) в DY
        "\n\t"
        "out 0x01, %[opc];" // Выполняем операцию
        "\n\t"
        :                                                   // выходные данные
        : [dsda] "r"(da), [dsdy] "r"(dy), [opc] "r"(divd)); // входные данные
    while ((((DSCR) >> (DSD1)) & 0x01) == 0)
        ; // ждем результат деления - 8 тактов
    if (i)
    {
        uDSC_op(nec_da); // DA = NEG(DA) изменяет знак числа на противоположный
    }
}

// деление целых чисел без знака (unsigned integer). Запись результата в DA. Возврат результата 32-битного числа из DA.
uint32_t DSC_DIV_get(uint32_t da, uint16_t dy)
{
    DSC_DIV(da, dy);
    return DA_get_long();
}

// деление целых чисел со знаком (signed integer). Запись результата в DA. Возврат результата 32-битного числа из DA.
int32_t DSC_DIV_get(int32_t da, int16_t dy)
{
    DSC_DIV(da, dy);
    return DA_get_longt();
}
int32_t DSC_DIV_get(uint32_t da, int16_t dy)
{
    DSC_DIV(da, dy);
    return DA_get_longt();
}
int32_t DSC_DIV_get(int32_t da, uint16_t dy)
{
    DSC_DIV(da, dy);
    return DA_get_longt();
}

// остаток от деления целых чисел без знака (unsigned integer). Запись результата деления в DA, запись остатка от деления в DY.
void DSC_MOD(uint32_t da, uint16_t dy)
{
    asm volatile(
        "out 0x38, %A[dsda];" // Записать младшие 2 байта da в DA
        "\n\t"
        "out 0x39, %C[dsda];" // Записать старшие 2 байта da в DA
        "\n\t"
        "out 0x11, %[dsdy];" // Записать второе число (dy) в DY
        "\n\t"
        "out 0x01, %[opc];" // Выполняем операцию
        "\n\t"
        :                                                // выходные данные
        : [dsda] "r"(da), [dsdy] "r"(dy), [opc] "r"(mod) // входные данные
    );
    while ((((DSCR) >> (DSD1)) & 0x01) == 0)
        ; // ждем результат деления - 8 тактов
}

// остаток от деления целых чисел со знаком (signed integer). Запись результата деления в DA, запись остатка от деления в DY.
void DSC_MOD(int32_t da, int16_t dy)
{
    da = abs(da);
    dy = abs(dy);
    asm volatile(
        "out 0x38, %A[dsda];" // Записать младшие 2 байта da в DA
        "\n\t"
        "out 0x39, %C[dsda];" // Записать старшие 2 байта da в DA
        "\n\t"
        "out 0x11, %[dsdy];" // Записать второе число (dy) в DY
        "\n\t"
        "out 0x01, %[opc];" // Выполняем операцию
        "\n\t"
        :                                                  // выходные данные
        : [dsda] "r"(da), [dsdy] "r"(dy), [opc] "r"(mod)); // входные данные
    while ((((DSCR) >> (DSD1)) & 0x01) == 0)
        ; // ждем результат деления - 8 тактов
}
void DSC_MOD(uint32_t da, int16_t dy)
{
    dy = abs(dy);
    asm volatile(
        "out 0x38, %A[dsda];" // Записать младшие 2 байта da в DA
        "\n\t"
        "out 0x39, %C[dsda];" // Записать старшие 2 байта da в DA
        "\n\t"
        "out 0x11, %[dsdy];" // Записать второе число (dy) в DY
        "\n\t"
        "out 0x01, %[opc];" // Выполняем операцию
        "\n\t"
        :                                                  // выходные данные
        : [dsda] "r"(da), [dsdy] "r"(dy), [opc] "r"(mod)); // входные данные
    while ((((DSCR) >> (DSD1)) & 0x01) == 0)
        ; // ждем результат деления - 8 тактов
}
void DSC_MOD(int32_t da, uint16_t dy)
{
    da = abs(da);
    asm volatile(
        "out 0x38, %A[dsda];" // Записать младшие 2 байта da в DA
        "\n\t"
        "out 0x39, %C[dsda];" // Записать старшие 2 байта da в DA
        "\n\t"
        "out 0x11, %[dsdy];" // Записать второе число (dy) в DY
        "\n\t"
        "out 0x01, %[opc];" // Выполняем операцию
        "\n\t"
        :                                                  // выходные данные
        : [dsda] "r"(da), [dsdy] "r"(dy), [opc] "r"(mod)); // входные данные
    while ((((DSCR) >> (DSD1)) & 0x01) == 0)
        ; // ждем результат деления - 8 тактов
}

// остаток от деления целых чисел без знака (unsigned integer). Запись результата деления в DA, запись остатка от деления в DY. Возврат результата 16-битного числа из DY.
uint16_t DSC_MOD_get(uint32_t da, uint16_t dy)
{
    DSC_MOD(da, dy);
    return DY_get();
}

// остаток от деления целых чисел со знаком (signed integer). Запись результата деления в DA, запись остатка от деления в DY. Возврат результата 16-битного числа из DY.
uint16_t DSC_MOD_get(int32_t da, int16_t dy)
{
    DSC_MOD(da, dy);
    return DY_get();
}
uint16_t DSC_MOD_get(uint32_t da, int16_t dy)
{
    DSC_MOD(da, dy);
    return DY_get();
}
uint16_t DSC_MOD_get(int32_t da, uint16_t dy)
{
    DSC_MOD(da, dy);
    return DY_get();
}

// Инкремент регистра DA += DY
void DA_INC(uint16_t dy)
{
    asm volatile(
        "out 0x11, %[dsdy];" // Записать второе число (dy) в DY
        "\n\t"
        "out 0x01, %[opc];" // Выполняем операцию
        "\n\t"
        :                                // выходные данные
        : [dsdy] "r"(dy), [opc] "r"(inc) // входные данные
    );
}

// Инкремент регистра DA += DY
void DA_INC(int16_t dy)
{
    uint8_t oper = inc;
    oper |= (1 << 5); // записать знаковый бит dx
    asm volatile(
        "out 0x11, %[dsdy];" // Записать второе число (dy) в DY
        "\n\t"
        "out 0x01, %[opc];" // Выполняем операцию
        "\n\t"
        :                                 // выходные данные
        : [dsdy] "r"(dy), [opc] "r"(oper) // входные данные
    );
}

// Инкремент регистра DA += DY
uint32_t DA_INC_get(uint16_t dy)
{
    asm volatile(
        "out 0x11, %[dsdy];" // Записать число (dy) в DY
        "\n\t"
        "out 0x01, %[opc];" // Выполняем операцию
        "\n\t"
        :                                // выходные данные
        : [dsdy] "r"(dy), [opc] "r"(inc) // входные данные
    );
    return DA_get_long();
}

// Инкремент регистра DA += DY
int32_t DA_INC_get(int16_t dy)
{
    DA_INC(dy);
    return DA_get_longt();
}

// Декремент регистра DA -= DY
void DA_DEC(uint16_t dy)
{
    asm volatile(
        "out 0x11, %[dsdy];" // Записать второе число (dy) в DY
        "\n\t"
        "out 0x01, %[opc];" // Выполняем операцию
        "\n\t"
        :                                // выходные данные
        : [dsdy] "r"(dy), [opc] "r"(dec) // входные данные
    );
}

// Декремент регистра DA -= DY
void DA_DEC(int16_t dy)
{
    uint8_t oper = dec;
    oper |= (1 << 5); // записать знаковый бит dx
    asm volatile(
        "out 0x11, %[dsdy];" // Записать второе число (dy) в DY
        "\n\t"
        "out 0x01, %[opc];" // Выполняем операцию
        "\n\t"
        :                                 // выходные данные
        : [dsdy] "r"(dy), [opc] "r"(oper) // входные данные
    );
}

// Декремент регистра DA -= DY
uint32_t DA_DEC_get(uint16_t dy)
{
    asm volatile(
        "out 0x11, %[dsdy];" // Записать второе число (dy) в DY
        "\n\t"
        "out 0x01, %[opc];" // Выполняем операцию
        "\n\t"
        :                                // выходные данные
        : [dsdy] "r"(dy), [opc] "r"(dec) // входные данные
    );
    return DA_get_long();
}

// Декремент регистра DA -= DY
int32_t DA_DEC_get(int16_t dy)
{
    DA_DEC(dy);
    return DA_get_longt();
}

// Деление регистра DA /= DY
void DA_DIV(uint16_t dy)
{
    bool i = (DA_get_longt() < 0);
    uDSC_op(abs_da);
    asm volatile(
        "out 0x11, %[dsdy];" // Записать второе число (dy) в DY
        "\n\t"
        "out 0x01, %[opc];" // Выполняем операцию
        "\n\t"
        :                                 // выходные данные
        : [dsdy] "r"(dy), [opc] "r"(divd) // входные данные
    );
    while ((((DSCR) >> (DSD1)) & 0x01) == 0)
        ; // ждем результат деления - 8 тактов
    if (i)
    {
        uDSC_op(nec_da); // DA = NEG(DA) изменяет знак числа на противоположный
    }
}

// деление целых чисел со знаком (signed integer). Запись результата в DA.
void DA_DIV(int16_t dy)
{
    bool i = (DA_get_longt() < 0) ^ (dy < 0); // ^ - операция XOR - исключающее ИЛИ
    dy = abs(dy);
    uDSC_op(abs_da);
    asm volatile(
        "out 0x11, %[dsdy];" // Записать второе число (dy) в DY
        "\n\t"
        "out 0x01, %[opc];" // Выполняем операцию
        "\n\t"
        :                                   // выходные данные
        : [dsdy] "r"(dy), [opc] "r"(divd)); // входные данные
    while ((((DSCR) >> (DSD1)) & 0x01) == 0)
        ; // ждем результат деления - 8 тактов
    if (i)
    {
        uDSC_op(nec_da); // DA = NEG(DA) изменяет знак числа на противоположный
    }
}

// Деление регистра DA /= DY. Возврат результата 32-битного числа из DA.
uint32_t DA_DIV_get(uint16_t dy)
{
    DA_DIV(dy);
    return DA_get_long();
}

// деление целых чисел без знака (unsigned integer). Запись результата в DA. Возврат результата 32-битного числа из DA.
int32_t DA_DIV_get(int16_t dy)
{
    DA_DIV(dy);
    return DA_get_longt();
}

// функция map() для преобразования числа из одного диапазона в другой (время работы около 2 мкс)
// входные данные ограничены 16 битами, in_max > in_min, out_max > out_min.
// выходной диапазон в пределах указанного
uint16_t uDSC_map(uint16_t x, uint16_t in_min, uint16_t in_max, uint16_t out_min, uint16_t out_max)
{
    if (x >= in_max)
        return out_max; // ограничение выхода
    if (x <= in_min)
        return out_min;                                             // ограничение выхода
    DSC_MUL((uint16_t)(x - in_min), (uint16_t)(out_max - out_min)); // DA = (x - in_min) * (out_max - out_min)
    DA_DIV((uint16_t)(in_max - in_min));                            // DA /= in_max
    return (uint16_t)DA_INC_get(out_min);                           // DA += out_min
}

int16_t uDSC_map_int(int16_t x, int16_t in_min, int16_t in_max, int16_t out_min, int16_t out_max)
{
    if (x >= in_max)
        return out_max; // ограничение выхода
    if (x <= in_min)
        return out_min;                                           // ограничение выхода
    DSC_MUL((int16_t)(x - in_min), (int16_t)(out_max - out_min)); // DA = (x - in_min) * (out_max - out_min)
    DA_DIV((int16_t)(in_max - in_min));                           // DA /= in_max
    return (int16_t)DA_INC_get(out_min);                          // DA += out_min
}

// shiftR = 0xD0,          // сдвиг на несколько значений (1 - 15) DA >> shift
//  shiftL = 0xC0,          // сдвиг на несколько значений (1 - 15) DA << shift

// сдвиг (DA >> shift) на несколько значений (1 - 15)
void DA_shiftR(uint8_t shift)
{
    shift |= 0b11010000; // записать сдвиг в операцию
    asm volatile(
        "out 0x01, %[opc];"
        "\n\t"             // Выполняем операцию
        :                  // выходные данные
        : [opc] "r"(shift) // входные данные
    );
}

// сдвиг (DA << shift) на несколько значений (1 - 15)
void DA_shiftL(uint8_t shift)
{
    shift |= 0b11000000; // записать сдвиг в операцию
    asm volatile(
        "out 0x01, %[opc];"
        "\n\t"             // Выполняем операцию
        :                  // выходные данные
        : [opc] "r"(shift) // входные данные
    );
}

#endif

/*********************************************/

/*
// записать число 32-бит в регистр DA
inline void DA_write_long(uint32_t da) {
   asm volatile(
        "out 0x38, %A[dsda];" "\n\t"  // Записать младшие 2 байта da в DA
        "out 0x39, %C[dsda];" "\n\t"  // Записать старшие 2 байта da в DA
        :                             // выходные данные
        : [dsda] "r"(da)              // входные данные
    );
}
*/
/*
// записать число 16-бит в регистр DA
inline void DA_write_int(uint16_t da) {
   asm volatile(
        "out 0x38, %[dsda];" "\n\t"   // Записать младшие 2 байта da в DA
        :                            // выходные данные
        : [dsda] "r"(da)             // входные данные
    );
}
*/
/*
// записать число 16-бит в регистр DX
inline void DX_write(uint16_t dx) {
   asm volatile(
        "out 0x10, %[dsdx];" "\n\t"  // Устанавливаем число dx в DX
        :                            // выходные данные
        : [dsdx] "r"(dx)             // входные данные
    );
}
*/
/*
// записать число 16-бит в регистр DY
inline void DY_write(uint16_t dy) {
   asm volatile(
        "out 0x11, %[dsdy];" "\n\t"  // Устанавливаем число dy в DY
        :                            // выходные данные
        : [dsdy] "r"(dy)             // входные данные
    );
}
*/
/*
// выполнение операций с DA
void uDSCda(uDSCda_op operation) {
    asm volatile(
        "out 0x01, %[opc];"  "\n\t"  // Выполняем операцию
        :                            // выходные данные
        : [opc] "r"(operation)  // входные данные
    );
}
*/

/*
// // выполнение операций деления  da на dy. Запись результата в DA. Запись остатка от деления в DY.
void uDSC_divided_int(uint16_t da, uint16_t dy, uDSC_divided_op operation) {
    asm volatile(
        "out 0x38, %[dsda];" "\n\t"  // Записать первое число da в DA
        "out 0x11, %[dsdy];" "\n\t"  // Записать второе число (dy) в DY
        "out 0x01, %[opc];"  "\n\t"  // Выполняем операцию
        :                            // выходные данные
        : [dsda] "r"(da), [dsdy] "r"(dy), [opc] "r"(operation)  // входные данные
    );
    while ((((DSCR) >> (DSD1)) & 0x01) == 0); // ждем результат деления - 8 тактов
}

// выполнение операций деления da на dy и возврат результата из DA 16-битного числа. Запись остатка от деления в DY.
uint16_t uDSC_divided_get_int(uint16_t da, uint16_t dy, uDSC_divided_op operation) {
    uDSC_divided_int(da, dy, operation); // Выполнить операцию деления
    return DA_get_int();  // вернуть результат
}
*/

/*
// выполнение операций деления  da на dy. Запись результата в DA.
void uDSC_divided_intt(int16_t da, int16_t dy, uDSC_divided_op operation) {
    asm volatile(
        "out 0x38, %[dsda];" "\n\t"  // Записать первое число da в DA
        "out 0x11, %[dsdy];" "\n\t"  // Записать второе число (dy) в DY
        "out 0x01, %[opc];"  "\n\t"  // Выполняем операцию
        :                            // выходные данные
        : [dsda] "r"(da), [dsdy] "r"(dy), [opc] "r"(operation));  // входные данные
        while ((((DSCR) >> (DSD1)) & 0x01) == 0); // ждем результат деления - 8 тактов
        if (da < 0 or dy < 0) uDSC_op(nec_da);  // DA = NEG(DA) изменяет знак числа на противоположный
        return;
}

// выполнение операций деления da на dy и возврат результата 16-битного числа
int16_t uDSC_divided_get_intt(int16_t da, int16_t dy, uDSC_divided_op operation) {
    uDSC_divided_intt(da, dy, operation); // Выполнить операцию деления
    return DA_get_intt();              // вернуть результат
}
*/