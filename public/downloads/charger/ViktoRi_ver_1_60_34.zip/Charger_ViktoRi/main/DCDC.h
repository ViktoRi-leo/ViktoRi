#include <Arduino.h>

#define DCDC_CHARGE true      // заряд
#define DCDC_DISCHARGE false  // разряд

// класс управления DC-DC модулем
class DCDC {
public:
  // DCDC(void){};

  // установить частоту работы ШИМ
  void Freq(const uint8_t frq);

  // режим работы DCDC (заряд/разряд)
  void start(bool mods);

  // отключить плавный пуск - вызывать после start() и перед begin()
  void Smooth_off(bool x);

  // задать максимальные значения напряжения и тока заряда
  void begin(uint16_t volt_charge, int16_t cur_charge);

  // величина ошибки
  int16_t Err(void);

  // регулировка напряжения и тока заряда
  void Control(void);
  
  // пауза
  void pause(bool x);

  // отключить заряд, разряд
  void Off(void);

  // стабилизация
  void stabilization(bool x);

  // напряжение
  void setVolt_charge(uint16_t v);

  // ток
  void setCur_charge(int16_t v);

  // вернуть напряжение
  uint16_t getVolt_charge(void);
  
  // вернуть ток
  int16_t getCur_charge(void);
  
  // вернуть ЩИМ
  uint8_t getTok(void);
  // вернуть состояние паузы
  bool get_pause(void);
  // вернуть состояние стабилизации
  bool get_stabilization(void);

private:
  // список членов для использования внутри класса
  uint16_t _volt_charge;    // напряжение заряда
  int16_t _cur_max;         // предельный ток зарядника
  int16_t _cur_charge_max;  // максимальный ток заряда
  int16_t _cur_charge;      // текущий ток заряда
  uint8_t _pwm = 0;         // значение ШИМ

  int16_t _err_pred;
  float _Integral;
  uint16_t _time_sec;

  uint8_t _flags = 0b00000000;  // флаги  
};

extern DCDC dcdc;