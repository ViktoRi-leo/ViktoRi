#include "1_User_Setup.h"
#include "AllFunctions.h"
#include "Classes.h"
#include "Display.h"
#include "global.h"
#include "menu_txt.h"
#include <EEPROM.h>

// сброс настроек при первой прошивке МК
void first_firmware(void) {
#if defined(__LGT8FX8P__)
  if (lgt_eeprom_read_byte(MEM_RESET) != MEMVER)
    Reset_settings(1);
#else
  if (EEPROM.read(MEM_RESET) != MEMVER)
    Reset_settings(1);
#endif
}

// сброс настроек по умолчанию
void Reset_settings(uint8_t sett) {
  lcd.clear();
  disp.printFromPGM((int)(&settings[22]));
  bool ext = true;
  do {
    setCursory();
    lcd.write('>');
    switch (sett) {
    case 0:
      lcd.print(F(txt5)); // "Exit"
      break;
    case 1:
      lcd.print(F(txt10)); // "All" Стереть все
      break;
    case 2:
      print_mode(SETTING); // "Settings"
      break;
    case 3:
      disp.printFromPGM((int)(&menuTxt[8])); // "Calibration"
      break;
    case 4:
      disp.printFromPGM((int)(&settings[SYSPARAM])); // "!system param!"
      break;
    }
    ClearStr(12);
    // пауза до сигала от кнопок или энкодера
    do {
      butt.Tick(); // опрос кнопок и энкодера
    } while (!butt.tick);

    switch (butt.tick) {
    case LEFT:
    case RIGHT:
      sett = constrain_my(sett, 0, 4, butt.tick);
      break;
    case STOPCLICK:
    case OKHELD:
      return; // выйти
    case OKCLICK:
      ext = false; // выйти из цикла
      break;
    }
  } while (ext);
  switch (sett) {
  case 0:
    break; // выйти
  case 1:
  // сбросить все
  case 2:
    // сбросить настройки по умолчанию - загрузить из PROGMEM
    memcpy_P(&profil, &profil_default, sizeof(Profils));
    lcd.clear();
    lcd.print(F(txt12)); // "Sbros"
    for (uint8_t num = 0; num <= PROFIL; num++) {
      eeSave_profil(num);
      lcd.write('.'); // ........
    }
    Res_ktc(); // очистить память КТЦ
    if (sett != 1)
      break;
  case 3:
    // сбросить калибровки по умолчанию
    vkr.Ohms = OHMS; // кооффицмент коррекции напряжения 0-255
    vkr.profil = 0;  // текущий профиль 0-6
#ifdef VKORRECT
    // коэффициент для калибровки напряжения БП  // REF
    vkr.Vref = VKORRECT; 
#else
    vkr.Vref = 1000; // коэффициент для калибровки напряжения БП
#endif
    vkr.shunt = (uint16_t)((float)SHUNT * 100000); // значение шунта
    vkr.inaKoof = INAVOLTKOOF;
    // сохранить структуру vkr
    eeSave_vkr();
  case 4:
    // сброс сервисных параметров
    eepResetService();
    break;
  }
  lcd.clear();
  if (sett) {
    print_mode(SETTING);
    lcd.print(F(txt2)); // сброс
    setCursory();
    lcd.print((sizeof(Profils)));
    lcd.print(F("B "));
    lcd.print((sizeof(vkr)));
    lcd.write('B');
#if defined(__LGT8FX8P__)
    lgt_eeprom_update_byte(MEM_RESET, MEMVER);
#else
    EEPROM.update(MEM_RESET, MEMVER);
#endif

    Delay(3000);
    if (sett == 1 or sett >= 3)
      resetFunc();
    lcd.clear();
  }
}

// функция сброса значений заряда
void Res_mem_char(void) {
  // единица для того чтобы Ач и Вт сразу отображались на дисплее
  profil.charge.stat.ah = 1;
  profil.charge.stat.wh = 1;
  profil.charge.stat.time = 0;
  profil.add.stat.time = 0;
  profil.add.stat.ah = 0;
  profil.add.stat.wh = 0;
#if (BRRANIMIR == 1)
  bitClear(profil.flags, BRANIM);
  bitClear(profil.flags, BRANIMBOIL);
#endif
}

// функция сброса значений разряда
void Res_mem_dischar(void) {
  profil.disch.stat.ah = 1;   // емкость разряда Ah
  profil.disch.stat.wh = 1;   // емкость разряда Вт/ч
  profil.disch.stat.time = 0; // время разряда
  profil.add.stat.ah = 0;     // емкость разряда до напряжения аккумулятора
  profil.add.stat.wh = 0;     // емкость до напряжения аккумулятора Вт/ч
}

// очистить память значений КТЦ
#if defined(__LGT8FX8P__)
void Res_ktc(void) {
   // сохранить количество циклов
  lgt_eeprom_update_byte(MEM_ROUND, 1);
  // сохранить номер текущего режима
  lgt_eeprom_update_byte(MEM_NUMBER, 1);
  // очистить память КТЦ
  for (uint16_t i = 0; i < (uint8_t)(5 * 16); i++)
    lgt_eeprom_update_byte(MEM_KTC + i, 0); 
}
#else
void Res_ktc(void) {  
  // сохранить количество циклов
  EEPROM.update(MEM_ROUND, 1);
  // сохранить номер текущего режима
  EEPROM.update(MEM_NUMBER, 1);
  // очистить память КТЦ
  for (uint16_t i = 0; i < (uint8_t)(5 * 16); i++)
    EEPROM.update(MEM_KTC + i, 0);
}
#endif
