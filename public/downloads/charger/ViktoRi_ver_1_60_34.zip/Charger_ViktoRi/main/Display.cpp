#include "Display.h"
#include "1_User_Setup.h"
#include "global.h"
#include "system.h"
#include "Classes.h"
#include "menu_txt.h"
#include "INA226int.h"
#include "Battery.h"
#include "AllFunctions.h"
#include "DCDC.h"

LiquidCrystal_I2C lcd(ADDRDISP, DISPLAYx, DISPLAYy);

// символы аккумулятора и заряда
const char simb_array[8][8] PROGMEM = {
  { 0x0E, 0x11, 0x11, 0x11, 0x11, 0x11, 0x11, 0x1F },  // akb 0
  { 0x0E, 0x11, 0x11, 0x11, 0x11, 0x11, 0x1F, 0x1F },  // akb 1
  { 0x0E, 0x11, 0x11, 0x11, 0x11, 0x1F, 0x1F, 0x1F },  // akb 2
  { 0x0E, 0x11, 0x11, 0x11, 0x1F, 0x1F, 0x1F, 0x1F },  // akb 3
  { 0x0E, 0x11, 0x11, 0x1F, 0x1F, 0x1F, 0x1F, 0x1F },  // akb 4
  { 0x0E, 0x11, 0x1F, 0x1F, 0x1F, 0x1F, 0x1F, 0x1F },  // akb 5
  { 0x0E, 0x1F, 0x1F, 0x1F, 0x1F, 0x1F, 0x1F, 0x1F },  // akb 6
  { 0x03, 0x06, 0x0C, 0x18, 0x1F, 0x06, 0x0C, 0x18 },  // заряд 7
};

// загрузка в память дисплея своих символов(состояние акб)
void setDisplaySimbol(void) {
  for (uint8_t x = 0; x < 8; x++) lcd.createChar(x, &simb_array[x][0]);
}

// Приветствие. Версия прошивки и тип контроллера
void print_version(void) {
  lcd.setCursor((uint8_t)((DISPLAYx - 7) / 2), (uint8_t)(DISPLAYy / 2 - 1));
  lcd.print(F(txt_ViktoRi));                                               // *      ViktoRi       *
  lcd.setCursor((uint8_t)((DISPLAYx - 12) / 2), (uint8_t)(DISPLAYy / 2));  // *   Ver 1.0-328p     *
  lcd.print(F(VER));
}


// Функции управления подсветкой
void Display::Light_setTime(void) {
  _light_tm = (uint32_t)eepGetService_num(TIMELIGHT) * 60000;  // установить время подсветки
}

// включение подсветки
void Display::Light_high(void) {
  lcd.setBacklight(true);      // включение подсветки
  _light_time = millis_sys() + _light_tm;  // старт отсчета времени подсветки
}

// отключение подсветки через 3 минуты, если разрешено
void Display::Light_low(void) {
  if (eepGetService_num(TIMELIGHT) and (millis_sys() >= _light_time)) {
    _light_time = millis_sys() + _light_tm;
     // если разрешено отключение подсветки и время вышло отключение подсветки
    lcd.setBacklight(false); 
  }
}

// функция отключает подсветку если отключилось питание от акб
void Display::Light_power(void) {
  if (!sysFlagGetBits(FlagsName::POWERON)) Light_low();
}

// функция для печати из PROGMEM
void Display::printFromPGM(int charMap) {
  // получаем адрес из таблицы ссылок
  uint16_t ptr = pgm_read_word(charMap);  
  while (true) {
    char c = pgm_read_byte(ptr++);
    if (c == '\0') break;
    // выводим в монитор или куда нам надо // всю строку до нулевого символа
    lcd.write(c);  
  }
}

Display disp;

// вывод флоат напряжения и тока
void print_float(float fl, uint8_t x) {
  lcd.print(fl / 1000, x);
}

// вывод флоат Ач и Втч
void print_floatA(int32_t fl) {
  lcd.print(((float)fl / 1000000), ((fl < 1000000) ? 2 : 1));
}

// Вывод напряжения
void print_volt(uint16_t volt, uint8_t x) {
  print_float((float)volt, x); 
  lcd.print(F("V "));
}

// Вывод тока
void print_current(int16_t amp, uint8_t x) {
  print_float((float)amp, x); 
  lcd.print(F("A "));
}

// вывод напряжения и тока
void print_volt_current(uint16_t volt, int16_t amp, uint8_t x) {
  print_volt(volt, x); 
  print_current(amp, x);
}

// вывод Ач
void print_Ah(int32_t Ah) {
  print_floatA(Ah);
  lcd.print(F("Ah "));
}

// вывод Втч
void print_Wh(int32_t Wh) {
   print_floatA(Wh);
   lcd.print(F("Wh "));
}

// вывод сопротивления - mOm
void print_resist(float R) {
  lcd.print(R);
  lcd.print(F("mOm "));
}

// вывод - часы
void print_hour(uint8_t hour) {
  lcd.print(hour);
  lcd.print(F("h "));
}


 // пробел
void print_space(void) {
  lcd.write(' ');
}


void pr_tm(uint16_t tm) {
  if (tm < 10) lcd.print(0);
  lcd.print(tm);
}

// функция расчета текущего времени и вывод на дисплей
#if defined(__LGT8FX8P__)
void Print_time(uint32_t time_real, uint8_t x, uint8_t y) {
  lcd.setCursor(x, y);
  // остаток от деления DA = DA/DY, DY = DA%DY
  DSC_MOD(time_real, (uint16_t)3600);
  pr_tm(DA_get_int());  // часы
  lcd.write(':');
  // остаток от деления DA = DA/DY, DY = DA%DY
  DSC_MOD((uint32_t)DY_get(), (uint16_t)60);
  pr_tm(DA_get_int());  // минуты
  lcd.write(':');
  pr_tm(DY_get());  // секунды
}
#else
void Print_time(uint32_t time_real, uint8_t x, uint8_t y) {
  lcd.setCursor(x, y);
  pr_tm((uint16_t)(time_real / 3600ul));  // часы
  lcd.write(':');
  uint32_t t = (time_real % 3600ul);
  pr_tm((uint16_t)(t / 60ul));  // минуты
  lcd.write(':');
  pr_tm((uint16_t)(t % 60ul));  // секунды
}
#endif


void setCursorx(void) {
  lcd.setCursor(0, 0);
}
void setCursory(void) {
  lcd.setCursor(0, 1);
}

#if (SENSTEMP1 or SENSTEMP2)

// печать температуры транзистора или акб
void print_tr(void) {
#if (SENSTEMP1 and SENSTEMP2)
  // если подключены 2 датчика температуры
  static uint8_t _tmr = 0;
  static char _tmp = 'c';  // c
  if (++_tmr >= 3) {
    _tmr = 0;
    _tmp = (_tmp == 'c') ? 'C' : 'c';
    lcd.print((_tmp == 'C') ? temp_Q1 : temp_akb);
    lcd.write(_tmp);
    ClearStr(2);
  }
#endif

#if (SENSTEMP1 > 0 and SENSTEMP2 == 0)
  // если подключен только датчик транзистора
  lcd.print(temp_Q1);
#if (INTERFACE == 0)
  lcd.print(F("C "));  // если русский интерфейс
#else
  lcd.write(223);  // знак градуса // если английский интерфейс
#endif
#endif

#if (SENSTEMP1 == 0 and SENSTEMP2 > 0)
  // если подключен только датчик акб
  lcd.print(temp_akb);
  lcd.print(F("С "));
#endif
}

#endif

// экран ошибки напряжения БП
void Power_error(void) {
#if (TIME_LIGHT)
  disp.Light_high();  // включение подсветки
#endif

#if (SPEAKER > 0)
  Speaker(500);
#endif
   
  lcd.clear();
  lcd.print(F(txt4));  // "Power "
  print_mode(ERROR);   // error  
  setCursory();
  print_volt(getPower());  
}

// экран вывода ошибок
void window_errors(void) {
#if (VOLTIN == 1)
  if (!sysFlagGetBits(FlagsName::POWERHIGH)) {
    if (bitRead(profil.flags, ACTIVITI)) {
      dcdc.Off();
      bitClear(profil.flags, ACTIVITI);
    }
    Power_error();
  }
#endif
}

bool akbzn = true;
// функция вывод на дисплей
#if ((DISPLAYx == 16 and DISPLAYy == 2) or (DISPLAYx == 20 and DISPLAYy == 2))
void Display_print(int32_t Ah, uint32_t time_real, uint8_t prc, bool add) {
  // 0 строка
  setCursorx();
  // if (ina.voltsec < 10000) lcd.print(0);
  print_volt(ina.voltsec, (ina.voltsec < (uint16_t)10000) ? (uint8_t)3 : (uint8_t)2);
  print_Ah(Ah); 
  lcd.setCursor(DISPLAYx - 1, 0);
  // вывод режима работы
  lcd.print((char)pgm_read_byte(&regimr[(add ? (uint8_t)Modes::ADDCHARGE : profil.Regim)]));
  // 1 строка
  setCursory();
  int16_t curr = abs(ina.ampersec); 
  print_current(curr, (curr < (int16_t)10000) ? (uint8_t)3 : (uint8_t)2);
  Print_time(time_real, 7, 1);
  lcd.setCursor(DISPLAYx - 1, 1);
    // знак акб:  пробел - значек заряда
  lcd.write((akbzn ? map_my(prc, 0, 100, 0, 6) : ((profil.Regim == Modes::DISCHARGE) ? ' ' : 7)));
  akbzn = !akbzn;
}
// *14.81V 0.01Ah Ch*  0
// *10.55A 01:01:01 *  1

// 1 - используется диспплей 20*4
#elif (DISPLAYx == 20 and DISPLAYy == 4)
// функция вывод на дисплей 20*4
void Display_print(int32_t Ah, int32_t Wh, uint32_t time_real, int8_t tr, uint8_t prc) {
  // 0 строка
  setCursorx();
  print_mode(TYPE_AKB);  // вывод типа акб
  print_space(); 
  print_Capacity();
  print_mode(VOLTAGE);  // 12.6V
  // 1 строка
  Print_time(time_real, 0, 1); 
  print_space();
  print_mode(MODE);             // режим работы
  // 2 строка
  lcd.setCursor(0, 2);
  print_Ah(Ah);
  print_Wh(Wh);  
  lcd.print(prc);         // процент заряда Акб
  lcd.print(F("%  "));
  // 3 строка
  lcd.setCursor(0, 3);
 // if (ina.voltsec < 10000) lcd.print(0);
  print_volt(ina.voltsec, (ina.voltsec < (uint16_t)10000) ? (uint8_t)3 : (uint8_t)2);
  int16_t curr = abs(ina.ampersec); 
  print_current(curr, (curr < 10000) ? 3 : 2);  // вывести Ампер
   
#if (SENSTEMP1 or SENSTEMP2)
  print_tr();                                                                                                             // температура транзистора или акб
#endif
  lcd.setCursor(DISPLAYx - 1, 3);
  lcd.write((akbzn ? map_my(prc, 0, 100, 0, 6) : ((profil.Regim == Modes::DISCHARGE) ? 32 : 7)));  // знак акб - значек заряда -  пробел
  akbzn = !akbzn;
}
// *PB Ca/Ca 60Ah 12.6V *  0
// *01:01:01 Zaryad>Doza*  1
// *60.56Ah 220.56Wh 56%*  2
// *14.81V 6.555A 35C  ~*  3


// 1 - используется диспплей 16*4
#elif (DISPLAYx == 16 and DISPLAYy == 4)
// функция вывод на дисплей 20*4
void Display_print(int32_t Ah, int32_t Wh, uint32_t time_real, int8_t tr, uint8_t prc) {
  // 0 строка
  setCursorx();
  print_Capacity();
  lcd.print(((float)bat.Volt(volt_cell_charge) / 100), 1);  // напряжение
  lcd.print(F("V "));                                       // V
  print_mode(MODE);                                         // режим работы
  // 1 строка
  Print_time(time_real, 0, 1);
  print_space();
  lcd.print(prc); 
  lcd.print(F("% "));
#if (SENSTEMP1 or SENSTEMP2)
  print_tr();  // температура транзистора или акб
#endif
  // 2 строка
  lcd.setCursor(0, 2);
  print_Ah(Ah);
  print_Wh(Wh); 
  // 3 строка
  lcd.setCursor(0, 3);
 // if (ina.voltsec < 10000) lcd.print(0);
  print_volt(ina.voltsec, (ina.voltsec < (uint16_t)10000) ? (uint8_t)3 : (uint8_t)2);
  print_current(((profil.Regim == 4) ? abs(ina.ampersec) : ina.ampersec), ((abs(ina.ampersec) < 10000) ? 3 : 2));
  lcd.setCursor(DISPLAYx - 1, 3);
  lcd.write((akbzn ? map_my(prc, 0, 100, 0, 6) : ((profil.Regim == Modes::DISCHARGE) ? ' ' : 7)));  // знак акб - значек заряда -  пробел
  akbzn = !akbzn;
}
// *60Ah 12.6V Zarya*
// *01:01:01 52% 35C*
// *60.56Ah 220.56Wh*
// *14.81V 6.555A  ~*

#endif

// вывести на дисплей - вкл/откл
void PrintOnOff(bool i) {
  lcd.print((i ? F(txt13) : F(txt14)));  // вкл  / откл
}

// вывод на дисплей > или пробел
void Write_x(bool x) {
  lcd.write((x ? '>' : ' '));  // > or  пробел
}
/*
// вывод на дисплей
enum DispRgb: uint8_t {
  MODE,      // 0 режим работы
  TYPE_AKB,  // 1 тип акб
  ERROR,     // 2 ошибка
  SETTING,   // 3 настройки
  VOLTAGE,   // 4 напряжение во float
};
*/

// вывод на дисплей: 0-режим работы, 1-тип акб
void print_mode(uint8_t i) {
  switch (i) {
    case MODE: disp.printFromPGM((int)(&modeTxt[profil.Regim])); break;
    case TYPE_AKB: disp.printFromPGM((int)(&akb_name_list[profil.akb.type])); break;
    case ERROR: lcd.print(F(txt21)); break;                      // "error"
    case SETTING: disp.printFromPGM((int)(&menuTxt[5])); break;  // "Settings"
    case VOLTAGE:
      lcd.print(((float)bat_volt(profil.akb.type) / 1000), 1);  // напряжение
      lcd.write('V');
      break;
  }
}

void print_Capacity(void) {
  lcd.print(profil.akb.capacity);
  lcd.print(F("Ah "));
}

void printCykl(void) {
  lcd.write('C');
  lcd.print(Round);
}

// Функция вывода напряжения акб и количество банок
void Vout(void) {
  print_mode(VOLTAGE);  // 12.6V
  lcd.write('(');
  lcd.print(profil.akb.cell);
  lcd.write(')');
  ClearStr(4);  // очистить поле
  lcd.setCursor(3, 0);
}

// функция очистки строки дисплея (i символов)
void ClearStr(uint8_t i) {
  while (i--) lcd.write(' ');
}
/*
void print_otval_akb(void) {  
  setCursorx();
  lcd.print(F("Akb"));
  lcd.print(F(txt21));
  PrintVA()
}
*/
/*
// вывод свободной оперативки
void print_memoryFree(void) {
  lcd.setCursor(0, 0);
  lcd.print(memoryFree());
  lcd.write(' ');
}
*/
/*
// Переменные, создаваемые процессом сборки,
// когда компилируется скетч
extern int __bss_end;
extern void *__brkval;

// Функция, возвращающая количество свободного ОЗУ (RAM)
int memoryFree(void) {
  int freeValue;
  if ((int)__brkval == 0)
    freeValue = ((int)&freeValue) - ((int)&__bss_end);
  else
    freeValue = ((int)&freeValue) - ((int)__brkval);
  return freeValue;
}
*/
