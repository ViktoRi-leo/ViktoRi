#include "1_User_Setup.h"
#include "AllFunctions.h"
#include "Classes.h"
#include "DCDC.h"
#include "Display.h"
#include "INA226int.h"
#include "global.h"
#include "menu_txt.h"
#include "operations.h"
#include "system.h"
#include <GyverIO.h>

#if (DISCHAR == 1)
// Функция разряда аккумулятора
void Discharge(void) {
  // вывод режима, напряжения и тока заряда/разряда
  print_volt_current(profil.disch.voltage_end, profil.disch.current);
  printCykl();                     // вывод количества циклов
  const uint16_t s1 = ina.voltsec; // текущее наряжение акб;
  uint8_t n_disp = 0, ns_disp = 0;
  bool dischar = true; // разряд включен

  uint8_t time_millis = 0;
  TimeCount tyme;
  tyme.local = profil.disch.stat.time;

#if (POWER == 1)
  Relay_on(LOW); // отключить реле
#endif
#if (FAN > 0 and FAN_DISCHAR_ON == 1)
  fan.ONonse(true); // запустить кулер
#endif
  Delay(3000);
#if (POWER == 1)
  // если ток разряда менее тока ЗУ*2 реле 220В включится
  if (profil.disch.current_end <= (abs(ina.curr_aver) << 1))
    Relay_on(HIGH); // включить реле
#endif

  uint16_t time10 = 600; // выполнить раз в 600 сек (10 мин)

  dcdc.start(DCDC_DISCHARGE);
  dcdc.begin(profil.disch.voltage_end, profil.disch.current);
  start_second_usr();
  // цикл разряда 35 часов максимум (35*60*60=126000 сек)
  while (dischar and bitRead(profil.flags, ACTIVITI)) {
    sensor_survey();

    if (butt.tick) {
      // если кнопка нажата
      switch (butt.tick) {
      case OKHELD:
      case STOPHELD:
        bitClear(profil.flags, ACTIVITI); // завершить разряд
        break;
      case RIGHT:
      case LEFT:
        n_disp++;            // окно отображения
        ns_disp = TIME_DISP; // время отображения сек
        lcd.clear();
        break;
      }
    }

    if (get_second()) {
      time_millis = 5;
    }

    // если прошла секунда
    if (time_millis) {
      switch (time_millis) {
      case 5:
        profil.disch.stat.ah += Calc_AhWh((int32_t)abs(ina.ampersec));
        profil.disch.stat.wh += Calc_AhWh(ina.getsPower());
        // рассчитать количество всех секунд разряда
        tyme.cal_real_tm();
        profil.disch.stat.time = tyme.real_tm;
        if (profil.disch.stat.time > 126000)
          dischar = false;
        break;
      case 4: {
        int16_t ampsec = abs(ina.ampersec);
        // напряжение уменьшилось до установленного и ток
        // уменьшился до установленного то завершить разряд
        if (ina.volt_aver <= profil.disch.voltage_end and
            ampsec <= profil.disch.current_end)
          dischar = false;
      } break;
      case 3:
        // вывод на дисплей 1602
#if (DISPLAYy == 2)
        switch (n_disp) {
          // вывод на дисплей
        case 0:
          Display_print(profil.disch.stat.ah, profil.disch.stat.time,
                        map_my(ina.voltsec, profil.disch.voltage_end, s1, 0, 100),
                        false);
          break;
        case 1:
          // экран 1 // вывод средних значений напряжения, тока. Вывод
          // Ватт-часов.
          setCursorx();
          print_mode(MODE);
          print_space();
          printCykl();
          print_space();
          lcd.print(dcdc.getTok()); // вывод значения ШИМ заряда
          setCursory();
          print_Wh(profil.disch.stat.wh);
          lcd.print(map_my(ina.voltsec, profil.disch.voltage_end, s1, 0, 100));
          lcd.write('%');
          print_space();
#if (SENSTEMP1 or SENSTEMP2)
          print_tr(); // температура транзистора или акб
#endif
              // print_memoryFree(); // вывод свободной оперативки
          if (ns_disp)
            ns_disp--;
          else
            n_disp = 0;
          break;
          // *Discharge C1 N1 *
          // *45.25Wh 45%     *
        default:
          n_disp = 0;
          break;
        }
// вывод на дисплей 2004 или 1604
#elif (DISPLAYy == 4)
        // вывод на дисплей
        switch (n_disp) {
        case 0:
          // экран 0  вывод текущих значений
          Display_print(profil.disch.stat.ah, profil.disch.stat.wh, profil.disch.stat.time,
                        temp_Q1,
                        map_my(ina.voltsec, profil.disch.voltage_end, s1, 0, 100));
          break;
        case 1:
          // экран 1
          setCursorx();
          print_mode(MODE);
          print_space();
          printCykl();
          setCursory();
#if (SENSTEMP1 or SENSTEMP2)
          print_tr(); // температура транзистора или акб
#endif
          if (ns_disp)
            ns_disp--;
          else
            n_disp = 0;
          break;
        default:
          n_disp = 0;
          break;
        }
#endif
        break;

      case 2:
#if (TIME_LIGHT)
        disp.Light_low();
#endif
        break;
      case 1:
#if (PROTECT_BLOCK)
        Protect::Guard();
#endif
#if (LOGGER)
#if (LOGGER == 4)
        Sout.create_advanced(-profil.disch.stat.ah, 0, 0, profil.disch.stat.time);
#else
        Sout.create(-profil.disch.stat.ah);
#endif
#endif
        // выполнить раз в 10 мин
        if (--time10 == 0) {
          time10 = 600;
          eepSavedStruct(); // сохранить настройки
        }
        break;
      }
      time_millis--;
    }
    // выполнить раз в секунду
  }
  // цикл разряда
  dcdc.Off(); // отключить заряд, разряд.
#if (PROTECT_BLOCK)
  Protect::Open(false);
#endif
#if (FAN > 0 and FAN_DISCHAR_ON == 1)
  fan.ONonse(false); // автоматический режим кулера
#endif
  eepSavedStruct(); // сохранить настройки
#if (POWER == 1)
  Relay_on(true); // включить сеть 220В
#endif
}
// Функция разряда аккумулятора
#endif
