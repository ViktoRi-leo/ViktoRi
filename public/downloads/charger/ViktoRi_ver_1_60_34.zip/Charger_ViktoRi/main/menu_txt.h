#include <Arduino.h>
#include "1_User_Setup.h"

/* ***** русский (!для дисплеев с поддержкой русского языка!) ***** */  
#if (INTERFACE == 0)
// пункты главного меню
const char menu_profil[] PROGMEM = "Pr:";                                                         //  0   Профиль
const char menu_akb_capacity[] PROGMEM = "\x45\xBC\xBA\x6F\x63\xBF\xC4 \x41\x4B\xA0";             //  1   Емкость  // АКБ
const char menu_akb_type[] PROGMEM = "\x54\xB8\xBE \x41\x4B\xA0";                                 //  2   Тип АКБ
const char menu_akb_volt[] PROGMEM = "\x48\x61\xBE\x70\xC7\xB6\x65\xBD\xB8\x65 \x41\x4B\xA0";     //  3   Напряжение АКБ
const char menu_mode[] PROGMEM = "\x50\x65\xB6\xB8\xBC \x70\x61\xB2\x6F\xBF\xC3";                 //  4   Режим работы
const char menu_settings[] PROGMEM = "\x48\x61\x63\xBF\x70\x6F\xB9\xBA\xB8";                      //  5   Настройки
const char menu_resist_akb[] PROGMEM = "\x43\x6F\xBE\x70\x6F\xBF\x2E\x41\x4B\xA0";                //  6   Сопрот. АКБ
const char menu_statistic[] PROGMEM = "\x43\xBF\x61\xBF\xB8\x63\xBF\xB8\xBA\x61";                 //  7   Статистика
const char menu_calibration[] PROGMEM = "\x4B\x61\xBB\xB8\xB2\x70\x6F\xB3\xBA\x61";               //  8   Калибровка
const char menu_sensors[] PROGMEM = " ";

// пункты меню режима работы
const char mode_charge[] PROGMEM = "\xA4\x61\x70\xC7\xE3";                                          //  0   Заряд
const char mode_charge_add[] PROGMEM = "\xA4\x61\x70\xC7\xE3>\xE0\x6F\xB7\x61\x70\xC7\xE3";         //  1   Заряд>Дозаряд
const char mode_asimm[] PROGMEM = "Acc\xB8\xBC. \xB7\x61\x70\xC7\xE3";                              //  2   Aссиметричный заряд // \x65\xBFp
const char mode_branimir[] PROGMEM = "\xA4\x61\x70\xC7\xE3 \xA0\x70\x61\xBD\xB8\xBC\xB8\x70\x61";   //  3   Заряд Бранимир
const char mode_addcharge[] PROGMEM = "\xE0\x6F\xB7\x61\x70\xC7\xE3";                               //  4   Дозаряд
const char mode_discharge[] PROGMEM = "\x50\x61\xB7\x70\xC7\xE3";                                   //  5   Разряд
const char mode_ktc[] PROGMEM = "KT\xE5";                                                           //  6   КТЦ (Разр>Зар>Дозар)
const char mode_storage[] PROGMEM = "\x58\x70\x61\xBD\x65\xBD\xB8\x65";                             //  7   Хранение АКБ
const char mode_bufer[] PROGMEM = "\xA0\x79\xE4.\x70\x65\xB6\xB8\xBC";                              //  8   Буф.режим  // Буферный режим "\xA0\x79\xE4\x65\x70\xBD\xc3\xB9 \x70\x65\xB6\xB8\xBC";

// пункты меню настроек
const char sett_charge_volt[] PROGMEM = "\x48\x61\xBE\x70\xC7\xB6 \xB7\x61\x70\xC7\xE3\x61";                    // Напряж. зарядa  *
const char sett_charge_curr[] PROGMEM = "\x54\x6F\xBA \xB7\x61\x70\xC7\xE3\x61";                                // Ток заряда      *
const char sett_charge_voltDecrCurr[] PROGMEM = "\x48\x61\xBE\x70\xC7\xB6 \x43\xBD\xB8\xB6.";                   // Напряжение при котором начинает снижаться ток
const char sett_charge_volt_min[] PROGMEM = "\x4D\xB8\xBD. \xBF\x6F\xBA \xB7\x61\x70\xC7\xE3\x61";              // Мин. ток заряда *
const char sett_charge_time[] PROGMEM = "\x42\x70\x65\xBC\xC7 \xB7\x61\x70\xC7\xE3\x61";                        // Время заряда    *
const char sett_asym_charge[] PROGMEM = "\xA8\x65\x70\xB8\x6F\xE3 \xB7\x61\x70\xC7\xE3\x61";                    // Период заряда
const char sett_asym_discharge[] PROGMEM = "\xA8\x65\x70\xB8\x6F\xE3 \x70\x61\xB7\x70\xC7\xE3\x61";             // Период разряда
const char sett_addcharge_volt[] PROGMEM = "\x48\x61\xBE\x70. \xE3\x6F\xB7\x61\x70\xC7\xE3\x61";                // Напр. дозаряда  *
const char sett_addcharge_curr[] PROGMEM = "\x54\x6F\xBA \xE3\x6F\xB7\x61\x70\xC7\xE3\x61";                     // Ток дозаряда    *
const char sett_addcharge_currmin[] PROGMEM = "\x4D\xB8\xBD. \xBF\x6F\xBA \xE3\x6F\xB7\x61\x70\xC7\xE3\x61";    // Мин. ток дозар. *
const char sett_addcharge_time[] PROGMEM = "\x42\x70\x65\xBC\xC7 \xE3\x6F\xB7\x61\x70\xC7\xE3\x61";             // Время дозаряда  *
const char sett_discharge_voltage[] PROGMEM = "\x48\x61\xBE\x70. \x70\x61\xB7\x70\xC7\xE3\x61";                 // Наряж. разряда  *
const char sett_discharge_curr[] PROGMEM = "\x54\x6F\xBA \x70\x61\xB7\x70\xC7\xE3\x61";                         // Ток разряда     *
const char sett_discharge_currmin[] PROGMEM = "\x4D\xB8\xBD. \xBF\x6F\xBA \x70\x61\xB7\x70\xC7\xE3\x61";        // Мин. ток разряда*
const char sett_bufer_volt[] PROGMEM = "\xA0\x79\xE4\x65\x70\xBD\xc3\xB9 \x70\x65\xB6\xB8\xBC";                 // Буферный режим  *
const char sett_storage_volt[] PROGMEM = "\x58\x70\x61\xBD\x65\xBD\xB8\x65";                                    // Хранение
const char sett_precharge[] PROGMEM = "\xA8\x70\x65\xE3\xB7\x61\x70\xC7\xE3";                                   // Предзаряд       *
const char sett_precharge_volt[] PROGMEM = "\x48\x61\xBE\x70. \xBE\x70\x65\xE3\xB7\x61\x70\xC7\xE3\x61";        // Напряж. предзар.*
const char sett_precharge_curr[] PROGMEM = "\x54\x6F\xBA \xBE\x70\x65\xE3\xB7\x61\x70\xC7\xE3\x61";             // Ток предзаряда  *
const char sett_charge_oscil[] PROGMEM = "\x4B\x61\xC0\x65\xBB\xB8";                                            // Качели          *
const char sett_round[] PROGMEM = "\xE1\xB8\xBA\xBB";                                                           // Цикл
const char sett_system[] PROGMEM = "\x21\x43\xB8\x63\xBF\x65\xBC\x2E\x20\xBE\x61\x70\x61\xBC\x21";              // !Cистем. парам! *
const char sett_reset[] PROGMEM = "\x43\xB2\x70\x6F\x63 \xBD\x61\x63\xBF\x70\x6F\x65\xBA";                      // Сброс настроек  *

// пункты калибровок
const char namc1[] PROGMEM = "\x48\x61\xBE\x70\xC7\xB6/\x54\x6F\xBA \x41\xBA\xB2";  // Напряж/ток акб
const char namc2[] PROGMEM = "\x48\x61\xBE\x70\xC7\xB6 \xA0\xA8";                   // Напряж. БП
const char namc3[] PROGMEM = "INA Volt";

// символы вывода режима работы - Заряд, Заряд, Бранимир, Дозаряд, Разряд, КТЦ
#if (DISPLAYy == 2)
const char regimr[] PROGMEM = "\xA4\xA4\x41\xA0\xE0\x50K";  
#endif

// текстовые строки
#define txt2 " \x63\xB2\x70\x6F\x63"            //  сброc
#define txt3 " \x63\x6F\x78\x70\x21"            //  сохр!
#define txt4 "\x42\x78\x2E\x20\xA0\xA8 "        //  "Вх. БП "
#define txt5 "\x42\xC3\x78\x6F\xE3"             //  Выход
#define txt6 "INA226 \x6F\xC1\xB8\xB2\xBA\x61"  //  INA226
#define txt7 "DS18B20 "                         //  DS18B20
//#define txt8 "!ALERT!"                                         //
#define txt9 "Temp akb:"                                       //  температура акб
#define txt10 "\x42\x63\xA2"                                   //  Всё
#define txt11 "\xA8\x6F\xE3\xBA\xBB\xC6\xC0\xB8 \x41\x4B\xA0"  //  Подключи АКБ
#define txt111 "\xA8\x6F\xE3\xBA\xBB\xC6\xC0\xB8 \xA0\xA8"     //  Подключи БП
#define txt12 "\x43\xB2\x70\x6F\x63"                           //  Сброс
#define txt13 "\x42\xBA\xBB\x2E "                              //  Вкл.
#define txt14 "\x4F\xBF\xBA\xBB\x2E"                           //  Откл.
//#define txt15 "\xAB\x61\x63"                                   //  Час
#define txt16 "\xA8\x61\x79\xB7\x61"  //  Пауза
#define txt17 "\x3C \x4F\x4B \x3E"    // "< OK >"
#define txt18 "Pe\xB6\xB8\xBC \xA0\xA8"          //  Режим БП
#define txt19 "\x3C\x43\xBF\x6F\xBE\x3e"         //  "<Стоп>"
#define txt20 " \xBC\xB8\xBD "                   //  мин
#define txt21 " \x6F\xC1\xB8\xB2\xBA\x61"        //  ошибка
#define txt22 "Volt"                             // Вольт
#define txt23 "Amper"                            // Ампер
#define txt24 "!-\xA8\x50\x4F\xA0\xA5\x54 Q1-!"  //  !-ПРОБИТ Q1-!
#define txt25 "\x56\xB2\xBE "                    //  Vбп
//#define txt26 "\x41\x4B\xA0\x20\x70\x61\xB7\x70\xC7\xB6\x65\xBD\x21"  //  АКБ разряжен!
//const char err[] PROGMEM = "\x6F\xC1\xB8\xB2\xBA\x61";

/* ***** английский ***** */ 
#elif (INTERFACE == 1)

// пункты главного меню
const char menu_profil[] PROGMEM = "Pr:";
const char menu_akb_capacity[] PROGMEM = "Capacity Akb";
const char menu_akb_type[] PROGMEM = "Type Akb";
const char menu_akb_volt[] PROGMEM = "Voltage Akb";
const char menu_mode[] PROGMEM = "Operating mode";
const char menu_settings[] PROGMEM = "Settings";
const char menu_resist_akb[] PROGMEM = "Resist. akb";
const char menu_statistic[] PROGMEM = "Statistics";
const char menu_calibration[] PROGMEM = "Calibration";
const char menu_sensors[] PROGMEM = " ";

// пункты меню режимов работы
const char mode_charge[] PROGMEM = "Charge";
const char mode_charge_add[] PROGMEM = "Charge>AddChar";
const char mode_asimm[] PROGMEM = "Asymmetric charge";
const char mode_branimir[] PROGMEM = "Charge Branim";
const char mode_addcharge[] PROGMEM = "Add charge";
const char mode_discharge[] PROGMEM = "Discharge";
const char mode_ktc[] PROGMEM = "Contr.trai.cycle";
const char mode_storage[] PROGMEM = "Storage";
const char mode_bufer[] PROGMEM = "Buffer";

// пункты меню настроек
const char sett_charge_volt[] PROGMEM = "Volt charge";              //  0   Напряж. зарядa
const char sett_charge_curr[] PROGMEM = "Curr. charge";             //  1   Ток заряда
const char sett_charge_voltDecrCurr[] PROGMEM = "Volt decr.Cur";    //  2   Напряжение при котором начинает снижаться ток
const char sett_charge_volt_min[] PROGMEM = "Curr. charge off";     //  3   ток завершения заряда
const char sett_charge_time[] PROGMEM = "Time charge";              //  4   Время заряда
const char sett_asym_charge[] PROGMEM = "Period charge";            //  5   Период заряда
const char sett_asym_discharge[] PROGMEM = "Period discharge";      //  6   Период разряда
const char sett_addcharge_volt[] PROGMEM = "Volt add charge";       //  7   Напряж. дозаряда
const char sett_addcharge_curr[] PROGMEM = "Curr. add charge";      //  8   Ток дозаряда
const char sett_addcharge_currmin[] PROGMEM = "Curr.addChar min";   //  9   Мин. ток дозар.
const char sett_addcharge_time[] PROGMEM = "Time add charge";       //  10  Время дозаряда
const char sett_discharge_voltage[] PROGMEM = "Volt dischar";       //  11  Наряж. разряда
const char sett_discharge_curr[] PROGMEM = "Curr. dischar";         //  12  Ток разряда
const char sett_discharge_currmin[] PROGMEM = "Curr.disch. off";    //  13  Мин. ток разряда
const char sett_bufer_volt[] PROGMEM = "Bufer mode";                //  14  Буферный режим
const char sett_storage_volt[] PROGMEM = "Storage mode";            //  15  напряжение режима Хранение
const char sett_precharge[] PROGMEM = "Precharge";                  //  16  Предзаряд
const char sett_precharge_volt[] PROGMEM = "Volt pre charge";       //  17  Напряж. предзар.
const char sett_precharge_curr[] PROGMEM = "Curr. pre charge";      //  18  Ток предзаряда
const char sett_charge_oscil[] PROGMEM = "Oscillation";             //  19  Качели
const char sett_round[] PROGMEM = "Cycle";                          //  20  Цикл
const char sett_system[] PROGMEM = "!system param!";                //  21  #define SYSPARAM 18       // номер системных параметров
const char sett_reset[] PROGMEM = "Reset settings";                 //  22   Сброс настроек

// пункты меню калибровки
const char namc1[] PROGMEM = "Volt/Curr akb";
const char namc2[] PROGMEM = "Volt Power";
const char namc3[] PROGMEM = "INA Volt";

#if (DISPLAYy == 2)
// символы вывода режима работы - Заряд, Заряд, Бранимир, Дозаряд, Разряд, КТЦ
const char regimr[] PROGMEM = "CCABADK";  
#endif

// текстовые строки
#define txt2 " reset"
#define txt3 " saved"  // 2 раза
#define txt4 "Power "
#define txt5 "Exit"
#define txt6 "INA226 error"
#define txt7 "DS18B20 "
//#define txt8 "!ALERT!"
#define txt9 "Temp akb:"  //  температура акб
#define txt10 "All"
#define txt11 "Connect batt"
#define txt111 "Connect power"
#define txt12 "Sbros"
#define txt13 "On "
#define txt14 "Off "
//#define txt15 " hour" // 2 раза
#define txt16 "Pause"
#define txt17 "< OK >"
#define txt18 "Regim BP"
#define txt19 "<Stop>"
#define txt20 " min "
#define txt21 " error"  // 6 раз
#define txt22 "Volt"
#define txt23 "Amper"
#define txt24 "!-BROKEN Q1-!"
#define txt25 "Vin "  //  Напряж БП превыш
//#define txt26 "Akb razryazen!"
//const char err[] PROGMEM = "error";

/* ***** транстит  ***** */ 
#elif (INTERFACE == 2)

// пункты меню
const char menu_main[] PROGMEM = "Main";
const char menu_profil[] PROGMEM = "Pr:";
const char menu_akb_capacity[] PROGMEM = "Emkost akb";
const char menu_akb_type[] PROGMEM = "Tip akb";
const char menu_akb_volt[] PROGMEM = "Napryagenie akb";
const char menu_mode[] PROGMEM = "Regim raboti";
const char menu_settings[] PROGMEM = "Nastroiki";
const char menu_resist_akb[] PROGMEM = "Soprot. akb";
const char menu_statistic[] PROGMEM = "Statistika";
const char menu_calibration[] PROGMEM = "Kalibrovka";
const char menu_sensors[] PROGMEM = " ";

// пункты меню режимов работы
const char mode_charge[] PROGMEM = "Zaryad";
const char mode_charge_add[] PROGMEM = "Zar.>Dozaryad";
const char mode_asimm[] PROGMEM = "Asymmetric zar.";   //  2   Aссиметричный заряд
const char mode_branimir[] PROGMEM = "Zar. Branimir";
const char mode_addcharge[] PROGMEM = "Dozaryad";
const char mode_discharge[] PROGMEM = "Razryad";
const char mode_ktc[] PROGMEM = "KTC";
const char mode_storage[] PROGMEM = "Hranenie";
const char mode_bufer[] PROGMEM = "Buf. regim";  // "Bufer regim"

// пункты меню настроек
const char sett_charge_volt[] PROGMEM = "Napr. zaryada";
const char sett_charge_curr[] PROGMEM = "Tok zaryada";
const char sett_charge_voltDecrCurr[] PROGMEM = "Napr. snigen";  //  2   Напряжение при котором начинает снижаться ток
const char sett_charge_volt_min[] PROGMEM = "Min. tok zaryda";
const char sett_charge_time[] PROGMEM = "Vremya zaryada";
const char sett_asym_charge[] PROGMEM = "Period zaryada";    //  5   Период заряда
const char sett_asym_discharge[] PROGMEM = "Period razryada";   //  6   Период разряда
const char sett_addcharge_volt[] PROGMEM = "Napr. dozaryada";
const char sett_addcharge_curr[] PROGMEM = "Tok dozaryada";
const char sett_addcharge_currmin[] PROGMEM = "Min. tok dozar.";
const char sett_addcharge_time[] PROGMEM = "Vremya dozaryada";
const char sett_discharge_voltage[] PROGMEM = "Napr. razryada";
const char sett_discharge_curr[] PROGMEM = "Tok razryada";
const char sett_discharge_currmin[] PROGMEM = "Min. tok razr.";
const char sett_bufer_volt[] PROGMEM = "Bufernii regim";
const char sett_storage_volt[] PROGMEM = "Xranenie Akb";
const char sett_precharge[] PROGMEM = "Predzaryad";
const char sett_precharge_volt[] PROGMEM = "Napr. predzaryda";
const char sett_precharge_curr[] PROGMEM = "Tok predzaryda";
const char sett_charge_oscil[] PROGMEM = "Regim kacheli";
const char sett_round[] PROGMEM = "Cycle";
const char sett_system[] PROGMEM = "!system param!";
const char sett_reset[] PROGMEM = "Sbros nastroek";

// пункты меню калибровок
const char namc1[] PROGMEM = "Volt/Curr akb";
const char namc2[] PROGMEM = "Volt Power";
const char namc3[] PROGMEM = "INA Volt";

#if (DISPLAYy == 2)
// символы вывода режима работы - Заряд, Заряд, Бранимир, Дозаряд, Разряд, КТЦ
const char regimr[] PROGMEM = "ZZABDRK";
#endif

// текстовые строки
#define txt2 " sbros"
#define txt3 " sohr."
#define txt4 "Power "
#define txt5 "Exit"
#define txt6 "INA226 error"
#define txt7 "DS18B20 "
//#define txt8 "!ALERT!"
#define txt9 "Temp akb:"
#define txt10 "Vse"
#define txt11 "Podkluchi AKB"
#define txt111 "Podkluchi BP"
#define txt12 "Sbros"
#define txt13 "Vkl."
#define txt14 "Otkl."
//#define txt15 " chas"
#define txt16 "Pause"
#define txt17 "< OK >"
#define txt18 "Regim BP"
#define txt19 "<Stop>"
#define txt20 " min "
#define txt21 " error"
#define txt22 "Volt"
#define txt23 "Amper"
#define txt24 "!-PROBIT Q1-!"
#define txt25 "Vin "  //  Напряж БП превыш
//#define txt26 "Akb razryazen!"
//const char err[] PROGMEM = "error";
#else
#error "Не правильный номер языка интерфейса"
#endif

const char* const menuTxt[] PROGMEM = {
  menu_profil,
  menu_akb_capacity,
  menu_akb_type,
  menu_akb_volt,
  menu_mode,
  menu_settings,
  menu_resist_akb,
  menu_statistic,
  menu_calibration,
  menu_sensors,
};

const char* const modeTxt[] PROGMEM = {
  mode_charge,
  mode_charge_add,
  mode_asimm,
  mode_branimir,
  mode_addcharge,
  mode_discharge,
  mode_ktc,
  mode_storage,
  mode_bufer,
};

const char* const settings[] PROGMEM = {
  sett_charge_volt,
  sett_charge_curr,
  sett_charge_voltDecrCurr,
  sett_charge_volt_min,
  sett_charge_time,
  sett_asym_charge,
  sett_asym_discharge,
  sett_addcharge_volt,
  sett_addcharge_curr,
  sett_addcharge_currmin,
  sett_addcharge_time,
  sett_discharge_voltage,
  sett_discharge_curr,
  sett_discharge_currmin,
  sett_bufer_volt,
  sett_storage_volt,
  sett_precharge,
  sett_precharge_volt,
  sett_precharge_curr,
  sett_charge_oscil,
  sett_round,
  sett_system,
  sett_reset,
};

const char* const calibr[] PROGMEM = { namc1, namc2, namc3 };

// число пунктов Меню - 9
#define POINTMENU (uint8_t)(sizeof(menuTxt) / sizeof(menuTxt[0]) - 1)
// число пунктов Режимов работы - 8
#define POINTMODE (uint8_t)(sizeof(modeTxt) / sizeof(modeTxt[0]) - 1)
// число пунктов Настроек
#define POINTSETTINGS (uint8_t)(sizeof(settings) / sizeof(settings[0]) - 1)
// число пунктов Калибровок 0-2
#define POINTCALIBRS (uint8_t)(sizeof(calibr) / sizeof(calibr[0]) - 1)  
// номер системных параметров
#define SYSPARAM 21       


/* ******* системные параметры ****** */
#define SETTINGS_AMOUNT 15  // количество настроек
const char service0[] PROGMEM = "POWER";
const char service1[] PROGMEM = "POWER_MAX";
const char service2[] PROGMEM = "***";
const char service3[] PROGMEM = "CURR_MAX";
const char service4[] PROGMEM = "FAN";
const char service5[] PROGMEM = "FANDEGON";
const char service6[] PROGMEM = "FANDEGOFF";
const char service7[] PROGMEM = "FANDEGMAX";
const char service8[] PROGMEM = "FANDEGCUR";
const char service9[] PROGMEM = "FANCURON";
const char service10[] PROGMEM = "FANCUROFF";
const char service11[] PROGMEM = "FANCURMAX";
const char service12[] PROGMEM = "TIME_LIGHT";
const char service13[] PROGMEM = "FREQ_CHARGE";
const char service14[] PROGMEM = "FREQ_DISCHAR";

const char* const servicc[] PROGMEM = {
  service0,
  service1,
  service2,
  service3,
  service4,
  service5,
  service6,
  service7,
  service8,
  service9,
  service10,
  service11,
  service12,
  service13,
  service14,
};






//const char simbols[] PROGMEM = "VAWCNh%()<>:; ";
