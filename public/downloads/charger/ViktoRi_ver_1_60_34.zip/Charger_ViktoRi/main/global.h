#include <Arduino.h>
#include "global_profils.h"

// версия структуры в EPPROM
#define MEMVER 107

  // функция reset с адресом 0
extern void (*resetFunc)(void);

// флаги системы
enum FlagsName : uint8_t {
              // напряжение блока питания:
  POWERHIGH,  // выше максимального (true - в норме)
  POWERLOW,   // ниже минимального  (true - в норме)
  POWERON,    // питание от БП поступает (true - в норме)
  TR_Q1_ERR,  // превышена температура на силовом транзисторе (false - в норме)
  RELEY_OFF,  // разрешено отключать реле  (true - в норме)
  TEMP_AKB,   // температура акб (true - в норме)
  SECOND      // флаг секунды (false)
};

// флаги системы
extern uint8_t sysFlag;

void sysFlagsBegin(void);

// получить флаги системы
#define sysFlagGetBits(bitt) ((sysFlag >> bitt) & 0x01)

// установить флаги системы
#define sysFlagSetBits(bitt) (sysFlag |= (1 << bitt))

// сбросить флаги системы
#define sysFlagClearBits(bitt) (sysFlag &= ~(1 << bitt))


// номера режимов работы
enum Modes: uint8_t {
  CHARGE,            // Заряд
  CHARGE_ADDCHARGE,  // Заряд-Дозаряд
  ASYMMETRIC,        // ассиметричный заряд
  BRANIMIR,          // Заряд по Бранимиру
  ADDCHARGE,         // Дозаряд
  DISCHARGE,         // Разряд
  KTCycle,           // Контрольно тренировочный цикл
  STORAGE,           // Режим хранения акб
  BUFER,             // Буферный режим
  KALIBRATION,       // калибровка
  RESISTENSE,        // замер сопротивления
  POWEROUT,          // блок питания  
  PRECHARGE,         // Заряд - предзаряд (в режиме Заряд включен предзаряд)
  OSCILLATION,       // Заряд - осциляция (в режиме Заряд включен режим осциляции)
  WAIT,              // ожидание
};

//причина завершения заряда
enum Reason : uint8_t {
  begin,            // 0
  out_time,         // 1 закончилось время
  volt_maxCur_min,  // 2 напряжение достигло максимума ток минимума
  cur_stop,         // 3 напряжение достигло максимума, ток перестал уменьшаться
  volt_decreased,   // 4 напряжение стало уменьшаться
  curr_increased,   // 5 ток стал увеличиваться
};

// номер причины завершения заряда
extern Reason regim_end;

// вывод на дисплей
enum DispRgb : uint8_t {
  MODE,      // 0 режим работы
  TYPE_AKB,  // 1 тип акб
  ERROR,     // 2 ошибка
  SETTING,   // 3 настройки
  VOLTAGE,   // 4 напряжение во float
};


// 8 байт
struct Intls {
  uint8_t Ohms;      // кооффициент коррекции напряжения 0-255 (сопротивление линии до акб)
  uint8_t profil;    // текущий профиль 0-9
  uint16_t Vref;     // коэффициент для калибровки напряжения БП - VKORRECT
  uint16_t shunt;    // значение сопротивления шунта (1000 это 10.00 мОм)
  uint16_t inaKoof;  // коэффициент для калибровки напряжения INA226
};
extern Intls vkr;

extern Profils profil;

// время (сек) до отключения ЗУ в режиме ожидания
extern uint16_t timer_bp;

extern uint8_t Round;  // текущий круг
extern uint8_t Number; // номер операции

struct TimeCount {
  uint32_t local;    // сюда сохраняем время заряда из памяти в сек (при запуске заряда)
  uint32_t real_tm;  // сюда рассчитывается полное время заряда (каждую секунду)
  // рассчитать количество всех секунд заряда (каждую секунду)
  void cal_real_tm(void);
};

// флаг секунды
bool get_second(void);

// ждать N секунд
void delay_sec(uint8_t sec);

// сохранить структуру vkr
void eeSave_vkr(void);

// сохранить структуру profil
void eeSave_profil(uint8_t profil_number);

// считать структуру vkr
void eeGet_vkr(void);

// считать структуру profil
void eeGet_profil(void);

// сохранение структур в EEPROM
void eepSavedStruct(void);

// чтение структур из EEPROM
void eepGetStruct(void);

// номера ячеек сервисных параметров в EEPROM
enum eepService_num: uint8_t {
  POWERIN,      // 0 напряжение от БП
  POWERMAX,     // 1 максимальное напряжение от БП
  INAVKOOFV,    // 2 ***
  CURRMAX,      // 3 максимальный ток
  FANMODE,      // 4 режим работы кулера
  FANDEGON,     // 5 температура включения вентилятора в градусах
  FANDEGOFF,    // 6 температура отключения вентилятора в градусах
  FANDEGMAX,    // 7 значение температуры для максимальных оборотов вентилятора ШИМ.
  DEGCUR,       // 8 температура при которой уменьшается ток заряда
  FANCURON,     // 9 значение тока в Амперах при котором включается вентилятор. (до 25,5А)
  FANCUROFF,    // 10 значение тока в Амперах при котором отключается вентилятор. (до 25,5А)
  FANCURMAX,    // 11 значение тока в Амперах  для максимальных оборотов вентилятора ШИМ. (до 25,5А)
  TIMELIGHT,    // 12 время подсветки дисплея в минутах
  FREQCHARGE,   // 13 частота работы силовогомодуля
  FREQDISCHAR,  // 14 частота работы разрядного модуля
};

uint8_t eepGetService_num(uint8_t nomer);

#define POWERINT   ((uint16_t)eepGetService_num(POWERIN) * 1000)  // напряжение от БП
#define CURRMAXINT ((int16_t)eepGetService_num(CURRMAX) * 100)  // максимальный ток

// сохранение сервисных параметров
void eepSavedService(void);

// чтение сервисных параметров
void eepGetService(void);

// сброс сервисных параметров
void eepResetService(void);


// количество экранов при заряде на дисплей 1602
#if (DISPLAYy == 2)
#define WINDC 4
// количество экранов на дисплей 2004
#elif (DISPLAYy == 4)
#define WINDC 2
#endif

#define InvBit(reg, bit) reg ^= (1 << bit)  //  nvBit(tmp,6);    //инвертировать шестой бит переменной tmp
#define BitIsClear(reg, bit) ((reg & (1 << bit)) == 0)
//if  (BitIsClear(PIND, 0)) {   //если очищен нулевой бит в регистре PIND    //выполнить блок
/*
#if ((float)CURR_MAX > (float)(0.08192f / (float)SHUNT))
#error "Указанное значение тока не может быть больше чем позволяет шунт."
#endif
*/


// адрес начальной ячейки памяти для значения сброса настроек
#define MEM_RESET 0
// адрес начальной ячейки памяти для структуры vkr
#define MEM_VKR 1
// адрес начальной ячейки памяти для сервисных параметров
#define MEM_SERV 10
// адрес начальной ячейки памяти для структуры profil
#define MEM_PAM 30
// адрес начальной ячейки памяти для результатов замера емкости КТЦ. Максимум 10 замеров по 16 байт
#define MEM_KTC 903
// адрес ячейки памяти для оставшегося количество циклов
#define MEM_ROUND 988
// адрес ячейки памяти для номер операции
 #define MEM_NUMBER 989

/*
Карта организации памяти EPRROM
0	- значение сброса настроек
1	9	- struct vkr 8 байт
10	25	- архив 15 байт сервисные параметры зарядника
30	126	Профиль 0
127	223	Профиль 1
224	320	Профиль 2
321	417	Профиль 3
418	514	Профиль 4
515	611	Профиль 5
612	708	Профиль 6
709	805	Профиль 7
806	902	Профиль 8
903	919	КТЦ-1
920	936	КТЦ-2
937	953	КТЦ-3
954	970	КТЦ-4
971	987	КТЦ-5
988		текущий круг
989		номер операции
*/

uint16_t volt_step(uint16_t volt, int8_t x);


#if defined(__LGT8FX8P__)
void lgt_eeprom_update_byte(uint16_t address, uint8_t value);

void lgt_eeprom_update_block(uint8_t* pbuf, uint16_t address, uint16_t len);
#endif

#define constrain_my(amt, low, high, x) (((amt) <= (low) and ((x) < 0)) or ((amt) >= (high) and ((x) > 0))) ? (amt) : ((amt) + (x))

int16_t difference(int32_t diff_1, int32_t diff_2);

// функция быстрого переключения "ног"
void digitalWrite_speed(uint8_t pin, bool x);

void analogWrite_my(uint8_t pin, uint16_t duty);

#if defined(__LGT8FX8P__)
int16_t map_my(int16_t x, int16_t in_min, int16_t in_max, int16_t out_min, int16_t out_max);
#else
int16_t map_my(int32_t x, int16_t in_min, int16_t in_max, int16_t out_min, int16_t out_max);
#endif

#if (PROFIL > 8)
#error "Максимальное количество профилей не может быть больше 8"
#endif

// напряжение аккумулятора
uint16_t bat_volt(uint8_t bat_type);

// функция рассчета профиля по параметрам аккумулятора
void calcProfile();