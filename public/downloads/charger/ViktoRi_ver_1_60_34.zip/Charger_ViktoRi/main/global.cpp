#include "global.h"
#include "1_User_Setup.h"
#include "Battery.h"
#include "menu_txt.h"
#include "system.h"
#include <EEPROM.h>
#include <GyverIO.h>

// функция reset с адресом 0
void (*resetFunc)(void) = 0;

uint8_t sysFlag;

void sysFlagsBegin(void) { sysFlag = 0b00110111; }

Intls vkr;

Profils profil;

uint8_t Round = 1;  // текущий круг
uint8_t Number = 1; // номер операции

// время (сек) до отключения ЗУ в режиме ожидания
uint16_t timer_bp = 0;

// флаг секунды
bool get_second(void) {
  if (sysFlagGetBits(FlagsName::SECOND)) {
    sysFlagClearBits(FlagsName::SECOND);
    return true;
  }
  return false;
}

Reason regim_end{Reason::begin};

uint16_t volt_step(uint16_t volt, int8_t x) {
  return constrain_my(volt, STEP_VOLT * 10, POWERINT, x * STEP_VOLT);
}

#if defined(__LGT8FX8P__)
void lgt_eeprom_update_byte(uint16_t address, uint8_t value) {
  if (lgt_eeprom_read_byte(address) != value)
    lgt_eeprom_write_byte(address, value);
}

void lgt_eeprom_update_block(uint8_t *pbuf, uint16_t address, uint16_t len) {
  uint16_t i;
  uint8_t *p = pbuf;
  for (i = 0; i < len; i++) {
    lgt_eeprom_update_byte(address + i, *p++);
  }
}
#endif

// ждать N секунд
void delay_sec(uint8_t sec) {
  start_second_usr(); // старт счета секунд
  while (get_second_usr() <= sec)
    _NOP();
  stop_second_usr();
}

// сохранить структуру vkr
void eeSave_vkr(void) {
#if defined(__LGT8FX8P__)
  // lgt_eeprom_update_block(((uint8_t*)&vkr), MEM_VKR, sizeof(vkr));
  lgt_eeprom_writeSWM((uint16_t)MEM_VKR, ((uint32_t *)&vkr),
                      (uint16_t)sizeof(vkr) / sizeof(uint32_t));
#else
  EEPROM.put((int)MEM_VKR, vkr);
#endif
}

// сохранить структуру profil
void eeSave_profil(uint8_t profil_number) {
#if defined(__LGT8FX8P__)
  // lgt_eeprom_update_block(((uint8_t*)&profil), ((int)sizeof(profil) *
  // profil_number + MEM_PAM), sizeof(profil));
  lgt_eeprom_writeSWM(((uint16_t)sizeof(Profils) * profil_number + MEM_PAM),
                      ((uint32_t *)&profil),
                      (uint16_t)sizeof(Profils) / sizeof(uint32_t));
#else
  EEPROM.put(((int)sizeof(Profils) * profil_number + MEM_PAM), profil);
#endif
}

/*
        //
   ----------------------------------------------------------------------
        // read/write bundle of data from/to E2PROM with SWM mode enable
        //
   ---------------------------------------------------------------------- void
   lgt_eeprom_writeSWM( uint16_t address, uint32_t *pData, uint16_t length );
        void lgt_eeprom_readSWM( uint16_t address, uint32_t *pData, uint16_t
   length );
*/

// функция сохранения настроек
void eepSavedStruct(void) {
  eeSave_vkr();
  eeSave_profil(vkr.profil);
}

// считать структуру vkr
void eeGet_vkr(void) {
#if defined(__LGT8FX8P__)
  // lgt_eeprom_read_block(((uint8_t*)&vkr), MEM_VKR, sizeof(vkr));
  lgt_eeprom_readSWM((uint16_t)MEM_VKR, ((uint32_t *)&vkr),
                     (uint16_t)sizeof(vkr) / sizeof(uint32_t));
#else
  EEPROM.get((int)MEM_VKR, vkr);
#endif
}

// считать структуру profil
void eeGet_profil(void) {
#if defined(__LGT8FX8P__)
  // lgt_eeprom_read_block(((uint8_t*)&profil), ((uint16_t)sizeof(profil) *
  // vkr.profil + MEM_PAM), sizeof(profil));
  lgt_eeprom_readSWM(((uint16_t)sizeof(Profils) * vkr.profil + MEM_PAM),
                     ((uint32_t *)&profil),
                     (uint16_t)sizeof(Profils) / sizeof(uint32_t));
#else
  EEPROM.get(((int)sizeof(Profils) * vkr.profil + MEM_PAM), profil);
#endif
}

// чтение структур из EEPROM
void eepGetStruct(void) {
  eeGet_vkr();
  eeGet_profil();
}

// системные параметры по умолчанию
const uint8_t service_default[SETTINGS_AMOUNT] PROGMEM = {
    POWER_IN,  // *напряжение от БП
    POWER_MAX, // *максимально допустимое напряжение от БП
    0,         // нет ****************  коэффициент напряжения INA226
    (uint8_t)((float)CURR_MAX * 10), // Максимальный ток зарядника 25.5А
    FAN,                             // *тип управления вентилятором
    FAN_DEG_ON,  // *температура включения вентилятора в градусах
    FAN_DEG_OFF, // *температура отключения вентилятора в градусах
    FAN_DEG_MAX, // *значение температуры для максимальных оборотов вентилятора
                 // ШИМ.
    DEG_CUR,     // *температура при которой уменьшается ток заряда
    (uint8_t)(FAN_CUR_ON / 100),  // *значение тока в Амперах/100 при котором
                                  // включается вентилятор. (до 25,5А)
    (uint8_t)(FAN_CUR_OFF / 100), // *значение тока в Амперах/100 при котором
                                  // отключается вентилятор. (до 25,5А)
    (uint8_t)(FAN_CUR_MAX /
              100), // *значение тока в Амперах/100  для максимальных оборотов
                    // вентилятора ШИМ. (до 25,5А)
    TIME_LIGHT,  // *время подсветки дисплея в минутах TIME_LIGHT (до 255 минут)
    FREQ_CHARGE, // *частота силового модуля {0.25, 0.5, 1, 2, 4, 8, 30, 60} кГц
    FREQ_DISCHARGE, // *частота разрядного модуля {0.25, 0.5, 1, 2, 4, 8, 30,
                    // 60} кГц
};

// сброс сервисных параметров
void eepResetService(void) {
#if defined(__LGT8FX8P__)
  for (byte i = 0; i < sizeof(service_default); i++) {
    lgt_eeprom_update_byte(MEM_SERV + i, pgm_read_byte(&service_default[i]));
  }
#else
  for (uint8_t i = 0; i < sizeof(service_default); i++) {
    EEPROM.update((int)MEM_SERV + i, pgm_read_byte(&service_default[i]));
  }
#endif
}

// чтение отдельных сеpвисных параметров
uint8_t eepGetService_num(uint8_t nomer) {
#if defined(__LGT8FX8P__)
  return lgt_eeprom_read_byte(MEM_SERV + nomer);
#else
  return EEPROM.read((int)MEM_SERV + nomer);
#endif
}

/*
// сохранение сервисных параметров
void eepSavedService((uint8_t*)&service) {
#if defined(__LGT8FX8P__)
  lgt_eeprom_update_block(((uint8_t*)service), MEM_SERV,
sizeof(service_default)); #else EEPROM.put((int)MEM_SERV, service); #endif
}

// чтение сервисных параметров
void eepGetService((uint8_t*)&service) {

#if defined(__LGT8FX8P__)
  lgt_eeprom_read_block(((uint8_t*)&service), MEM_SERV, sizeof(service));
#else
  EEPROM.get((int)MEM_SERV, service);
#endif
}
*/

int16_t difference(int32_t diff_1, int32_t diff_2) {
  return (int16_t)(diff_1 - diff_2);
}

// функция быстрого переключения "ног"
void digitalWrite_speed(uint8_t pin, bool x) {
  // PWM disable
  switch (pin) {
  case 3:
    bitClear(TCCR2A, COM2B1);
    break;
  case 5:
    bitClear(TCCR0A, COM0B1);
    break;
  case 6:
    bitClear(TCCR0A, COM0A1);
    break;
  case 9:
    bitClear(TCCR1A, COM1A1);
    break;
  case 10:
    bitClear(TCCR1A, COM1B1);
    break;
  case 11:
    bitClear(TCCR2A, COM2A1);
    break;
  }
  gio::write(pin, x);
}

void analogWrite_my(uint8_t pin, uint16_t duty) {
  if (!duty) {
    digitalWrite_speed(pin, LOW); // Disable PWM and set pin to LOW
    return;                       // Skip next code
  }
  switch (pin) {
  case 5:
    bitSet(TCCR0A, COM0B1); // Enable hardware timer output
    OCR0B = duty;           // Load duty to compare register
    return;
  case 6:
    bitSet(TCCR0A, COM0A1);
    OCR0A = duty;
    return;
  case 10:
    bitSet(TCCR1A, COM1B1);
    OCR1B = duty;
    return;
  case 9:
    bitSet(TCCR1A, COM1A1);
    OCR1A = duty;
    return;
  case 3:
    bitSet(TCCR2A, COM2B1);
    OCR2B = duty;
    return;
  case 11:
    bitSet(TCCR2A, COM2A1);
    OCR2A = duty;
    return;
  }
}

void TimeCount::cal_real_tm(void) {
  // рассчитать количество всех секунд заряда (каждую секунду)
  real_tm = local + get_second_usr();
}

#if defined(__LGT8FX8P__)
int16_t map_my(int16_t x, int16_t in_min, int16_t in_max, int16_t out_min,
               int16_t out_max) {
  return uDSC_map_int(x, in_min, in_max, out_min, out_max);
}
#else
int16_t map_my(int32_t x, int16_t in_min, int16_t in_max, int16_t out_min,
               int16_t out_max) {
  if (x >= in_max)
    return out_max;
  if (x <= in_min)
    return out_min;
  int32_t diff =
      ((x - in_min) * (out_max - out_min)); // Предварительное масштабирование
  int16_t range = (in_max - in_min);        // Диапазон исходных значений
  if (range == 0)
    return out_min;
  return (int16_t)(diff / range + out_min); // Итоговая формула
}
#endif

// напряжение аккумулятора
uint16_t bat_volt(uint8_t bat_type) {
  return pgm_read_word(&batteries[bat_type].volt_cell) * profil.akb.cell;
}

// функция рассчета профиля по параметрам аккумулятора
void calcProfile() {
  /* Mаксимальный ток ЗУ*/
  const int16_t max_current = CURRMAXINT;
  // напряжение акб
  const uint16_t akb_voltage = bat_volt(profil.akb.type);
  // напряжение заряда
  uint16_t akb_voltage_charge =
      pgm_read_word(&batteries[profil.akb.type].volt_cell_charge) * profil.akb.cell;

  while ((akb_voltage_charge > POWERINT) and (profil.akb.cell > (uint8_t)1)) {
    profil.akb.cell--;
    akb_voltage_charge = pgm_read_word(&batteries[profil.akb.type].volt_cell_charge) * profil.akb.cell;    
  }

  /* Заряд */
  profil.charge.voltage = akb_voltage_charge;

  profil.charge.current =
      (int16_t)pgm_read_byte(&batteries[profil.akb.type].curr_cell_charge) *
      profil.akb.capacity * 10;
  profil.charge.current =
      constrain(profil.charge.current, CUR_CHARGE_MIN, max_current);

  profil.charge.current_end = profil.charge.current / 50;
  profil.charge.current_end =
      constrain(profil.charge.current_end, CUR_CHARGE_MIN, max_current);

  profil.charge.voltage_decr_cur =
      (uint16_t)(((uint32_t)profil.charge.voltage + akb_voltage) >> 1);

  uint8_t t =
      (uint8_t)((uint32_t)profil.akb.capacity * 1000 / profil.charge.current);
  t += t >> 1;
  profil.charge.time = constrain(t, (uint8_t)1, (uint8_t)48);

  profil.charge.voltage_pre =
      (uint16_t)(((uint32_t)akb_voltage * 110 + 50) / 100);
  profil.charge.current_pre =
      constrain(profil.charge.current >> 1, (int16_t)CUR_CHARGE_MIN,
                profil.charge.current);

  /* Дозаряд */
  profil.add.voltage =
      pgm_read_word(&batteries[profil.akb.type].volt_cell_add_charge) *
      profil.akb.cell;
  profil.add.current =
      (int16_t)pgm_read_byte(&batteries[profil.akb.type].curr_cell_addcharge) *
      profil.akb.capacity * 10;
  profil.add.current =
      constrain(profil.add.current, CUR_CHARGE_MIN, max_current);
  profil.add.current_min = profil.add.current / 3;
  profil.add.current_min =
      constrain(profil.add.current_min, CUR_CHARGE_MIN, max_current);
  profil.add.time = 10;

  /* Разряд */
  profil.disch.voltage_end =
      pgm_read_word(&batteries[profil.akb.type].volt_cell_discharge) *
      profil.akb.cell;
  profil.disch.current =
      (int16_t)pgm_read_byte(&batteries[profil.akb.type].curr_cell_discharge) *
      profil.akb.capacity * 10;
  profil.disch.current =
      constrain(profil.disch.current, CUR_CHARGE_MIN, max_current);
  profil.disch.current_end = profil.disch.current;

  /* Асимметричный режим */
  profil.asym.voltage = profil.charge.voltage;
  profil.asym.current = profil.charge.current;
  profil.asym.current_discharge = profil.disch.current;
  profil.asym.period_charge = 20;
  profil.asym.period_discharge = 10;
  profil.asym.pause = 5;

  /* Хранение */
  profil.storage.voltage =
      (uint16_t)(((uint32_t)akb_voltage * 104 + 50) / 100); // * 1.04;
  profil.storage.current =
      constrain(profil.charge.current / 20, CUR_CHARGE_MIN, max_current);

  /* Буферный режим */
  profil.buffer.voltage = (uint16_t)(((uint32_t)akb_voltage * 110 + 50) / 100);
  profil.buffer.current = profil.charge.current;
}
