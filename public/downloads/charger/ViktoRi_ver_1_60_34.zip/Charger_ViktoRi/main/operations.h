#include <Arduino.h>

void Operations(void);

// функция заряда
void ChargeAkb(uint16_t volt_charge_init, int16_t curr_charge_init, int16_t curr_min, uint32_t time_charge, bool add_charge);

//Функция разряда аккумулятора
void Discharge(void);
