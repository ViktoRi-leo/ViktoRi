//#define _GYVERCORE_NOMILLIS
#include <Arduino.h>

#include "system.h"
#include "1_User_Setup.h"
#include "AllFunctions.h"
#include "Classes.h"
#include "Display.h"
#include "INA226int.h"
#include "Menu.h"
#include "global.h"
#include "menu_txt.h"
#include "operations.h"

#include <GyverIO.h>
#include <microWire.h>

int main() {
// Настройка микроконтроллера
#if defined(__LGT8FX8P__)
  lgt8fx8x_clk_src(); // Настройка тактовой частоты LGT8
#ifdef LGT8_TIMER3
  timer3_init();
#endif
  uDSC_ON(); // Включить ускоритель вычислений uDSC
#endif

// Настройка таймера 0 (CTC режим, генерирует прерывание каждые 1мс)
  timer0_init();
#if (LOGGER > 0)
  serial_begin();
#endif  

  sysFlagsBegin();

  // настройка пинов
  // ШИМ заряд
  gio::mode(PWMCH_PIN, OUTPUT);
  gio::low(PWMCH_PIN);

// ШИМ разряд
#if (DISCHAR == 1)
  gio::mode(PWMDCH_PIN, OUTPUT);
  gio::low(PWMDCH_PIN);
#elif defined(PWMDCH_PIN)
  gio::mode(PWMDCH_PIN, INPUT);
#endif

// ШИМ вентилятор
#if (FAN > 0)
  gio::mode(PWMKUL_PIN, OUTPUT);
#elif defined(PWMKUL_PIN)
  gio::mode(PWMKUL_PIN, INPUT);
#endif

  // пин вывода звука
#if (SPEAKER > 0)
  gio::mode(BUZER_PIN, OUTPUT);
#elif defined(BUZER_PIN)
  gio::mode(BUZER_PIN, INPUT);
#endif

  // управление реле нагрузки в буферном режиме
#if (BUFFER > 0)
#ifdef BUFER_PIN
  gio::mode(BUFER_PIN, OUTPUT);
  gio::low(BUFER_PIN);
#endif
#elif defined(BUFER_PIN)
  gio::mode(BUFER_PIN, INPUT);
#endif


// управление реле подключения к сети 220В, или индикатор сети
#if (POWER > 0)
  gio::mode(POWER_PIN, OUTPUT);
#if (POWER == 1)
  Relay_on(true); // включить сеть 220В
#endif
#elif defined(POWER_PIN)
  gio::mode(POWER_PIN, INPUT);
#endif

// управление защитой
#if (PROTECT_LOCK > 0)
  gio::mode(PROTECT_CLOSE_PIN, OUTPUT);
  gio::low(PROTECT_CLOSE_PIN); // открыть защитный транзистор
#elif defined(PROTECT_CLOSE_PIN)
  gio::mode(PROTECT_CLOSE_PIN, INPUT);
#endif
// принудительно открывает транзистор модуля защиты Q4
#if (PROTECT_BLOCK)
  gio::mode(PROTECT_OPEN_PIN, OUTPUT);
  gio::low(PROTECT_OPEN_PIN);
#elif defined(PROTECT_OPEN_PIN)
  gio::mode(PROTECT_OPEN_PIN, INPUT);
#endif

#if (EBSTEP != EB_STEP4_LOW)
// установить тип энкодера (EB_STEP4_LOW, EB_STEP4_HIGH, EB_STEP2, EB_STEP1)
  enc.setEncType(EBSTEP); 
#endif

  // частота I2C в герцах // влияет на INA226 и на дисплей
 // Wire.begin(100000);
  Wire.setClock(WIRE_CLOCK);

  lcd.init();      // Инициализация дисплея
 // lcd.backlight(); // Подключение подсветки

  // сброс настроек при первой прошивке МК
  first_firmware();

  // загрузка в память дисплея своих символов(состояние акб)
  setDisplaySimbol();

  // Приветствие. Версия прошивки и тип контроллера
  print_version();

  // старт счета секунд
  start_second_usr();
#if (SPEAKER > 0)
  Speaker(300);
#endif
#if (FAN > 0)
  // инициализация и проверочный запуск кулера
  fan.begin();
  // автоматический режим кулера
  fan.ONonse(false);
  // запуск вентилятора, проверка работоспособности
  gio::high(PWMKUL_PIN);
#endif

#if (VOLTIN == 1 or SENSTEMP1 == 2 or SENSTEMP2 == 2)
  // Инициализация АЦП
  ADC_begin();

#if (VOLTIN == 1)
  // Максимально допустимое напряжение от БП
  Power_begin();
#endif
#endif

  // задержка
  // Ожидание 3 секунды в течении которых удержанием кнопки Стоп или энкодера
  // можно сбросить настройки по умолчанию
  while (get_second_usr() <= 3) {
    butt.Tick();
#if (VOLTIN == 1)
    // замер напряжения БП - чтобы АЦП вошел в норму
    Power_sample();
#endif
    if (butt.tick == STOPHELD or butt.tick == OKHELD) {
#if (FAN > 0)
      gio::low(PWMKUL_PIN); // остановка вентилятора
#endif
      Reset_settings(1); // сброс настроек - 1 Стереть все.
    }
  }
  stop_second_usr();
#if (FAN > 0)
      gio::low(PWMKUL_PIN); // остановка вентилятора
#endif

  bool tr = true;
#if (SENSTEMP1 == 1)
  // датчик температуры DS18B20
  tr = temp_Q1_begin();
#endif
#if (SENSTEMP2 == 1)
  // датчик температуры DS18B20
  tr = temp_akb_begin();
#endif
  if (tr == false) {
    lcd.print(F(txt7));  // "DS18B20 "
    lcd.print(F(txt21)); // "error"
    delay_sec(2);
  }

  // чтение структур из EEPROM
  eepGetStruct();

  // конфигурация INA226
  if (ina.begin())
    ina.start(); // старт замеров INA
  else {
    lcd.clear();
    lcd.print(F(txt6)); // INA226 error
    delay_sec(2);
  }

#if (MCP4725DAC)
  if (!dac.testConnection()) {
    lcd.clear();
    lcd.print(F("MCP4725"));
    print_mode(ERROR); // "error"
    delay_sec(2);
  }
#endif

  // если заряд не был завершен корректно
  if (bitRead(profil.flags, ACTIVITI)) {
    lcd.clear();
    print_mode(MODE);
    bitWrite(profil.flags, ACTIVITI, (Choice(10, true)));
    lcd.clear();
  }
#if (TIME_LIGHT)
  disp.Light_setTime(); // установить время подсветки дисплея если оно больше 0
#endif

 // Wire.setClock(WIRE_CLOCK);

  for (;;) {
    Menu1602();   // Меню v4.0.
    Operations(); // Работа
  }
  return 0;
}
// Конец программы
