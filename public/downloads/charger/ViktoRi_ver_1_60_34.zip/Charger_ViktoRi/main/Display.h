#pragma once

#include <Arduino.h>
 // Библиотека дисплея
#include "LiquidCrystal_I2C.h" 
extern LiquidCrystal_I2C lcd;

// класс управления дисплеем
class Display {
public:
  // Display(void) {}

  // Функции управления подсветкой
  void Light_setTime(void);

  void Light_high(void);

  void Light_low(void);

  // функция отключает подсветку если отключилось питание от акб
  void Light_power(void);

  // функция для печати из PROGMEM
  void printFromPGM(int charMap);

private:
  // список членов для использования внутри класса
  uint32_t _light_time;
  uint32_t _light_tm;

};
extern Display disp;

// экран вывода ошибок
void window_errors(void);

// загрузка в память дисплея своих символов(состояние акб)
void setDisplaySimbol(void);

// Приветствие. Версия прошивки и тип контроллера
void print_version(void);

// Вывод напряжения
void print_volt(uint16_t volt, uint8_t x = 2);

// Вывод тока
void print_current(int16_t amp, uint8_t x = 2);

// вывод напряжения и тока
void print_volt_current(uint16_t volt, int16_t amp, uint8_t x = 2);

// вывод Ач
void print_Ah(int32_t Ah);

// вывод Втч
void print_Wh(int32_t Wh);

// вывод - часы
void print_hour(uint8_t hour);

// вывод сопротивления - mOm
void print_resist(float shunt);

void Print_time(uint32_t time_real, uint8_t x, uint8_t y);
void setCursorx(void);
void setCursory(void);
void print_space(void);
void print_tr(void);
void PrintOnOff(bool i);
void Write_x(bool x);
void print_mode(uint8_t i);
void print_Capacity(void);
void printCykl(void);
void ClearStr(uint8_t i);
void Vout(void);

#if (DISPLAYy == 2)
void Display_print(int32_t Ah, uint32_t time_real, uint8_t prc, bool add);
#endif
#if (DISPLAYy == 4)
void Display_print(int32_t Ah, int32_t Wh, uint32_t time_real, int8_t tr, uint8_t prc);
#endif


