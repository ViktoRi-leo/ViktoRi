#include <Arduino.h>

// Меню версии 4.0 для дисплея LCD1602
void Menu1602(void);

// пункты меню настроек
void Settings_point(uint8_t point, bool edit, int16_t x);

// изменение сервисных параметров
void serviceparam(void);

void Statistics_point(uint8_t point);


