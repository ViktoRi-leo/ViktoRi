#include "Menu.h"
#include "global.h"
#include "Classes.h"
#include "INA226int.h"
#include "Display.h"
#include "menu_txt.h"
#include "Battery.h"
#include "1_User_Setup.h"
#include "AllFunctions.h"
#include <EEPROM.h>

// Меню версии 4.0 для дисплея LCD1602
void Menu1602(void) {  
  if (bitRead(profil.flags, ACTIVITI)) return;  // если флаг заряда установлен true то выйти иначе выполнять Menu
#if (TIME_LIGHT)
  disp.Light_high();  // включение подсветки
#endif
#if (FAN > 0)
// автоматический режим кулера
  fan.ONonse(false);
#endif
  butt.tick = 0;
  eepSavedStruct();           // сохранить настройки
  uint8_t urovenmenu = 0;     // три уровня меню
  uint8_t main_menu = 0;      // номер пункта меню
  uint8_t point_setting = 0;  // номер пункта настроек
  bool printx = true;
  int8_t x = 0;
  ina.start();  // старт замеров INA
  do {
    // цикл меню
    switch (urovenmenu) {
      // основное меню urovenmenu
      case 0:
        point_setting = 0;
        // вывод меню
        if (printx) {
          printx = false;
          if (x) main_menu = (main_menu == 0 and x < 0) ? POINTMENU : ((main_menu == POINTMENU and x > 0) ? 0 : main_menu + x);  // реализация кругового меню
          lcd.clear();
          disp.printFromPGM((int)(&menuTxt[main_menu]));
          setCursory();
          switch (main_menu) {
            case 0:
              // профиль
              print_Capacity();
              Vout();                 // *Pr:0 Pb CA/Ca   *
              lcd.print(vkr.profil);  // *60Ah 12.60V(6)  *
              lcd.setCursor(5, 0);
              print_mode(TYPE_AKB);  // вывод типа акб
              break;
            case 1:
              print_Capacity();  // емкость акб
              break;
            case 2:
              print_mode(TYPE_AKB);  // вывод типа акб
              break;
            case 3:
              Vout();  // напряжение
              break;
            case 4:
              print_mode(MODE);  //  режим
              break;
          }
        }
        if (main_menu < POINTMENU) {
          if (butt.tick == OKCLICK) {
            urovenmenu = (main_menu < 5) ? 2 : 1;
            point_setting = 0;
            printx = true;
            break;
          }

          // удержание Пуск или Энкодера запускает заряд
          if (butt.tick == OKHELD) {
            bool ch = true;
            if (profil.akb.type >= Akb_type::LI_ION) {
              switch (profil.Regim) {
                case Modes::CHARGE_ADDCHARGE:
                case Modes::BRANIMIR:
                case Modes::ADDCHARGE:
                case Modes::KTCycle:
                  ch = false;
                  break;
              }
            }
            if (ch) bitSet(profil.flags, ACTIVITI);  // запустить работу режима, выйти из цикла меню
            else {
              lcd.clear();
              print_mode(TYPE_AKB);
              print_space();
              print_mode(MODE);
              setCursory();
              print_mode(ERROR);  // "error"
#if (SPEAKER > 0)
          Speaker(300);
#endif
              Delay(3000);
            }
            printx = true;
          }
        }
#ifdef BP_vc
        if (main_menu == POINTMENU and butt.tick == OKHELD) BP_vvcc();  // включить режим БП
#endif
        break;  // основное меню
      case 1:
        // urovenmenu 1 - подменю
        switch (main_menu) {
          case 0:
            eepSavedStruct();  // сохранить настройки
            urovenmenu = 0;
            printx = true;
            break;
          case 1:
            // емкость акб
          case 2:
            // тип  акб            
          case 3: 
            // напряжение акб            
            calcProfile();
            urovenmenu = 0;
            printx = true;
            break;
          case 4:
            urovenmenu = 0;
            printx = true;
            break;
          case 5:
            // настройки
            if (printx) {
              printx = false;
              if (x) point_setting = (point_setting == 0 and x < 0) ? POINTSETTINGS : ((point_setting == POINTSETTINGS and x > 0) ? 0 : point_setting + x);  // реализация кругового меню
              lcd.clear();
              // вывод названия пункта настроек
              disp.printFromPGM((int)(&settings[point_setting]));
              setCursory();
              // вывод значения пункта настроек
              Settings_point(point_setting, false, 0);
            }
            switch (butt.tick) {
              case STOPCLICK:
              case OKHELD:
                urovenmenu = 0;
                point_setting = 0;
                printx = true;
                eepSavedStruct();  // сохранить настройки
                lcd.clear();
                print_mode(SETTING);  // "Settings"
                lcd.print(F(txt3));   // saved
                Delay(1000);
                break;
              case OKCLICK:
                urovenmenu = 2;
                printx = true;
                break;
            }
            break;
          case 6:
            // измерение сопротивления
#if (RESIST == 1)
            Resist();
            eepSavedStruct();  // сохранить настройки
#endif
            urovenmenu = 0;
            printx = true;
            break;
          case 7:
            // статистика
            if (printx) {
              printx = false;
              if (x) point_setting = constrain_my(point_setting, 0, 3 + Round, x);
              lcd.clear();
              Statistics_point(point_setting);  // вывод статистики
            }
            switch (butt.tick) {
              case OKCLICK:
              case STOPCLICK:
                urovenmenu = 0;
                point_setting = 0;
                printx = true;
                break;
            }
            break;
          case 8:
            // калибровка
            if (printx) {
              printx = false;
              lcd.clear();
#if (DISPLAYy == 2)
              if (x) point_setting = constrain_my(point_setting, 0, POINTCALIBRS, x);  // изменить пункт
              disp.printFromPGM((int)(&calibr[point_setting]));                        // вывести пункт
#endif

#if (DISPLAYy == 4)
              // вывести все пункты
              for (uint8_t i = 0; i <= POINTCALIBRS; i++) {
                lcd.setCursor(1, i);
                disp.printFromPGM((int)(&calibr[i]));
              }
              if (x) point_setting = constrain_my(point_setting, 0, POINTCALIBRS, x);
              // вывести указатель на пункт
              lcd.setCursor(0, point_setting);
              lcd.write('>');
#endif
            }
            switch (butt.tick) {
              case STOPCLICK:
              case OKHELD:
                urovenmenu = 0;
                point_setting = 0;
                printx = true;
                break;
              case OKCLICK:
                urovenmenu = 2;
                printx = true;
                break;
            }
            break;
        }
        break;
      case 2:
        //urovenmenu -  изменение параметров
        if (printx) {
          printx = false;
          setCursory();
          if (main_menu) lcd.write('<');
          switch (main_menu) {
            case 0:
              // выбор профиля
              vkr.profil = constrain_my(vkr.profil, 0, PROFIL, x);
              // считать структуру profil
              eeGet_profil();
              print_Capacity();
              Vout();
              lcd.write('<');  // *Pr:<0>Pb CA/Ca  *
              lcd.print(vkr.profil);
              lcd.write('>');
              print_mode(TYPE_AKB);  // вывод типа акб
              ClearStr(4);           // очистить поле
              break;
            case 1:
              // емкость
              profil.akb.capacity = constrain_my(profil.akb.capacity, 1, 255, x);  // 255 максимальная емкость акб Ач
              lcd.print(profil.akb.capacity);
              ClearStr(4);  // очистить поле
              break;
            case 2:
              // выбор типа аккумулятора
              profil.akb.type = constrain_my(profil.akb.type, 0, (uint8_t)AKB_COUNT, x);
              print_mode(TYPE_AKB);                              // вывод типа акб
              ClearStr(4);                                       // очистить поле
              break;
            case 3:
              // напряжение, количество ячеек
              profil.akb.cell = constrain_my(profil.akb.cell, 1, 26, x);  // 26 - максимальное количество ячеек акб
              print_mode(VOLTAGE);  // 12.6V
              lcd.write('(');
              lcd.print(profil.akb.cell);
              lcd.write(')');
              ClearStr(2);  // очистить поле
              break;
            case 4:
              // выбор режима
              profil.Regim = constrain_my(profil.Regim, 0, POINTMODE, x);
              print_mode(MODE);
              ClearStr(10);  // очистить поле
              break;
            case 5:
              // настройки
              Settings_point(point_setting, true, (int16_t)x);  // изменение пунктов настроек
              // сброс настроек по умолчанию
              if (point_setting == POINTSETTINGS) {
                urovenmenu = 0;
                main_menu = 0;
                printx = true;
              }
              if (butt.tick == OKCLICK or butt.tick == STOPCLICK or point_setting == SYSPARAM) {
                urovenmenu = 1;
                printx = true;
              }
              break;
            case 8:
              // калибровка
              Korrect(point_setting);
              //eepSavedStruct();  // сохранить настройки
              urovenmenu = 1;
              printx = true;
              break;
          }
          if (main_menu and main_menu < POINTSETTINGS - 2) {
            lcd.setCursor(DISPLAYx - 1, 1);
            lcd.write('>');
          }
        }

        if (main_menu < 5 and (butt.tick == OKCLICK or butt.tick == STOPCLICK)) {
          urovenmenu = 1;
          printx = true;
        }
        break;  // изменение параметров urovenmenu = 2
    }
    // -- меню
    x = 0;
    // ожидание действий пользователя
    do {
      sensor_survey();
      if (get_second()) {
        // если прошла секунда
        // вывод на дисплей напряжения, тока, температуры раз в одну секунду
        if (main_menu == POINTMENU) {
          // *24.12V 25C 20C   *
          // *12.652V 0.061A  *
#if (VOLTIN == 1)
          // напряжение от БП
          setCursorx();
          print_volt(getPower());
#endif
#if (SENSTEMP1 or SENSTEMP2)
          lcd.setCursor(7, 0);
          print_tr();  // температура транзистора или акб
#endif
#if (POWER == 1)
          if (timer_bp > 0) {
            lcd.setCursor(DISPLAYx - 4, 0);
            lcd.print(timer_bp);  // вывод времени до отключения ЗУ
            print_space();
          }
#endif
          setCursory();
         // print_volt_current(ina.voltsec, ina.ampersec, 3);  // *12.361V -0.253A *
          print_volt_current(ina.volt_aver, ina.curr_aver, 3);
          // print_memoryFree(); // вывод свободной оперативки
        }
#if (TIME_LIGHT)        
        disp.Light_power();
#endif
      }
      // --- выполнить раз в секунду

    } while (!butt.tick and !printx);
    // --- ожидание действий пользователя

    if (butt.tick <= 1) x = butt.tick;
    printx = true;
  } while (BitIsClear(profil.flags, ACTIVITI));  // цикл меню

  if (profil.Regim != Modes::DISCHARGE) Res_mem_char();                                // сброс значений заряда
  if (profil.Regim == Modes::DISCHARGE or profil.Regim == KTCycle) Res_mem_dischar();  // сброс значений разряда
  if (profil.Regim == Modes::KTCycle) Res_ktc();                                       // очистить память КТЦ
  if (profil.Regim == Modes::BRANIMIR) Round = 3;                                      // для Бранимира минимум 3 раунда
  regim_end = Reason::begin;
  if (Round == 0) Round = 1;
   Number = 1; // номер операции
#if defined(__LGT8FX8P__)
  // сохранить количество циклов
  lgt_eeprom_update_byte(MEM_ROUND, Round);
  // сохранить номер текущего режима
  lgt_eeprom_update_byte(MEM_NUMBER, Number); 
#else
  EEPROM.update(MEM_ROUND, Round); 
  EEPROM.update(MEM_NUMBER, Number); 
#endif
}
