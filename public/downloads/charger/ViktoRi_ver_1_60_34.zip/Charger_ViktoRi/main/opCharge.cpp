#include "1_User_Setup.h"
#include "AllFunctions.h"
#include "Classes.h"
#include "DCDC.h"
#include "Display.h"
#include "INA226int.h"
#include "global.h"
#include "menu_txt.h"
#include "operations.h"
#include "system.h"
#include <GyverIO.h>

#if (Time_pause_assimetric == 0)
#undef Time_pause_assimetric
#define Time_pause_assimetric 1
#endif

const uint16_t timer[3]{60, 600, 1800};

// структура для Дозаряда
struct Add_charge {
  // Дозаряд
  // два значения напряжений при дозаряде
  uint16_t add_volt_max = 0; // напряжение при максимальном токе
  uint16_t add_volt_min = 0; // напряжение при минимальном токе

  // когда разница между напряжениями станет менее 300 мВ то завершить дозаряд
  bool add_end(void) {
    // int16_t volt_diff = difference(add_volt_max, add_volt_min);
    // return (abs(volt_diff) < (int16_t)Volt_difference_mV);
    return ((add_volt_min + Volt_difference_mV) >= add_volt_max);
  }
};

// структура счета скорость снижения тока заряда
struct Curr_speed_check {
  uint16_t counterCurrSpeed = Time_Curr_decrease;
  // значение изменения тока
  int8_t curr_speed = 0;
  // предыдущее значение
  int curr_speed_previous = 0;

  // проверка тока на скорость снижения
  bool curr_speed_check(int charge_current_aver) {
    // сохраняем значение тока
    if (counterCurrSpeed == Time_Curr_decrease)
      curr_speed_previous = charge_current_aver;
    // ждем 20 минут
    if (--counterCurrSpeed == 0) {
      counterCurrSpeed = Time_Curr_decrease;
      // высчитываем разницу
      int16_t cs = charge_current_aver - curr_speed_previous;
      curr_speed = (int8_t)constrain(cs, (int8_t)-127, (int8_t)127);
      // если ток снижается менее чем 5 мА за 20 минут, то завершить заряд
      if (curr_speed >= -5)
        return true;
    }
    return false;
  }
};

// структура для контроля критических изменений тока заряда
struct Curr_critical_check {
private:
  // значения изменения тока мА которые проверяются каждые 60, 600, 1800 сек
  const int8_t curr_step[3]{100, 50, 20};
  // счет 60, 600, 1800 сек
  uint16_t counter[3]{60, 600, 1800};
  // предыдущее значение
  int16_t curr_previous = 0;

public:
  // значений изменения тока
  int16_t curr_critical = 0;

  void reset() {
    curr_critical = 0;
    memcpy(counter, timer, 6);
  }

  // проверка ток на увеличение
  bool offset_critical_current(bool v_max, int16_t charge_current_aver) {
    // если напряжение достигло максимального
    if (v_max) {
      // проверка тока на увеличение
      int16_t cs = charge_current_aver - curr_previous;
      curr_previous = charge_current_aver;
      curr_critical += (int8_t)constrain(cs, (int8_t)-40, (int8_t)40);

      // если ток уменьшается  то сбрасываем значение
      if (curr_critical < 0) {
        reset();
      } else if (curr_critical > 0) {
        if (curr_critical > Curr_Critical_mA)
          return true;
        // в цикле проверить counter - если одно из значений равно 0
        // то то присваеваем ему счет 60, 600, 1800 сек
        for (uint8_t i = 0; i < 3; i++) {
          if (counter[i] > 0) {
            counter[i]--;
          } else {
            counter[i] = timer[i];
            if (curr_critical > curr_step[i])
              return true;
          }
        }
      }

    } else {
      reset();
    }
    return false;
  }
};

// структура для контроля критических изменений напряжения заряда
struct Volt_critical_check {
private:
  const uint16_t timer[3]{60, 600, 1800};
  // значения изменения напряжения мВ которые проверяются каждые 60, 600, 1800
  // сек
  const int8_t volt_step[3]{-100, -50, -20};
  // предыдущее значение
  uint16_t volt_previous = 0;
  // счет 60, 600, 1800 сек
  uint16_t counter[3]{60, 600, 1800};

public:
  // значений изменения напряжения
  int16_t volt_critical = 0;

  void reset() {
    volt_critical = 0;
    memcpy(counter, timer, 6);
  }

  // проверка напряжение на уменьшение
  bool offset_critical_voltage(uint16_t charge_volt_aver) {
    // разница напряжения за 1 секунду
    int16_t cs = difference(charge_volt_aver, volt_previous);
    volt_previous = charge_volt_aver;
    // ограничиваем диапазон и суммируем
    volt_critical += (int8_t)constrain(cs, (int8_t)-40, (int8_t)40);
    // если напряжение увеличивается то сбрасываем значение
    if (volt_critical >= 0) {
      reset();
    } else if (volt_critical < 0) {
      if (volt_critical < Volt_Critical_mV)
        return true;
      // в цикле проверить counter - если одно из значений равно 0
      // то то присваеваем ему счет 60, 600, 1800 сек
      for (uint8_t i = 0; i < 3; i++) {
        if (counter[i] > 0) {
          counter[i]--;
        } else {
          counter[i] = timer[i];
          if (volt_critical < volt_step[i])
            return true;
        }
      }
    }
    return false;
  }
};

// флаги управления зарядом
enum : uint8_t {
  CHARGEZ, // заряд включен
  OSCILZ,  // осциляция
  KORR,    // корректировка напряжения и тока заряда
  KORRVA,  // изменение вольт или ампер
  POWOFF,  // Напряжение от БП пропало
  VMAXM,   // напряжение достигло максимума
  ADD_mm,  // если минимальный ток меньше тока дозаряда - будет работать
           // алгоритм качелей
};
// режимы заряда
enum Regims : uint8_t {
  REGIM_PRECHARGE = 1, // 1 Предзаряд
  REGIM_CHARGE,        // 2 Заряд
  REGIM_ADDCHARGE,     // 3 Дозаряд
  REGIM_OSCIL,         // 4 осциляция(качели)
  REGIM_BRANIMIR,      // 5 заряд по Бранимиру
  REGIM_ASYMMETRIC,    // 6 ассиметричный заряд
};

// Функция заряда. volt_charge_init - напряжение заряда, curr_charge_init -
// ток заряда, curr_min - минимальный ток заряда, time_charge - время заряда в
// часах, add_charge - дозаряд вкл/откл
void ChargeAkb(uint16_t volt_charge_init, int16_t curr_charge_init,
               int16_t curr_min, uint32_t time_charge, bool add_charge) {
  Regims typez;
  uint8_t flagsz = 0b00001011;
  bitWrite(flagsz, ADD_mm, (curr_min < curr_charge_init));
  // вывод режима, напряжения и тока заряда/разряда
#if (PROTECT_BLOCK)
  Protect::Guard();
#endif
  // вывод значений заряда
  // вывод напряжения и тока заряда
  print_volt_current(volt_charge_init, curr_charge_init);
  lcd.print(time_charge); // вывод времени заряда/дозаряда
  lcd.write('h');
  lcd.setCursor(DISPLAYx - 2, 0);
  printCykl();         // вывод количества циклов
  time_charge *= 3600; // перевел часы в секунды

  // VA_var va;

  Curr_critical_check cc;
  Volt_critical_check vc;
  Curr_speed_check cs;
  Add_charge add;

  TimeCount tyme;
  // время заряда или дозаряда
  tyme.local = add_charge ? profil.add.stat.time : profil.charge.stat.time;

  // 1 - Предзаряд, 2 - Заряд, 3 - Дозаряд, 4 - осциляция(качели), 5 - заряд
  // по Бранимиру
  typez = add_charge ? REGIM_ADDCHARGE
                     : (bitRead(profil.flags, PRECHAR) ? REGIM_PRECHARGE
                                                       : REGIM_CHARGE);

#if (BRRANIMIR == 1)
  if (profil.Regim == Modes::BRANIMIR)
    typez = REGIM_BRANIMIR;
  uint32_t tyme_branim = 0;
#endif
  if (profil.Regim == Modes::ASYMMETRIC)
    typez = REGIM_ASYMMETRIC;
  uint8_t pre_minut = 60; // таймер 60 секунд для предзаряда
  uint16_t sec_600 = 600; // время 10 минут

  uint8_t n_disp = 0, ns_disp = 0; // номер экрана, время отображения
  uint16_t Timezar = 0;            // время до завершения заряда секунды
  uint16_t v1 = 0;                 // переменная для сохранения напряжения
  uint8_t tsw = 10; // Дозаряд переменная времени переключения, сек.

  uint16_t period =
      profil.asym.period_charge; // счет времени для ассиметричного заряда

  uint8_t time_millis = 0;
  const int16_t cur_max = curr_charge_init;
  // * 1.025 дополнительная защита от повышенного напряжения
  const uint16_t volt_crash = volt_charge_init + (volt_charge_init >> 4);
  // * 1.25 дополнительная защита от повышенного тока
  const int16_t curr_crash = curr_charge_init + (curr_charge_init >> 2);

#if (Time_pause_assimetric <= 255)
  uint8_t time_pause_assimetric = 0;
#elif (Time_pause_assimetric <= 65535)
  uint16_t time_pause_assimetric = 0;
#else
  uint32_t time_pause_assimetric = 0;
#endif

#ifdef CURR_OFF_CHARGE
  // таймер 5 сек до отключения заряда при снятии клеммы
  uint8_t time_y = CURR_OFF_CHARGE;
#endif

#if (POWER == 1)
  // Relay_on(true);                       // включить сеть 220В
#endif
  // {предварительный заряд, заряд,дозаряд, Качели, Бранимир, асимметрия}
  const int x[]{(int)(&settings[16]),
                (int)(&modeTxt[Modes::CHARGE]),
                (int)(&modeTxt[Modes::ADDCHARGE]),
                (int)(&settings[19]),
                (int)(&modeTxt[Modes::BRANIMIR]),
                (int)(&modeTxt[Modes::ASYMMETRIC])};

  Delay(3000);
  lcd.clear();
  dcdc.start(DCDC_CHARGE);
  dcdc.begin(volt_charge_init,
             (add_charge ? curr_charge_init
                         : (bitRead(profil.flags, PRECHAR)
                                ? profil.charge.current_pre >> 1
                                : curr_charge_init)));
  start_second_usr();
  // цикл заряда
  while (bitRead(flagsz, CHARGEZ) and bitRead(profil.flags, ACTIVITI)) {
    sensor_survey();

#if (VOLTIN == 1)
    if (!sysFlagGetBits(FlagsName::POWERON) and BitIsClear(flagsz, POWOFF)) {
      // если пропадет напряжение от БП то работу заряда поставить на паузу
      dcdc.Off();
      bitSet(flagsz, POWOFF);
      pause_second_usr(false);
      cc.reset();
      vc.reset();
#if (SPEAKER > 0)
      Speaker(300);
#endif
    } else if (sysFlagGetBits(FlagsName::POWERON) and bitRead(flagsz, POWOFF)) {
      dcdc.start(DCDC_CHARGE);
      bitClear(flagsz, POWOFF);
      pause_second_usr(true);
#if (SPEAKER > 0)
      Speaker(300);
#endif
      lcd.clear();
    }
#endif

    if (butt.tick) {
      // если кнопка нажата
      if (bitRead(flagsz, KORR)) {
        // производится корректировка напряжения и тока заряда
        cc.reset();
        vc.reset();
        switch (butt.tick) {
        case RIGHT:
        case LEFT:
          // изменение напряжения или тока
          if (bitRead(flagsz, KORRVA)) {
            // изменение напряжения
            volt_charge_init = volt_step(volt_charge_init, butt.tick);
            dcdc.setVolt_charge(volt_charge_init);
          } else {
            // изменение тока
            int8_t step =
                butt.tick > 0 ? (int8_t)STEP_CURR : -(int8_t)STEP_CURR;
            curr_charge_init = constrain_my(curr_charge_init, CUR_CHARGE_MIN,
                                            CURRMAXINT - 500, step);
            dcdc.setCur_charge(curr_charge_init);
          }
          break;
        case OKCLICK:
          InvBit(flagsz, KORRVA);
          break;
        case OKHELD:
        case STOPCLICK:
          bitClear(flagsz, KORR); // выйти из изменения
          setCursory();
          ClearStr(15);
          break;
        }
      } else {
        if (n_disp == WINDC and butt.tick == OKHELD) {
          bitSet(flagsz, KORR);
        } else {
          switch (butt.tick) {
          case STOPHELD:
          case OKHELD:
            // завершить заряд
            if (n_disp == 0)
              bitClear(profil.flags, ACTIVITI);
            break;
          case RIGHT:
          case LEFT:
            if (sysFlagGetBits(FlagsName::POWERON)) {
              // если питание от БП приходит то выбрать следующее окно
              lcd.clear();
              // окно отображения
              n_disp =
                  (n_disp == 0 and butt.tick < 0) ? WINDC : n_disp + butt.tick;
              // время отображения сек
              ns_disp = TIME_DISP;
            }
            break;
          }
        }
      }
    }
    if (get_second()) {
      // если прошла секунда
      // раз в секунду запускаем 13 шагов или 3 если отсутствует напряжение от
      // БП
      time_millis = sysFlagGetBits(FlagsName::POWERON) ? 13 : 3;
    }

    switch (time_millis) {
    case 0:
      // тут не должно ни чего быть
      break;
    case 13:
#if (PROTECT_BLOCK)
      Protect::Guard();
#endif
      break;
    case 12:
      tyme.cal_real_tm(); // рассчитать количество всех секунд заряда
      if (tyme.real_tm > time_charge) {
        //  если время больше установленного завершить работу
        bitClear(flagsz, CHARGEZ);
        regim_end = Reason::out_time; // закончилось время
      }
      if (add_charge) {
        profil.add.stat.time = tyme.real_tm;
        // расчет ампер/часов
        profil.add.stat.ah += Calc_AhWh((int32_t)ina.ampersec);
        // расчет ватт/часов
        profil.add.stat.wh += Calc_AhWh(ina.getsPower());
      } else {
        profil.charge.stat.time = tyme.real_tm;
        profil.charge.stat.ah +=
            Calc_AhWh((int32_t)ina.ampersec); // расчет ампер/часов
        profil.charge.stat.wh +=
            Calc_AhWh(ina.getsPower()); // расчет ватт/часов
      }

      // выполнить если включен таймер завершения заряда
      if (Timezar) {
        // если таймер вышел то завершить заряд
        if (--Timezar == 0)
          bitClear(flagsz, CHARGEZ);
      }
      break;
    case 11:
      switch (typez) {
        // выбор типа заряда
      case REGIM_PRECHARGE:
        //  включен предварительный заряд
        // если напряжение больше напряжения предзаряда то отключить
        // предварительный заряд
        if (ina.volt_aver > profil.charge.voltage_pre) {
          // отключить предварительный заряд
          typez = REGIM_CHARGE;
          // обычный заряд
          dcdc.setCur_charge(curr_charge_init);
          bitSet(flagsz, OSCILZ);
        } else if (--pre_minut == 0) {
          pre_minut = 60;
          // ток заряда увеличивается и уменьшается раз в минуту в течении 10
          // минут
          if (bitRead(flagsz, OSCILZ)) {
            // увеличение тока заряда
            dcdc.setCur_charge(dcdc.getCur_charge() +
                               (profil.charge.current_pre >> 4));
            // когда ток достигнет максимального
            // переключить флаг на уменьшение
            if (dcdc.getCur_charge() >= profil.charge.current_pre)
              bitClear(flagsz, OSCILZ);

          } else {
            // увеличение тока заряда
            dcdc.setCur_charge(dcdc.getCur_charge() -
                               (profil.charge.current_pre >> 4));
            // когда ток достигнет минимального переключить флаг на увеличение
            if (dcdc.getCur_charge() <= profil.charge.current_pre >> 1)
              bitSet(flagsz, OSCILZ);
          }
        }
        break;

      case REGIM_CHARGE:
        // включен заряд
#if (CURRENT_REDUCTION == 1)
        // начать снижение тока заряда когда напряжение достигнет
        // установленного и ток заряда - максимальный деленный на 4
        if ((profil.charge.voltage_decr_cur < volt_charge_init) and
            (ina.voltsec > profil.charge.voltage_decr_cur) and
            (ina.ampersec > (cur_max >> 2))) {
          curr_charge_init = map_my(ina.voltsec, profil.charge.voltage_decr_cur,
                                    volt_charge_init, cur_max, (cur_max >> 2));
          dcdc.setCur_charge(curr_charge_init);
        }
#endif
        if (bitRead(flagsz, VMAXM)) {
          // если напряжение достигло максимального
          if (cs.curr_speed_check(ina.curr_aver)) {
            // если ток перестал снижаться
            // включение режима Осчиляция(Качели) при завершении заряда
            if (bitRead(profil.flags, OSCIL))
              typez = REGIM_OSCIL;
            else {
              regim_end = Reason::cur_stop; // ток перестал снижаться
              bitClear(flagsz, CHARGEZ);    // завершить заряд
            }
          }
        }
      case REGIM_BRANIMIR:
        // проверка критических значений - тока и напряжения
        // если напряжение достигло максимального и ток увеличивается
        if (cc.offset_critical_current(bitRead(flagsz, VMAXM), ina.curr_aver)) {
          bitClear(profil.flags, ACTIVITI); // завершить заряд
          regim_end = Reason::curr_increased;
        }

        // если напряжение начало уменьшаться
        if (vc.offset_critical_voltage(ina.volt_aver)) {
          bitClear(profil.flags, ACTIVITI); // завершить заряд
          regim_end = Reason::volt_decreased;
        }
        break;
      case REGIM_ADDCHARGE:
        // Дозаряд
        if (bitRead(flagsz, ADD_mm)) {
          if (tsw)
            tsw--;
          auto vt = difference(ina.volt_aver, v1);
          if (!tsw and (abs(vt) < 10)) {
            // если время завершилось и напряжение стабилизировалось
            if ((dcdc.getCur_charge() == curr_charge_init)) {
              // если ток максимальный
              // сохранить максимальное напряжение
              add.add_volt_max = ina.volt_aver;
              // установить минимальный ток
              dcdc.setCur_charge(profil.add.current_min);
            } else {
              // если ток минимальный
              // сохранить минимальное напряжение
              add.add_volt_min = ina.volt_aver;
              // установить максимальный ток
              dcdc.setCur_charge(curr_charge_init);
            }
            tsw = 10; // ожидание 10 сек
          } else
            v1 = ina.volt_aver;
        } else {
          // проверка критических значений - тока и напряжения
          // если напряжение достигло максимального и ток увеличивается
          if (cc.offset_critical_current(bitRead(flagsz, VMAXM),
                                         ina.curr_aver)) {
            bitClear(profil.flags, ACTIVITI); // завершить заряд
            regim_end = Reason::curr_increased;
          }

          // если напряжение начало уменьшаться
          if (vc.offset_critical_voltage(ina.volt_aver)) {
            bitClear(profil.flags, ACTIVITI); // завершить заряд
            regim_end = Reason::volt_decreased;
          }
        }
        break;
      case REGIM_OSCIL: {
        // если в настройках включена Осциляция(Качели) то при снижении тока
        // менее curr_min*2 включается Режим осциляции - включение и
        // отключение тока
        auto vt = difference(ina.volt_aver, v1);
        if (abs(vt) < 10) {
          InvBit(flagsz, OSCILZ); // инвертируем флаг
#if (MCP4725DAC)
          if (BitIsClear(flagsz, OSCILZ))
            dac.setVoltage(0);
#else
          dcdc.pause(bitRead(flagsz, OSCILZ));
#endif
        } else
          v1 = ina.volt_aver;
        break;
      }
      case REGIM_ASYMMETRIC:
        // ассиметричный режим
        if (period > 0)
          period--;
        else if (time_pause_assimetric == 0) {
          dcdc.Off(); // отключить заряд
          time_pause_assimetric = Time_pause_assimetric;
        } else {
          if (--time_pause_assimetric == 0) {
            if (bitRead(flagsz, OSCILZ)) {
              // период заряда - переключиться в разряд
              period = profil.asym.period_discharge;
              dcdc.start(DCDC_DISCHARGE);
              // задает напряжение и ток разряда
              dcdc.begin(profil.disch.voltage_end, profil.disch.current);
#if (FAN > 0 and FAN_DISCHAR_ON == 1)
              fan.ONonse(true);
#endif
            } else {
              // период разряда - переключиться в заряд
              period = profil.asym.period_charge;
              dcdc.start(DCDC_CHARGE);
              // задает напряжение и ток заряда
              dcdc.begin(volt_charge_init, curr_charge_init);
#if (FAN > 0 and FAN_DISCHAR_ON == 1)
              fan.ONonse(false);
#endif
            }
            InvBit(flagsz, OSCILZ); // переключить флаг режима
          }
        }
        break;
      }
      break;
    case 10:
      // вывод на дисплей 1602
#if (DISPLAYy == 2)
      switch (n_disp) {
      case 0:
        // экран 0
        // вывод текущих значений напряжения, тока.  Вывод Ватт-часов.
        Display_print((add_charge ? profil.add.stat.ah : profil.charge.stat.ah),
                      tyme.real_tm, Percentage(curr_min), add_charge);
        break;
      case 1:
        // экран 1
        setCursorx();
        print_mode(MODE);
        setCursory();
        disp.printFromPGM(x[typez - 1]);
        print_space();
        lcd.print(Percentage(curr_min)); // процент заряда Акб
        lcd.write('%');
        break;
        // *Charge>AddChar  *
        // *Charge 45% 125  *
      case 2:
        // экран 2
        setCursorx();
        print_Wh(add_charge ? profil.add.stat.wh : profil.charge.stat.wh);
#if (SENSTEMP1 or SENSTEMP2)
        print_tr(); // температура транзистора или акб
#endif
        lcd.setCursor(DISPLAYx - 1, 0);
        lcd.print(regim_end); // причина завершения заряда

        setCursory();
#if (VOLTIN == 1)
        print_volt(getPower());
#endif
        printCykl();
        print_space();
        // вывод значения ШИМ заряда
        lcd.print(dcdc.getTok());
        // выполнить если включен таймер завершения заряда
        if (Timezar) {
          print_space();
          lcd.print(Timezar);
        }
        break;
        // *58.3Wh 45C 25C  *
        // *24.1V C1 N1     *
      case 3:
        // экран 3
        setCursorx();
        print_volt_current(ina.volt_aver, ina.curr_aver, 3);
        setCursory();
        lcd.print(cc.curr_critical);
        print_space();
        lcd.print(vc.volt_critical);
        print_space();
        lcd.print(cs.curr_speed);
        print_space();
        // print_memoryFree(); // вывод свободной оперативки
        break;
      case 4:
        // экран 4           // изменение напряжения и тока заряда
        setCursorx();
        print_volt_current(ina.voltsec, ina.ampersec);
        lcd.setCursor(DISPLAYx - 2, 0);
        lcd.print(F("OK"));
        if (bitRead(flagsz, KORR)) {
          setCursory();
          Write_x(bitRead(flagsz, KORRVA));  // > or  пробел
          print_volt(volt_charge_init);      // Напряжение и ток заряда
          Write_x(!bitRead(flagsz, KORRVA)); // > or  пробел
          print_current(curr_charge_init);   // Напряжение и ток заряда
        } else {
          setCursory();
          print_volt_current(ina.volt_aver, ina.curr_aver, 3);
        }
        break;
      default:
        n_disp = 0;
        lcd.clear(); // очистить дисплей
        break;
      }
#endif
// вывод на дисплей 2004
#if (DISPLAYy == 4)
      switch (n_disp) {
      // экран 0
      case 0:
        Display_print((add_charge ? profil.add.stat.ah : profil.charge.stat.ah),
                      (add_charge ? profil.add.stat.wh : profil.charge.stat.wh),
                      tyme.real_tm, temp_Q1, Percentage(curr_min));
        break;
      case 1:
        setCursorx();
        print_mode(MODE);
        setCursory();
        disp.printFromPGM(x[typez - 1]);
        lcd.setCursor(0, 2);
        lcd.print(regim_end); // причина завершения заряда
        if (Timezar) {
          print_space();
          // выполнить если включен таймер завершения заряда
          lcd.print(Timezar);
        }
        printCykl();
        lcd.setCursor(0, 3);
        lcd.print((float)ina.getsPower() / 1000, 2);
        lcd.write('W');
        break;
      // изменение напряжения и тока заряда
      case 2:
        setCursorx();
        // текущие напряжение и ток
        print_volt_current(ina.voltsec, ina.ampersec);
        lcd.setCursor(DISPLAYx - 2, 0);
        lcd.print(F("OK"));
        if (bitRead(flagsz, KORR)) {
          setCursory();
          Write_x(bitRead(flagsz, KORRVA));
          print_volt(volt_charge_init); // Напряжение и ток заряда
          Write_x(!bitRead(flagsz, KORRVA));
          print_current(curr_charge_init); // Напряжение и ток заряда
        } else {
          setCursory();
          print_volt_current(ina.volt_aver, ina.curr_aver);
        }
        break;

      case 3:
        break;
      default:
        n_disp = 0;
        break;
      }
#endif
      if (BitIsClear(flagsz, KORR) and n_disp) {
        if (ns_disp)
          ns_disp--;
        else {
          n_disp = 0;
          lcd.clear();
        }
      }
      break;
    case 9:
      // когда напряжение достигнет максимального то устанавливается
      // соответствующий флаг если напряджение снизилось менее 200 мВ то флаг
      // снимается
      if (BitIsClear(flagsz, VMAXM) and
          (ina.volt_aver >= volt_charge_init - 30) and
          ina.curr_aver > (int8_t)20) {
        // если флаг макс напр не установлен и напряжение достигло
        // максимального то установить этот флаг
        bitSet(flagsz, VMAXM);
      } else if (bitRead(flagsz, VMAXM) and
                 (ina.volt_aver < volt_charge_init - 200)) {
        // иначе если флаг макс напр установлен и напряжение стало ниже
        // максимального то снять этот флаг
        bitClear(flagsz, VMAXM);
        Timezar = 0;
      }
      break;
#ifdef CURR_OFF_CHARGE
    case 8:
      // если ток заряда меньше или равен 0 то отключить заряд и выйти в меню.
      if (ina.ampersec <= (uint8_t)CURR_OFF_CHARGE and
          bitRead(flagsz, OSCILZ) and time_pause_assimetric == 0) {
        if (--time_y == 0) {
          // dcdc.Off();
          bitClear(profil.flags, ACTIVITI);
#if (SPEAKER > 0)
          Speaker(300);
          Delay(300); // пик
          Speaker(300);
          Delay(300); // пик
#endif
        }
      } else
        time_y = CURR_OFF_CHARGE;
      break;
#endif
    case 7:
      // выполнить каждые 10 минут
      if (--sec_600 == 0) {
        sec_600 = 600;

        switch (typez) {
        case REGIM_CHARGE:
          // включен заряд

          if (bitRead(flagsz, VMAXM)) {
            // если напряжение достигло максимального

            // включение режима Осчиляция(Качели) при снижении тока заряда до
            // curr_min * 4
            // if (bitRead(profil.flags, OSCIL) and (ina.curr_aver < (curr_min
            // << 2)))
            //  typez = REGIM_OSCIL;

            if (ina.curr_aver <= curr_min) {
              // напряжение достигло максимума, ток минимума
              if (bitRead(profil.flags, OSCIL))
                typez = REGIM_OSCIL;
              else {
                regim_end = Reason::volt_maxCur_min;
                bitClear(flagsz, CHARGEZ); // завершить заряд
              }
            }
          }
          break;
        case REGIM_ADDCHARGE:
          // включен дозаряд,
          if (bitRead(flagsz, ADD_mm) and !Timezar and add.add_end()) {
            // если разница напряжений при максимальном и минимальном тока
            // ниже 0,5 Вольт то включить таймер
            if (!Timezar)
              Timezar = Time_AddCarge; //  установить таймер на 30 минут
          }
          break;
        case REGIM_OSCIL:
          // включен режим Качели
          // если минимальный ток меньше тока завершения заряда и напряжение
          // достигло максимального то завершить заряд
          if (bitRead(flagsz, VMAXM) and (ina.curr_aver <= curr_min)) {
            regim_end = Reason::volt_maxCur_min;
            bitClear(flagsz, CHARGEZ); // завершить заряд
            break;
          }
          break;
#if (BRRANIMIR == 1)
        case REGIM_BRANIMIR:
          // заряд по Бранимиру
          // если напряжение достигло максимального начинаем отсчет времени
          if (bitRead(flagsz, VMAXM)) {
            tyme_branim += 600;
            if (tyme_branim >= 72000) {
              // если прошло более 20 часов останавливаем заряд и перемешиваем
              bitClear(flagsz, CHARGEZ);
              // установить флаг перемешивания электролита
              bitSet(profil.flags, BRANIMBOIL);
            }
            if (ina.curr_aver <= curr_min) {
              // если ток заряда снизился до установленного то устанавливаем
              // флаг об успешном заряде Бранимира и переходим в дозаряд
              //  напряжение достигло максимума ток минимума;
              regim_end = Reason::volt_maxCur_min;
              // установить флаг успешного завершения заряда по Бранимиру
              bitSet(profil.flags, BRANIM);
              bitClear(flagsz, CHARGEZ); // отключить заряд
            }
          }
          break;
#endif
        case REGIM_ASYMMETRIC:
          // условия завершения работы
          // если минимальный ток меньше тока завершения заряда и напряжение
          // достигло максимального то завершить заряд
          if (bitRead(flagsz, VMAXM) and (ina.ampersec <= curr_min)) {
            regim_end = Reason::volt_maxCur_min;
            bitClear(flagsz, CHARGEZ); // завершить заряд
          }
          break;
        }
        eepSavedStruct();
        // ---выполнить раз в 10 минут.
      }

      break;
    case 6:
      // защита от повышенного тока и напряжения
      if (ina.ampersec > curr_crash or
          (ina.voltsec > volt_crash and ina.ampersec > 20)) {
        dcdc.Off(); // отключить ШИМ
#if (SPEAKER > 0)
        Speaker(300);
#endif
#if (TIME_LIGHT)
        disp.Light_high(); // включение подсветки
#endif
        dcdc.start(DCDC_CHARGE); // перезапустить dcdc
      }
      break;
    case 3:
      if (!sysFlagGetBits(FlagsName::POWERON)) {
        // если питание от БП не приходит
#if (TIME_LIGHT)
        disp.Light_power();
#endif
        lcd.clear();
        lcd.print(F(txt4)); // "Power "
        print_mode(ERROR);  // "error"
#if (VOLTIN == 1)
        print_volt(getPower());
#endif
        setCursory();
        print_volt_current(ina.voltsec, ina.ampersec);
      }
      break;
    case 2:
#if (CORRECTCUR and SENSTEMP2)
      Control_trAkb(); // контроль температуры Акб
#endif
      break;
    case 1:
#if (LOGGER)
#if (LOGGER == 4)
      Sout.create_advanced(
          (add_charge ? profil.add.stat.ah : profil.charge.stat.ah),
          (uint16_t)ina.volt_aver, ina.curr_aver, tyme.real_tm);
#else
      Sout.create((add_charge ? profil.add.stat.ah : profil.charge.stat.ah),
                  (uint16_t)ina.volt_aver, ina.curr_aver);
#endif
#endif
#if (TIME_LIGHT)
      disp.Light_low();
#endif
      break;
    }
    if (time_millis > 0)
      time_millis--;
  }
  // цикл заряда
  dcdc.Off(); // отключить заряд, разряд.
#if (FAN > 0)
  // автоматический режим кулера
  fan.ONonse(false);
#endif
#if (PROTECT_BLOCK)
  Protect::Open(false);
#endif
  eepSavedStruct(); // сохранить настройки
}
