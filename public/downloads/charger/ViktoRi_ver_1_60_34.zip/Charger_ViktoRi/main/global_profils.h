// новая структура профиля
#include <Arduino.h>


// название бит для profil.flags
enum Pr_flags : uint8_t {
  ACTIVITI,    // активность
  PRECHAR,     // режим предзаряда
  OSCIL,       // режим осцилляции
  CHARGE_ADD,  // дозаряд после заряда
  BRANIM,      // флаг успешного завершения заряда по Бранимиру
  BRANIMBOIL,  // флаг перемешивания электролита
};


#pragma pack(push, 1)
struct Akb {
  // тип аккумулятора
  uint8_t type;
  // емкость аккумулятора
  uint8_t capacity;
  // количество ячеек аккумулятора
  uint8_t cell;
};
#pragma pack(pop)

// Статистика
#pragma pack(push, 1)
struct Statistic {
  // Ач
  int32_t ah;
  // Втч
  int32_t wh;
  // Время, сек
  uint32_t time : 24;
};
#pragma pack(pop)

#pragma pack(push, 1)
struct Regim_Charge {
  // напряжение
  uint16_t voltage;
  // ток
  int16_t current;
  // ток завершения заряда
  int16_t current_end;
  // Напряжение при котором начинает снижаться ток
  uint16_t voltage_decr_cur;
  // Время заряда
  uint8_t time;
  // дозаряд
  // bool add_charge;
  // статистика
  Statistic stat;
  // напряжение предзаряда
  uint16_t voltage_pre;
  // ток предзаряда
  int16_t current_pre;
};
#pragma pack(pop)

#pragma pack(push, 1)
struct Regim_addCharge {
  // напряжение
  uint16_t voltage;
  // ток
  int16_t current;
  // Мин. ток дозар
  int16_t current_min;
  // Время заряда, часы
  uint8_t time;
  // статистика
  Statistic stat;
};
#pragma pack(pop)

#pragma pack(push, 1)
struct Regim_Asymmetric {
  // напряжение заряда
  uint16_t voltage;
  // ток заряда
  int16_t current;
  //ток разряда
  int16_t current_discharge;
  // Период заряда - сек
  uint8_t period_charge;
  // Период разряда
  uint8_t period_discharge;
  // Пауза между периодами - сек
  uint8_t pause;
  // статистика
  Statistic stat;
};
#pragma pack(pop)

#pragma pack(push, 1)
struct Regim_discharge {
  // напряжение завершения разряда
  uint16_t voltage_end;
  // ток разряда
  int16_t current;
  // ток завершения разряда
  int16_t current_end;
  // статистика
  Statistic stat;
};
#pragma pack(pop)

// Режим хранения акб
#pragma pack(push, 1)
struct Regim_Storage {
  // напряжение
  uint16_t voltage;
  // ток
  int16_t current;
};
#pragma pack(pop)

// Буферный режим
#pragma pack(push, 1)
struct Regim_Buffer {
  // напряжение
  uint16_t voltage;
  // ток
  int16_t current;
};
#pragma pack(pop)

// Профиль
#pragma pack(push, 1)
struct Profils {
  uint8_t flags;
  Akb akb;
  uint8_t Regim;
  Regim_Charge charge;
  Regim_addCharge add;
  Regim_Asymmetric asym;
  Regim_discharge disch;
  Regim_Storage storage;
  Regim_Buffer buffer;
  uint16_t resist;
  uint16_t currentInrush;
};
#pragma pack(pop)
// размер профиля: 96 байт


/*
// вернуть размер  профиля
size_t sizeof_profil() {
  return sizeof(Profils);
 // profil.charge.stat.ah
}
*/

// Дефолтные настройки профиля в PROGMEM
const Profils PROGMEM profil_default = {
  .flags = 0,
  .akb = {
    .type = 0,
    .capacity = 60,
    .cell = 6
  },
  .Regim = 0,
  .charge = {
    .voltage = 14700,
    .current = 6000,
    .current_end = 120,
    .voltage_decr_cur = 13600,
    .time = 15,
    .stat = {
      .ah = 0,
      .wh = 0,
      .time = 0
    },
    .voltage_pre = 13800,
    .current_pre = 2000
  },
  .add = {
    .voltage = 16200,
    .current = 1200,
    .current_min = 400,
    .time = 10,
    .stat = {
      .ah = 0,
      .wh = 0,
      .time = 0
    }
  },
  .asym = {
    .voltage = 14700,
    .current = 6000,
    .current_discharge = 2000,
    .period_charge = 20,
    .period_discharge = 10,
    .pause = 10,
    .stat = {
      .ah = 0,
      .wh = 0,
      .time = 0
    },
  },
  .disch = {
    .voltage_end = 11600,
    .current = 1800,
    .current_end = 1800,
    .stat = {
      .ah = 0,
      .wh = 0,
      .time = 0
    }
  },
  .storage = {
    .voltage = 13100,
    .current = 300
  },
  .buffer = {
    .voltage = 13800,
    .current = 6000
  },
  .resist = 0,
  .currentInrush = 0
};

/*
    profil.flags = 0b00000000;
    profil.akb.type = BatName::PB_CACA;
    profil.akb.capacity = 60;
     profil.akb.cell = 6;
    profil.Regim = Modes::CHARGE;   
    profil.charge.voltage = 14700;
    profil.charge.voltage_decr_cur = Volt_DCur();
    profil.add.voltage = 16200;
    profil.charge.current = 6000;
    profil.add.current = 1200;
    profil.charge.current_end = 120;
    profil.add.current_min = 600;
    profil.charge.time = 15;
    profil.add.time = 10;
    profil.disch.voltage_end = 11600;
    profil.disch.current = 1800;
    profil.disch.current_end = 1800;
    profil.buffer.voltage = 13800;
    profil.charge.current = profil.charge.current;
    profil.storage.voltage = 13100;
    profil.charge.voltage_pre = 13800;
    profil.charge.current_pre = 2000;
    profil.resist = 0;
    profil.currentInrush = 0;
    profil.asym.period_charge = 20;
    profil.asym.period_discharge = 10;
    Res_mem_char();
    Res_mem_dischar();
    */
