#include "operations.h"
#include "1_User_Setup.h"
#include "AllFunctions.h"
#include "Battery.h"
#include "Display.h"
#include "INA226int.h"
#include "global.h"
#include "system.h"
#include <EEPROM.h>

// пауза после заряда перед разрядом, мин (0-255)
#if (PAUSE_AFTER_CHARGE > 255) 
#error "PAUSE_AFTER_CHARGE пауза после заряда перед разрядом должна быть в пределах 0-255"
#endif

// пауза после разряда перед зарядом, мин (0-255))
#if ( PAUSE_AFTER_DISCHARGE > 255)
#error "PAUSE_AFTER_DISCHARGE пауза после разряда перед зарядом должна быть в пределах 0-255"
#endif


void Operations(void) {
  const uint8_t mode = profil.Regim; // сохранить режим работы
  uint8_t roundi;
#if defined(__LGT8FX8P__)
  roundi = lgt_eeprom_read_byte(MEM_ROUND); // считать из памяти
#else
  roundi = EEPROM.read(MEM_ROUND); // считать из памяти
#endif
  // если флаг заряда установлен true то выполнять работу
  while (bitRead(profil.flags, ACTIVITI)) {
    lcd.clear();
    print_mode(MODE); // вывод режима
    setCursory();
    eepSavedStruct(); // сохранить настройки
    ina.start();      // старт замеров INA
                      // Delay(500);
#if (SPEAKER > 0)
    Speaker(1000);
#endif
    // Выбор режима заряда
    switch (profil.Regim) {
    case Modes::CHARGE:
      // Заряд
      ChargeAkb(profil.charge.voltage, profil.charge.current,
                profil.charge.current_end, (uint32_t)profil.charge.time,
                false); // заряд, дозаряд откл
      // если счетчик циклов равен 0 то завершить заряд иначе повторить заряд
      if (bitRead(profil.flags, ACTIVITI) and (--roundi == 0))
        profil.Regim = Modes::STORAGE;

      break;
    case Modes::CHARGE_ADDCHARGE:
      // Заряд - Дозаряд
      switch (Number) {
      case 1:
        // Заряд
        ChargeAkb(profil.charge.voltage, profil.charge.current,
                  profil.charge.current_end, (uint32_t)profil.charge.time,
                  false);
        Number++;
        break;
      case 2:
        // Дозаряд
        // дать отстояться
        Wait(5); // Функция ожидания - минут
                 // Включить дозаряд
        ChargeAkb(profil.add.voltage, profil.add.current,
                  profil.add.current_min, (uint32_t)profil.add.time, true);
        if (bitRead(profil.flags, ACTIVITI)) {
          // если счетчик циклов равен 0 то завершить заряд
          // иначе повторить заряд - дозаряд
          if (--roundi == 0)
            profil.Regim = Modes::STORAGE;
          else
            Number = 1;
        }
        break;
      }
      break;
    case Modes::ASYMMETRIC:
      // 2 ассиметричный заряд
      // заряд, дозаряд откл
      ChargeAkb(profil.charge.voltage, profil.charge.current,
                profil.charge.current_end, (uint32_t)profil.charge.time, false);

      // если счетчик циклов равен 0 то завершить заряд иначе повторить заряд
      if (bitRead(profil.flags, ACTIVITI) and (--roundi == 0))
        profil.Regim = Modes::STORAGE;
      break;
    case Modes::BRANIMIR:
      // Заряд по Бранимиру
#if (BRRANIMIR == 1)
      switch (Number) {
      case 1:
        roundi--;
        // Бранимир Заряд 20 часов после достижения максимального напряжения
        ChargeAkb(
            profil.charge.voltage, (int16_t)profil.akb.capacity * 10,
            constrain((int16_t)profil.akb.capacity + (profil.akb.capacity >> 1),
                      CURMIN, 120), 48, false);
        // если ток заряда снизился до установленного то переходим в дозаряд
        if (bitRead(profil.flags, BRANIM) or roundi == 0)
          Number = 3;
        else if (bitRead(profil.flags, BRANIMBOIL))
          Number++; // иначе если время заряда превысило 20 часов  -
                    // перемешивание
        break;
      case 2:
        bitClear(profil.flags, BRANIMBOIL);
        // Бранимир перемешивание
        ChargeAkb(profil.add.voltage, (int16_t)profil.akb.capacity * 20,
                  constrain(((int16_t)profil.akb.capacity << 3), CURMIN, 1500),
                  1, false);
        // снова заряд малым током
        Number = 1;
        break;
      case 3:
        // Бранимир дозаряд
        // дать отстояться
        Wait(5); // Функция ожидания - минут

        if (profil.akb.type <= Akb_type::PB_GEL)
          ChargeAkb(profil.add.voltage, profil.add.current,
                    profil.add.current_min, 10, true);
        profil.Regim = Modes::STORAGE;
        break;
      }
#else
      bitClear(profil.flags, ACTIVITI);
#endif
      break;
    case Modes::ADDCHARGE:
      // Дозаряд
      ChargeAkb(profil.add.voltage, profil.add.current, profil.add.current_min,
                (uint32_t)profil.add.time, true); // Включить дозаряд
      if (bitRead(profil.flags, ACTIVITI) and (--roundi == 0))
        // если счетчик циклов равен 0 то завершить дозаряд
        profil.Regim = Modes::STORAGE;
      break;
    case Modes::DISCHARGE:
      // Разряд
#if (DISCHAR == 1)
      // разряд аккумулятора
      Discharge();
      // если счетчик циклов равен 0 то завершить разряд// иначе повторить
      // разряд
      if (bitRead(profil.flags, ACTIVITI) and (--roundi == 0))
        bitClear(profil.flags, ACTIVITI);
#else
      bitClear(profil.flags, ACTIVITI);
#endif
      break;
    case Modes::KTCycle:
      //  Котнтрольно-тренировочный цикл
#if (DISCHAR == 1)
    {
      int32_t KTC[4]; //  Ah_discharge, Wh_discharge, Ah_charge, Wh_charge,
#if defined(__LGT8FX8P__)
      /*  lgt_eeprom_read_block(((uint8_t *)&KTC),
                              (((uint16_t)roundi << 4) - 16 + MEM_KTC),
                              sizeof(KTC)); */
      // считать из памяти значения разряда, заряда roundi-циклаКТЦ
      lgt_eeprom_readSWM((((uint16_t)roundi << 4) - 16 + MEM_KTC),
                         ((uint32_t *)&KTC),
                         (uint16_t)(sizeof(KTC) / sizeof(uint32_t)));
#else
      // считать из памяти значения разряда, заряда roundi-цикла КТЦ
      EEPROM.get((((uint16_t)roundi << 4) - 16 + MEM_KTC), KTC);
#endif
      switch (Number) {
      case 1:
        // предварительный заряд
        ChargeAkb(profil.charge.voltage, profil.charge.current,
                  profil.charge.current_end, (uint32_t)profil.charge.time,
                  false);
        Number++;
        Res_mem_char(); // сброс значений заряда
        break;
      case 2:
        // дать отстояться // пауза после заряда перед разрядом
        Wait((uint16_t)PAUSE_AFTER_CHARGE); // Функция ожидания - минут
        Number++;
        break;
      case 3:
        // Разряд
        // Res_mem_dischar();  // сброс значений разряда
        Discharge(); // разряд аккумулятора
        Number++;
        //  Ah_discharge, Wh_discharge, Ah_charge, Wh_charge,
        KTC[0] = profil.disch.stat.ah;
        KTC[1] = profil.disch.stat.wh;
#if defined(__LGT8FX8P__)
        /*  lgt_eeprom_update_block(((uint8_t *)&KTC),
                          (((uint16_t)roundi << 4) - 16 + MEM_KTC),
                          sizeof(KTC)); */
        lgt_eeprom_writeSWM((((uint16_t)roundi << 4) - 16 + MEM_KTC),
                            ((uint32_t *)&KTC),
                            (uint16_t)(sizeof(KTC) / sizeof(uint32_t)));
#else
        // сохранить в памяти значения разряда roundi-цикла КТЦ
        EEPROM.put((((uint16_t)roundi << 4) - 16 + MEM_KTC), KTC);
#endif
        break;
      case 4:
        // дать отстояться // пауза после разряда перед зарядом
        Wait((uint16_t)PAUSE_AFTER_DISCHARGE); // Функция ожидания - минут
        Number++;
        break;
      case 5:
        // заряд
        // Res_mem_char();     // сброс значений заряда
        ChargeAkb(profil.charge.voltage, profil.charge.current,
                  profil.charge.current_end, (uint32_t)profil.charge.time,
                  false); // заряд, дозаряд откл
        //  Ah_discharge, Wh_discharge, Ah_charge, Wh_charge,
        KTC[2] = profil.charge.stat.ah;
        KTC[3] = profil.charge.stat.wh;
#if defined(__LGT8FX8P__)
        /*  lgt_eeprom_update_block(((uint8_t *)&KTC),
                            (((uint16_t)roundi << 4) - 16 + MEM_KTC),
                            sizeof(KTC)); */
        lgt_eeprom_writeSWM((((uint16_t)roundi << 4) - 16 + MEM_KTC),
                            ((uint32_t *)&KTC),
                            (sizeof(KTC) / sizeof(uint32_t)));
#else
        // сохранить в памяти значения разряда roundi-цикла КТЦ
        EEPROM.put((((uint16_t)roundi << 4) - 16 + MEM_KTC), KTC);
#endif
        if (bitRead(profil.flags, ACTIVITI)) {
          if (--roundi == 0)
            Number++; // если счетчик циклов равен 0 то перейти в Дозаряд
          else {
            // иначе повторить КТЦ
            Number = 2;
            Res_mem_dischar(); // сброс значений разряда
            Res_mem_char();    // сброс значений заряда
          }
        }
        break;
      case 6:
        // Дозаряд
        // дать отстояться - минут
        Wait(5);
        // Включить дозаряд
        if (profil.akb.type <= Akb_type::PB_GEL)
          ChargeAkb(profil.add.voltage, profil.add.current,
                    profil.add.current_min, (uint32_t)profil.add.time, true);
        profil.Regim = Modes::STORAGE; // перейти в Хранение
        break;
      }
    }
#else
      bitClear(profil.flags, ACTIVITI);
#endif
    break;
    case Modes::STORAGE: // хранение
      roundi = 1;
      Storage();
      profil.Regim = mode;
      break;
    case Modes::BUFER: // буферный режим
#if (BUFFER == 1)
      roundi = 1;
      Buffer();
      profil.Regim = mode;
#else
      roundi = 1;
      profil.Regim = mode;
      bitClear(profil.flags, ACTIVITI);
#endif
      break;
    } // выбор режима
    pause_second_usr(false); // счет времени заряда откл.

#if defined(__LGT8FX8P__)
    // сохранить количество циклов
    lgt_eeprom_update_byte(MEM_ROUND, roundi);
    // сохранить номер текущего режима
    lgt_eeprom_update_byte(MEM_NUMBER, Number);
#else
    EEPROM.update(MEM_ROUND, roundi);
    EEPROM.update(MEM_NUMBER, Number);
#endif

    if (BitIsClear(profil.flags, ACTIVITI)) {
      eepSavedStruct(); // сохранить настройки
      End();            // Завершение работы
    }
  }
  // цикл работы
}
