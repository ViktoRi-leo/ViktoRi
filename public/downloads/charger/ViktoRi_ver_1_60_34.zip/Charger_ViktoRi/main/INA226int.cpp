#include "INA226int.h"
#include "global.h"
#include "system.h"
#include <microWire.h>

// Инициализация и проверка
bool INA226::begin(void) {
  _vs = _as = 0;
  _vs_aver = _as_aver = 0.0;
  // _se_aver = 10;
  return testConnection(); // Вернуть true если все ок
}

// Установка встроенного усреднения выборок
void INA226::setAveraging(uint8_t avg) {
  // Читаем конф. регистр, сбросив биты AVG2-0
  uint16_t cfg_register = readRegister(INA226_CFG_REG_ADDR) & ~(0b111 << 9);
  // Пишем новое значение конф. регистр
  writeRegister(INA226_CFG_REG_ADDR, cfg_register | avg << 9);
}

// Установка разрешения для выбранного канала
void INA226::setSampleTime(bool ch, uint8_t mode) {
  // Читаем конф. регистр
  uint16_t cfg_register = readRegister(INA226_CFG_REG_ADDR);
  // Сбрасываем нужную пачку бит, в зависимости от канала
  cfg_register &= ~((0b111) << (ch ? 6 : 3));
  // Пишем нужную пачку бит, в зависимости от канала
  cfg_register |= mode << (ch ? 6 : 3);
  // Пишем новое значение конф. регистра
  writeRegister(INA226_CFG_REG_ADDR, cfg_register);
}

// Чтение напряжения, mV
uint16_t INA226::getVoltage(void) {
  // Чтение регистра напряжения
  uint16_t value = readRegister(INA226_VBUS_REG_ADDR);
  if (value == 0)
    return 0;
  if (vkr.inaKoof == 12500u) {
    // гораздо более скоростное (в 7 раз) умножение на 1,25 (_vkoof) с
    // математическим округлением
    uint32_t j = value;
    j <<= 3;
    // берем четвертую часть числа (j >> 2) и прибавляем к
    // исходному числу, (плюс 5) - математическое округление.
    value = (uint16_t)((j + (j >> 2) + 5) >> 3);

  } else {
#if defined(__LGT8FX8P__)
    DSC_MUL((uint16_t)value, (uint16_t)vkr.inaKoof); // value * _vkoof
    DA_INC((uint16_t)5000);                          // + 500
    DA_DIV_get((uint16_t)10000);                     // / 10000
    value = DA_get_int();
#else
    // LSB = 1.25mV = 0.00125V
    value = (uint16_t)(((uint32_t)value * vkr.inaKoof + 5000u) / 10000u);
#endif
  }
  return value;
}

// Чтение тока, mA
int16_t INA226::getCurrent(void) {
  int16_t value = readRegister(INA226_CUR_REG_ADDR); // Чтение регистра тока
  if (value < (int8_t)(3) and value > (int8_t)(-3))
    return 0;
#if defined(__LGT8FX8P__)
  // value * _current_lsb_int
  DSC_MUL((uint16_t)abs(value), (uint16_t)_current_lsb_int);
  DA_INC((uint16_t)2048);
  DA_shiftR((uint8_t)12); // >> 12
  int16_t val = DA_get_intt();
  return ((value > 0) ? val : -val);
#else
  // LSB рассчитывается на основе макс. ожидаемого тока, умножаем и возвращаем
  // return value * _current_lsb;
  //  return (int16_t)(((val * _current_lsb_int + 2048u) >> 12); // 2048
  //  округление
  uint32_t val = abs(value);
  val = (val * _current_lsb_int + 2048u) >> 12;
  return (int16_t)((value > 0) ? val : -val);
#endif
}

// возвращает милливатты
int32_t INA226::getsPower(void) {
#if defined(__LGT8FX8P__)
  DSC_MUL((uint16_t)voltsec, (int16_t)abs(ampersec)); // voltsec * abs(ampersec)
  DA_INC(500);                                        // + 500
  DA_DIV(1000);                                       // / 1000
  return (int32_t)DA_get_long();
#else
  return ((int32_t)voltsec * abs(ampersec) + 500) / 1000;
#endif
}

// Чтение регистра срабатывания Alert
bool INA226::isAlert(void) {
  return ((readRegister(INA226_REG_MASKENABLE) & INA226_BIT_AFF) ==
          INA226_BIT_AFF);
}

/*
время выборки (накопления сигнала для оцифровки)
INA226_CONV_140US // 140 мкс
INA226_CONV_204US // 204 мкс
INA226_CONV_332US // 332 мкс
INA226_CONV_588US // 588 мкс
INA226_CONV_1100US // 1100 мкс
INA226_CONV_2116US // 2116 мкс
INA226_CONV_4156US // 4156 мкс
INA226_CONV_8244US // 8244 мкс
*/

void INA226::start(void) {
  // множитель для тока // 0,00025 в А // 0.25 в мА // (0.08192f / _shunt  -
  // максимальный ток)
  _current_lsb_int = (uint16_t)((250ul * 4096) / vkr.shunt);
  // расчёт LSB для мощности (см. доку INA226)
  //_power_lsb = _current_lsb * 25;
  writeRegister(INA226_CFG_REG_ADDR, 0x8000); // Принудительный сброс
  // trunc(0.00512f / (_current_lsb * _shunt))
  // Пишем значение в регистр калибровки
  writeRegister(INA226_CAL_REG_ADDR, 2048);

  // writeRegister(INA226_REG_MASKENABLE, INA226_BIT_SOL);  // сигнал Alert
  // сработает при превышении напряжения на шунте 0,081 Вольт. При шунте 0,01 Ом
  // ток срабатывания 0,08192/0,01=8,1А writeRegister(INA226_REG_ALERTLIMIT,
  // 32400);           // Alert - ограничение по максимальному току   //
  // 0,081/0,0000025f   ограничение по напряжению на шунте 32400 * 0.0025 = 81мВ

  setSampleTime(INA226_VBUS, INA226_CONV_588US);    // время выборки напряжения
  setSampleTime(INA226_VSHUNT, INA226_CONV_1100US); // время выборки тока
  // setAveraging(INA226_AVG_X4);                      // усреднение, по
  // умолчанию усреднения нет(1, 4, 16, 64, 128, 256, 512, 1024).
}

// скользящее среднее - сгладить в 64 раз
int32_t INA226::average(int32_t aver, int32_t val) {
  return (((val << 6) - aver) >> 6);
}

void INA226::sample(void) {
  amperms = getCurrent();
  // считаем напряжение с коррекцией по току
#if defined(__LGT8FX8P__)
  voltms = getVoltage();
  DSC_MUL((int16_t)amperms, (uint16_t)vkr.Ohms); // amperms * vkr.Ohms
  voltms -= (int16_t)DA_DIV_get(1000);           //  / 1000
#else
  voltms = getVoltage() - (int16_t)((int32_t)amperms * vkr.Ohms / 1000);
#endif

  _vs += average(_vs, voltms);
  _as += average(_as, amperms);

  _vs_aver += ((float)voltms - _vs_aver) * 0.001;
  _as_aver += ((float)amperms - _as_aver) * 0.001;
}

// преобразование промежуточных средних значений тока и напряжения 
// в реальные значения
void INA226::calc(void) {
  voltsec = (uint16_t)(_vs >> 6);
  ampersec = (int16_t)(_as >> 6);
 
  volt_aver = (uint16_t)(round(_vs_aver));
  curr_aver = (int16_t)(round(_as_aver));
}

// Запись 16-ти битного регистра INA226
void INA226::writeRegister(uint8_t address, uint16_t data) {
  Wire.beginTransmission(_iic_address); // Начинаем передачу
  Wire.write(address);                  // Отправляем адрес
  Wire.write(highByte(data));           // Отправляем старший байт
  Wire.write(lowByte(data));            // Отправляем младший байт
  Wire.endTransmission();               // Заканчиваем передачу
}

// Чтение 16-ти битного регистра INA226
uint16_t INA226::readRegister(uint8_t address) {
  Wire.beginTransmission(_iic_address);       // Начинаем передачу
  Wire.write(address);                        // Отправляем адрес
  Wire.endTransmission();                     // Заканчиваем передачу
  Wire.requestFrom(_iic_address, (uint8_t)2); // Запрашиваем 2 байта
  return Wire.read() << 8 | Wire.read();      // Клеим и возвращаем результат
}

// Проверка присутствия
bool INA226::testConnection(void) {
  Wire.beginTransmission(_iic_address); // Начинаем передачу
  // Сразу заканчиваем, инвертируем результат
  return (bool)!Wire.endTransmission();
}

INA226 ina;
