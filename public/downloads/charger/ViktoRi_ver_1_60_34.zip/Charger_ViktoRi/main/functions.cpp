#include "1_User_Setup.h"
#include "AllFunctions.h"
#include "Battery.h"
#include "Classes.h"
#include "DCDC.h"
#include "Display.h"
#include "INA226int.h"
#include "global.h"
#include "menu_txt.h"
#include "system.h"
#include <GyverIO.h>

// постоянно работающие функции, // опрос датчиков
void sensor_survey(void) {
  butt.Tick(); // опрос кнопок и энкодера

  if (get_ina_flag_sys()) {
    ina.sample();
    // if (bitRead(profil.flags, ACTIVITI)
    // регулировка тока и напряжения
    dcdc.Control();

#if (VOLTIN == 1)
    // check_Q1();     //проверка на то что силовой транзистор пробит
#endif
  }

#if (VOLTIN == 1)
  // замер напряжения БП
  Power_sample();
#endif

#if (SENSTEMP1 == 2)
  // датчик температуры NTC транзистора
  ntc_Q1_sample();
#endif

#if (SENSTEMP2 == 2)
  // датчик температуры NTC аккумулятора
  ntc_akb_sample();
#endif

  if (get_second_flag_sys()) {
    // выполняются раз в секунду
    sysFlagSetBits(FlagsName::SECOND);

#if (VOLTIN == 1)
    // проверить напряжение БП на наличие и на превышение
    Power_check();
#endif

    ina.calc();

#if (SENSTEMP1 > 0)
    // чтение температуры транзистора, вызывать раз в секунду
    temp_Q1_compute();
#endif

#if (SENSTEMP2 > 0)
    // чтение температуры акб, вызывать раз в секунду
    temp_akb_compute();
#endif

#if (FAN > 0)
    fan.control(); //  управение кулером
#endif

#if (POWER == 1)
    Relay(); // функция управления реле подключения к сети 220В
#endif
#if (LOGGER)
    Sout.Serial_out(); // вывод данных в серийный порт
#if (LOGGER == 4)
    Sout.create_advanced(0, 0, 0, 0);
#else
    Sout.create(); // сбросить данные
#endif
#endif
    // экран вывода ошибок
    window_errors();
  }
}

// Хранение
void Storage(void) {
#if (PROTECT_BLOCK)
  Protect::Guard();
#endif

  print_volt_current(profil.storage.voltage,
                     ((int16_t)profil.akb.capacity << 3));
  Delay(3000);

  start_second_usr();
  // цикл работы
  while (bitRead(profil.flags, ACTIVITI)) {

    sensor_survey();

    // прошла секунда
    if (get_second()) {
      // когда напряжение акб снизится ниже напряжения Хранения
      // включить заряд
      if (dcdc.get_pause() == LOW and
          (ina.volt_aver < profil.storage.voltage - 30)) {
        dcdc.start(DCDC_CHARGE);
        dcdc.begin(profil.storage.voltage, ((int16_t)profil.akb.capacity << 3));
      }
#if (PROTECT_BLOCK)
      Protect::Guard();
#endif
      Print_time(get_second_usr(), DISPLAYx - 8, 0); // *Storage 12:10:36*
      setCursory();                                  // *13.10V 6.12A 25C*
      print_volt_current(ina.voltsec, ina.ampersec);
#if (SENSTEMP1 or SENSTEMP2)
      print_tr(); // температура транзистора или акб
#endif

#if (LOGGER > 0)
#if (LOGGER == 4)
      Sout.create_advanced(0, (uint16_t)ina.volt_aver, ina.curr_aver,
                           get_second_usr());
#else
      Sout.create(0, (uint16_t)ina.volt_aver, ina.curr_aver);
#endif
#endif


#if (TIME_LIGHT)
      disp.Light_low();
#endif

    } // прошла секунда

    if (butt.tick == OKHELD or butt.tick == STOPHELD)
      bitClear(profil.flags, ACTIVITI); // завершить работу режима
  } // цикл работы
  dcdc.Off(); // отключить заряд, разряд.
#if (PROTECT_BLOCK)
  Protect::Open(false);
#endif
}

// Буферный режим
void Buffer(void) {
#if (PROTECT_BLOCK)
  Protect::Guard();
#endif

  // переменная для сигнала буферного режима
  uint8_t signal_timer = 0; // время отстчета сигнала буферного режима
  uint8_t signal_time = 60; // период сигнала буферного режима
  // расчет напряжения акб - ниже которого будет подаваться сигнал
  const uint16_t signal_voltage = (bat_volt(profil.akb.type) / 100) * 100;
  const uint16_t signal_critical =
      profil.disch.voltage_end; // bat.Volt(volt_cell_discharge);
  // переменная для подсчета Ампер/часов
  int32_t Ah = 1;

  print_volt_current(profil.buffer.voltage, profil.buffer.current);

#ifdef BUFER_PIN
  // Включить реле нагрузки
  gio::high(BUFER_PIN);
#endif

  Delay(3000);

  dcdc.start(DCDC_CHARGE);
  dcdc.begin(profil.buffer.voltage, profil.buffer.current);
  start_second_usr();

  // цикл работы
  while (bitRead(profil.flags, ACTIVITI)) {

    sensor_survey();

    // прошла секунда
    if (get_second()) {
#if (PROTECT_BLOCK)
      Protect::Guard();
#endif
      // *Bufer   12:10:36*
      // *13.10V 6.12A 25C*
      Print_time(get_second_usr(), DISPLAYx - 8, 0);
      setCursory();
      print_volt_current(ina.voltsec, ina.ampersec);
#if (DISPLAYy == 4)
      print_Ah(Ah);
#endif
#if (SENSTEMP1 or SENSTEMP2)
      print_tr(); // температура транзистора или акб
#endif
#if (SPEAKER > 0)
      // сигнализация о снижении напряжения акб ниже предела (12V)
      if (ina.volt_aver < signal_voltage) {
        if (signal_timer > 0) {
          signal_timer--;
        } else {
          signal_timer = signal_time; // сигнал раз в 60 секунд
          Speaker(300);
        }
      } else {
        signal_timer = 0;
      }
#endif

#ifdef BUFER_PIN
      // если нагрузка подключена и напряжение снизилось менее напряжения
      // разряда то отключить реле нагрузки и включить заряд акб
      if (gio::read(BUFER_PIN) and (ina.volt_aver < signal_critical)) {
        gio::low(BUFER_PIN);
        dcdc.Off();
        dcdc.start(DCDC_CHARGE);
        dcdc.begin(profil.charge.voltage, profil.charge.current);
        Ah = 1;
#if (SPEAKER > 0)
        Speaker(300);
#endif
        // start_second_usr();
      }

      if (!gio::read(BUFER_PIN)) {
        // расчет ампер/часов заряда
        Ah += Calc_AhWh((int32_t)ina.ampersec);
      }
      // если нагрузка отключена и идет заряд акб
      // проверяем напряжение и ток, когда напряжение достигнет
      // напряженя заряда и ток снизится до 0,01С
      // то снизить напряжение до буферного включить реле нагрузки
      if (!gio::read(BUFER_PIN) and
          ((ina.volt_aver > profil.charge.voltage - 30) and
           ina.curr_aver <= ((int16_t)profil.akb.capacity << 3))) {
        dcdc.Off();
        dcdc.start(DCDC_CHARGE);
        dcdc.begin(profil.buffer.voltage, profil.buffer.current);
        gio::high(BUFER_PIN);
#if (SPEAKER > 0)
        Speaker(300);
#endif
        // start_second_usr();
      }
#else
      // если напряжение снизилось менее напряжения разряда акб
      // то подавать сигнал каждые 10 сек
      if (ina.volt_aver <= signal_critical) {
        signal_time = 10;
      } else {
        signal_time = 60;
      }

#endif

#if (LOGGER > 0)
#if (LOGGER == 4)
      Sout.create_advanced(Ah, (uint16_t)ina.volt_aver, ina.curr_aver,
                           get_second_usr());
#else
      Sout.create(Ah, (uint16_t)ina.volt_aver, ina.curr_aver);
#endif
#endif

#if (TIME_LIGHT)
      disp.Light_low();
#endif

    } // прошла секунда

    if (butt.tick == OKHELD or butt.tick == STOPHELD)
      bitClear(profil.flags, ACTIVITI); // завершить работу режима
  } // цикл работы
#ifdef BUFER_PIN
  gio::low(BUFER_PIN); // отключить реле нагрузки
#endif
  dcdc.Off();
#if (PROTECT_BLOCK)
  Protect::Open(false);
#endif
}

#if (POWER == 1)
// функция управления реле подключения к сети 220В. Вызывать раз в секунду
void Relay(void) {
  if (ina.voltsec < VOLT_AKB_RELE_ON and timer_bp == 0) {
    gio::high(POWER_PIN);                   // включить реле
    sysFlagClearBits(FlagsName::RELEY_OFF); // запрещено отключать реле
  } else if (ina.voltsec > VOLT_AKB_RELE_OFF)
    sysFlagSetBits(FlagsName::RELEY_OFF); // разрешено отключать реле

  // отключить БП если не включен ни какой режим и акб отключен.
  if (BitIsClear(profil.flags, ACTIVITI) and ina.voltsec < 2000) {
    if (timer_bp) {
      // сбросить время в секундах при каждом нажатии
      if (butt.tick)
        timer_bp = POW_TIME * 60;

      if (--timer_bp == 1)
        gio::low(POWER_PIN); // отключить реле - зарядник отключится
    } else
      timer_bp = POW_TIME * 60; // задать время в секундах
  } else
    timer_bp = 0;
}

// (true - включить реле, false - отключить реле)
void Relay_on(bool vkl) {
  if (vkl)
    gio::high(POWER_PIN); // включить реле
  else if (sysFlagGetBits(FlagsName::RELEY_OFF))
    gio::low(POWER_PIN); // отключать реле если включен флаг разрешающий
}
#endif

#if (RESIST == 1)
// Функция измерения сопротивления
void Resist(void) {
  if (ina.voltsec < 2000) {
    print_mode(ERROR); // "error"
    Delay(1000);
    return;
  }
#if (PROTECT_BLOCK)
  // открыть защитный транзистор
  Protect::Open(true);
#endif
  uint8_t mode = profil.Regim;
  profil.Regim = Modes::RESISTENSE;
  bitSet(profil.flags, ACTIVITI);
  dcdc.start(DCDC_DISCHARGE);          // старт разряда
  dcdc.Smooth_off(LOW);                // отключить плавный пуск
  dcdc.begin((ina.voltsec >> 1), 800); // задает напряжение и ток разряда
  uint16_t vlt = ina.voltsec;
  uint8_t timer = 60; // время первого замера сек.
  do {
    sensor_survey();
    if (butt.tick == OKHELD or butt.tick == STOPCLICK) {
      dcdc.Off(); // отключить заряд, разряд.
      bitClear(profil.flags, ACTIVITI);
      profil.Regim = mode;
#if (PROTECT_BLOCK)
      Protect::Open(false);
#endif
      return;
    }
    if (get_second()) {
      // если прошла секунда вывод на дисплей
      setCursory();
      print_volt_current(ina.voltsec, abs(ina.ampersec),
                         3); // *12.361V 3.555A  *
      lcd.setCursor(DISPLAYx - 2, 0);
      lcd.print(--timer);
      print_space();
      vlt = ina.voltsec;
      // стабилизация напряжения до 1мВ/сек
      if (difference(vlt, ina.voltsec) <= 1)
        timer = 0;
    }
  } while (timer);
  int16_t I[2]{abs(ina.ampersec), 0}; // сохранить ток
  uint16_t U[2]{ina.voltsec, 0};      // сохранить напряжение
  dcdc.setCur_charge((int16_t)4000);
  Delay(1000);              // ожидание // 3000
  I[1] = abs(ina.ampersec); // сохранить ток
  U[1] = ina.voltsec;       // сохранить напряжение
  dcdc.Off();               // отключить заряд, разряд.
  bitClear(profil.flags, ACTIVITI);
  setCursory();
  print_volt_current(U[1], I[1], 3); // *12.361V 3.554A  *
  ClearStr(4);
  Delay(4000);
  // расчитать внутренее сопротивление аккумулятора
  int16_t curr = I[1] - I[0];
  if (curr and (U[0] > U[1])) {
    float r = ((float)(U[0] - U[1]) / (float)curr);
    // расчет пускового тока
    profil.currentInrush =
        (uint16_t)((1.0 / (float)(U[0] - U[1]) / r) * 1000 + 0.5);
    r *= 1000;  // перевод в миллиОм
    r *= 0.215; // подстроечный коэффициент сопротивления

    profil.resist = (uint16_t)(r * 100);
    setCursory();
    print_resist(r);
    lcd.print(profil.currentInrush);
    lcd.write('A');
    ClearStr(4);
    Delay(7000);
  } else {
    lcd.clear();
    disp.printFromPGM((int)(&menuTxt[6])); // *Resist       *
    lcd.print(F(txt21));                   // "error"
    Delay(2000);
  }
#if (PROTECT_BLOCK)
  Protect::Open(false);
#endif
  profil.Regim = mode;
}
#endif

// функция расчета Ач и Втч
int32_t Calc_AhWh(int32_t i) {
#if defined(__LGT8FX8P__)
  return DSC_DIV_get((int32_t)(i * 5 + 9), (uint16_t)18);
#else
  return (i * 5 + 9) / 18; // эквивалент round(i*0.277777f) с округлением
                           // //return (int32_t)round(i * 0.277777f);
#endif
}

// функции управления модулем защиты
namespace Protect {
// функция включения блокировки модуля защиты в зависимости от напряжения акб
// включает блокировку при напряжении акб менее 5 Вольт и отключает при напр.
// более 6 Вольт
void Guard(void) {
  if (ina.voltsec < 5000)
    gio::high(PROTECT_OPEN_PIN);
  else if (ina.voltsec > 6000)
    gio::low(PROTECT_OPEN_PIN);
}

// #define PROTECT_OPEN_PIN  A0  // принудительно открывает транзистор модуля
// защиты Q4 #define PROTECT_CLOSE_PIN A2  // принудительно закрывает транзистор
// модуля защиты Q4

// принудительно закрыть защитный транзистор - true
// отключить принудительное закрытие защитного транзистора - false
void Close(bool x) {
  if (x)
    gio::high(PROTECT_CLOSE_PIN);
  else
    gio::low(PROTECT_CLOSE_PIN);
}

// подать 12 вольт на транзисор модуля защиты - true
// отключить подачу 12 вольт на транзисор модуля защиты - false
void Open(bool x) {
  if (x)
    gio::high(PROTECT_OPEN_PIN);
  else
    gio::low(PROTECT_OPEN_PIN);
}

} // namespace Protect

// функция задержки (t - милисекунды)
void Delay(uint16_t ms) {
  uint32_t t = millis_sys() + ms;
  do {
    sensor_survey();
  } while ((millis_sys() < t) and !butt.tick);
}

// пауза до нажатия
void pauses(void) {
  do {
    sensor_survey();
  } while (!butt.tick);
}

// расчет напряжения при котором начинается снижение тока заряда
uint16_t Volt_DCur(void) {
  return (profil.charge.voltage + bat_volt(profil.akb.type)) >> 1;
}

#if (KALIBROVKA == 1)
// калибровка падения напряжения при токе нагрузки, напряжения от БП
void Korrect(uint8_t kof) {
  // если выбрана калибровка напряжения от БП и не установлен делитель
  // напряжения на входе то выйти из функции
  if (kof == 1 and VOLTIN == 0)
    return;

#if (TIME_LIGHT)
  disp.Light_high(); // включение подсветки
#endif
  if (kof == 0 or kof == 2) {
    Delay(500);
    while (ina.voltsec < 9000) {
      lcd.clear();
      lcd.print(F(txt11)); //  Подключи АКБ
      lcd.print(F(" 12V"));
      Delay(200);
      if (butt.tick == STOPCLICK or butt.tick == OKCLICK) {
        dcdc.Off();
        return;
      }
    }
    if (kof == 0) {
      bitSet(profil.flags, ACTIVITI);
      dcdc.start(DCDC_DISCHARGE);
      dcdc.begin((ina.voltsec >> 1), 2100);
    }
  }
  lcd.clear();

  bool x = false;
  bool ext = true;
  uint8_t mode = profil.Regim;
  profil.Regim = Modes::KALIBRATION;

  do {
    // установка напряжения
    do {
      // ожидание действий пользователя
      sensor_survey();
      if (kof == 0 and ina.ampersec < -2000)
        // отключить стабилизацию тока
        dcdc.stabilization(LOW);
      if (get_second() or butt.tick) {
        // вывод на дисплей
        switch (kof) {
        case 0:
          setCursorx(); // 0, 0
          print_volt_current(ina.voltsec, ina.ampersec, 3);
          if (!dcdc.get_stabilization()) {
            setCursory(); // *12.365V 3.254А  *
            Write_x(x);   // > or  пробел  // *>80     >55    *
            lcd.print(vkr.Ohms);
            if (vkr.Ohms > 120)
              lcd.write('!');
            print_space();
            lcd.setCursor(8, 1);
            Write_x(!x); // > or  пробел
            print_resist(((float)vkr.shunt / 100));
          }
          break;
#ifdef VKORRECT
#if (VOLTIN == 1)
        case 1:
          // замер напряжения блока питания
          setCursorx();
          print_volt(getPower());
          lcd.write('<');
          lcd.print(vkr.Vref);
          lcd.write('>');
          print_space();
          break;
#endif
#endif
        case 2:
          // замер напряжения акб
          setCursorx();
          print_volt(ina.voltsec, 3);
          lcd.write('<');
          lcd.print(vkr.inaKoof);
          lcd.write('>');
          print_space();
          break;
        }
      }
    } while (!butt.tick);

    switch (butt.tick) {
    case OKCLICK:
      x = !x;
      break;
    case RIGHT:
    case LEFT:
      switch (kof) {
      case 0:
        if (x)
          vkr.Ohms = constrain_my(vkr.Ohms, 0, 255, butt.tick);
        else
          vkr.shunt = constrain_my(vkr.shunt, 10, 11000, butt.tick);
        ina.start();
        break;
#if defined(VKORRECT) and (VOLTIN == 1)
        // референсное напряжение АЦП
      case 1:
        vkr.Vref = constrain_my(vkr.Vref, 500, 1500, butt.tick);
        break;
#endif
      case 2:
        // коэффициент напряжения INA226
        vkr.inaKoof = constrain_my(vkr.inaKoof, 10000, 15000, butt.tick);
        break;
      }
      break;
    case OKHELD:
    case STOPCLICK:
      ext = false;
      break;
    }
  } while (ext);
  dcdc.Off();
  bitClear(profil.flags, ACTIVITI);
  profil.Regim = mode;
  eeSave_vkr();
}

#elif (KALIBROVKA == 2)
// калибровка падения напряжения при токе нагрузки, напряжения от БП
void Korrect(const uint8_t kof) {
  // если выбрана калибровка напряжения от БП и не установлен делитель
  // напряжения на входе то выйти из функции
  if (kof == 1 and VOLTIN == 0)
    return;

#if (TIME_LIGHT)
  disp.Light_high(); // включение подсветки
#endif
  if (kof == 0 or kof == 2) {
    Delay(500);
    while (ina.voltsec < 9000) {
      lcd.clear();
      lcd.print(F(txt111)); //  Подключи БП
      setCursorx();
      lcd.print(F(" >12V 2А"));
      Delay(200);
      if (butt.tick == STOPCLICK or butt.tick == OKCLICK)
        return;
    }
    if (kof == 0)
      gio::high(PWMDCH_PIN); // включить разряд
  }
  lcd.clear();

  bool x = false;
  bool ext = true;
  bitSet(profil.flags, ACTIVITI);

  do {
    // установка напряжения
    do {
      // ожидание действий пользователя
      sensor_survey();
      if (get_second() or butt.tick) {
        // вывод на дисплей
        switch (kof) {
        case 0:
          setCursorx(); // 0, 0
          print_volt_current(ina.voltsec, ina.ampersec, 3);
          setCursory(); // *12.365V 3.254А  *
          Write_x(x);   // > or  пробел  // *>80     >55    *
          lcd.print(vkr.Ohms);
          if (vkr.Ohms > 120)
            lcd.write('!');
          print_space();
          lcd.setCursor(8, 1);
          Write_x(!x); // > or  пробел
          print_resist((float)vkr.shunt / 100);
          break;
#if defined(VKORRECT) and (VOLTIN == 1)
        case 1:
          // замер напряжения блока питания
          setCursorx();
          print_volt(getPower());
          lcd.write('<'); // <
          lcd.print(vkr.Vref);
          lcd.write('>'); // >
          print_space();
          break;
#endif
        case 2:
          // замер напряжения акб
          setCursorx();
          print_volt(ina.voltsec, 3);
          lcd.write('<');
          lcd.print(vkr.inaKoof);
          lcd.write('>');
          print_space();
          break;
        }
      }
    } while (!butt.tick);

    switch (butt.tick) {
    case OKCLICK:
      x = !x;
      break;
    case RIGHT:
    case LEFT:
      switch (kof) {
      case 0:
        if (x)
          vkr.Ohms = constrain_my(vkr.Ohms, 0, 255, butt.tick);
        else
          vkr.shunt = constrain_my(vkr.shunt, 10, 11000, butt.tick);
        ina.start(); // старт замеров INA
        break;
#if defined(VKORRECT) and (VOLTIN == 1)
        // референсное напряжение АЦП
      case 1:
        vkr.Vref = constrain_my(vkr.Vref, 500, 1500, butt.tick);
        break;
#endif
      case 2:
        // замер напряжения акб
        vkr.inaKoof = constrain_my(vkr.inaKoof, 10000, 15000, butt.tick);
        break;
      }
      break;

    case OKHELD:
    case STOPCLICK:
      ext = false;
      break;
    }
  } while (ext);
  gio::low(PWMDCH_PIN); // отключить разряд
  bitClear(profil.flags, ACTIVITI);
  eeSave_vkr();
}
#endif

// Функция ожидания time_charge - минут
void Wait(uint16_t time_min) {
  lcd.clear();
  lcd.print(F(txt16)); // Pause
  start_second_usr();
  do {
    sensor_survey();

    // если прошла секунда вывод на дисплей
    if (get_second()) {
      setCursory();
      print_volt(ina.voltsec);
      lcd.print(time_min);
      lcd.print(F(txt20)); // "мин"
      if (get_second_usr() >= (uint8_t)60) {
        // когда прошла минута
        start_second_usr();
        time_min--;
      }

#if (TIME_LIGHT)
      // отключение подсветки через 3 минуты, если разрешено отключение
      disp.Light_low();
#endif
    }
    //  цикл в минутах или долгово нажатия OK
  } while (time_min and butt.tick != STOPHELD and butt.tick != OKHELD);
}

// Функция завершения заряда
void End(void) {
#if (TIME_LIGHT)
  disp.Light_high(); // включение подсветки
#endif
  lcd.clear();
  lcd.print(regim_end); // вывод причины завершения работы.
  print_space();
  print_mode(MODE); // вывод режима
  setCursory();
  int32_t Ah = 0;
  uint32_t tm = 0;
  switch (profil.Regim) {
  case Modes::CHARGE:
  case Modes::ASYMMETRIC:
    // Заряд
    Ah = profil.charge.stat.ah;
    tm = profil.charge.stat.time;
    break;
  case Modes::CHARGE_ADDCHARGE:
  case Modes::BRANIMIR:
  case Modes::KTCycle:
    // Заряд-Дозаряд , Бранимир, КТЦ
    Ah = profil.charge.stat.ah + profil.add.stat.ah;
    tm = profil.charge.stat.time + profil.add.stat.time;
    break;
  case Modes::ADDCHARGE:
    // Дозаряд
    Ah = profil.add.stat.ah;
    tm = profil.add.stat.time;
    break;
  case Modes::DISCHARGE:
    // Разряд
    Ah = profil.disch.stat.ah;
    tm = profil.disch.stat.time;
    break;
  case Modes::STORAGE:
  case Modes::BUFER:
    // Хранение, Буфер.
    Ah = 0;
    tm = 0;
    break;
  }
  print_Ah(Ah);
#if (DISPLAYx == 16)
  Print_time(tm, DISPLAYx - 5, 1);
#elif (DISPLAYx == 20)
  Print_time(tm, DISPLAYx - 11, 1);
#endif
#if (DISPLAYy == 4)
  lcd.setCursor(0, 2);
  ClearStr(3);
#endif
  regim_end = Reason::begin;
#if (SPEAKER > 0)
  Speaker(1000);
#endif
  Delay(1000);
  pauses();
  lcd.clear();
  Delay(500);
}

// функция выбора Stop/OK. (timer - секунд, время через которое возвращается
// false. Если timer = 0 то возврат из функции по нажатию кнопок/енкодера)
bool Choice(uint8_t second, bool rez) {
  butt.tick = 0;
  do {
    switch (butt.tick) {
    case LEFT:
    case RIGHT:
      rez = !rez;
      break;
    case OKCLICK:
    case STOPCLICK:
      return rez;
      break;
    }
    lcd.setCursor(4, 1);
    lcd.print((rez ? F(txt17) : F(txt19))); // OK / Stop

    do {
      // цикл ожидания действий пользователя
      sensor_survey();
      if (get_second()) {
        lcd.setCursor(DISPLAYx - 2, 1);
        lcd.print(second);
        print_space();
        second--;
      }
    } while (!butt.tick and second);
    // ожидание истечения времени
  } while (second);
  return rez;
}

#if (SPEAKER > 0)
#endif

// функция звукового сигнала (n - время в миллисекундах)
void Speaker(uint16_t n) {
// активный звукового сигнала
#if (SPEAKER == 2)
  gio::high(BUZER_PIN); // включить сигнал
  delay_sys(n);         // подождать n - миллисекунд
  gio::low(BUZER_PIN);  // отключить сигнал

#elif (SPEAKER == 1)
  // пассивный звукового сигнала
  uint32_t t = millis_sys() + n;
  // звуковой сигнал в течении n миллисекунд
  // 2314 - частота 432Гц; 1157 - частота 864Гц; 771 - частота 1296Гц
  while (millis_sys() < t) {
    gio::high(BUZER_PIN);
    delayMicroseconds(300);
    gio::low(BUZER_PIN);
    delayMicroseconds(471);
  }
#endif
  return;
}

// расчет времени заряда
void ChargeTimeCalc(void) {
#if defined(__LGT8FX8P__)
  DSC_MUL((uint16_t)profil.akb.capacity, (uint16_t)1000);
  uint16_t v = DA_DIV_get((uint16_t)profil.charge.current);
#else
  uint16_t v = ((uint32_t)profil.akb.capacity * 1000 / profil.charge.current);
#endif
  v += ((v + 2 - 1) >> 1);
  profil.charge.time = (uint8_t)constrain(v, 1, 48);
}

// вычисление процента заряда
uint8_t Percentage(int16_t curr_min) {
  // миним напряжение (напряжение разряда)
  uint16_t vmin = profil.disch.voltage_end;
  if (ina.volt_aver <= vmin)
    return 0;
  // процент по напряжению
  auto v = map_my(ina.volt_aver, vmin, dcdc.getVolt_charge(), 0, 100);
  // процент по току
  auto c = map_my(ina.curr_aver, curr_min, dcdc.getCur_charge(), 0, 100);
  c >>= 1;
  // процент общий
  uint8_t prc = v - c;
  return constrain(prc, 0, 100);
}

#if (CORRECTCUR and SENSTEMP2)
// контроль температуры Акб
void Control_trAkb(void) {
  if (temp_akb_status) {
    if (sysFlagGetBits(FlagsName::TEMP_AKB)) {
      if (temp_akb > 40)
        sysFlagClearBits(FlagsName::TEMP_AKB);
      else if (profil.akb.type <= Akb_type::PB_GEL and temp_akb < -15)
        sysFlagClearBits(FlagsName::TEMP_AKB);
      else if ((profil.akb.type <= Akb_type::LI_POL or
                profil.akb.type >= Akb_type::NI_CD) and
               temp_akb < 10)
        sysFlagClearBits(FlagsName::TEMP_AKB);
    }

    if (!sysFlagGetBits(FlagsName::TEMP_AKB)) {
      dcdc.Off();
#if (TIME_LIGHT)
      disp.Light_high();
#endif
      lcd.clear();
      lcd.print(F(txt9)); // "Temp akb:"
#if (SPEAKER > 0)
      Speaker(300);
#endif
      uint32_t sek = 0;
      do {
        sensor_survey();
        if (butt.tick == OKHELD or butt.tick == STOPHELD) {
          sysFlagSetBits(FlagsName::TEMP_AKB);
          return;
        }
        if (millis_sys() - sek >= 3000) {
          sek = millis_sys();
          lcd.setCursor(9, 0);
          lcd.print(temp_akb);
          print_space();
          setCursory();
          print_volt_current(ina.voltsec, ina.ampersec, 3);

          if (temp_akb < 37) {
            if (profil.akb.type <= Akb_type::PB_GEL and temp_akb > -14)
              sysFlagSetBits(FlagsName::TEMP_AKB);
            else if ((profil.akb.type <= Akb_type::LI_POL or
                      profil.akb.type >= Akb_type::NI_CD) and
                     temp_akb > 11)
              sysFlagSetBits(FlagsName::TEMP_AKB);
            // включить заряд
            dcdc.pause(sysFlagGetBits(FlagsName::TEMP_AKB));
          }
        }
        // цикл выполняется пока температура АКБ не пришла в норму
      } while (!sysFlagGetBits(FlagsName::TEMP_AKB));
      lcd.clear();
#if (SPEAKER > 0)
      Speaker(300);
#endif
    }
  } else {
    sysFlagSetBits(FlagsName::TEMP_AKB);
  }
}
#endif

#if (VOLTIN == 1)
// проверка на то что силовой транзистор пробит
void check_Q1(void) {
  auto vt = difference(ina.voltms, getPower());
  if ((abs(vt) < 100) and abs(ina.amperms) > 500 and dcdc.getTok() == 0) {
#if (TIME_LIGHT)
    disp.Light_high(); // включение подсветки
#endif
    dcdc.Off();
#if (PROTECT_LOCK == 1)
    // принудительно закрыть защитный транзистор
    Protect::Close(true);
#endif
#if (POWER == 1)
    gio::low(POWER_PIN); // отключить сеть 220В
#endif

    eepSavedStruct(); // сохранить настройки
    lcd.clear();
    lcd.print(F(txt24)); //"!!-BROKEN Q1-!!"

    pauses();

    eepSavedStruct(); // сохранить настройки
#if (PROTECT_LOCK == 1)
    // отключить - принудительно закрыть защитный транзистор
    Protect::Close(false);
#endif
#if (POWER == 1)
    Relay_on(true); // включить сеть 220В
#endif
    lcd.clear();
  }
}
#endif

/*
ШИМ на выводах 9 и 10
9 бит, 31 250 Гц
TCCR1A = TCCR1A & 0xe0 | 2;
TCCR1B = TCCR1B & 0xe0 | 0x09;

*/

// функция блока питания
/*
Вызывается из меню на экране датчиков, удержанием кнопки ПУСК.


*/
void BP_vvcc(void) {
  uint16_t bp_volt = BP_volt; // начальное напряжение БП
  int16_t bp_curr = BP_curr;  // начальный ток БП
  bool x = true;              // изменение напряжения или тока

#if (PROTECT_BLOCK)
  // открыть защитный транзистор
  Protect::Open(true);
#endif
  lcd.clear();
  lcd.print(F(txt18));
  Delay(2000);
  lcd.clear();
  bitSet(profil.flags, ACTIVITI);
  dcdc.start(DCDC_CHARGE);
  dcdc.begin(bp_volt, bp_curr);
  uint8_t mode = profil.Regim;
  profil.Regim = Modes::POWEROUT;
  start_second_usr();
  do {
    sensor_survey();

    if (butt.tick) {
      // если кнопка нажата
      // производится корректировка напряжения и тока заряда
      switch (butt.tick) {
      case RIGHT:
      case LEFT:
        
        if (x) {
          // изменение напряжения
          bp_volt = volt_step(bp_volt, butt.tick);
          dcdc.setVolt_charge(bp_volt);
        } else {
          // изменение тока
          bp_curr = constrain_my(bp_curr, CUR_CHARGE_MIN, CURRMAXINT,
                                 butt.tick * STEP_CURR);
          dcdc.setCur_charge(bp_curr);                             
        }
        break;        
      case OKCLICK:
        x = !x;
        break;
      case STOPHELD:
      case OKHELD:
        dcdc.Off();
        bitClear(profil.flags, ACTIVITI);
        lcd.clear();
#if (PROTECT_BLOCK)
        // отключить - принудительная блокировка модуля защиты
        Protect::Open(false);
#endif
        break;
      }
    }

    // если прошла секунда или кнопки/энкодер
    if (get_second() or butt.tick) {
      // вывод на дисплей
      // первая строка
      setCursorx();
      print_volt_current(ina.voltsec, ina.ampersec, 3); // напряжение и ток

      //  вторая строка
      setCursory();
      Write_x(x); // > or  пробел
      lcd.print(bp_volt);
      print_space();
      lcd.setCursor(8, 1);
      Write_x(!x); // > or  пробел
      lcd.print(bp_curr);
      print_space();
#if (DISPLAYy == 4)
      // третья строка
      lcd.setCursor(0, 2);
      print_tr(); // температура транзистора или акб
#endif
      if (butt.tick == 0) {
#if (TIME_LIGHT)
        disp.Light_low();
#endif

#if (LOGGER > 0)
#if (LOGGER == 4)
        Sout.create_advanced(0, (uint16_t)ina.volt_aver, ina.curr_aver,
                             get_second_usr());
#else
        Sout.create(0, (uint16_t)ina.volt_aver, ina.curr_aver);
#endif
#endif

      }
    }
  } while (bitRead(profil.flags, ACTIVITI));
  profil.Regim = mode;
  stop_second_usr();
  lcd.clear();
}
