#include "Menu.h"
#include "global.h"
#include "Classes.h"
#include "INA226int.h"
#include "Display.h"
#include "menu_txt.h"
#include "1_User_Setup.h"
#include "AllFunctions.h"
#include "Battery.h"
#include <EEPROM.h>


// вывод пунктов настроек
void Settings_point(uint8_t point, bool edit, int16_t x) {

  bool st = true;
  // изменение настроек
  if (profil.akb.type >= Akb_type::LI_ION) {
    switch (point) {
      case 7:   // напряжение дозаряда
      case 8:   // ток дозаряда
      case 9:   // минимальный ток дозаряда
      case 10:  // время дозаряда, часы
      case 19:  // режим качели
        st = false;
        break;
    }
  }

  if (!edit) {
    // отображение настроек
    if (st) {
      switch (point) {
        case 0:
          print_volt(profil.charge.voltage);  // напряжение заряда
          break;
        case 1:
          print_current(profil.charge.current);  // ток заряда
          break;
        case 2:
          print_volt(profil.charge.voltage_decr_cur);  //     Напряжение при котором начинает снижаться ток
          break;
        case 3:
          print_current(profil.charge.current_end);  // минимальный ток заряда
          break;
        case 4:
          print_hour(profil.charge.time);  // время заряда          
          break;
        case 5:
          lcd.print(profil.asym.period_charge);  // Период заряда
          lcd.write('s');
          break;
        case 6:
          lcd.print(profil.asym.period_discharge);  // Период разряда
          lcd.write('s');
          break;
        case 7:
          print_volt(profil.add.voltage);  // напряжение дозаряда
          break;
        case 8:
          print_current(profil.add.current);  // ток дозаряда
          break;
        case 9:
          print_current(profil.add.current_min);  // минимальный ток дозаряда
          break;
        case 10:
          print_hour(profil.add.time);  // время дозаряда 
          break;
        case 11:
          print_volt(profil.disch.voltage_end);  // напряжение разряда
          break;
        case 12:
          print_current(profil.disch.current);  // ток разряда
          break;
        case 13:
          print_current(profil.disch.current_end);  // ток завершения разряда
          break;
        case 14:
          print_volt(profil.buffer.voltage);  // напряжение буферный режим
          break;
        case 15:
          print_volt(profil.storage.voltage);  // напряжение режима хранения
          break;
        case 16:  // Предзаряд
          PrintOnOff(bitRead(profil.flags, PRECHAR));
          break;
        case 17:
          print_volt(profil.charge.voltage_pre);  // напряжение предзаряда
          break;
        case 18:
          print_current(profil.charge.current_pre);  // ток предзаряда
          break;
        case 19:
          PrintOnOff(bitRead(profil.flags, OSCIL));  // режим качели
          break;
        case 20:
          lcd.print(Round);  // колицество циклов
          break;
      }
    }
  } else {
    // изменение настроек
    if (st) {
      switch (point) {
        case 0:
          // напряжение заряда
          profil.charge.voltage = volt_step(profil.charge.voltage, x);
          print_volt(profil.charge.voltage);
          break;
        case 1:
          // ток заряда
          profil.charge.current = constrain_my(profil.charge.current, CUR_CHARGE_MIN, CURRMAXINT - 500, x * STEP_CURR);
          print_current(profil.charge.current);
          ChargeTimeCalc();  // расчет времени заряда
          break;
        case 2:
          //  Напряжение при котором начинает снижаться ток
          profil.charge.voltage_decr_cur = constrain_my(profil.charge.voltage_decr_cur, STEP_VOLT * 10, profil.charge.voltage, x * STEP_VOLT);
          print_volt(profil.charge.voltage_decr_cur);
          break;
        case 3:
          // минимальный ток заряда
          profil.charge.current_end = constrain_my(profil.charge.current_end, CURMIN, profil.charge.current, x * 10);
          print_current(profil.charge.current_end);
          break;
        case 4:
          // время заряда
          profil.charge.time = constrain_my(profil.charge.time, 1, 255, x);
          print_hour(profil.charge.time);
          break;
        case 5:
          // Период заряда
          profil.asym.period_charge = constrain_my(profil.asym.period_charge, 1, 65535, x);
          lcd.print(profil.asym.period_charge);
          break;
        case 6:
          // Период разряда
          profil.asym.period_discharge = constrain_my(profil.asym.period_discharge, 1, 65535, x);
          lcd.print(profil.asym.period_discharge);
          break;
        case 7:
          // напряжение дозаряда
          profil.add.voltage = volt_step(profil.add.voltage, x);
          print_volt(profil.add.voltage);
          break;
        case 8:
          // ток дозаряда
          profil.add.current = constrain_my(profil.add.current, CUR_CHARGE_MIN, CURRMAXINT - 500, x * STEP_CURR_ADD);
          print_current(profil.add.current);
          break;
        case 9:
          // минимальный ток дозаряда
          profil.add.current_min = constrain_my(profil.add.current_min, CUR_CHARGE_MIN, profil.add.current, x * 10);
          print_current(profil.add.current_min);
          break;
        case 10:
          // время дозаряда, часы
          profil.add.time = constrain_my(profil.add.time, 1, 252, x);
          print_hour(profil.add.time);
          break;
        case 11:
          // напряжение разряда
          profil.disch.voltage_end = volt_step(profil.disch.voltage_end, x);
          print_volt(profil.disch.voltage_end);
          break;
        case 12:
          // ток разряда
          profil.disch.current = constrain_my(profil.disch.current, STEP_CURR, CURRMAXINT - 500, x * STEP_CURR);
          print_current(profil.disch.current);
          profil.disch.current_end = profil.disch.current;  // ток завершения разряда
          break;
        case 13:
          // ток завершения разряда
          profil.disch.current_end = constrain_my(profil.disch.current_end, 20, profil.disch.current, x * 10);
          print_current(profil.disch.current_end);
          break;
        case 14:
          // напряжение буферного режима
          profil.buffer.voltage = volt_step(profil.buffer.voltage, x);
          print_volt(profil.buffer.voltage);
          break;
        case 15:
          // напряжение режима Хранение
          profil.storage.voltage = volt_step(profil.storage.voltage, x);
          print_volt(profil.storage.voltage);
          break;
        case 16:
          // Предзаряд
          if (x) InvBit(profil.flags, PRECHAR);
          PrintOnOff(bitRead(profil.flags, PRECHAR));
          break;
        case 17:
          // напряжение предзаряда
          profil.charge.voltage_pre = volt_step(profil.charge.voltage_pre, x);
          print_volt(profil.charge.voltage_pre);
          break;
        case 18:
          // ток предзаряда
          profil.charge.current_pre = constrain_my(profil.charge.current_pre, CUR_CHARGE_MIN, profil.charge.current, x * 10);
          print_current(profil.charge.current_pre);
          break;
        case 19:
          // режим качели
          if (x) InvBit(profil.flags, OSCIL);  // инвертировать бит
          PrintOnOff(bitRead(profil.flags, OSCIL));
          break;
        case 20:
          // цикл
          Round = constrain_my(Round, 1, 5, x);
          lcd.print(Round);
          break;
#if (SERVICE == 1)
        case 21:
          // системные пaраметры на 3 нажатия
          if (butt.Click3()) {
            serviceparam();  // изменение системныx параметров
            lcd.clear();
          }
          break;
#endif          
        case 22:
          // сброс всех настроек
          Reset_settings(0);  // сброс настроек по умолчанию
          lcd.clear();
          break;
      }
    }
    ClearStr(10);  // очистить поле
  }
}

// печать статистики
void Statistics_print(int i, uint32_t time_i, int32_t Ah, int32_t Wh) {
  disp.printFromPGM(i);
#if (DISPLAYx == 16)
  Print_time(time_i, DISPLAYx - 5, 0);
#else
  Print_time(time_i, DISPLAYx - 8, 0);
#endif
  setCursory();
  print_Ah(Ah);
  print_Wh(Wh);
}

// вывод статистики
void Statistics_point(uint8_t point) {
  switch (point) {
    case 0:
      // Заряд
      // *Zaryad     24:42*
      // *55.36Ah 366.35Wh*
      Statistics_print((int)(&modeTxt[Modes::CHARGE]), profil.charge.stat.time, profil.charge.stat.ah, profil.charge.stat.wh);
      break;
    case 1:
      //  Дозаряд
      // *Add charge 24:42*
      // *55.36Ah 366.35Wh*
      Statistics_print((int)(&modeTxt[Modes::ADDCHARGE]), profil.add.stat.time, profil.add.stat.ah, profil.add.stat.wh);
      break;
    case 2:
      // Разряд
      // *Razryad    24:42*
      // *55.36Ah 366.35Wh*
      Statistics_print((int)(&modeTxt[Modes::DISCHARGE]), profil.disch.stat.time, profil.disch.stat.ah, profil.disch.stat.wh);
      break;
    case 3:
      // Внутреннее сопротивление
      // *Resist       *
      // *20.3mOm 520A *
      disp.printFromPGM((int)(&menuTxt[6]));  // *Resist       *
      setCursory();
      print_resist((float)profil.resist / 100); 
      lcd.print(profil.currentInrush); 
      lcd.write('A');
      break;
    default:
      // вывод значений емкости КТЦ
      {
        // архив Ah_discharge, Wh_discharge, Ah_charge, Wh_charge,
        int32_t KTC[4] = { 0 };  
        uint16_t m = Round;  // считать количество циклов в переменную
        m -= (point - 4);
#if defined(__LGT8FX8P__)
        // считать из памяти значения разряда, заряда roundi-цикла КТЦ
        //  lgt_eeprom_read_block(((uint8_t *)&KTC), ((m << 4) - 16 + MEM_KTC), sizeof(KTC));  
        lgt_eeprom_readSWM((((uint16_t)m << 4) - 16 + MEM_KTC),
                         ((uint32_t *)&KTC), (uint16_t)(sizeof(KTC) / sizeof(uint32_t)));
#else
        // считать из памяти значения разряда, заряда m-цикла КТЦ
        EEPROM.get(((m << 4) - 16 + MEM_KTC), KTC);  
#endif
        lcd.print(point - 3); // 1
        lcd.print(F("D:"));   // 1D:
        print_Ah(KTC[0]);     // 1D:65.3Ah
        print_Wh(KTC[1]);     // 1D:65.3Ah 255Wh
        setCursory();
        lcd.print(point - 3); // 1
        lcd.print(F("C:"));   // 1C:
        print_Ah(KTC[2]);     // 1C:65.3Ah
        print_Wh(KTC[3]);     // 1C:65.3Ah 255Wh
        break;
      }
  }
}

/*
*                *
------------------
*1D:65.3Ah 255Wh *
*1C:66.4AH 257Wh *
------------------
*/
