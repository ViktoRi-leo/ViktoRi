#include "system.h"

// #include <avr/interrupt.h>
// #include <avr/io.h>
// #include <stdint.h>

// Определяем коэффициент для расчета микросекунд
#if (F_CPU == 32000000L)
#define MICROS_CLOCK (uint8_t)clockCyclesToMicroseconds(256)
#elif (F_CPU == 16000000L)
#define MICROS_CLOCK (uint8_t)clockCyclesToMicroseconds(64)
#else
#error "CPU frequency not supported"
#endif

volatile unsigned long t0_millis_my = 0; // счетчик миллисекунд
volatile unsigned int t0_second_my = 0;  // счетчик 1000 миллисекунд (1 сек)
volatile bool second_flag_sys = false;   // флаг секунды
// счетчик секунд пользователя
volatile unsigned long t0_second_usr = 0;
// флаг включения/отключения счета секунд пользователя
volatile bool second_flag_usr = false;
volatile uint8_t ina_mc = 0;
// флаг 2мс - отдельный флаг для считывания данных с INA226
// и работы функции ШИМ (DCDC) контроллера
volatile bool ina_flag = false;
// счетчик delay
volatile uint16_t delay_count = 0;

// Таймер 0 в режиме CTC (Count-to-Compare), генерирует прерывание каждые 1 мс
void timer0_init() {
  cli();
#if (F_CPU == 32000000L)
  TCCR0B = _BV(CS02);   // Установим предделитель 256
  TCCR0A = _BV(WGM01);  // Режим CTC, сравнение OCR0A (Output Compare Register A)
  // Значение OCR0A рассчитывается для интервала примерно 1 мс при частоте CPU 32 MHz
  OCR0A = 124;           // Подобранное значение для 1 мс
  TIMSK0 = _BV(OCIE0A);  // Разрешаем прерывание при совпадении значения OCR0A
#elif (F_CPU == 16000000L)
  TCCR0B = (_BV(CS01) | _BV(CS00));  // Выбираем предделитель 64
  TCCR0A = _BV(WGM01);               // Режим CTC, сравнение OCR0A (Output Compare Register A)
  // Установим значение сравнения OCR0A для интервала примерно 1 мс при частоте CPU 16 MHz
  OCR0A = 249;           // Formula: (F_CPU / prescaler * desired frequency) - 1
  TIMSK0 = _BV(OCIE0A);  // Разрешаем прерывание при совпадении значения OCR0A
#else
#error "CPU frequency not supported"
#endif
  sei();
}

/*
void timer0_init(void) {
  cli();
  TCCR0B = (F_CPU == 32000000L) ? _BV(CS02) : (_BV(CS01) | _BV(CS00));
  TCCR0A = _BV(WGM01);
  OCR0A = (F_CPU == 32000000L) ? 124 : 249;
  TIMSK0 = _BV(OCIE0A);
  sei();
}
*/

// Прерывание Timer0 (обработчик события)
// код обработки события (каждую 1 мс)
ISR(TIMER0_COMPA_vect) {
  t0_millis_my++; // счет миллисекунд
  // отсчет 1 секунды
  if (++t0_second_my >= 1000) {
    t0_second_my = 0;
    second_flag_sys = true; // флаг 1 секунды
    if (second_flag_usr)
      t0_second_usr++; // счет секунд пользователя
  }

  if (delay_count > 0) delay_count--;

  // отдельный флаг для считывания данных с INA226
  // и работы функции ШИМ (DCDC) контроллера
  if (!ina_flag) {
    if (++ina_mc >= 2) {
      ina_mc = 0;
      ina_flag = true;
    }
  }
}

unsigned long millis_sys(void) {
  uint8_t oldSREG = SREG;
  cli();
  unsigned long m = t0_millis_my;
  SREG = oldSREG;
  return m;
}

unsigned long micros_sys(void) {
  uint8_t oldSREG = SREG;
  cli();
  uint8_t t = TCNT0;
  unsigned long m = t0_millis_my;
  SREG = oldSREG;
  return (unsigned long)(((m << 8) + t) * MICROS_CLOCK);
}

/*
// задержка в миллисекундах
void delay_sys(uint16_t ms) {
  unsigned long end = millis_sys() + ms;
  while (millis_sys() < end) { _NOP(); }
}
*/

// задержка в миллисекундах
void delay_sys(uint16_t ms) {
  delay_count = ms;
  while (delay_count) { _NOP(); }
}
  

/*
// вернуть флаг 2мс
bool get_ina_flag_sys(void) {
  uint8_t oldSREG = SREG;
  cli();
  bool result = ina_flag;
  ina_flag = false;
  SREG = oldSREG;
  return result;
}
*/

// вернуть флаг 2мс
bool get_ina_flag_sys(void) {
  bool ina = false;
  uint8_t oldSREG = SREG;
  cli();
  if (ina_flag) {
    ina_flag = false;
    ina = true;
  }
  SREG = oldSREG;
  return ina;
}
/*
// вернуть флаг 1 секунды
bool get_second_flag_sys(void) {
  uint8_t oldSREG = SREG;
  cli();
  bool result = second_flag_sys;
  second_flag_sys = false;
  SREG = oldSREG;
  return result;
}
*/
// вернуть флаг 1 секунды
bool get_second_flag_sys(void) {
  bool sec = false;
  uint8_t oldSREG = SREG;
  cli();
  if (second_flag_sys) {
    second_flag_sys = false;
    sec = true;
  }
  SREG = oldSREG;
  return sec;
}

// сброс счетчика секунды
void secondReset(void) {
  uint8_t oldSREG = SREG;
  cli();
  t0_second_my = 0;
  second_flag_sys = false;
  SREG = oldSREG;
}

// счет секунд пользователя
unsigned long get_second_usr(void) {
  uint8_t oldSREG = SREG;
  cli();
  unsigned long m = t0_second_usr;
  SREG = oldSREG;
  return m;
}

// сбросить и запустить счет секунд пользователя
void start_second_usr(void) {
  uint8_t oldSREG = SREG;
  cli();
  second_flag_usr = true;
  t0_second_usr = 0;
  SREG = oldSREG;
}

// остановить и сбросить счет секунд пользователя
void stop_second_usr(void) {
  uint8_t oldSREG = SREG;
  cli();
  second_flag_usr = false;
  t0_second_usr = 0;
  SREG = oldSREG;
}

// пауза счета секунд пользователя
void pause_second_usr(bool pause) { second_flag_usr = pause; }

// включить/отключить вывод сигнала 500 Гц
void Timer0_outputPin6(bool state) {
  if (state)
    TCCR0A |= (1 << COM0A0);
  else
    TCCR0A &= ~(1 << COM0A0);
}
