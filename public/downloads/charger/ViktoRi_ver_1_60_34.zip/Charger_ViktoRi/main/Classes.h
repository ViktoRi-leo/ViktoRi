// #pragma once

#include <Arduino.h>

/*======== АЦП ========*/

void ADC_begin(void);

/*======== замер напряжения БП ========*/

void Power_begin(void);

void Power_sample(void);

uint16_t getPower(void);

void Power_check(void);


/*======== Температура транзистора и акб ========*/

// Температура транзистора
extern int8_t temp_Q1;
// Температура аккумулятора
extern int8_t temp_akb;
// Статус аккумулятора
extern bool temp_akb_status;

/*======== Датчики температуры DS18B20 ========*/
bool temp_Q1_begin(void);

bool temp_akb_begin(void);

/*======== Чтение данных с датчиков температуры NTC (вызывать совместно с INA и dcdc) ========*/
// считать данные с датчика NTC транзистора Q1
void ntc_Q1_sample(void);

// считать данные с датчика NTC транзистора акб
void ntc_akb_sample(void);

/*======== Расчет (NTC), считывание (DS18B20) реальной температуры ========*/

// чтение температуры транзистора, вызывать раз в секунду
void temp_Q1_compute(void);

// чтение температуры акб, вызывать раз в секунду
void temp_akb_compute(void);


/*======== класс управления кулером ========*/

class Cooler {
public:
  // Cooler(void) {}

  // инициализация
  void begin(void);

  bool onse;
  // принудительно включить/выключить кулер
  void ONonse(bool x);

  void control(void);

private:
  uint8_t _kul;  // значение ШИМ кулера
  int16_t _curfan[3];
  enum : uint8_t {
    curfanOn,
    curfanOff,
    curfanMax
  };
};

extern Cooler fan;


//int16_t _curfanOn;   // значение тока в Амперах при котором включается вентилятор. (до 25,5А) define в 2_menu.h
//int16_t _curfanOff;  // значение тока в Амперах при котором отключается вентилятор. (до 25,5А)
//int16_t _curfanMax;  // значение тока в Амперах  для максимальных оборотов вентилятора ШИМ. (до 25,5А)


/*======== Энкодер, кнопки ========*/

// настройка команд энкодера и кнопок
#define LEFT -1
#define RIGHT 1
#define OKCLICK 16
#define OKHELD 12
#define STOPCLICK 36
#define STOPHELD 22
#define PLUSHELD 32
#define MINUSHELD 42

class Enbutt {
public:
  // Enbutt(void){};

  int8_t tick;
  // функция опрашивает энкодер и кнопки.
  void Tick(void);

  // функция проверяет три клика энкодера или ОК
  bool Click3(void);
};
extern Enbutt butt;


/*======== отправка значений в сетевой порт ========*/

// инициализация серийного порта
void serial_begin(void);

#pragma pack(push, 1)
  struct Log_get {
    uint8_t start_send;  //маркер старта
    uint8_t len_send;    //длина посылки
    uint8_t cod_send;    //код данных

    uint16_t volt;  // 1 напряжение на АКБ (милливольт)
    int16_t amper;  // 2 ток АКБ (миллиампер)
    int32_t Achas;  // 5 Полученная_отданная емкость АКБ в Ач

    uint16_t volt_in;  // 4 напряжение от БП (милливольт)
    int8_t tQ1;        // 3 Температура на Q1 (градусы)
    int8_t tAkb;       // 6 Температура АКБ (градусы)
    uint8_t crc;       //контролная сумма
  };
#pragma pack(pop)

// Расширенный лог (LOGGER == 4) 30 байт
#pragma pack(push, 1)
  struct Log_get_advanced {
    uint8_t start_send;  // маркер старта ":" (0x3A)
    uint8_t cod_send;    // код данных '4'

    uint16_t volt;     // напряжение АКБ (мВ)
    int16_t amper;     // ток АКБ (мА)
    int32_t Achas;     // емкость заряда А/ч
    uint16_t volt_in;  // напряжение БП (мВ)
    int8_t tQ1;        // температура транзистора
    int8_t tAkb;       // температура АКБ

    // Дополнительные параметры
    uint8_t mode;           // индекс режима работы (0-8)
    uint8_t type_akb;       // индекс типа АКБ (0-8)
    uint8_t capacity;       // емкость АКБ (Ач)
    uint8_t active_flag;    // устройство в работе (0/1)
    uint8_t round_current;  // текущий круг/цикл
    uint8_t profil;         // номер активного профиля (0-9)

    uint32_t time_charge;  // время с начала зарядки (сек)
    int32_t Wh_charge;     // энергия заряда (Вт/ч)
    uint8_t regim_end;     // причина завершения (0-5)

    uint8_t crc;  // контрольная сумма
  };
#pragma pack(pop)

class Serial_Out {
public:
  // Serial_Out(){}

  // формируем основные данные
  void create(int32_t Achas = 0, uint16_t volt = 0, int16_t amper = 0);

  // Расширенные данные LOGGER = 4
  void create_advanced(int32_t Achas = 0, uint16_t volt = 0, int16_t amper = 0, uint32_t time_current = 0);

  // Вывод логов в сетевой порт. Вызывать постоянно раз в секунду
  void Serial_out(void);

private:
  uint8_t _tm = 2;

  Log_get send_str{ ':', sizeof(Log_get) - 1, '1', 0, 0, 0, 0, 0, 0, 0 };
  uint8_t *ptr = ((uint8_t *)&send_str);

  Log_get_advanced send_str_adv{ ':', '4', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
  uint8_t *ptr_adv = ((uint8_t *)&send_str_adv);

  void serial_print(float x, uint8_t y);

  float fl(float y);
  uint32_t _time = 0;

  void serial_print(int32_t x);
};

#if (LOGGER > 0)
extern Serial_Out Sout;
#endif

// библиотека для работы с ЦАП MCP4725
// просто отправляет значение 0-4095 напряжения в MCP4725
class MCP4725 {
public:
  // инициализация
  MCP4725(uint8_t addr)
    : _address(addr) {}

  // Запись 16-ти битного регистра MCP4725
  void setVoltage(uint16_t data);

  // Проверка присутствия
  bool testConnection(void);

private:
  const uint8_t _address;
};

extern MCP4725 dac;
