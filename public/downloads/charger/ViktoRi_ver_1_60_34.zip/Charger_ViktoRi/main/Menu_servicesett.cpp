#include "1_User_Setup.h"
#include "AllFunctions.h"
#include "Classes.h"
#include "Display.h"
#include "Menu.h"
#include "global.h"
#include "menu_txt.h"
#include <EEPROM.h>

#if (SERVICE == 1)
// изменение сервисных параметров
void serviceparam(void) {
  lcd.clear();
  // сервисные параметры зарядника
  uint8_t service[SETTINGS_AMOUNT + 1];
#if defined(__LGT8FX8P__)
  // lgt_eeprom_read_block(((uint8_t *)&service), MEM_SERV, sizeof(service));
  lgt_eeprom_readSWM((uint16_t)MEM_SERV, ((uint32_t*)&service), (uint16_t)4);
#else
  EEPROM.get((int)MEM_SERV, service);
#endif
  uint8_t arrowPos = 0;  // номер пункта меню
  bool controlState = 0; // клик
  int8_t screenPos = 0;  // номер "экрана"
  int8_t lastScreen = 0; // предыдущий номер "экрана"
  bool ext = true;
  do {
    screenPos = arrowPos / DISPLAYy; // ищем номер экрана (0..3 - 0, 4..7 - 1)
    if (lastScreen != screenPos)
      lcd.clear(); // если экран сменился - очищаем
    lastScreen = screenPos;
    // для всех строк
    for (byte i = 0; i < DISPLAYy; i++) {
      lcd.setCursor(0, i); // курсор в начало
      // если курсор находится на выбранной строке
      int8_t arr = DISPLAYy * screenPos + i;
      // рисуем стрелку или пробел
      lcd.write((arrowPos == arr) ? (controlState ? '>' : 126) : ' ');
      // если пункты меню закончились, покидаем цикл for
      if (arr == SETTINGS_AMOUNT)
        break;
      // выводим имя и значение пункта меню
      disp.printFromPGM((int)(&servicc[arr]));
      lcd.print(F(": "));
      lcd.print(service[arr]);
      print_space();
    }
    pauses(); // ожидание действий пользователя

    switch (butt.tick) {
    case RIGHT:
    case LEFT:
      if (!controlState) {
        // двигаем курсор // ограничиваем
        arrowPos = constrain_my(arrowPos, 0, SETTINGS_AMOUNT - 1, butt.tick);
      } else {
        switch (arrowPos) {
        case FANMODE:
          // выбор режима работы кулера
          service[arrowPos] = constrain_my(service[arrowPos], 0, 2, butt.tick);
          break;
        case CURRMAX: {
          uint8_t cur = (uint8_t)(81920 / vkr.shunt);
          // установка ограничения максимального тока. Не может
          // быть больше чем рассчетное значение с шунтом.
          service[arrowPos] =
              constrain_my(service[arrowPos], 1, cur, butt.tick);
        } break;
        case FREQCHARGE:
        case FREQDISCHAR:
          // изменение частоты заряда
          // изменение частоты разряда
          service[arrowPos] = constrain_my(service[arrowPos], 0, 7, butt.tick);
          break;
        case INAVKOOFV:
          break;
        default:
          service[arrowPos] =
              constrain_my(service[arrowPos], 0, 255, butt.tick);
          break;
        }
      }
      break;
    case OKCLICK:
      // двигать курсор / изменять данныые
      controlState = !controlState;
      break;
    case STOPCLICK:
    case OKHELD:
      // выйти из цикла
      ext = false;
      break;
    }
  } while (ext);
  lcd.clear();
  print_mode(SETTING);
  lcd.print(F(txt3));
  lcd.write('?');
  if (Choice(30, false)) {
#if defined(__LGT8FX8P__)
   // lgt_eeprom_update_block(((uint8_t *)&service), MEM_SERV, sizeof(service));
    lgt_eeprom_writeSWM((uint16_t)MEM_SERV, ((uint32_t*)&service), (uint16_t)4);
#else
    EEPROM.put((int)MEM_SERV, service);
#endif
    resetFunc();
  }
}
#endif
