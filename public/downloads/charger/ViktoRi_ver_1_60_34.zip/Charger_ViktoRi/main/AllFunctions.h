#include <Arduino.h>

// опрос датчиков
void sensor_survey(void);
// Хранение
void Storage(void);
// Буферный режим
void Buffer(void);
// калибровка
void Korrect(uint8_t kof);

// функции сброса настроек
void Reset_settings(uint8_t sett);
void Res_mem_char(void);
void Res_mem_dischar(void);
void Res_ktc(void);
// сброс настроек при первой прошивке МК
void first_firmware(void);

// режим БП
void BP_vvcc(void);
// Функция измерения сопротивления
void Resist(void);

// ожидание
void Delay(uint16_t t);
// пауза
void pauses(void);
// расчет напряжения при котором начинается снижение тока заряда
uint16_t Volt_DCur(void);
// функция расчета Ач и Втч
int32_t Calc_AhWh(int32_t i);
// Функция ожидания
void Wait(uint16_t time_charge);
// Функция завершения заряда
void End(void);
// функция выбора Stop/OK.
bool Choice(uint8_t secund, bool rez);
void Speaker(uint16_t n);
// расчет времени заряда
void ChargeTimeCalc(void);
// вычисление процента заряда
uint8_t Percentage(int16_t curr_min);
// проверка на то что силовой транзистор пробит
void check_Q1(void);
// функция управления реле подключения к сети 220В.
void Relay(void);
void Relay_on(bool vkl);
// контроль температуры Акб
void Control_trAkb(void);

// функции управления модулем защиты
namespace Protect {
// функция включения блокировки модуля защиты в зависимости от напряжения акб
// включает блокировку при напряжении акб менее 5 Вольт и отключает при напр.
// более 6 Вольт
void Guard(void);

// принудительно закрыть защитный транзистор
void Close(bool x);

// подать 12 вольт на транзисор модуля защиты - true
// отключить подачу 12 вольт на транзисор модуля защиты - false
void Open(bool x);

} // namespace Protect

