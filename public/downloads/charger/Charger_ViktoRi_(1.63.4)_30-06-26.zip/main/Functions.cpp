#include "Battery.h"
#include "DCDC.h"
#include "Display.h"
#include "INA226int.h"
#include "global.h"
#include "Protections.h"
#include <GyverIO.h>

// щелчoк на кнопки и энкодер
#if (SPEAKER > 0 and BEEP_DURATION_MS > 0)
#define BEEP()                                                                 \
  do {                                                                         \
    Speaker(BEEP_DURATION_MS);                                                 \
  } while (0)
#endif

// постоянно работающие функции, // опрос датчиков
void sensor_survey(void) {
  butt.Tick(); // опрос кнопок и энкодера

  // щелчок на кнопку и энкодер
#if (SPEAKER > 0 and BEEP_DURATION_MS > 0)
  if (butt.tick and butt.tick <= Butt::STOPCLICK) {
    BEEP();
  }
#endif

  if (get_ina_flag_sys()) {
    ina.sample();
    // if (bitRead(profil.flags, Pr_flags:: ACTIVITI)
    // регулировка тока и напряжения
    dcdc.Control();

#if (VOLTIN == 1)
    // check_Q1();     //проверка на то что силовой транзистор пробит
#endif
  }

#if (VOLTIN == 1)
  // замер напряжения БП
  Power_sample();
#endif

#if (SENSTEMP1 == 2)
  // датчик температуры NTC транзистора
  ntc_Q1_sample();
#endif

#if (SENSTEMP2 == 2)
  // датчик температуры NTC аккумулятора
  ntc_akb_sample();
#endif

#if (POWER == 1)
  Relay_butt_tick();
#endif

  if (get_second_flag_sys()) {
    // выполняются раз в секунду
    sysFlagSetBits(FlagsName::SECOND);

#if (VOLTIN == 1)
    // проверить напряжение БП на наличие и на превышение
    Power_check();
#endif

    ina.calc();

#if (SENSTEMP1 > 0)
    // чтение температуры транзистора, вызывать раз в секунду
    temp_Q1_compute();
#endif

#if (SENSTEMP2 > 0)
    // чтение температуры акб, вызывать раз в секунду
    temp_akb_compute();
#endif

#if (FAN > 0)
    fan.control(); //  управение кулером
#endif

#if (POWER == 1)
    Relay(); // функция управления реле подключения к сети 220В
#endif
#if (LOGGER)
    Sout.Serial_out(); // вывод данных в серийный порт
#if (LOGGER == 4)
    Sout.create_advanced(0, 0, 0, 0);
#else
    Sout.create(); // сбросить данные
#endif
#endif
  }
}


#if (RESIST == 1)
// Функция измерения сопротивления
void Resist(void) {
  if (ina.voltsec < 2000) {
    print_mode(ERROR); // "error"
    Delay(1000);
    return;
  }
#if (PROTECT_BLOCK)
  // открыть защитный транзистор
  Protect::Open(true);
#endif
  eeSetMode(); // сохранить режим работы eeGetMode();
  profil.Regim = Modes::RESISTENSE;
  bitSet(profil.flags, Pr_flags::ACTIVITI);
  dcdc.start(DCDC_DISCHARGE);          // старт разряда
  dcdc.Smooth_off(LOW);                // отключить плавный пуск
  dcdc.begin((ina.voltsec >> 1), 800); // задает напряжение и ток разряда
  uint16_t vlt = ina.voltsec;
  uint8_t timer = 60; // время первого замера сек.
  do {
    sensor_survey();
    if (butt.tick == Butt::OKHELD or butt.tick == Butt::STOPCLICK) {
      dcdc.Off(); // отключить заряд, разряд.
      bitClear(profil.flags, Pr_flags::ACTIVITI);
#if (PROTECT_BLOCK)
      Protect::Open(false);
#endif
      eeGetMode();
      return;
    }
    if (get_second()) {
      // если прошла секунда вывод на дисплей
      // *12.361V 3.555A  *
      setCursory();
      print_volt_current(ina.voltsec, abs(ina.ampersec), 3);
      lcd.setCursor(DISPLAYx - 2, 0);
      lcd.print(--timer);
      print_space();
      vlt = ina.voltsec;
      // стабилизация напряжения до 1мВ/сек
      if (difference(vlt, ina.voltsec) <= 1)
        timer = 0;
    }
  } while (timer);
  int16_t I[2]{abs(ina.ampersec), 0}; // сохранить ток
  uint16_t U[2]{ina.voltsec, 0};      // сохранить напряжение
  dcdc.setCur_charge((int16_t)4000);
  Delay(1000);              // ожидание // 3000
  I[1] = abs(ina.ampersec); // сохранить ток
  U[1] = ina.voltsec;       // сохранить напряжение
  dcdc.Off();               // отключить заряд, разряд.
  bitClear(profil.flags, Pr_flags::ACTIVITI);
  setCursory();
  print_volt_current(U[1], I[1], 3); // *12.361V 3.554A  *
  ClearStr(4);
  Delay(4000);
  // расчитать внутренее сопротивление аккумулятора
  int16_t curr = I[1] - I[0];
  if (curr and (U[0] > U[1])) {
    float r = ((float)(U[0] - U[1]) / (float)curr);
    // расчет пускового тока
    uint16_t currentInrush =
        (uint16_t)((1.0 / (float)(U[0] - U[1]) / r) * 1000 + 0.5);
    r *= 1000;  // перевод в миллиОм
    r *= 0.215; // подстроечный коэффициент сопротивления
    setCursory();
    print_resist(r);
    lcd.print(currentInrush);
    lcd.write('A');
    ClearStr(4);
    pauses();
  }
#if (PROTECT_BLOCK)
  Protect::Open(false);
#endif
  eeGetMode();
}
#endif

// функция расчета Ач и Втч
int32_t Calc_AhWh(int32_t i) {
#if defined(__LGT8FX8P__)
  return DSC_DIV_get((int32_t)(i * 5 + 9), (uint16_t)18);
#else
  return (i * 5 + 9) / 18; // эквивалент round(i*0.277777f) с округлением
                           // //return (int32_t)round(i * 0.277777f);
#endif
}


// функция задержки (t - милисекунды)
void Delay(uint16_t ms) {
  uint32_t t = millis_sys() + ms;
  do {
    sensor_survey();
  } while ((millis_sys() < t) and !butt.tick);
}

// пауза до нажатия
void pauses(void) {
  do {
    sensor_survey();
  } while (!butt.tick);
}

// расчет напряжения при котором начинается снижение тока заряда
uint16_t Volt_DCur(void) {
  return (profil.charge.voltage + bat_volt(profil.akb.type)) >> 1;
}

#if (KALIBROVKA == 1)
// калибровка падения напряжения при токе нагрузки, напряжения от БП
void Korrect(uint8_t kof) {
  // если выбрана калибровка напряжения от БП и не установлен делитель
  // напряжения на входе то выйти из функции
  if (kof == 1 and VOLTIN == 0)
    return;

#if (TIME_LIGHT)
  disp.Light_high(); // включение подсветки
#endif
  if (kof == 0 or kof == 2) {
    Delay(500);
    while (ina.voltsec < 9000) {
      lcd.clear();
      lcd.print(F(txt11)); //  Подключи АКБ
      lcd.print(F(" 12V"));
      Delay(200);
      if (butt.tick == Butt::STOPCLICK or butt.tick == Butt::OKCLICK) {
        dcdc.Off();
        return;
      }
    }
    if (kof == 0) {
      bitSet(profil.flags, Pr_flags::ACTIVITI);
      dcdc.start(DCDC_DISCHARGE);
      dcdc.begin((ina.voltsec >> 1), 2100);
    }
  }
  lcd.clear();

  bool x = false;
  bool ext = true;
  eeSetMode(); // сохранить режим работы eeGetMode();
  profil.Regim = Modes::KALIBRATION;

  do {
    // установка напряжения
    do {
      // ожидание действий пользователя
      sensor_survey();
      if (kof == 0 and ina.ampersec < -2000)
        // отключить стабилизацию тока
        dcdc.stabilization(LOW);
      if (get_second() or butt.tick) {
        // вывод на дисплей
        switch (kof) {
        case 0:
          setCursorx(); // 0, 0
          print_volt_current(ina.voltsec, ina.ampersec, 3);
          if (!dcdc.get_stabilization()) {
            setCursory(); // *12.365V 3.254А  *
            Write_x(x);   // > or  пробел  // *>80     >55    *
            lcd.print(vkr.Ohms);
            if (vkr.Ohms > 120)
              lcd.write('!');
            print_space();
            lcd.setCursor(8, 1);
            Write_x(!x); // > or  пробел
            print_resist(((float)vkr.shunt / 100));
          }
          break;
#ifdef VKORRECT
#if (VOLTIN == 1)
        case 1:
          // замер напряжения блока питания
          setCursorx();
          print_volt(getPower());
          lcd.write('<');
          lcd.print(vkr.Vref);
          lcd.print('>');
          print_space();
          break;
#endif
#endif
        case 2:
          // замер напряжения акб
          setCursorx();
          print_volt(ina.voltsec, 3);
          lcd.write('<');
          lcd.print(vkr.inaKoof);
          lcd.print('>');
          print_space();
          break;
        }
      }
    } while (!butt.tick);

    switch (butt.tick) {
    case Butt::OKCLICK:
      x = !x;
      break;
    case Butt::RIGHT:
    case Butt::LEFT:
      switch (kof) {
      case 0:
        if (x)
          vkr.Ohms = constrain_my(vkr.Ohms, 0, 255, butt.tick);
        else
          vkr.shunt = constrain_my(vkr.shunt, 10, 11000, butt.tick);
        ina.start();
        break;
#if defined(VKORRECT) and (VOLTIN == 1)
        // референсное напряжение АЦП
      case 1:
        vkr.Vref = constrain_my(vkr.Vref, 500, 1500, butt.tick);
        break;
#endif
      case 2:
        // коэффициент напряжения INA226
        vkr.inaKoof = constrain_my(vkr.inaKoof, 10000, 15000, butt.tick);
        break;
      }
      break;
    case Butt::OKHELD:
    case Butt::STOPCLICK:
      ext = false;
      break;
    }
  } while (ext);
  dcdc.Off();
  bitClear(profil.flags, Pr_flags::ACTIVITI);
  eeGetMode();
}

#elif (KALIBROVKA == 2)
// калибровка падения напряжения при токе нагрузки, напряжения от БП
void Korrect(const uint8_t kof) {
  // если выбрана калибровка напряжения от БП и не установлен делитель
  // напряжения на входе то выйти из функции
  if (kof == 1 and VOLTIN == 0)
    return;

#if (TIME_LIGHT)
  disp.Light_high(); // включение подсветки
#endif
  if (kof == 0 or kof == 2) {
    Delay(500);
    while (ina.voltsec < 9000) {
      if (get_second()) {
        lcd.clear();
        lcd.print(F(txt111)); //  Подключи БП
        setCursorx();
        lcd.print(F(" >12V 2А"));
      }

      if (butt.tick == Butt::STOPCLICK or butt.tick == Butt::OKCLICK)
        return;
    }
    if (kof == 0)
      gio::high(PWMDCH_PIN); // включить разряд
  }
  lcd.clear();

  bool x = false;
  bool ext = true;
  bitSet(profil.flags, Pr_flags::ACTIVITI);
  eeSetMode(); // сохранить режим работы eeGetMode();
  profil.Regim = Modes::KALIBRATION;

  do {
    // установка напряжения
    do {
      // ожидание действий пользователя
      sensor_survey();
      if (get_second() or butt.tick) {
        // вывод на дисплей
        switch (kof) {
        case 0:
          setCursorx(); // 0, 0
          print_volt_current(ina.voltsec, ina.ampersec, 3);
          setCursory(); // *12.365V 3.254А  *
          Write_x(x);   // > or  пробел  // *>80     >55    *
          lcd.print(vkr.Ohms);
          if (vkr.Ohms > 120)
            lcd.write('!');
          print_space();
          lcd.setCursor(8, 1);
          Write_x(!x); // > or  пробел
          print_resist((float)vkr.shunt / 100);
          break;
#if defined(VKORRECT) and (VOLTIN == 1)
        case 1:
          // замер напряжения блока питания
          setCursorx();
          print_volt(getPower());
          lcd.write('<'); // <
          lcd.print(vkr.Vref);
          lcd.print('>'); // >
          print_space();
          break;
#endif
        case 2:
          // замер напряжения акб
          setCursorx();
          print_volt(ina.voltsec, 3);
          lcd.write('<');
          lcd.print(vkr.inaKoof);
          lcd.print('>');
          print_space();
          break;
        }
      }
    } while (!butt.tick);

    switch (butt.tick) {
    case Butt::OKCLICK:
      x = !x;
      break;
    case Butt::RIGHT:
    case Butt::LEFT:
      switch (kof) {
      case 0:
        if (x)
          vkr.Ohms = constrain_my(vkr.Ohms, 0, 255, butt.tick);
        else
          vkr.shunt = constrain_my(vkr.shunt, 10, 11000, butt.tick);
        ina.start(); // старт замеров INA
        break;
#if defined(VKORRECT) and (VOLTIN == 1)
        // референсное напряжение АЦП
      case 1:
        vkr.Vref = constrain_my(vkr.Vref, 500, 1500, butt.tick);
        break;
#endif
      case 2:
        // замер напряжения акб
        vkr.inaKoof = constrain_my(vkr.inaKoof, 10000, 15000, butt.tick);
        break;
      }
      break;

    case Butt::OKHELD:
    case Butt::STOPCLICK:
      ext = false;
      break;
    }
  } while (ext);
  gio::low(PWMDCH_PIN); // отключить разряд
  bitClear(profil.flags, Pr_flags::ACTIVITI);
  eeSave_vkr();
  eeGetMode();
}
#endif

// Функция ожидания time_charge - минут
void Wait(uint16_t time_min) {
  regims = Regims::WAIT;
  lcd.clear();
  lcd.print(F(txt16)); // Pause
  start_second_usr();
  do {
    sensor_survey();

    // если прошла секунда вывод на дисплей
    if (get_second()) {
      setCursory();
      print_volt(ina.voltsec);
      lcd.print(time_min);
      lcd.print(F(txt20)); // "мин"
      if (get_second_usr() >= (uint8_t)60) {
        // когда прошла минута
        start_second_usr();
        time_min--;
      }

#if (TIME_LIGHT)
      // отключение подсветки через 3 минуты, если разрешено отключение
      disp.Light_low();
#endif
    }
    //  цикл в минутах или долгово нажатия OK
  } while (time_min and butt.tick != Butt::STOPHELD and
           butt.tick != Butt::OKHELD);
}

// Функция завершения заряда
void End(void) {
  regims = Regims::REGIM_OFF;
#if (TIME_LIGHT)
  disp.Light_high(); // включение подсветки
#endif
  lcd.clear();
  lcd.print(regim_end); // вывод причины завершения работы.
  print_space();
  print_mode(MODE); // вывод режима
  setCursory();
  int32_t Ah = 0;
  uint32_t tm = 0;
  switch (profil.Regim) {
  case Modes::CHARGE:
    // Заряд
    Ah = profil.charge.stat.ah;
    tm = profil.charge.stat.time;
    break;
#if (BRRANIMIR)
  case Modes::BRANIMIR:
#endif
  case Modes::KTCycle:
    // Заряд-Дозаряд , Бранимир, КТЦ
    Ah = profil.charge.stat.ah + profil.add.stat.ah;
    tm = profil.charge.stat.time + profil.add.stat.time;
    break;
  case Modes::ADDCHARGE:
    // Дозаряд
    Ah = profil.add.stat.ah;
    tm = profil.add.stat.time;
    break;
  case Modes::DISCHARGE:
    // Разряд
    Ah = profil.disch.stat.ah;
    tm = profil.disch.stat.time;
    break;
  case Modes::ASYMMETRIC:
    // 2 ассиметричный заряд
    Ah = profil.asym.stat.ah;
    tm = profil.asym.stat.time;
    break;
  }
  print_Ah(Ah);
#if (DISPLAYx == 16)
  Print_time(tm, DISPLAYx - 5, 1);
#elif (DISPLAYx == 20)
  Print_time(tm, DISPLAYx - 11, 1);
#endif
#if (DISPLAYy == 4)
  lcd.setCursor(0, 2);
  ClearStr(3);
#endif
  regim_end = Reason::begin;
#if (SPEAKER > 0)
  Speaker(1000);
#endif
  pauses();
  lcd.clear();
  Delay(500);
}

// функция выбора Stop/OK. (timer - секунд, время через которое возвращается
// false. Если timer = 0 то возврат из функции по нажатию кнопок/енкодера)
bool Choice(uint8_t second, bool rez) {
  butt.tick = 0;
  do {
    switch (butt.tick) {
    case Butt::LEFT:
    case Butt::RIGHT:
      rez = !rez;
      break;
    case Butt::OKCLICK:
    case Butt::STOPCLICK:
      return rez;
      break;
    }
    lcd.setCursor(4, 1);
    lcd.print((rez ? F(txt17) : F(txt19))); // OK / Stop

    do {
      // цикл ожидания действий пользователя
      sensor_survey();
      if (get_second()) {
        lcd.setCursor(DISPLAYx - 2, 1);
        lcd.print(second);
        print_space();
        second--;
      }
    } while (!butt.tick and second);
    // ожидание истечения времени
  } while (second);
  return rez;
}

#if (SPEAKER > 0)
#endif

// функция звукового сигнала (n - время в миллисекундах)
void Speaker(uint16_t n) {
// активный звукового сигнала
#if (SPEAKER == 2)
  gio::high(BUZER_PIN); // включить сигнал
  delay_sys(n);         // подождать n - миллисекунд
  gio::low(BUZER_PIN);  // отключить сигнал

#elif (SPEAKER == 1)
  // пассивный звукового сигнала
  uint32_t t = millis_sys() + n;
  // звуковой сигнал в течении n миллисекунд
  // 2314 - частота 432Гц; 1157 - частота 864Гц; 771 - частота 1296Гц
  while (millis_sys() < t) {
    gio::high(BUZER_PIN);
    delayMicroseconds(300);
    gio::low(BUZER_PIN);
    delayMicroseconds(471);
  }
#endif
  return;
}

// расчет времени заряда
void ChargeTimeCalc(void) {
#if defined(__LGT8FX8P__)
  DSC_MUL((uint16_t)profil.akb.capacity, (uint16_t)1000);
  uint16_t v = DA_DIV_get((uint16_t)profil.charge.current);
#else
  uint16_t v = ((uint32_t)profil.akb.capacity * 1000 / profil.charge.current);
#endif
  v += ((v + 2 - 1) >> 1);
  profil.charge.time = (uint8_t)constrain(v, 1, 48);
}

// вычисление процента заряда
uint8_t Percentage(int16_t curr_min) {
  // миним напряжение (напряжение разряда)
  uint16_t vmin = profil.disch.voltage_end;
  if (ina.volt_aver <= vmin)
    return 0;
  // процент по напряжению
  auto v = map_my(ina.volt_aver, vmin, dcdc.getVolt_charge(), 0, 100);
  // процент по току
  auto c = map_my(ina.curr_aver, curr_min, dcdc.getCur_charge(), 0, 100);
  c >>= 1;
  // процент общий
  int16_t prc = v - c;
  return (uint8_t)constrain(prc, 0, 100);
}

#if (VOLTIN == 1)
// проверка на то что силовой транзистор пробит
void check_Q1(void) {
  auto vt = difference(ina.voltms, getPower());
  if ((abs(vt) < 100) and abs(ina.amperms) > 500 and dcdc.getTok() == 0) {
#if (TIME_LIGHT)
    disp.Light_high(); // включение подсветки
#endif
    dcdc.Off();
#if (PROTECT_LOCK == 1)
    // принудительно закрыть защитный транзистор
    Protect::Close(true);
#endif
#if (POWER == 1)
    gio::low(POWER_PIN); // отключить сеть 220В
#endif

    eepSavedStruct(); // сохранить настройки
    lcd.clear();
    lcd.print(F(txt24)); //"!!-BROKEN Q1-!!"

    pauses();

    eepSavedStruct(); // сохранить настройки
#if (PROTECT_LOCK == 1)
    // отключить - принудительно закрыть защитный транзистор
    Protect::Close(false);
#endif
#if (POWER == 1)
    Relay_on(true); // включить сеть 220В
#endif
    lcd.clear();
  }
}
#endif

/*
ШИМ на выводах 9 и 10
9 бит, 31 250 Гц
TCCR1A = TCCR1A & 0xe0 | 2;
TCCR1B = TCCR1B & 0xe0 | 0x09;

*/

// функция блока питания
/*
Вызывается из меню на экране датчиков, удержанием кнопки ПУСК.


*/
void BP_vvcc(void) {
  uint16_t bp_volt = BP_volt; // начальное напряжение БП
  int16_t bp_curr = BP_curr;  // начальный ток БП
  bool x = true;              // изменение напряжения или тока

#if (PROTECT_BLOCK)
  // открыть защитный транзистор
  Protect::Open(true);
#endif
  lcd.clear();
  lcd.print(F(txt18));
  Delay(2000);
  lcd.clear();
  bitSet(profil.flags, Pr_flags::ACTIVITI);
  dcdc.start(DCDC_CHARGE);
  dcdc.begin(bp_volt, bp_curr);
  eeSetMode(); // сохранить режим работы eeGetMode();
  profil.Regim = Modes::POWEROUT;
  start_second_usr();
  do {
    sensor_survey();

    if (butt.tick) {
      // если кнопка нажата
      // производится корректировка напряжения и тока заряда
      switch (butt.tick) {
      case Butt::RIGHT:
      case Butt::LEFT:

        if (x) {
          // изменение напряжения
          bp_volt = volt_step(bp_volt, butt.tick);
          dcdc.setVolt_charge(bp_volt);
        } else {
          // изменение тока
          int16_t step = (int16_t)butt.tick * (int16_t)STEP_CURR;
          bp_curr = constrain_my(bp_curr, CUR_CHARGE_MIN, CURRMAXINT, step);
          dcdc.setCur_charge(bp_curr);
        }
        break;
      case Butt::OKCLICK:
        x = !x;
        break;
      case Butt::STOPHELD:
      case Butt::OKHELD:
        dcdc.Off();
        bitClear(profil.flags, Pr_flags::ACTIVITI);
        lcd.clear();
#if (PROTECT_BLOCK)
        // отключить - принудительная блокировка модуля защиты
        Protect::Open(false);
#endif
        break;
      }
    }

    // если прошла секунда или кнопки/энкодер
    if (get_second() or butt.tick) {
      // вывод на дисплей
      // первая строка
      setCursorx();
      print_volt_current(ina.voltsec, ina.ampersec, 3); // напряжение и ток

      //  вторая строка
      setCursory();
      Write_x(x); // > or  пробел
      lcd.print(bp_volt);
      print_space();
      lcd.setCursor(8, 1);
      Write_x(!x); // > or  пробел
      lcd.print(bp_curr);
      print_space();
#if (DISPLAYy == 4)
      // третья строка
      lcd.setCursor(0, 2);
      print_tr(); // температура транзистора или акб
#endif
      if (butt.tick == 0) {
#if (TIME_LIGHT)
        disp.Light_low();
#endif

#if (LOGGER > 0)
#if (LOGGER == 4)
        Sout.create_advanced(0, (uint16_t)ina.volt_aver, ina.curr_aver,
                             get_second_usr());
#else
        Sout.create(0, (uint16_t)ina.volt_aver, ina.curr_aver);
#endif
#endif
      }
    }
  } while (bitRead(profil.flags, Pr_flags::ACTIVITI));
  eeGetMode();
  stop_second_usr();
  lcd.clear();
}


