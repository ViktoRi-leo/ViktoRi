#include "global.h"
#include "Battery.h"
#include <EEPROM.h>
#include <GyverIO.h>

uint8_t sysFlag;

void sysFlagsBegin(void) { sysFlag = 0b00110111; }

Intls vkr;

Profils profil;

Regims regims = Regims::REGIM_OFF;

// считать из EEPROM номер режима работы
uint8_t eeGetModeNumber(void) {
#if defined(__LGT8FX8P__)
  return lgt_eeprom_read_byte(MEM_NUMBER);
#else
  return EEPROM.read(MEM_NUMBER);
#endif
}

// сохранить в EEPROM номер режима работы
void eeSetModeNumber(uint8_t mode) {
#if defined(__LGT8FX8P__)
  lgt_eeprom_update_byte(MEM_NUMBER, mode);
#else
  EEPROM.update(MEM_NUMBER, mode);
#endif
}

// считать из EEPROM текущий круг
uint8_t eeGetRound(void) {
#if defined(__LGT8FX8P__)
  return lgt_eeprom_read_byte(MEM_ROUND);
#else
  return EEPROM.read(MEM_ROUND);
#endif
}

// сохранить в EEPROM текущий круг
void eeSetRound(uint8_t round) {
#if defined(__LGT8FX8P__)
  lgt_eeprom_update_byte(MEM_ROUND, round);
#else
  EEPROM.update(MEM_ROUND, round);
#endif
}

// сохранить в EEPROM выбранный режим работы
void eeSetMode(void) {
#if defined(__LGT8FX8P__)
  lgt_eeprom_update_byte(MEM_MODE, profil.Regim);
#else
  EEPROM.update(MEM_MODE, profil.Regim);
#endif
}

// считать из EEPROM выбранный режим работы
void eeGetMode(void) {
#if defined(__LGT8FX8P__)
  profil.Regim = lgt_eeprom_read_byte(MEM_MODE);
#else
  profil.Regim = EEPROM.read(MEM_MODE);
#endif
  eepSavedStruct();
}

// флаг секунды
bool get_second(void) {
  if (sysFlagGetBits(FlagsName::SECOND)) {
    sysFlagClearBits(FlagsName::SECOND);
    return true;
  }
  return false;
}

Reason regim_end{Reason::begin};

uint16_t volt_step(uint16_t volt, int8_t x) {
  return constrain_my(volt, STEP_VOLT * 10, POWERINT, x * STEP_VOLT);
}

#if defined(__LGT8FX8P__)
void lgt_eeprom_update_byte(uint16_t address, uint8_t value) {
  if (lgt_eeprom_read_byte(address) != value)
    lgt_eeprom_write_byte(address, value);
}

void lgt_eeprom_update_block(uint8_t *pbuf, uint16_t address, uint16_t len) {
  uint16_t i;
  uint8_t *p = pbuf;
  for (i = 0; i < len; i++) {
    lgt_eeprom_update_byte(address + i, *p++);
  }
}
#endif

// ждать N секунд
void delay_sec(uint8_t sec) {
  start_second_usr(); // старт счета секунд
  while (get_second_usr() <= sec)
    _NOP();
  stop_second_usr();
}

// сохранить структуру vkr
void eeSave_vkr(void) {
#if defined(__LGT8FX8P__)
  // lgt_eeprom_update_block(((uint8_t*)&vkr), MEM_VKR, sizeof(vkr));
  lgt_eeprom_writeSWM((uint16_t)MEM_VKR, ((uint32_t *)&vkr),
                      (uint16_t)sizeof(vkr) / sizeof(uint32_t));
#else
  EEPROM.put((int)MEM_VKR, vkr);
#endif
}

// считать структуру vkr
void eeGet_vkr(void) {
#if defined(__LGT8FX8P__)
  // lgt_eeprom_read_block(((uint8_t*)&vkr), MEM_VKR, sizeof(vkr));
  lgt_eeprom_readSWM((uint16_t)MEM_VKR, ((uint32_t *)&vkr),
                     (uint16_t)sizeof(vkr) / sizeof(uint32_t));
#else
  EEPROM.get((int)MEM_VKR, vkr);
#endif
}

// сохранить структуру profil
void eeSave_profil(uint8_t profil_number) {
#if defined(__LGT8FX8P__)
  const uint16_t eeAddr = (uint16_t)sizeof(profil) * profil_number + MEM_PAM;
  //lgt_eeprom_update_block(((uint8_t *)&profil), eeAddr, sizeof(profil));
  lgt_eeprom_writeSWM(eeAddr, ((uint32_t *)&profil),
                      (uint16_t)sizeof(Profils) / sizeof(uint32_t));
#else
  const int16_t eeAddr = (int16_t)sizeof(Profils) * profil_number + MEM_PAM;
  EEPROM.put(eeAddr, profil);
#endif
}

// считать структуру profil
void eeGet_profil(void) {
#if defined(__LGT8FX8P__)
  const uint16_t eeAddr = (uint16_t)sizeof(profil) * vkr.profil + MEM_PAM;
  // lgt_eeprom_read_block(((uint8_t *)&profil), eeAddr, sizeof(profil));
  lgt_eeprom_readSWM(eeAddr, ((uint32_t *)&profil),
                     (uint16_t)sizeof(Profils) / sizeof(uint32_t));
#else
  const int16_t eeAddr = (int16_t)sizeof(Profils) * vkr.profil + MEM_PAM;
  EEPROM.get(eeAddr, profil);
#endif
}

// функция сохранения настроек
void eepSavedStruct(void) {
  eeSave_vkr();
  eeSave_profil(vkr.profil);
}

// чтение структур из EEPROM
void eepGetStruct(void) {
  eeGet_vkr();
  eeGet_profil();
}

int16_t difference(int32_t diff_1, int32_t diff_2) {
  return (int16_t)(diff_1 - diff_2);
}

// функция быстрого переключения "ног"
void digitalWrite_speed(uint8_t pin, bool x) {
  // PWM disable
  switch (pin) {
  case 3:
    bitClear(TCCR2A, COM2B1);
    break;
  case 5:
    bitClear(TCCR0A, COM0B1);
    break;
  case 6:
    bitClear(TCCR0A, COM0A1);
    break;
  case 9:
    bitClear(TCCR1A, COM1A1);
    break;
  case 10:
    bitClear(TCCR1A, COM1B1);
    break;
  case 11:
    bitClear(TCCR2A, COM2A1);
    break;
  }
  gio::write(pin, x);
}

void analogWrite_my(uint8_t pin, uint16_t duty) {
  if (!duty) {
    digitalWrite_speed(pin, LOW); // Disable PWM and set pin to LOW
    return;                       // Skip next code
  }
  switch (pin) {
  case 5:
    bitSet(TCCR0A, COM0B1); // Enable hardware timer output
    OCR0B = duty;           // Load duty to compare register
    return;
  case 6:
    bitSet(TCCR0A, COM0A1);
    OCR0A = duty;
    return;
  case 10:
    bitSet(TCCR1A, COM1B1);
    OCR1B = duty;
    return;
  case 9:
    bitSet(TCCR1A, COM1A1);
    OCR1A = duty;
    return;
  case 3:
    bitSet(TCCR2A, COM2B1);
    OCR2B = duty;
    return;
  case 11:
    bitSet(TCCR2A, COM2A1);
    OCR2A = duty;
    return;
  }
}

#if defined(__LGT8FX8P__)
int16_t map_my(int16_t x, int16_t in_min, int16_t in_max, int16_t out_min,
               int16_t out_max) {
  return uDSC_map_int(x, in_min, in_max, out_min, out_max);
}
#else
int16_t map_my(int32_t x, int16_t in_min, int16_t in_max, int16_t out_min,
               int16_t out_max) {
  if (x >= in_max)
    return out_max;
  if (x <= in_min)
    return out_min;
  int32_t diff =
      ((x - in_min) * (out_max - out_min)); // Предварительное масштабирование
  int16_t range = (in_max - in_min);        // Диапазон исходных значений
  if (range == 0)
    return out_min;
  return (int16_t)(diff / range + out_min); // Итоговая формула
}
#endif

// напряжение аккумулятора
uint16_t bat_volt(uint8_t bat_type) {
  return pgm_read_word(&batteries[bat_type].volt_cell) * profil.akb.cell;
}

// функция рассчета профиля по параметрам аккумулятора
void calcProfile() {
  /* Mаксимальный ток ЗУ*/
  const int16_t max_current = CURRMAXINT;
  // напряжение акб
  const uint16_t akb_voltage = bat_volt(profil.akb.type);
  // напряжение заряда
  uint16_t akb_voltage_charge =
      pgm_read_word(&batteries[profil.akb.type].volt_cell_charge) *
      profil.akb.cell;

  // уменьшить количество ячеек если напряжение заряда превышает напряжение
  // БП
  while ((akb_voltage_charge > POWERINT) and (profil.akb.cell > (uint8_t)1)) {
    profil.akb.cell--;
    akb_voltage_charge =
        pgm_read_word(&batteries[profil.akb.type].volt_cell_charge) *
        profil.akb.cell;
  }

  /* Заряд */
  profil.charge.voltage = akb_voltage_charge;

  profil.charge.current =
      (int16_t)pgm_read_byte(&batteries[profil.akb.type].curr_cell_charge) *
      profil.akb.capacity * 10;
  profil.charge.current =
      constrain(profil.charge.current, CUR_CHARGE_MIN, max_current);

  profil.charge.current_end = profil.charge.current / 50;
  profil.charge.current_end =
      constrain(profil.charge.current_end, CUR_CHARGE_MIN, max_current);

  profil.charge.voltage_decr_cur =
      (uint16_t)(((uint32_t)profil.charge.voltage + akb_voltage) >> 1);

  uint8_t t =
      (uint8_t)((uint32_t)profil.akb.capacity * 1000 / profil.charge.current);
  t += t >> 1;
  profil.charge.time = constrain(t, (uint8_t)1, (uint8_t)48);

  profil.charge.voltage_pre =
      (uint16_t)(((uint32_t)akb_voltage * 110 + 50) / 100);
  profil.charge.current_pre =
      constrain(profil.charge.current >> 1, (int16_t)CUR_CHARGE_MIN,
                profil.charge.current);

  /* Дозаряд */
  profil.add.voltage =
      pgm_read_word(&batteries[profil.akb.type].volt_cell_add_charge) *
      profil.akb.cell;
  profil.add.current =
      (int16_t)pgm_read_byte(&batteries[profil.akb.type].curr_cell_addcharge) *
      profil.akb.capacity * 10;
  profil.add.current =
      constrain(profil.add.current, CUR_CHARGE_MIN, max_current);
  profil.add.current_min = profil.add.current / 3;
  profil.add.current_min =
      constrain(profil.add.current_min, CUR_CHARGE_MIN, max_current);
  profil.add.time = 10;

  /* Разряд */
  profil.disch.voltage_end =
      pgm_read_word(&batteries[profil.akb.type].volt_cell_discharge) *
      profil.akb.cell;
  profil.disch.current =
      (int16_t)pgm_read_byte(&batteries[profil.akb.type].curr_cell_discharge) *
      profil.akb.capacity * 10;
  profil.disch.current =
      constrain(profil.disch.current, CUR_CHARGE_MIN, max_current);
  profil.disch.current_end = profil.disch.current;

  /* Асимметричный режим */
  profil.asym.voltage = profil.charge.voltage;
  profil.asym.current = profil.charge.current;
  profil.asym.current_discharge = profil.disch.current;
  profil.asym.period_charge = 20;
  profil.asym.period_discharge = 10;
  profil.asym.pause = 5;

  /* Хранение */
  profil.storage.voltage =
      (uint16_t)(((uint32_t)akb_voltage * 104 + 50) / 100); // * 1.04;
  profil.storage.current =
      constrain(profil.charge.current / 20, CUR_CHARGE_MIN, max_current);

  /* Буферный режим */
  profil.buffer.voltage = (uint16_t)(((uint32_t)akb_voltage * 110 + 50) / 100);
  profil.buffer.current = profil.charge.current;
}

/*
#if defined(__LGT8FX8P__)
      // считать из памяти значения разряда, заряда opRound-циклаКТЦ
      lgt_eeprom_readSWM((((uint16_t)opRound << 4) - 16 + MEM_KTC),
                         ((uint32_t *)&KTC),
                         (uint16_t)(sizeof(KTC) / sizeof(uint32_t)));
#else
      // считать из памяти значения разряда, заряда opRound-цикла КТЦ
      EEPROM.get((((uint16_t)opRound << 4) - 16 + MEM_KTC), KTC);
#endif
*/

/*
        //
   ----------------------------------------------------------------------
        // read/write bundle of data from/to E2PROM with SWM mode enable
        //
   ----------------------------------------------------------------------
   void lgt_eeprom_writeSWM( uint16_t address, uint32_t *pData, uint16_t
   length ); void lgt_eeprom_readSWM( uint16_t address, uint32_t *pData,
   uint16_t length );
*/
