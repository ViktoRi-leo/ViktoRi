#include "global.h"
#include "DCDC.h"
#include "Display.h"
#include "INA226int.h"
#include "operations.h"

// Хранение
void Storage(void) {
#if (PROTECT_BLOCK)
  Protect::Guard();
#endif

  print_volt_current(profil.storage.voltage,
                     ((int16_t)profil.akb.capacity << 3));
  Delay(3000);

  start_second_usr();
  // цикл работы
  while (bitRead(profil.flags, Pr_flags::ACTIVITI)) {

    sensor_survey();

    // прошла секунда
    if (get_second()) {
      // когда напряжение акб снизится ниже напряжения Хранения
      // включить заряд
      if (dcdc.get_pause() == LOW and
          (ina.volt_aver < profil.storage.voltage - 30)) {
        dcdc.start(DCDC_CHARGE);
        dcdc.begin(profil.storage.voltage, ((int16_t)profil.akb.capacity << 3));
      }
#if (PROTECT_BLOCK)
      Protect::Guard();
#endif
      Print_time(get_second_usr(), DISPLAYx - 8, 0); // *Storage 12:10:36*
      setCursory();                                  // *13.10V 6.12A 25C*
      print_volt_current(ina.voltsec, ina.ampersec);
#if (SENSTEMP1 or SENSTEMP2)
      print_tr(); // температура транзистора или акб
#endif

#if (LOGGER > 0)
#if (LOGGER == 4)
      Sout.create_advanced(0, (uint16_t)ina.volt_aver, ina.curr_aver,
                           get_second_usr());
#else
      Sout.create(0, (uint16_t)ina.volt_aver, ina.curr_aver);
#endif
#endif


#if (TIME_LIGHT)
      disp.Light_low();
#endif

    } // прошла секунда

    if (butt.tick == Butt::OKHELD or butt.tick == Butt::STOPHELD)
      bitClear(profil.flags, ACTIVITI); // завершить работу режима
  } // цикл работы
  dcdc.Off(); // отключить заряд, разряд.
#if (PROTECT_BLOCK)
  Protect::Open(false);
#endif
}