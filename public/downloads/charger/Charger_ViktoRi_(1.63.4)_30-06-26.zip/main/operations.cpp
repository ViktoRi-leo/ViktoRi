#include "operations.h"
#include "Battery.h"
#include "DCDC.h"
#include "Display.h"
#include "INA226int.h"
#include "global.h"
#include <EEPROM.h>

// пауза после заряда перед разрядом, мин (0-255)
#if (PAUSE_AFTER_CHARGE > 255)
#error                                                                         \
    "PAUSE_AFTER_CHARGE пауза после заряда перед разрядом должна быть в пределах 0-255"
#endif

// пауза после разряда перед зарядом, мин (0-255))
#if (PAUSE_AFTER_DISCHARGE > 255)
#error                                                                         \
    "PAUSE_AFTER_DISCHARGE пауза после разряда перед зарядом должна быть в пределах 0-255"
#endif

// сохранить текущие значения КТЦ
void eeSavedKTC(void) {
  int32_t KTC[]{profil.disch.stat.ah, profil.disch.stat.wh,
                profil.charge.stat.ah, profil.charge.stat.wh};
#if defined(__LGT8FX8P__)
  const uint16_t eeAddr = ((uint16_t)eeGetRound() << 4) - 16 + MEM_KTC;
  lgt_eeprom_writeSWM(eeAddr, ((uint32_t *)&KTC),
                      (uint16_t)(sizeof(KTC) / sizeof(uint32_t)));
#else
  const int16_t eeAddr = ((int16_t)eeGetRound() << 4) - 16 + MEM_KTC;
  // сохранить в памяти значения разряда n-цикла КТЦ
  EEPROM.put(eeAddr, KTC);
#endif
}

void Operations(void) {
  uint8_t opRound = eeGetRound(); // получить счетчик циклов

  bool wait = false;

  // если флаг заряда установлен true то выполнять работу
  while (bitRead(profil.flags, Pr_flags::ACTIVITI)) {
    lcd.clear();
    print_mode(MODE); // вывод режима
    setCursory();
    eepSavedStruct(); // сохранить настройки
    ina.start();      // старт замеров INA
    op_window = 0;

#if (SPEAKER > 0)
    Speaker(1000);
#endif

    // Функция ожидания если сработали защиты по температуре акб и напряжению БП
   // if (wait) Wait(); 

    // Выбор режима заряда
    switch (profil.Regim) {
    case Modes::CHARGE:
      // Заряд - Дозаряд
      switch (eeGetModeNumber()) {
      case 1:
        // Заряд
        Charge(profil.charge.voltage, profil.charge.current,
               profil.charge.current_end, (uint32_t)profil.charge.time);

        if (bitRead(profil.flags, Pr_flags::ACTIVITI)) {
          // если флаг дозаряд установлен true
          if (bitRead(profil.flags, Pr_flags::CHARGE_ADD)) {
            eeSetModeNumber(2); // номер операции
          } else {
            if (--opRound == 0) {
              profil.Regim = Modes::STORAGE;
            } else {
              eeSetModeNumber(1); // иначе повторить заряд
              Wait(PBC);          // Функция ожидания - минут
            }
          }
        }
        break;

      case 2:
        // дать отстояться
        Wait(5);            // Функция ожидания - минут
        eeSetModeNumber(3); // номер операции
        break;

      case 3:
        // Дозаряд после заряда
        AddCharge(profil.add.voltage, profil.add.current,
                  profil.add.current_min, (uint32_t)profil.add.time);
        if (bitRead(profil.flags, Pr_flags::ACTIVITI)) {
          // если счетчик циклов равен 0 то завершить заряд
          if (--opRound == 0) {
            profil.Regim = Modes::STORAGE;
          } else {
            eeSetModeNumber(1); // иначе повторить заряд - дозаряд
            Wait(PBC);          // Функция ожидания - минут
          }
          break;
        }
      }
      break;

    case Modes::ADDCHARGE:
      // Дозаряд
      AddCharge(profil.add.voltage, profil.add.current, profil.add.current_min,
                (uint32_t)profil.add.time);
      if (bitRead(profil.flags, Pr_flags::ACTIVITI)) {
        // если счетчик циклов равен 0 то завершить заряд
        if (--opRound == 0) {
          profil.Regim = Modes::STORAGE;
        } else {
          // иначе повторить дозаряд
          Wait(PBC); // Функция ожидания - минут
        }
        break;
      }
      break;

    case Modes::ASYMMETRIC:
      // 2 ассиметричный заряд
      // заряд, дозаряд откл
      /*Asymmetric(profil.charge.voltage, profil.charge.current,
                 profil.charge.current_end, (uint32_t)profil.charge.time);*/

      Asymmetric();

      // если счетчик циклов равен 0 то завершить заряд иначе повторить заряд
      if (bitRead(profil.flags, Pr_flags::ACTIVITI)) {
        // если счетчик циклов равен 0 то завершить заряд
        if (--opRound == 0) {
          profil.Regim = Modes::STORAGE;
        } else {
          // иначе повторить дозаряд
          Wait(PBC); // Функция ожидания - минут
        }
        break;
      }
      break;

    case Modes::DISCHARGE:
      // Разряд
#if (DISCHAR == 1)
      // разряд аккумулятора
      Discharge();
      // если счетчик циклов равен 0 то завершить разряд// иначе повторить
      // разряд
      if (bitRead(profil.flags, Pr_flags::ACTIVITI) and (--opRound == 0))
        bitClear(profil.flags, Pr_flags::ACTIVITI);
#else
      bitClear(profil.flags, Pr_flags::ACTIVITI);
#endif
      break;

    case Modes::KTCycle:
      //  Котнтрольно-тренировочный цикл
#if (DISCHAR == 1)
      switch (eeGetModeNumber()) {
      case 1:
        // предварительный заряд
        Charge(profil.charge.voltage, profil.charge.current,
               profil.charge.current_end, (uint32_t)profil.charge.time);
        eeSetModeNumber(2);
        Res_mem_char(); // сброс значений заряда
        break;
      case 2:
        // дать отстояться // пауза после заряда перед разрядом
        Wait((uint16_t)PAUSE_AFTER_CHARGE); // Функция ожидания - минут
        eeSetModeNumber(3);
        break;
      case 3:
        // Разряд
        Discharge(); // разряд аккумулятора
        eeSetModeNumber(4);
        eeSavedKTC();
        break;
      case 4:
        // дать отстояться // пауза после разряда перед зарядом
        Wait((uint16_t)PAUSE_AFTER_DISCHARGE); // Функция ожидания - минут
        eeSetModeNumber(5);
        break;
      case 5:
        // заряд
        // Res_mem_char();     // сброс значений заряда
        Charge(profil.charge.voltage, profil.charge.current,
               profil.charge.current_end, (uint32_t)profil.charge.time);
        eeSavedKTC();

        if (bitRead(profil.flags, Pr_flags::ACTIVITI)) {
          // если счетчик циклов равен 0 то перейти в Дозаряд
          if (--opRound == 0) {
            if (bitRead(profil.flags, Pr_flags::CHARGE_ADD))
              eeSetModeNumber(6);
            else
              profil.Regim = Modes::STORAGE; // перейти в Хранение
          } else {
            // иначе повторить КТЦ
            eeSetModeNumber(2);
            Res_mem_dischar(); // сброс значений разряда
            Res_mem_char();    // сброс значений заряда
          }
        }
        break;
      case 6:
        // Дозаряд
        // дать отстояться - минут
        Wait(5);
        // Включить дозаряд
        if (profil.akb.type <= Akb_type::PB_GEL)
          AddCharge(profil.add.voltage, profil.add.current,
                    profil.add.current_min, (uint32_t)profil.add.time);
        profil.Regim = Modes::STORAGE; // перейти в Хранение
        break;
      }
#else
      bitClear(profil.flags, Pr_flags::ACTIVITI);
#endif
      break;

    case Modes::STORAGE: // хранение
      Storage();
      break;

#if (BUFFER == 1)
    case Modes::BUFER: // буферный режим
      Buffer();
#endif
      break;

#if (BRRANIMIR)
    case Modes::BRANIMIR:
      // Заряд по Бранимиру

      switch (eeGetModeNumber()) {
      case 1:
        regims = Regims::REGIM_CHARGE;
        // Бранимир Заряд - 20 часов после достижения максимального напряжения
        Branimir(profil.charge.voltage, (int16_t)profil.akb.capacity * 10,
                 constrain((int16_t)profil.akb.capacity * 2, CURMIN, 1000), 96);
        opRound--;
        eeSetModeNumber(2); // номер операции
        break;
      case 2:
        // Бранимир перемешивание 1 час
        regims = Regims::REGIM_MIXING;
        Branimir(profil.add.voltage, (int16_t)profil.akb.capacity * 30,
                 constrain((int16_t)profil.akb.capacity * 2, CURMIN, 1000), 1);
        eeSetModeNumber(3);
      case 3:
        // дать отстояться
        Wait(60); // Функция ожидания - минут

        if (opRound == 0)
          eeSetModeNumber(4); // Дозаряд
        else
          eeSetModeNumber(1); // снова заряд малым током
        break;

      case 4:
        // Бранимир дозаряд
        if (profil.akb.type <= Akb_type::PB_GEL) {
          AddCharge(profil.add.voltage, profil.add.current,
                    profil.add.current_min, 10);
        }
        profil.Regim = Modes::STORAGE;
        break;
      }
#endif
      break;
    } // выбор режима

    pause_second_usr(false); // счет времени заряда откл.
    // сохранить счетчик циклов
    eeSetRound(opRound);

    if (BitIsClear(profil.flags, Pr_flags::ACTIVITI)) {
      eeGetMode();
      End(); // Завершение работы
    }
  }
  // цикл работы
}
