#pragma once
#include <Arduino.h>
 // Библиотека дисплея
#include "LiquidCrystal_I2C.h" 

extern LiquidCrystal_I2C lcd;

// вывод на дисплей
enum DispRgb : uint8_t {
  MODE,     // 0 режим работы
  TYPE_AKB, // 1 тип акб
  ERROR,    // 2 ошибка
  SETTING,  // 3 настройки
  VOLTAGE,  // 4 напряжение во float
};

void print_mode(uint8_t i);

// класс управления дисплеем
class Display {
public:
  // Display(void) {}

  // Функции управления подсветкой
  void Light_setTime(void);

  void Light_high(void);

  void Light_low(void);

  // функция отключает подсветку если отключилось питание от от сети
  void Light_power(void);

  // функция для печати из PROGMEM
  void printFromPGM(int charMap);

private:
  // список членов для использования внутри класса
  uint32_t _light_time;
  uint32_t _light_tm;

};
extern Display disp;

// экран вывода ошибок
void window_errors(void);

// загрузка в память дисплея своих символов(состояние акб)
void setDisplaySimbol(void);

// Приветствие. Версия прошивки и тип контроллера
void print_version(void);

// Вывод напряжения
void print_volt(uint16_t volt, uint8_t x = 2);

// Вывод тока
void print_current(int16_t amp, uint8_t x = 2);

// вывод напряжения и тока
void print_volt_current(uint16_t volt, int16_t amp, uint8_t x = 2);

// вывод Ач
void print_Ah(int32_t Ah);

// вывод Втч
void print_Wh(int32_t Wh);

// вывод - часы
void print_hour(uint8_t hour);

// вывод - секунды
void print_sec(uint8_t sec);

// вывод сопротивления - mOm
void print_resist(float shunt);

void Print_time(uint32_t time_real, uint8_t x, uint8_t y);
void setCursorx(void);
void setCursory(void);
void print_space(void);
void print_tr(void);
#if (SENSTEMP1 and SENSTEMP2)
void print_tr_split(void);
#endif
void PrintOnOff(bool i);
void Write_x(bool x);
void print_Capacity(void);
void printCykl(void);
void ClearStr(uint8_t i);
void Vout(void);
void print_power_error(void);

extern uint8_t op_window;  // номер экрана
extern uint8_t ns_disp; // время отображения

// изменение номера экрана
void window_change(uint8_t window_max);

// обратный отсчет время отображения
void disp_time(void);

void Display_print(int32_t Ah, int32_t Wh, uint32_t time_real, uint8_t prc);



