#include "global.h"
#include "DCDC.h"
#include "Display.h"
#include "INA226int.h"
#include "operations.h"
#include <GyverIO.h>


// Буферный режим
void Buffer(void) {
#if (PROTECT_BLOCK)
  Protect::Guard();
#endif

  // переменная для сигнала буферного режима
  uint8_t signal_timer = 0; // время отстчета сигнала буферного режима
  uint8_t signal_time = 60; // период сигнала буферного режима
  // расчет напряжения акб - ниже которого будет подаваться сигнал
  const uint16_t signal_voltage = (bat_volt(profil.akb.type) / 100) * 100;
  const uint16_t signal_critical =
      profil.disch.voltage_end; // bat.Volt(volt_cell_discharge);
  // переменная для подсчета Ампер/часов
  int32_t Ah = 1;

  print_volt_current(profil.buffer.voltage, profil.buffer.current);

#ifdef BUFER_PIN
  // Включить реле нагрузки
  gio::high(BUFER_PIN);
#endif

  Delay(3000);

  dcdc.start(DCDC_CHARGE);
  dcdc.begin(profil.buffer.voltage, profil.buffer.current);

  lcd.clear();

  start_second_usr();

  // цикл работы
  while (bitRead(profil.flags, Pr_flags::ACTIVITI)) {

    sensor_survey();

    // прошла секунда
    if (get_second()) {
#if (PROTECT_BLOCK)
      Protect::Guard();
#endif
      // *Bufer   12:10:36*
      // *13.10V 6.12A 25C*
      Print_time(get_second_usr(), DISPLAYx - 8, 0);
      setCursory();
      print_volt_current(ina.voltsec, ina.ampersec);
#if (DISPLAYy == 4)
      print_Ah(Ah);
#endif
#if (SENSTEMP1 or SENSTEMP2)
      print_tr(); // температура транзистора или акб
#endif
#if (SPEAKER > 0)
      // сигнализация о снижении напряжения акб ниже предела (12V)
      if (ina.volt_aver < signal_voltage) {
        if (signal_timer > 0) {
          signal_timer--;
        } else {
          signal_timer = signal_time; // сигнал раз в 60 секунд
          Speaker(300);
        }
      } else {
        signal_timer = 0;
      }
#endif

#ifdef BUFER_PIN
      // если нагрузка подключена и напряжение снизилось менее напряжения
      // разряда то отключить реле нагрузки и включить заряд акб
      if (gio::read(BUFER_PIN) and (ina.volt_aver < signal_critical)) {
        gio::low(BUFER_PIN);
        dcdc.Off();
        dcdc.start(DCDC_CHARGE);
        dcdc.begin(profil.charge.voltage, profil.charge.current);
        Ah = 1;
#if (SPEAKER > 0)
        Speaker(300);
#endif
      }

      if (!gio::read(BUFER_PIN)) {
        // расчет ампер/часов заряда
        Ah += Calc_AhWh((int32_t)ina.ampersec);
      }
      // если нагрузка отключена и идет заряд акб
      // проверяем напряжение и ток, когда напряжение достигнет
      // напряженя заряда и ток снизится до 0,01С
      // то снизить напряжение до буферного включить реле нагрузки
      if (!gio::read(BUFER_PIN) and
          ((ina.volt_aver > profil.charge.voltage - 30) and
           ina.curr_aver <= ((int16_t)profil.akb.capacity << 3))) {
        dcdc.Off();
        dcdc.start(DCDC_CHARGE);
        dcdc.begin(profil.buffer.voltage, profil.buffer.current);
        gio::high(BUFER_PIN);
#if (SPEAKER > 0)
        Speaker(300);
#endif
      }
#else
      // если напряжение снизилось менее напряжения разряда акб
      // то подавать сигнал каждые 10 сек
      if (ina.volt_aver <= signal_critical) {
        signal_time = 10;
      } else {
        signal_time = 60;
      }

#endif

#if (LOGGER > 0)
#if (LOGGER == 4)
      Sout.create_advanced(Ah, (uint16_t)ina.volt_aver, ina.curr_aver,
                           get_second_usr());
#else
      Sout.create(Ah, (uint16_t)ina.volt_aver, ina.curr_aver);
#endif
#endif

#if (TIME_LIGHT)
      disp.Light_low();
#endif

    } // прошла секунда

    if (butt.tick == Butt::OKHELD or butt.tick == Butt::STOPHELD)
      bitClear(profil.flags, Pr_flags::ACTIVITI); // завершить работу режима
  } // цикл работы
#ifdef BUFER_PIN
  gio::low(BUFER_PIN); // отключить реле нагрузки
#endif
  dcdc.Off();
#if (PROTECT_BLOCK)
  Protect::Open(false);
#endif
}