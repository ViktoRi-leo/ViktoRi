#include "Protections.h"
#include "Battery.h"
#include "DCDC.h"
#include "Display.h"
#include "INA226int.h"
#include <GyverIO.h>

void TimeCount::cal_real_tm(void) {
  // рассчитать количество всех секунд заряда (каждую секунду)
  real_tm = local + get_second_usr();
}

const uint16_t timer[3]{60, 900, 1800};

// структура для контроля критических изменений тока заряда
// и контроля скорости снижения тока

void Curr_critical_check::reset() {
  curr_critical = 0.0;
  curr_critical_int = 0;
  memcpy(counter, timer, 6);
}

// проверка тока на увеличение
Reason
Curr_critical_check::offset_critical_current(bool v_max,
                                             int16_t charge_current_aver) {
  // проверка на включение контроля в сервисных параметрах
  if (!eepGetService_flag(Serviceflags::FLAG_SECURITY))
    return Reason::begin;

  // если напряжение достигло максимального
  if (v_max) {
    // проверка тока на увеличение
    // суммируем разницу тока за 1 секунду
    curr_critical_int += (charge_current_aver - curr_previous);
    // суммируем (скользящее среднее)
    curr_critical += ((float)curr_critical_int - curr_critical) * 0.09;
    int16_t curr_critic = round(curr_critical);

    // если ток уменьшается  то сбрасываем значение
    if (curr_critic <= 0) {
      reset();
    } else if (curr_critic >= (int8_t)30) {
      if (curr_critic >
          (int16_t)eepGetService_num(eepService_num::CURRCRIT) * 10) {
        return Reason::curr_increased;
      }

      // в цикле проверить counter - если одно из значений равно 0
      // то то присваеваем ему счет 60, 900, 1800 сек
      for (uint8_t i = 0; i < 3; i++) {
        if (counter[i] > 0) {
          counter[i]--;
        } else {
          counter[i] = timer[i];
          if (curr_critic > curr_step[i])
            return Reason::curr_increased;
        }
      }
    }

    /* проверка тока на скорость снижения */
    // сгладить ток
    curr_speed += ((float)charge_current_aver - curr_speed) * 0.1;

    // сохранить текущее значение тока
    if (counterCurrSpeed == Time_Curr_decrease)
      curr_speed_previous = (int16_t)round(curr_speed);

    // проверка скорости снижения тока по завершении таймера
    if (--counterCurrSpeed == 0) {
      counterCurrSpeed = Time_Curr_decrease;
      // если ток снижается менее чем 5 мА за Time_Curr_decrease секунд, то
      // завершить заряд
      if ((curr_speed - curr_speed_previous) >= (int8_t)-5)
        return Reason::cur_stop;
    }

  } else {
    reset();
    curr_speed = (float)charge_current_aver;
  }
  curr_previous = charge_current_aver;
  return Reason::begin;
}

// структура для контроля критических изменений напряжения заряда
void Volt_critical_check::reset() {
  volt_critical = 0.0;
  volt_critical_int = 0;
  memcpy(counter, timer, 6);
}

// проверка напряжение на уменьшение
Reason Volt_critical_check::offset_critical_voltage(uint16_t charge_volt_aver) {
  // проверка на включение контроля в сервисных параметрах
  if (!eepGetService_flag(Serviceflags::FLAG_SECURITY))
    return Reason::begin;

  // разница напряжения за 1 секунду
  volt_critical_int = difference(charge_volt_aver, volt_previous);
  // суммируем (скользящее среднее)
  volt_critical += ((float)volt_critical_int - volt_critical) * 0.1;
  int16_t volt_critic = round(volt_critical);

  // если напряжение увеличивается то сбрасываем значение
  if (volt_critic >= 0) {
    reset();
  } else if (volt_critic < (int8_t)-30) {
    if (volt_critic <
        (int16_t)eepGetService_num(eepService_num::VOLTDROP) * (-10)) {
      return Reason::volt_decreased;
    }

    // в цикле проверить counter - если одно из значений равно 0
    // то то присваеваем ему счет 60, 900, 1800 сек
    for (uint8_t i = 0; i < 3; i++) {
      if (counter[i] > 0) {
        counter[i]--;
      } else {
        counter[i] = timer[i];
        if (volt_critical < volt_step[i])
          return Reason::volt_decreased;
      }
    }
  }
  volt_previous = charge_volt_aver;
  return Reason::begin;
}

// структура для фиксации достижения максимального напряжения заряда
// функция достижения максимального напряжения заряда
void Volt_max_check::max_volt_check(uint16_t charge_volt_init, uint16_t voltage,
                                    int16_t current) {
  // когда напряжение достигнет максимального то устанавливается
  // соответствующий флаг если напряджение снизилось менее 200 мВ то флаг
  // снимается
  if (!volt_max and (voltage >= charge_volt_init - 30) and
      current > (int8_t)20) {
    // если флаг макс напр не установлен и напряжение достигло
    // максимального то установить этот флаг
    volt_max = true;
  } else if (volt_max and (voltage < charge_volt_init - 200)) {
    // иначе если флаг макс напр установлен и напряжение стало ниже
    // максимального то снять этот флаг
    volt_max = false;
  }
}

uint8_t Disconnect_battery::check(int16_t current) {
  uint8_t fl = 0;
  // если прошло более 10 секунд и ток заряда меньше 10 mA
  if (timer)
    --timer;
  // если ток заряда меньше или равен 10 mA то отключить заряд и выйти в меню.
  if (!timer and current <= (int8_t)CURR_OFF_CHARGE) {
#if (SPEAKER > 0)
    Speaker(300);
#endif

    fl = 1;
    if (--time == 0) {
      regim_end = Reason::disconnect_batt;
      fl = 2;
#if (SPEAKER > 0)
      Speaker(500);
#endif
    }
  } else {
    time = TYME_OFF_CHARGE;
  }

  return fl;
}

// сброс таймера
void Disconnect_battery::reset_timer(void) { timer = 5; }

#if (VOLTIN == 1)
bool Waiting_power::power_check(void) {
  // если напряжение сети есть
  if (sysFlagGetBits(FlagsName::POWERON)) {
    // если флаг отсутствия питания включен и работа на паузе
    // то запустить работу
    if (flag_power) {
      dcdc.start(DCDC_CHARGE);
      flag_power = false;
      pause_second_usr(true);
#if (SPEAKER > 0)
      Speaker(300);
#endif
      lcd.clear();
      return true;
    }

  } else {
    // пропало напряжение сети
    // если флаг отсутствия питания выключен и работа не на паузе
    if (!flag_power) {
      // если пропадет напряжение от БП то работу заряда поставить на паузу
      dcdc.Off();
      flag_power = true;
      pause_second_usr(false);
#if (SPEAKER > 0)
      Speaker(300);
#endif
      return true;
    }
#if (TIME_LIGHT)
    disp.Light_power();
#endif
    print_power_error();
  }
  return false;
}
#endif

/* Структура для изменения напряжения или тока заряда */
// функция изменения напряжения или тока заряда
void Change_charge::change_charge(void) {
  // производится корректировка напряжения и тока заряда
  switch (butt.tick) {
  case Butt::RIGHT:
  case Butt::LEFT:
    // изменение напряжения или тока
    if (flag_change) {
      // изменение напряжения
      *max_voltage = volt_step(*max_voltage, butt.tick);
      dcdc.setVolt_charge(*max_voltage);
    } else {
      // изменение тока
      int16_t step = (int16_t)butt.tick * (int16_t)STEP_CURR;
      *max_current =
          constrain_my(*max_current, CUR_CHARGE_MIN, CURRMAXINT - 500, step);
      dcdc.setCur_charge(*max_current);
    }
    calc_crash();
    break;
  case Butt::OKCLICK:
    flag_change = !flag_change;
    break;
  case Butt::OKHELD:
  case Butt::STOPCLICK:
    // выйти из изменения
    flag = false;
    break;
  }
}

// функция проверки на превышение тока и напряжения
bool Change_charge::check_charge(void) {
  if (ina.ampersec > current_crash or
      (ina.voltsec > volt_crash and ina.ampersec > 20)) {
    dcdc.Off(); // отключить ШИМ
#if (SPEAKER > 0)
    Speaker(300);
#endif
#if (TIME_LIGHT)
    disp.Light_high(); // включение подсветки
#endif
    dcdc.start(DCDC_CHARGE); // перезапустить dcdc
    Delay(1000);
#if (SPEAKER > 0)
    Speaker(300);
#endif
    return true;
  }
  return false;
}

// функция расчета переменных защиты от повышенного напряжения и тока
void Change_charge::calc_crash(void) {
  if (max_voltage != nullptr and max_current != nullptr) {
    // рассчитать переменные защиты от повышенного напряжения и тока
    volt_crash = *max_voltage + (*max_voltage >> 4);    // * 1.025
    current_crash = *max_current + (*max_current >> 2); // * 1.25
  }
}

// функция контроля температуры акб
bool CheckTempBattery(void) {
  bool flag = false;
  if (getTempStatus(sens_temp::akb)) {
    // минимальная температура АКБ
    int8_t temp_min = pgm_read_byte(&sett_count[profil.akb.type][0]);
    // максимальная температура АКБ
    int8_t temp_max = pgm_read_byte(&sett_count[profil.akb.type][1]);

    // если температура акб вышла за пределы
    if (temp_akb <= temp_min or temp_akb >= temp_max) {
      flag = true;
      sysFlagClearBits(FlagsName::TEMP_AKB);
      dcdc.Off();
      pause_second_usr(false);
#if (TIME_LIGHT)
      disp.Light_high();
#endif
      lcd.clear();
      lcd.print(F(txt9)); // "Temp akb:"
#if (SPEAKER > 0)
      Speaker(1000);
#endif
      Regims regimss = regims;
      regims = Regims::WAIT;

      // режим ожидания по температуре
      while (!sysFlagGetBits(FlagsName::TEMP_AKB)) {
        sensor_survey();

        // выполнить раз в секунду...
        if (get_second()) {
          lcd.setCursor(9, 0);
          lcd.print(temp_akb);
          print_space();
          setCursory();
          print_volt_current(ina.voltsec, ina.ampersec, 3);

          // если температура акб вошла в допустимые пределы с гистерезисом
          if (temp_akb > (temp_min + 3) or temp_akb < (temp_max - 5)) {
            sysFlagSetBits(FlagsName::TEMP_AKB);
          }
        }

        if (butt.tick == Butt::OKHELD or butt.tick == Butt::STOPHELD) {
          sysFlagSetBits(FlagsName::TEMP_AKB);
        }
      }
      // выйти из режима ожидания по температуре
      regims = regimss;
      lcd.clear();
      pause_second_usr(true);
#if (SPEAKER > 0)
      Speaker(500);
#endif
    }
  }
  return flag;
}

// функции управления модулем защиты
namespace Protect {
// функция включения блокировки модуля защиты в зависимости от напряжения акб
// включает блокировку при напряжении акб менее 5 Вольт и отключает при напр.
// более 6 Вольт
void Guard(void) {
  if (ina.voltsec < 5000)
    gio::high(PROTECT_OPEN_PIN);
  else if (ina.voltsec > 6000)
    gio::low(PROTECT_OPEN_PIN);
}

// #define PROTECT_OPEN_PIN  A0  // принудительно открывает транзистор модуля
// защиты Q4 #define PROTECT_CLOSE_PIN A2  // принудительно закрывает транзистор
// модуля защиты Q4

// принудительно закрыть защитный транзистор - true
// отключить принудительное закрытие защитного транзистора - false
void Close(bool x) {
  if (x)
    gio::high(PROTECT_CLOSE_PIN);
  else
    gio::low(PROTECT_CLOSE_PIN);
}

// подать 12 вольт на транзисор модуля защиты - true
// отключить подачу 12 вольт на транзисор модуля защиты - false
void Open(bool x) {
  if (x)
    gio::high(PROTECT_OPEN_PIN);
  else
    gio::low(PROTECT_OPEN_PIN);
}

} // namespace Protect

// время (сек) до отключения ЗУ в режиме меню
#define RELAY_TIME ((uint16_t)POW_TIME * 60)
uint16_t relay_timer = RELAY_TIME;

// сбросить таймер
void Relay_butt_tick(void) {
  if (butt.tick) {
    relay_timer = RELAY_TIME;
  }
}

// Реле 220В

//  функция проверяет напряжение акб и включает реле 220В если напряжение акб
//  меньше нижнего предела. Рарешает отключать реле если напряжение акб больше
//  верхнего предела.
//  Вызывать раз в секунду
void Relay(void) {
  if (ina.voltsec < VOLT_AKB_RELE_ON and relay_timer == RELAY_TIME) {
    gio::high(POWER_PIN);                   // включить реле
    sysFlagClearBits(FlagsName::RELEY_OFF); // запрещено отключать реле
  } else if (ina.voltsec > VOLT_AKB_RELE_OFF)
    sysFlagSetBits(FlagsName::RELEY_OFF); // разрешено отключать реле

  Relay_off();
}

// функция отключения реле 220В если не включен ни какой режим и акб отключен.
inline void Relay_off(void) {
  // отключить БП если не включен ни какой режим и акб отключен.
  if (BitIsClear(profil.flags, Pr_flags::ACTIVITI) and ina.voltsec < 2000 and
      gio::read(POWER_PIN)) {
    if (relay_timer > 0) {
      if (--relay_timer == 0)
        gio::low(POWER_PIN); // отключить реле - зарядник отключится
    }
  } else {
    relay_timer = RELAY_TIME;
  }
}

// (true - включить реле, false - отключить реле)
void Relay_on(bool vkl) {
  if (vkl) {
    gio::high(POWER_PIN); // включить реле
  } else if (sysFlagGetBits(FlagsName::RELEY_OFF)) {
    gio::low(POWER_PIN); // отключать реле если включен флаг разрешающий
  }
}
