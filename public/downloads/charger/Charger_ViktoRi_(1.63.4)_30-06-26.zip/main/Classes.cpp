#include "DCDC.h"
#include "Display.h"
#include "INA226int.h"
#include "User_Setup_Loader.h"
#include "global.h"
#include <GyverIO.h>

/*======== АЦП ========*/

// разрядность АЦП (1024 по умолчанию)
// #define BITRATE 1024
#if defined(__LGT8FX8P__)
#define BITRATE 4096
#endif

#include <ADCaverage.h>

void ADC_begin(void) {
  // настройка АЦП
  // DIVIDER 64  // делитель частоты АЦП (2, 4, 8, 16, 32, 64, 128),
  // Выбрать источник опорного напряжения АЦП (ADC_1V1, ADC_AREF, ADC_VCC)
  ADC_init(DIVIDER, ADC_VCC);
}

#if (VOLTIN == 1)
// замер напряжения БП
VoltRead adc_v(POWER_ADC_PIN, DIV_R1, DIV_R2);
// максимальное напряжение от БП
uint16_t _vmax;

void Power_begin(void) {
  // Максимально допустимое напряжение от БП
  _vmax = (uint16_t)eepGetService_num(POWERMAX) * 1000;
}

// замер напряжения БП
void Power_sample(void) {
  // считываем данные с АЦП с накоплением и усреднением
  adc_v.sample();
}

uint16_t getPower(void) { return adc_v.volt; }

// корректировка напряжения БП
void Power_korrect(void) {
#if defined(__LGT8FX8P__)
  if (vkr.Vref != 1000) {
    DSC_MUL((uint16_t)adc_v.volt, (uint16_t)vkr.Vref); // умножить
    DA_DIV((uint16_t)1000);                            // разделить на 1000
    adc_v.volt = DA_get_int();
  }
#else
  if (vkr.Vref != 1000)
    adc_v.volt = (uint16_t)((uint32_t)adc_v.volt * vkr.Vref / 1000);
#endif
}

// проверить напряжение БП на наличие и на превышение
void Power_check(void) {
  static uint8_t _k = 0;
  // рассчитать среднее напряжение БП  20 мкс
  adc_v.compute();
#ifdef VKORRECT
  // корректировка напряжения БП
  Power_korrect();
#endif
  // если есть питание от БП (если напряжение от БП превышает напряжение на АКБ)
  if ((adc_v.volt > ina.voltsec + 1000))
    sysFlagSetBits(FlagsName::POWERON);
  else
    sysFlagClearBits(FlagsName::POWERON);

  if (adc_v.volt > _vmax) {
    // если напряжение превысит максимальное проводим 5 проверок
    if (++_k > 3) {
      _k = 0;
      // Напряжение от БП превышено
      sysFlagClearBits(FlagsName::POWERHIGH);
    }
  } else {
    _k = 0;
    // Напряжение от БП в норме
    sysFlagSetBits(FlagsName::POWERHIGH);
  }

#if (POWER == 2)
  // индикатор включения БП в сеть
  gio::write(POWER_PIN, sysFlagGetBits(FlagsName::POWERON));
#endif
}

#endif

/*======== Температура транзистора и акб ========*/

// Температура транзистора
int8_t temp_Q1 = 0;
// Температура аккумулятора
int8_t temp_akb = 0;
// Статус аккумулятора
uint8_t temp_status = 0b00000000;
// вернуть статус датчика температуры
bool getTempStatus(sens_temp num) { return bitRead(temp_status, num); }

/*======== Датчики температуры DS18B20 ========*/

// Библиотека датчика температуры DS18B20.
#include <microDS18B20.h>

#if (SENSTEMP1 == 1)

#ifdef DS18B20_PIN
// Уникальные адреса датчиков - считать можно в примере address_read
uint8_t ds_Q1_addr[] = DS_Q1_ADDR;

// Создаем термометр с адресацией
MicroDS18B20<DS18B20_PIN, ds_Q1_addr> tr_Q1;
#else
// датчик температуры силового транзистора на отдельном пине
MicroDS18B20<Q1_DS18_PIN> tr_Q1;
#endif

void temp_Q1_begin(void) {
  // датчик температуры DS18B20
  if (tr_Q1.online()) {
    // Установить разрешение термометра 9-12 бит,
    // разрешающей способность - 0,5 (1/2) °C, 0,25 (1/4) °C,
    // 0,125 (1/8) °C и 0,0625 (1/16) °C
    tr_Q1.setResolution(9);
    // Запросить новое преобразование температуры
    tr_Q1.requestTemp();
    bitSet(temp_status, q1);
  } else {
    temp_Q1 = (int8_t)(-127); // значение при отключенном датчике
    bitClear(temp_status, q1);
  }
}

// чтение температуры транзистора, вызывать раз в секунду
void temp_Q1_compute(void) {
  if (getTempStatus(sens_temp::q1)) {
    if (tr_Q1.readTemp()) {
      temp_Q1 = tr_Q1.getTempInt();
      tr_Q1.requestTemp(); // Запросить новое преобразование температуры
    }

// если подключен датчик температуры и разрешено уменьшать ток при превышении
// температуры транзистора
#if (GUARDTEMP > 0)
    // если превышена температура
    if (temp_Q1 > eepGetService_num(TEMPCUR)) {
      sysFlagSetBits(FlagsName::TR_Q1_ERR);
      // температура Q1 снизилась на 5 гр.
    } else if (sysFlagGetBits(FlagsName::TR_Q1_ERR) and
               temp_Q1 < eepGetService_num(TEMPCUR) - 5) {
      sysFlagClearBits(FlagsName::TR_Q1_ERR);
    }
#endif
  } else {
    temp_Q1_begin();
  }
}
#endif

#if (SENSTEMP2 == 1)
#ifdef DS18B20_PIN
// Уникальные адреса датчиков - считать можно в примере address_read
uint8_t ds_akb_addr[] = DS_AKB_ADDR;

// Создаем термометр с адресацией
MicroDS18B20<DS18B20_PIN, ds_akb_addr> tr_akb;
#else
// датчик температуры аккумулятора на отдельном пине
MicroDS18B20<AKB_DS18_PIN> tr_akb;
#endif

void temp_akb_begin(void) {
  // датчик температуры DS18B20
  if (tr_akb.online()) {
    // Установить разрешение термометра 9-12 бит,
    // разрешающей способность - 0,5 (1/2) °C, 0,25 (1/4) °C,
    // 0,125 (1/8) °C и 0,0625 (1/16) °C
    tr_akb.setResolution(9);
    tr_akb.requestTemp(); // Запросить новое преобразование температуры
    bitSet(temp_status, akb);
  } else {
    temp_akb = (int8_t)(-127); // значение при отключенном датчике
    bitClear(temp_status, akb);
  }
}

// чтение температуры акб, вызывать раз в секунду
void temp_akb_compute(void) {
  if (getTempStatus(sens_temp::akb)) {
    if (tr_akb.readTemp()) {
      temp_akb = tr_akb.getTempInt();
      tr_akb.requestTemp(); // Запросить новое преобразование температуры
    }
  } else {
    temp_akb_begin();
  }
}
#endif

/*======== Датчик температуры NTC транзистора ========*/

#define BITRATEGATE (uint16_t)(BITRATE - (BITRATE / 100))

#if (SENSTEMP1 == 2)
// датчик температуры NTC транзистора Q1
NTCRead ntc_q(Q1_NTC_PIN, NTCR1, NTCRS2, NTCB1, TEMPBASE1);

void temp_Q1_begin(void) {
  uint32_t t = millis_sys() + 300;
  do {
    ntc_Q1_sample();
  } while ((millis_sys() < t));
}

void ntc_Q1_sample(void) {
  // считываем данные с АЦП с накоплением и усреднением
  if (ntc_q.sample()) {
    if (ADC_read() > BITRATEGATE) {
      bitClear(temp_status, q1);
    } else {
      bitSet(temp_status, q1);
    }
  }
}

// температура NTC транзистора
void temp_Q1_compute(void) {
  // рассчитать температуру термистора 300 мкс
  if (getTempStatus(sens_temp::q1)) {
    ntc_q.compute();
    temp_Q1 = ntc_q.temp;

    // если подключен датчик температуры и разрешено уменьшать ток при
    // превышении температуры транзистора
#if (GUARDTEMP > 0)
    // если превышена температура
    if (temp_Q1 > eepGetService_num(TEMPCUR))
      sysFlagSetBits(FlagsName::TR_Q1_ERR); // превышена температура Q1
    else if (sysFlagGetBits(FlagsName::TR_Q1_ERR) and
             temp_Q1 < eepGetService_num(TEMPCUR) - 5)
      sysFlagClearBits(
          FlagsName::TR_Q1_ERR); // температура Q1 снизилась на 5 гр.
#endif
  } else {
    temp_Q1 = (int8_t)(-127); // значение при отключенном датчике
  }
}
#endif

#if (SENSTEMP2 == 2)
// датчик температуры NTC аккумулятора
NTCRead ntc_akb(AKB_NTC_PIN, NTCR2, NTCRS2, NTCB2, TEMPBASE2);

void temp_akb_begin(void) {
  uint32_t t = millis_sys() + 300;
  do {
    ntc_akb_sample();
  } while ((millis_sys() < t));
}

void ntc_akb_sample(void) {
  if (ntc_akb.sample()) {
    // если датчик NTC отключить то АЦП выдас максимум
    if (ADC_read() > BITRATEGATE) {
      bitClear(temp_status, akb);
    } else {
      bitSet(temp_status, akb);
    }
  }
}

// температура NTC аккумулятора
void temp_akb_compute(void) {
  if (getTempStatus(sens_temp::akb)) {
    // рассчитать температуру термистора 300 мкс
    ntc_akb.compute();
    temp_akb = ntc_akb.temp;
  } else {
    temp_akb = (int8_t)(-127); // значение при отключенном датчике
  }
}
#endif

/*======== Кулер ========*/

// класс управления кулером
// инициализация
void Cooler::begin(void) {
  // Пины D9 и D10 - 30 Гц для вентилятора
  // Настройка таймера 1 для ШИМ
  TCCR1A = 0b00000001; // 8bit
  TCCR1B = 0b00000101; // x1024 phase correct
  _kul = 0;            // значение ШИМ кулера
}

void Cooler::ONonse(bool x) {
  onse = x;
  digitalWrite_speed(PWMKUL_PIN, x);
}

void Cooler::control(void) {
  if (onse)
    return;

  int16_t amp = abs(ina.ampersec); // чтение тока
  switch ((uint8_t)eepGetService_flag(Serviceflags::FLAG_FANMODE)) {
  case 0:
    // управление кулером ШИМ
    if (temp_Q1 >= (uint8_t)FAN_DEG_MAX)
      _kul = 255;
    else
      _kul = (getTempStatus(sens_temp::q1))
                 ? ((temp_Q1 >= (int8_t)FAN_DEG_ON)
                        ? (_kul ? map_my(temp_Q1, FAN_DEG_OFF, FAN_DEG_MAX, 70,
                                         255)
                                : 150)
                        : _kul)
                 : ((amp >= (int16_t)FAN_CUR_ON)
                        ? (_kul ? map_my(amp, FAN_CUR_OFF, FAN_CUR_MAX, 70, 255)
                                : (uint8_t)150)
                        : _kul);
    // если кулер включен
    if (_kul) {
      _kul = (getTempStatus(sens_temp::q1))
                 ? ((temp_Q1 <= (uint8_t)FAN_DEG_OFF) ? 0 : _kul)
                 : ((amp <= (int16_t)FAN_CUR_OFF) ? 0 : _kul);
    }
    analogWrite_my(PWMKUL_PIN, _kul);
    break;

  case 1:
    // управление кулером вкл/откл
    // если кулер включен
    if (_kul) {
      _kul = (getTempStatus(sens_temp::q1))
                 ? (temp_Q1 <= (uint8_t)FAN_DEG_OFF ? false : _kul)
                 : ((amp <= (int16_t)FAN_CUR_OFF) ? false : _kul);
    } else {
      // если кулер отключен
      _kul = (getTempStatus(sens_temp::q1))
                 ? (temp_Q1 >= (uint8_t)FAN_DEG_ON ? true : _kul)
                 : ((amp >= (int16_t)FAN_CUR_ON) ? true : _kul);
    }
    gio::write(PWMKUL_PIN, _kul);
    break;
  }
}

Cooler fan;

/*======== Энкодер, кнопки ========*/

// void setEncType(uint8_t type);
#define EB_DEB_TIME 50    // таймаут гашения дребезга кнопки (кнопка)
#define EB_CLICK_TIME 500 // таймаут ожидания кликов (кнопка)
#define EB_HOLD_TIME 1000 // таймаут удержания (кнопка)
#define EB_STEP_TIME 200  // таймаут импульсного удержания (кнопка)
#define EB_FAST_TIME 30   // таймаут быстрого поворота (энкодер)
#define EB_NO_CALLBACK    // отключить обработчик событий attach
// отключить счётчик энкодера [VirtEncoder, Encoder,EncButton]
#define EB_NO_COUNTER
// отключить буферизацию энкодера (экономит 2 байта оперативки)
// #define EB_NO_BUFFER

// более сильная функция для замены в библиотеке EncButton
uint32_t EB_uptime() { return (uint32_t)millis_sys(); }

// Библиотека энкодера и кнопок
#include <EncButton.h>

#if (ENCBUTT == 0)
// 0 - только энкодер с кнопкой
EncButtonT<ENC_S2, ENC_S1, ENC_KL> enc(INPUT_PULLUP, INPUT_PULLUP);
#elif (ENCBUTT == 1)
// 1 - только кнопки
ButtonT<PUSK> OK(INPUT_PULLUP);     // кнопка - Пуск
ButtonT<MINUS> Minus(INPUT_PULLUP); // кнопка - Минус
ButtonT<PLUS> Plus(INPUT_PULLUP);   // кнопка - Плюс
ButtonT<STOP> Stop(INPUT_PULLUP);   // кнопка - Стоп
#elif (ENCBUTT == 2)
// 2 - энкодер + OK + Stop
EncButtonT<ENC_S2, ENC_S1, ENC_KL> enc(INPUT_PULLUP, INPUT_PULLUP);
ButtonT<PUSK> OK(INPUT_PULLUP);
ButtonT<STOP> Stop(INPUT_PULLUP);
#elif (ENCBUTT == 3)
// 3 - энкодер + все кнопки
EncButtonT<ENC_S2, ENC_S1, ENC_KL> enc(INPUT_PULLUP, INPUT_PULLUP);
ButtonT<PUSK> OK(INPUT_PULLUP);
ButtonT<MINUS> Minus(INPUT_PULLUP);
ButtonT<PLUS> Plus(INPUT_PULLUP);
ButtonT<STOP> Stop(INPUT_PULLUP);
#else
#error "ENCBUTT must be 0, 1, 2 or 3"
#endif

void Enbutt::begin(void) {
#if (ENCBUTT == 0 or ENCBUTT == 2 or ENCBUTT == 3)
  enc.setEncType(EBSTEP);
#endif
}

// функция опрашивает энкодер и кнопки.
void Enbutt::Tick(void) {
  tick = 0;
// -1 - left, 1 - right, 16 - click, 2 - hold, 4 - step
#if (ENCBUTT == 0)
  // 0 - только энкодер
  if (enc.tick()) {
    if (enc.turn())
      tick = enc.dir(); // -1 - left, 1 - right,
    else {
      if (enc.click())
        tick = Butt::OKCLICK;
      if (enc.hold())
        tick = Butt::OKHELD;
    }
  }
#elif (ENCBUTT == 1)
  // 1 - только кнопки
  if (OK.tick()) {
    if (OK.click())
      tick = Butt::OKCLICK;
    if (OK.hold())
      tick = Butt::OKHELD;
  }
  if (Stop.tick()) {
    if (Stop.click())
      tick = Butt::STOPCLICK;
    if (Stop.hold())
      tick = Butt::STOPHELD;
  }
  if (Plus.tick()) {
    if (Plus.click() or Plus.step())
      tick = Butt::RIGHT;
  }
  if (Minus.tick()) {
    if (Minus.click() or Minus.step())
      tick = Butt::LEFT;
  }
#elif (ENCBUTT == 2)
  // 2 - энкодер + OK + Stop
  if (enc.tick()) {
    if (enc.turn())
      tick = enc.dir(); // -1 - left, 1 - right,
    else {
      if (enc.click())
        tick = Butt::OKCLICK;
      if (enc.hold())
        tick = Butt::OKHELD;
    }
  }
  if (OK.tick()) {
    if (OK.click())
      tick = Butt::OKCLICK;
    if (OK.hold())
      tick = Butt::OKHELD;
  }
  if (Stop.tick()) {
    if (Stop.click())
      tick = Butt::STOPCLICK;
    if (Stop.hold())
      tick = Butt::STOPHELD;
  }
#elif (ENCBUTT == 3)
  // 3 - энкодер + все кнопки
  if (enc.tick()) {
    if (enc.turn())
      tick = enc.dir(); // -1 - left, 1 - right,
    else {
      if (enc.click())
        tick = Butt::OKCLICK;
      if (enc.hold())
        tick = Butt::OKHELD;
    }
  }
  if (OK.tick()) {
    if (OK.click())
      tick = Butt::OKCLICK;
    if (OK.hold())
      tick = Butt::OKHELD;
  }
  if (Stop.tick()) {
    if (Stop.click())
      tick = Butt::STOPCLICK;
    if (Stop.hold())
      tick = Butt::STOPHELD;
  }
  if (Plus.tick()) {
    if (Plus.click() or Plus.step())
      tick = Butt::RIGHT;
  }
  if (Minus.tick()) {
    if (Minus.click() or Minus.step())
      tick = Butt::LEFT;
  }
#endif
#if (TIME_LIGHT)
  if (tick)
    disp.Light_high();
#endif
}

// функция проверяет три клика энкодера или ОК
bool Enbutt::Click3(void) {
  bool flag = false;

#if (ENCBUTT == 0 or ENCBUTT == 3)
  if (enc.clicks == 3)
    flag = true;
#endif

#if (ENCBUTT == 1 or ENCBUTT == 2 or ENCBUTT == 3)
  if (OK.clicks == 3)
    flag = true;
#endif

  return flag;
}

Enbutt butt;
// Enbutt butt = Enbutt();

#if (LOGGER > 0)
/*======== отправка значений в сетевой порт ========*/

#if (LOGGER == 1)
// буфер отправки - байт
#define MU_TX_BUF 16
#elif (LOGGER == 2 or LOGGER == 3 or LOGGER == 4)
// буфер отправки - байт
#define MU_TX_BUF 30
#else
// буфер отправки - байт
#define MU_TX_BUF 4
#endif
// буфер приема - байт
#define MU_RX_BUF 4
#if (LOGGER == 2 or LOGGER == 3)
// подключить Print.h
#define MU_PRINT
#endif

#include <MicroUART.h>
MicroUART mSerial;

void serial_begin(void) {
  mSerial.begin(SERIAL_SPEED); // 9600   115200
}

// формируем основные данные
void Serial_Out::create(int32_t Achas, uint16_t volt, int16_t amper) {
  // напряжение на АКБ (милливольт)/1000
  send_str.volt = volt ? volt : ina.voltsec;
  // ток АКБ (миллиампер)/1000
  send_str.amper = amper ? amper : ina.ampersec;
#if defined(__LGT8FX8P__)
  // Полученная_отданная емкость АКБ (А/ч)) /1000
  send_str.Achas =
      Achas ? DSC_DIV_get((int32_t)(Achas + 500), (uint16_t)1000) : 0;
#else
  // Полученная_отданная емкость АКБ (А/ч)) /1000
  send_str.Achas = Achas ? (Achas + 500) / 1000 : 0;
#endif

#if (VOLTIN == 1)
  send_str.volt_in = getPower(); // напряжение от БП (милливольт) /1000
#endif
#if (SENSTEMP1 > 0)
  send_str.tQ1 = temp_Q1; // Температура на Q1 (градусы)
#endif
#if (SENSTEMP2 > 0)
  send_str.tAkb = temp_akb; // 6 Температура АКБ (градусы)
#endif
}

// Расширенные данные LOGGER = 4
void Serial_Out::create_advanced(int32_t Achas, uint16_t volt, int16_t amper,
                                 uint32_t time_current) {
  send_str_adv.volt = volt ? volt : ina.voltsec;
  send_str_adv.amper = amper ? amper : ina.ampersec;
#if defined(__LGT8FX8P__)
  send_str_adv.Achas =
      Achas ? DSC_DIV_get((int32_t)(Achas + 500), (uint16_t)1000) : 0;
#else
  send_str_adv.Achas = Achas ? (Achas + 500) / 1000 : 0;
#endif

#if (VOLTIN == 1)
  send_str_adv.volt_in = getPower();
#endif
#if (SENSTEMP1 > 0)
  send_str_adv.tQ1 = temp_Q1;
#endif
#if (SENSTEMP2 > 0)
  send_str_adv.tAkb = temp_akb;
#endif

  // Дополнительные данные
  send_str_adv.mode = profil.Regim;
  send_str_adv.type_akb = profil.akb.type;
  send_str_adv.capacity = profil.akb.capacity;
  send_str_adv.active_flag = bitRead(profil.flags, Pr_flags::ACTIVITI);

  send_str_adv.round_current = eeGetRound();
  send_str_adv.profil = vkr.profil;
  send_str_adv.time_charge = time_current;

  send_str_adv.Wh_charge = profil.charge.stat.wh / 1000;
  send_str_adv.regim_end = (uint8_t)regim_end;
  send_str_adv.regims = regims;
}

// Вывод логов в сетевой порт. Вызывать постоянно раз в секунду
void Serial_Out::Serial_out(void) {
  if (--_tm == 0) {
    _tm = LOGGTIME;

#if (LOGGER == 1)
    send_str.crc = 0;
    for (uint8_t i = 0; i < sizeof(Log_get) - 1; i++) {
      send_str.crc += ptr[i]; // Расчет контрольной суммы
      mSerial.write(ptr[i]);  // передать данные
    }
    mSerial.write(ptr[sizeof(Log_get) - 1]); // передать символ CRC

#elif (LOGGER == 2)
    _time += LOGGTIME;
    mSerial.print(F(txt_ViktoRi)); // ViktoRi  // начало посылки
    mSerial.write(';');
    mSerial.print(_time); // время
    mSerial.write(';');
    serial_print(fl((float)send_str.volt), 3);
    serial_print(fl((float)send_str.amper), 3);
    serial_print(fl((float)send_str.Achas), 4);
    serial_print(fl((float)send_str.volt_in), 3); // напряжение от БП Вольт
    serial_print((float)send_str.tQ1, 0);         // Температура на Q1 (градусы)
    serial_print((float)send_str.tAkb, 0);        // 6 Температура АКБ (градусы)
    mSerial.println();                            // конец посылки

#elif (LOGGER == 3)
    mSerial.write('$'); // начало посылки
    serial_print(send_str.volt);
    serial_print(send_str.amper);
    serial_print(send_str.Achas);
    serial_print(send_str.volt_in); // напряжение от БП (милливольт)/1000
    serial_print(send_str.tQ1);     // Температура на Q1 (градусы)
    serial_print(send_str.tAkb);    // 6 Температура АКБ (градусы)
    mSerial.write(';');             // конец посылки

#elif (LOGGER == 4)
    // Расширенный лог
    send_str_adv.crc = 0;
    for (uint8_t i = 0; i < sizeof(Log_get_advanced) - 1; i++) {
      send_str_adv.crc += ptr_adv[i]; // Расчет контрольной суммы
      mSerial.write(ptr_adv[i]);      // передать данные
    }
    // передать символ CRC
    mSerial.write(ptr_adv[sizeof(Log_get_advanced) - 1]);
#endif
  }
}

#if (LOGGER == 2)
void Serial_Out::serial_print(float x, uint8_t y) {
  mSerial.print(x, y);
  mSerial.write(';');
}

float Serial_Out::fl(float y) { return y / 1000; }
#endif

#if (LOGGER == 3)
void Serial_Out::serial_print(int32_t x) {
  mSerial.print(x);
  mSerial.write(' ');
}
#endif

Serial_Out Sout;
#endif

#if (MCP4725DAC)
/*======== ЦАП MCP4725 ========*/
// библиотека для работы с ЦАП MCP4725
// просто отправляет значение 0-4095 напряжения в MCP4725
#include <microWire.h>

// Запись 16-ти битного регистра MCP4725
void MCP4725::setVoltage(uint16_t data) {
  // Начинаем передачу
  Wire.beginTransmission(_address);
  // передаем контрольный байт (010-Sets in Write mode)
  Wire.write(0b01000000);
  // Upper data bits (D11.D10.D9.D8.D7.D6.D5.D4)Отправляем старший байт
  Wire.write((uint8_t)(data >> 4));
  // Lower data bits (D3.D2.D1.D0.x.x.x.x));
  // Отправляем младший байт
  Wire.write((uint8_t)((data % 12) << 4));
  Wire.endTransmission(); // Заканчиваем передачу
}

// Проверка присутствия
bool MCP4725::testConnection(void) {
  Wire.beginTransmission(_address);     // Начинаем передачу
  return (bool)!Wire.endTransmission(); // Сразу заканчиваем
}

MCP4725 dac = MCP4725(ADDR4725);
#endif