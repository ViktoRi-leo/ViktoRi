#include "global.h"
#include "Battery.h"
#include "DCDC.h"
#include "Display.h"
#include "INA226int.h"
#include "operations.h"

// структура для Дозаряда
struct Add_charge {
  // Дозаряд
  // два значения напряжений при дозаряде
  uint16_t add_volt_max = 0; // напряжение при максимальном токе
  uint16_t add_volt_min = 0; // напряжение при минимальном токе

  // когда разница между напряжениями станет менее 300 мВ то завершить дозаряд
  bool add_end(void) {
    return ((add_volt_min + Volt_difference_mV) >= add_volt_max);
  }
};

// функция Дозаряда
void AddCharge(uint16_t volt_charge_init, int16_t curr_charge_init,
               int16_t curr_min, uint32_t time_charge) {

  if (profil.akb.type >= Akb_type::LI_ION) {
    bitClear(profil.flags, Pr_flags::ACTIVITI);
    lcd.clear();
    print_mode(TYPE_AKB);
    print_space();
    print_mode(MODE);
    setCursory();
    print_mode(ERROR); // "error"
#if (SPEAKER > 0)
    Speaker(300);
#endif
    pauses();
    return;
  }

  regims = Regims::REGIM_ADDCHARGE;

#if (PROTECT_BLOCK)
  Protect::Guard();
#endif
  // вывод напряжения и тока заряда
  print_volt_current(volt_charge_init, curr_charge_init);
  print_hour((uint8_t)time_charge); // вывод времени

  time_charge *= 3600;

  TimeCount tyme;
  // время дозаряда
  tyme.local = profil.add.stat.time;

  // флаг активности режима
  bool activiti = true;

  // 10 мин
  uint16_t sec_600 = 600;
  // шаги
  uint8_t step = 0;
  // переменная времени переключения, сек.
  uint8_t tsw = 10;

  uint16_t Timezar = 0;

  Add_charge add;

  uint16_t v1 = 0;

  Curr_critical_check cc;
  Volt_critical_check vc;
  Volt_max_check vmax;
  Disconnect_battery dbat;
#if (VOLTIN == 1)
  Waiting_power wpower;
#endif

  Delay(3000);
  dcdc.start(DCDC_CHARGE);
  dcdc.begin(volt_charge_init, curr_charge_init);

  lcd.clear();

  // старт счета времени
  start_second_usr();
  // цикл заряда
  while (activiti and bitRead(profil.flags, Pr_flags::ACTIVITI)) {
    sensor_survey();

    if (butt.tick) {
      // если кнопка нажата
      switch (butt.tick) {
      case Butt::STOPHELD:
      case Butt::OKHELD:
        // завершить заряд
        if (op_window == 0)
          bitClear(profil.flags, Pr_flags::ACTIVITI);
        break;
      case Butt::RIGHT:
      case Butt::LEFT:
        // изменение номера экрана
        window_change(2);
        break;
      }
    }

    // выполнить раз в секунду...
    if (get_second()) {
#if (VOLTIN == 1)
      if (wpower.power_check()) {
        // если произошло изменение состояния питания
        cc.reset();
        vc.reset();
        vmax.volt_max = false;
        v1 = 0;
        dcdc.start(DCDC_CHARGE);
      }
#endif

      step = sysFlagGetBits(FlagsName::POWERON);

#if (LOGGER == 4)
      Sout.create_advanced(profil.add.stat.ah, ina.volt_aver, ina.curr_aver,
                           tyme.real_tm);
#elif (LOGGER > 0)
      Sout.create(profil.add.stat.ah, ina.volt_aver, ina.curr_aver);
#endif

#if (TIME_LIGHT > 0)
      disp.Light_low();
#endif
    } // ... выполнить раз в секунду

    // выполнить раз в секунду шаги...
    switch (step) {
    case 0:
      // пустой шаг
      _NOP();
      break;

    case 1:
      // рассчитать количество всех секунд заряда
      tyme.cal_real_tm();
      // статистика
      profil.add.stat.time = tyme.real_tm;
      profil.add.stat.ah += Calc_AhWh((int32_t)ina.ampersec);
      profil.add.stat.wh += Calc_AhWh(ina.getsPower());

      if (tyme.real_tm > time_charge) {
        //  если время больше установленного завершить работу
        activiti = false;
        regim_end = Reason::out_time; // закончилось время
      }

      // выполнить если включен таймер завершения заряда
      if (Timezar) {
        // если таймер вышел то завершить заряд
        if (--Timezar == 0)
          activiti = false;
      }
      break;

    case 2:
      // вывод на дисплей
      Display_print(profil.add.stat.ah, profil.add.stat.wh, tyme.real_tm,
                    Percentage(curr_min));
      break;

    case 3:
      // выполнить раз в 600 сек
      if (--sec_600 == 0) {
        sec_600 = 600;

        // сохранить настройки и статистику в EEPROM
        eepSavedStruct();

        if ((curr_min < curr_charge_init) and !Timezar and add.add_end()) {
          // если разница напряжений при максимальном и минимальном тока
          // ниже 0,5 Вольт то включить таймер
          if (!Timezar)
            Timezar = Time_AddCarge; //  установить таймер на 30 минут
          regim_end = Reason::volt_maxCur_min;
        }
      }
      break;

    case 4:
#if (PROTECT_BLOCK)
      Protect::Guard();
#endif

#ifdef TYME_OFF_CHARGE
      // если ток заряда меньше или равен 10 mA 
      switch (dbat.check(ina.ampersec)) {
      case 1:
        // сбросить значения
        cc.reset();
        vc.reset();
        v1 = 0;
        vmax.volt_max = false;
        break;

      case 2:
      // то отключить заряд
        bitClear(profil.flags, Pr_flags::ACTIVITI);
        break;
      }
#endif

#if (BATT_TEMP_CONTROL and SENSTEMP2)
      // контроль температуры Акб
      if (CheckTempBattery()) {
        // если была пауза по температуре
        cc.reset();
        vc.reset();
        vmax.volt_max = false;
        dcdc.start(DCDC_CHARGE);
      }
#endif
      break;

    case 5:
      if ((curr_min < curr_charge_init)) {
        if (tsw)
          tsw--;
        auto vt = difference(ina.volt_aver, v1);
        if (!tsw and (abs(vt) < 10)) {
          // если время завершилось и напряжение стабилизировалось
          if ((dcdc.getCur_charge() == curr_charge_init)) {
            // если ток максимальный
            // сохранить максимальное напряжение
            add.add_volt_max = ina.volt_aver;
            // установить минимальный ток
            dcdc.setCur_charge(profil.add.current_min);
          } else {
            // если ток минимальный
            // сохранить минимальное напряжение
            add.add_volt_min = ina.volt_aver;
            // установить максимальный ток
            dcdc.setCur_charge(curr_charge_init);
          }
          tsw = 10; // ожидание 10 сек
        } else
          v1 = ina.volt_aver;
      } else {
        // когда напряжение достигнет максимального то устанавливается
        // соответствующий флаг если напряджение снизилось менее 200 мВ то флаг
        // снимается
        vmax.max_volt_check(volt_charge_init, ina.volt_aver, ina.curr_aver);

        // проверка критических значений тока
        regim_end = cc.offset_critical_current(vmax.volt_max, ina.curr_aver);
        // если ток увеличивается
        if (regim_end == Reason::curr_increased) {
          bitClear(profil.flags, Pr_flags::ACTIVITI); // завершить заряд
        } else {
          // проверка критических значений напряжения
          regim_end = vc.offset_critical_voltage(ina.volt_aver);

          // если напряжение начало уменьшаться
          if (regim_end == Reason::volt_decreased) {
            bitClear(profil.flags, Pr_flags::ACTIVITI); // завершить заряд
          }
        }
      }

      break;
    } // ...выполнить раз в секунду шаги

    if (step) {
      if (++step > 5)
        step = 0;
    }
  }
  // цикл заряда

  dcdc.Off();       // отключить заряд, разряд.
  eepSavedStruct(); // сохранить настройки
}