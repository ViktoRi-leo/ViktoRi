#include "DCDC.h"
#include "Display.h"
#include "INA226int.h"
#include "global.h"
#include "operations.h"

// функция Асимметричного заряда
void Asymmetric(void) {

  regims = Regims::REGIM_CHARGE;

#if (PROTECT_BLOCK)
  Protect::Guard();
#endif

  // вывод напряжения и тока заряда
  print_volt_current(profil.asym.voltage, profil.asym.current);
  print_hour(profil.asym.time); // вывод времени

  // время берется из Заряда (пока что)
  const uint32_t time_charge = (uint32_t)profil.asym.time * 3600;

  TimeCount tyme;
  // время заряда или дозаряда
  tyme.local = profil.asym.stat.time;

  // флаг активности режима
  bool activiti = true;

  // флаг максимального напряжения
  bool max_volt = false;

  Disconnect_battery dbat;
#if (VOLTIN == 1)
  Waiting_power wpower;
#endif

  // 10 мин
  uint16_t sec_600 = 600;
  // шаги
  uint8_t step = 0;
  // счет времени
  uint16_t period = profil.asym.period_charge;
  // флаг периода (заряд/разряд)
  bool oscil = true;
  uint8_t time_pause_assimetric = 0;
  regims = Regims::REGIM_CHARGE;

  Delay(3000);
  dcdc.start(DCDC_CHARGE);
  dcdc.begin(profil.asym.voltage, profil.asym.current);

  lcd.clear();

  // старт счета времени
  start_second_usr();
  // цикл заряда
  while (activiti and bitRead(profil.flags, Pr_flags::ACTIVITI)) {
    sensor_survey();

    if (butt.tick) {
      // если кнопка нажата
      switch (butt.tick) {
      case Butt::STOPHELD:
      case Butt::OKHELD:
        // завершить заряд
        if (op_window == 0)
          bitClear(profil.flags, Pr_flags::ACTIVITI);
        break;
      case Butt::RIGHT:
      case Butt::LEFT:
        // изменение номера экрана
        window_change(2);
        break;
      }
    }

    // выполнить раз в секунду...
    if (get_second()) {
#if (VOLTIN == 1)
      // если произошло изменение состояния питания
      if (wpower.power_check()) {
        dcdc.start(DCDC_CHARGE);
        sec_600 = 600;
        step = 0;
        oscil = true;
        time_pause_assimetric = 0;
        regims = Regims::REGIM_CHARGE;
        dcdc.begin(profil.asym.voltage, profil.asym.current);
        oscil = true;
      }
#endif

      step = sysFlagGetBits(FlagsName::POWERON);

#if (LOGGER == 4)
      Sout.create_advanced(profil.asym.stat.ah, ina.volt_aver, ina.curr_aver,
                           tyme.real_tm);
#elif (LOGGER > 0)
      Sout.create(profil.asym.stat.ah, ina.volt_aver, ina.curr_aver);
#endif

#if (TIME_LIGHT > 0)
      disp.Light_low();
#endif
    } // ... выполнить раз в секунду

    // выполнить раз в секунду шаги...
    switch (step) {
    case 0:
      // пустой шаг
      _NOP();
      break;

    case 1:
      // рассчитать количество всех секунд заряда
      tyme.cal_real_tm();
      // статистика
      profil.asym.stat.time = tyme.real_tm;
      profil.asym.stat.ah += Calc_AhWh((int32_t)ina.ampersec);
      profil.asym.stat.wh += Calc_AhWh(ina.getsPower());

      if (tyme.real_tm > time_charge) {
        //  если время больше установленного завершить работу
        activiti = false;
        regim_end = Reason::out_time; // закончилось время
      }
      break;

    case 2:
      // вывод на дисплей
      Display_print(profil.asym.stat.ah, profil.asym.stat.wh, tyme.real_tm,
                    0); // Percentage(curr_min)
      switch (op_window) {
      case 3:

        break;
      }
      break;

    case 3:
      // выполнить раз в 600 сек
      if (--sec_600 == 0) {
        sec_600 = 600;

        // сохранить настройки и статистику в EEPROM
        eepSavedStruct();

        // условия завершения работы
        // если минимальный ток меньше тока завершения заряда и напряжение
        // достигло максимального то завершить заряд
        /*  if (max_volt and (ina.ampersec <= curr_min)) {
            regim_end = Reason::volt_maxCur_min;
            activiti = false; // завершить заряд
          } */
      }
      break;

    case 4:
#if (PROTECT_BLOCK)
      Protect::Guard();
#endif

#ifdef TYME_OFF_CHARGE
      if (regims == Regims::REGIM_CHARGE) {
        // если ток заряда меньше или равен 10 mA
        switch (dbat.check(ina.ampersec)) {
        case 1:
          break;

        case 2:
          // то отключить заряд
          bitClear(profil.flags, Pr_flags::ACTIVITI);
          break;
        }
      }
#endif

#if (BATT_TEMP_CONTROL and SENSTEMP2)
      // контроль температуры Акб
      if (CheckTempBattery()) {
        // если была пауза по температуре
        dcdc.start(DCDC_CHARGE);
        sec_600 = 600;
        step = 0;
        oscil = true;
        time_pause_assimetric = 0;
        regims = Regims::REGIM_CHARGE;
        dcdc.begin(profil.asym.voltage, profil.asym.current);
        oscil = true;
      }
#endif
      break;

    case 5:
      // ассиметричный режим
      switch (regims) {
      case Regims::REGIM_CHARGE:
      case Regims::REGIM_DISCHARGE:
        if (period > 0) {
          period--; // отсчет времени работы периода
        } else {
          dcdc.Off(); // отключить заряд/разряд
          regims = Regims::WAIT;
          time_pause_assimetric = profil.asym.pause; // включить паузу
        }
        break;
      case Regims::WAIT:
        if (--time_pause_assimetric == 0) {
          if (oscil) {
            // период заряда - переключиться в разряд
            regims = Regims::REGIM_DISCHARGE;
            period = profil.asym.period_discharge;
            dcdc.start(DCDC_DISCHARGE);
            // задает напряжение и ток разряда
            dcdc.begin(profil.asym.voltage >> 1, profil.asym.current_discharge);
#if (FAN > 0 and FAN_DISCHAR_ON == 1)
            fan.ONonse(true);
#endif
          } else {
            // период разряда - переключиться в заряд
            regims = Regims::REGIM_CHARGE;
            period = profil.asym.period_charge;
            dcdc.start(DCDC_CHARGE);
            // задает напряжение и ток заряда
            dcdc.begin(profil.asym.voltage, profil.asym.current);
#if (FAN > 0 and FAN_DISCHAR_ON == 1)
            fan.ONonse(false);
#endif
          }
          oscil = !oscil; // переключить флаг режима
        }
        break;
      }
      break;
    }
    // ...выполнить раз в секунду шаги

    if (step) {
      if (++step > 5)
        step = 0;
    }
  }
  // цикл заряда

  dcdc.Off();       // отключить заряд, разряд.
  eepSavedStruct(); // сохранить настройки
#if (FAN > 0)
  fan.ONonse(false); // автоматический режим кулера
#endif
}
