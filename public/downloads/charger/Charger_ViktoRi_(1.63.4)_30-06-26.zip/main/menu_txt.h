#pragma once
#include <Arduino.h>
#include "User_Setup_Loader.h"


/* ***** русский (!для дисплеев с поддержкой русского языка!) ***** */  
#if (INTERFACE == 0)
// пункты главного меню
const char menu_profil[] PROGMEM = "Pr:";                                                         //  0   Профиль
const char menu_akb_capacity[] PROGMEM = "\x45\xBC\xBA\x6F\x63\xBF\xC4 \x41\x4B\xA0";             //  1   Емкость  // АКБ
const char menu_akb_type[] PROGMEM = "\x54\xB8\xBE \x41\x4B\xA0";                                 //  2   Тип АКБ
const char menu_akb_volt[] PROGMEM = "\x48\x61\xBE\x70\xC7\xB6\x65\xBD\xB8\x65 \x41\x4B\xA0";     //  3   Напряжение АКБ
const char menu_mode[] PROGMEM = "\x50\x65\xB6\xB8\xBC \x70\x61\xB2\x6F\xBF\xC3";                 //  4   Режим работы
const char menu_settings[] PROGMEM = "\x48\x61\x63\xBF\x70\x6F\xB9\xBA\xB8";                      //  5   Настройки
const char menu_resist_akb[] PROGMEM = "\x43\x6F\xBE\x70\x6F\xBF\x2E\x41\x4B\xA0";                //  6   Сопрот. АКБ
const char menu_statistic[] PROGMEM = "\x43\xBF\x61\xBF\xB8\x63\xBF\xB8\xBA\x61";                 //  7   Статистика
const char menu_system[] PROGMEM = "\x43\xB8\x63\xBF\x65\xBC\x61";                                //  8   Система
//const char menu_sensors[] PROGMEM = " ";

// пункты меню режима работы
const char mode_charge[] PROGMEM = "\xA4\x61\x70\xC7\xE3";                                          //  0   Заряд
const char mode_addcharge[] PROGMEM = "\xE0\x6F\xB7\x61\x70\xC7\xE3";                               //  1   Дозаряд
const char mode_discharge[] PROGMEM = "\x50\x61\xB7\x70\xC7\xE3";                                   //  2   Разряд
const char mode_storage[] PROGMEM = "\x58\x70\x61\xBD\x65\xBD\xB8\x65";                             //  3   Хранение АКБ
const char mode_asimm[] PROGMEM = "Acc\xB8\xBC. \xB7\x61\x70\xC7\xE3";                              //  4   Aссиметричный заряд // \x65\xBFp
const char mode_ktc[] PROGMEM = "KT\xE5";                                                           //  5   КТЦ (Разр>Зар>Дозар)
const char mode_bufer[] PROGMEM = "\xA0\x79\xE4\x65\x70";                                           //  6   Буф.режим  // Буферный режим "\xA0\x79\xE4\x65\x70\xBD\xc3\xB9 \x70\x65\xB6\xB8\xBC";  \xA0\x79\xE4.\x70\x65\xB6\xB8\xBC
#if (BRRANIMIR)
const char mode_branimir[] PROGMEM = "\xA0\x70\x61\xBD\xB8\xBC\xB8\x70\x61";                        //  7   Заряд Бранимир
const char boiling[] PROGMEM = "Boiling";  // Кипение (перемешивание) 
#endif
const char mode_pause[] PROGMEM = "\xA8\x61\x79\xB7\x61";  // Пауза



// пункты меню Система
// Калибровка
const char system_calibration[] PROGMEM = "\x4B\x61\xBB\xB8\xB2\x70\x6F\xB3\xBA\x61";
// Системные параметры
const char system_setting[] PROGMEM = "\x21\x43\xB8\x63\xBF\x65\xBC\x2E\x20\xBE\x61\x70\x61\xBC\x21";
// Сброс настроек
const char system_reset[] PROGMEM = "\x43\xB2\x70\x6F\x63 \xBD\x61\x63\xBF\x70\x6F\x65\xBA";


// пункты меню настроек
// Напряжение
const char sett_volt[] PROGMEM = "\x48\x61\xBE\x70."; // \xC7\xB6\x65\xBD\xB8\x65
// Ток
const char sett_curr[] PROGMEM = "\x54\x6F\xBA"; 
// минимальный ток
const char sett_curr_min[] PROGMEM = "\x4D\xB8\xBD. \xBF\x6F\xBA";
// Время часы
const char sett_time[] PROGMEM = "\x42\x70\x65\xBC\xC7";

//  Напряжение при котором начинает снижаться ток (Напр. сниж. тока)
const char sett_voltDecrCurr[] PROGMEM = "\x43\xBD\xB8\xB6\x65\xBD\xB8\x65";  // \xC7\xB6
// Предзаряд
const char sett_precharge[] PROGMEM = "\xA8\x70\x65\xE3\xB7\x61\x70\xC7\xE3";
const char sett_precharge_vc[] PROGMEM = "\xA8\x70\x65\xE3\xB7\x61\x70";
//  Напр.предзар.
// const char sett_precharge_volt[] PROGMEM = "\x48\x61\xBE\x70.\xBE\x70\x65\xE3"; // \xC7\xE3\x61  // \xB7\x61\x70
// Ток предзаряда
// const char sett_precharge_curr[] PROGMEM = "\x54\x6F\xBA \xBE\x70\x65\xE3"; // \xC7\xE3\x61  // \xB7\x61\x70
// Качели
const char sett_charge_oscil[] PROGMEM = "\x4B\x61\xC0\x65\xBB\xB8";
//  Ток разряда
// const char sett_discharge_curr[] PROGMEM = "\x54\x6F\xBA \x70\x61\xB7\x70."; // \xC7\xE3\x61
// Период заряда
const char sett_asym_period_charge[] PROGMEM = "\xA4\x61\x70\xC7\xE3 cek";  // \xB8\x6F\xE3   \xA8\x65\x70.\xB7\x61\x70\xC7\xE3\x61
//  Период разряда
const char sett_asym_period_discharge[] PROGMEM = "\x50\x61\xB7\x70\xC7\xE3 cek"; // \xB8\x6F\xE3  // \xC7\xE3\x61   \xA8\x65\x70.\x70\x61\xB7\x70.
//  Пауза
const char sett_asym_pause[] PROGMEM = "\xA8\x61\x79\xB7\x61 cek";
//  Цикл
const char sett_round[] PROGMEM = "\xE1\xB8\xBA\xBB";


// пункты калибровок
const char namc1[] PROGMEM = "\x48\x61\xBE\x70\xC7\xB6/\x54\x6F\xBA \x41\xBA\xB2";  // Напряж/ток акб
const char namc2[] PROGMEM = "\x48\x61\xBE\x70\xC7\xB6 \xA0\xA8";                   // Напряж. БП
const char namc3[] PROGMEM = "INA Volt";


#if (DISPLAYy == 2)
// символы вывода режима работы - Предзаряд, Заряд, Качели, Дозаряд, Разряд, Кипение (Бурление), Ожидание (пауза)
#if (BRRANIMIR)
const char regimr[] PROGMEM = " \xA8\xA4\x4B\xE0\x50\xA0\x4F";
#else
const char regimr[] PROGMEM = " \xA8\xA4\x4B\xE0\x50\x4F";
#endif
#endif

// пункты сброса настроек
const char reset_exit[] PROGMEM = "\x42\xC3\x78\x6F\xE3"; // Выход
const char reset_all[] PROGMEM = "\x42\x63\xA2";          // Всё
const char reset_profils[] PROGMEM = "\xA8\x70\x6F\xE4\xB8\xBB\xB8"; // Профили
const char reset_calibr[] PROGMEM = "\x4B\x61\xBB\xB8\xB2\x70\x6F\xB3\xBA\xB8"; // Калибровки


// текстовые строки
#define txt2 " \x63\xB2\x70\x6F\x63"            //  сброc
#define txt3 " \x63\x6F\x78\x70\x21"            //  сохр!
#define txt4 "\x42\x78\x2E\x20\xA0\xA8 "        //  "Вх. БП "
#define txt5 "\x42\xC3\x78\x6F\xE3"             //  Выход
#define txt6 "INA226 \x6F\xC1\xB8\xB2\xBA\x61"  //  INA226
#define txt7 "Temp Q1"                            
//#define txt8 "Temp akb"
#define txt9 "Temp akb:"                                       //  температура акб
#define txt10 "\x42\x63\xA2"                                   //  Всё
#define txt11 "\xA8\x6F\xE3\xBA\xBB\xC6\xC0\xB8 \x41\x4B\xA0"  //  Подключи АКБ
#define txt111 "\xA8\x6F\xE3\xBA\xBB\xC6\xC0\xB8 \xA0\xA8"     //  Подключи БП
#define txt12 "\x43\xB2\x70\x6F\x63"                           //  Сброс
#define txt13 "\x42\xBA\xBB\x2E "                              //  Вкл.
#define txt14 "\x4F\xBF\xBA\xBB\x2E"                           //  Откл.
#define txt15 "\x4B\x6F\x70\x70\x65\xBA\xBF OK"                // Коррект OK
#define txt16 "\xA8\x61\x79\xB7\x61"  //  Пауза
#define txt17 "\x3C \x4F\x4B \x3E"    // "< OK >"
#define txt18 "Pe\xB6\xB8\xBC \xA0\xA8"          //  Режим БП
#define txt19 "\x3C\x43\xBF\x6F\xBE\x3e"         //  "<Стоп>"
#define txt20 " \xBC\xB8\xBD "                   //  мин
#define txt21 " \x6F\xC1\xB8\xB2\xBA\x61"        //  ошибка
#define txt22 "Volt"                             // Вольт
#define txt23 "Amper"                            // Ампер
#define txt24 "!-\xA8\x50\x4F\xA0\xA5\x54 Q1-!"  //  !-ПРОБИТ Q1-!
#define txt25 "\x56\xB2\xBE "                    //  Vбп
//#define txt26 "\x41\x4B\xA0\x20\x70\x61\xB7\x70\xC7\xB6\x65\xBD\x21"  //  АКБ разряжен!
//const char err[] PROGMEM = "\x6F\xC1\xB8\xB2\xBA\x61";

/* ***** английский ***** */ 
#elif (INTERFACE == 1)

// пункты главного меню
const char menu_profil[] PROGMEM = "Pr:";
const char menu_akb_capacity[] PROGMEM = "Capacity Akb";
const char menu_akb_type[] PROGMEM = "Type Akb";
const char menu_akb_volt[] PROGMEM = "Voltage Akb";
const char menu_mode[] PROGMEM = "Operating mode";
const char menu_settings[] PROGMEM = "Settings";
const char menu_resist_akb[] PROGMEM = "Resist. akb";
const char menu_statistic[] PROGMEM = "Statistics";
const char menu_system[] PROGMEM = "System";
// const char menu_sensors[] PROGMEM = " ";

// пункты меню режимов работы
const char mode_charge[] PROGMEM = "Charge";
const char mode_addcharge[] PROGMEM = "Addcharge";
const char mode_asimm[] PROGMEM = "Asymmetric";
const char mode_discharge[] PROGMEM = "Discharge";
const char mode_storage[] PROGMEM = "Storage";
const char mode_bufer[] PROGMEM = "Buffer";
const char mode_ktc[] PROGMEM = "Training cycle";
#if (BRRANIMIR)
const char mode_branimir[] PROGMEM = "Branimir";
// Кипение (перемешивание) 
const char boiling[] PROGMEM = "Boiling";
#endif
const char mode_pause[] PROGMEM = "Pause";  // Пауза



//const char mode_charge_add[] PROGMEM = "Charge>AddChar";

// пункты меню Система
const char system_calibration[] PROGMEM = "Calibration";
const char system_setting[] PROGMEM = "!system param!";
const char system_reset[] PROGMEM = "Reset settings";


// пункты меню настроек
// Напряжение
const char sett_volt[] PROGMEM = "Volt";
// Ток
const char sett_curr[] PROGMEM = "Current";
// минимальный ток
const char sett_curr_min[] PROGMEM = "Curr. min";
// Время часы
const char sett_time[] PROGMEM = "Time";

//  Напряжение при котором начинает снижаться ток (Напр. сниж. тока)
const char sett_voltDecrCurr[] PROGMEM = "Derease";
// Предзаряд
const char sett_precharge[] PROGMEM = "Precharge";
const char sett_precharge_vc[] PROGMEM = "Precharg";
//  Напряж.предзар.
//const char sett_precharge_volt[] PROGMEM = "Volt precharge";
// Ток предзаряда
//const char sett_precharge_curr[] PROGMEM = "Curr. precharge";
// Качели
const char sett_charge_oscil[] PROGMEM = "Oscill.";
//  Ток разряда
// const char sett_discharge_curr[] PROGMEM = "Dischar";
// Период заряда
const char sett_asym_period_charge[] PROGMEM = "Charge sec";
//  Период разряда
const char sett_asym_period_discharge[] PROGMEM = "Disch. sec";
//  Пауза
const char sett_asym_pause[] PROGMEM = "Pause sec";
//  Цикл
const char sett_round[] PROGMEM = "Cycle";

// пункты меню калибровки
const char namc1[] PROGMEM = "Volt/Curr akb";
const char namc2[] PROGMEM = "Volt Power";
const char namc3[] PROGMEM = "INA Volt";


#if (DISPLAYy == 2)
// символы вывода режима работы - Предзаряд, Заряд, Качели, Дозаряд, Разряд, Кипение (Бурление), Ожидание (пауза)
#if (BRRANIMIR)
const char regimr[] PROGMEM = " PCOADKBO";
#else
const char regimr[] PROGMEM = " PCOADKO";
#endif
#endif

// пункты сброса настроек
const char reset_exit[] PROGMEM = "Exit";              // Выход
const char reset_all[] PROGMEM = "All";                // Всё
const char reset_profils[] PROGMEM = "Profils";        // Профили
const char reset_calibr[] PROGMEM = "Calibrations";    // Калибровки 

// текстовые строки
#define txt2 " reset"
#define txt3 " saved"  // 2 раза
#define txt4 "Power "
#define txt5 "Exit"
#define txt6 "INA226 error"
#define txt7 "Temp Q1"                            
// #define txt8 "Temp akb"
#define txt9 "Temp akb:"  //  температура акб
#define txt10 "All"
#define txt11 "Connect batt"
#define txt111 "Connect power"
#define txt12 "Sbros"
#define txt13 "On "
#define txt14 "Off "
#define txt15 "Korrect OK"
#define txt16 "Pause"
#define txt17 "< OK >"
#define txt18 "Regim BP"
#define txt19 "<Stop>"
#define txt20 " min "
#define txt21 " error"  // 6 раз
#define txt22 "Volt"
#define txt23 "Amper"
#define txt24 "!-BROKEN Q1-!"
#define txt25 "Vin "  //  Напряж БП превыш
//#define txt26 "Akb razryazen!"
//const char err[] PROGMEM = "error";

/* ***** транстит  ***** */ 
#elif (INTERFACE == 2)

// пункты меню
const char menu_profil[] PROGMEM = "Pr:";
const char menu_akb_capacity[] PROGMEM = "Emkost akb";
const char menu_akb_type[] PROGMEM = "Tip akb";
const char menu_akb_volt[] PROGMEM = "Napryagenie akb";
const char menu_mode[] PROGMEM = "Regim raboti";
const char menu_settings[] PROGMEM = "Nastroiki";
const char menu_resist_akb[] PROGMEM = "Soprot. akb";
const char menu_statistic[] PROGMEM = "Statistika";
const char menu_system[] PROGMEM = "System";

// пункты меню режимов работы
const char mode_charge[] PROGMEM = "Zaryad";
const char mode_addcharge[] PROGMEM = "Dozaryad";
const char mode_asimm[] PROGMEM = "Asymmetric";
const char mode_discharge[] PROGMEM = "Razryad";
const char mode_storage[] PROGMEM = "Hranenie";
const char mode_bufer[] PROGMEM = "Bufer"; 
const char mode_ktc[] PROGMEM = "KTC";
#if (BRRANIMIR)
const char mode_branimir[] PROGMEM = "Branimir";
// Кипение (перемешивание) 
const char boiling[] PROGMEM = "Peremeshiv.";
#endif
const char mode_pause[] PROGMEM = "Pauza";  // Пауза


// пункты меню Система
const char system_calibration[] PROGMEM = "Kalibrovka";
const char system_setting[] PROGMEM = "!system param!";
const char system_reset[] PROGMEM = "Cbros nastroek";


// пункты меню настроек
// Напряжение
const char sett_volt[] PROGMEM = "Volt";
// Ток
const char sett_curr[] PROGMEM = "Tok";
// минимальный ток
const char sett_curr_min[] PROGMEM = "Min. tok";
// Время часы
const char sett_time[] PROGMEM = "Vremya";

//  Напряжение при котором начинает снижаться ток (Напр. сниж. тока)
const char sett_voltDecrCurr[] PROGMEM = "Snigenie";
// Предзаряд
const char sett_precharge[] PROGMEM = "Predzaryad";
const char sett_precharge_vc[] PROGMEM = "Predzar.";
// Качели
const char sett_charge_oscil[] PROGMEM = "Kacheli";
//  Ток разряда
// const char sett_discharge_curr[] PROGMEM = "Razryad";
// Период заряда
const char sett_asym_period_charge[] PROGMEM = "Zaryad sek";
//  Период разряда
const char sett_asym_period_discharge[] PROGMEM = "Razryad sek";
//  Пауза
const char sett_asym_pause[] PROGMEM = "Pause sek";
//  Цикл
const char sett_round[] PROGMEM = "Cycle";

// пункты меню калибровок
const char namc1[] PROGMEM = "Volt/Curr akb";
const char namc2[] PROGMEM = "Volt Power";
const char namc3[] PROGMEM = "INA Volt";

#if (DISPLAYy == 2)
// символы вывода режима работы - Предзаряд, Заряд, Качели, Дозаряд, Разряд, Кипение (Бурление), Ожидание (пауза)
#if (BRRANIMIR)
const char regimr[] PROGMEM = " PZKDRBO";
#else
const char regimr[] PROGMEM = " PZKDRO";
#endif
#endif

// пункты сброса настроек
const char reset_exit[] PROGMEM = "Exit";              // Выход
const char reset_all[] PROGMEM = "Vse";                // Всё
const char reset_profils[] PROGMEM = "Profili";        // Профили
const char reset_calibr[] PROGMEM = "Kalibrovki";      // Калибровки 

// текстовые строки
//#define txt2 " sbros"
#define txt3 " sohr."
#define txt4 "Power "
//#define txt5 "Exit"
#define txt6 "INA226 error"
#define txt7 "DS18B20 "
//#define txt8 "!ALERT!"
#define txt9 "Temp akb:"
//#define txt10 "Vse"
#define txt11 "Podkluchi AKB"
#define txt111 "Podkluchi BP"
#define txt12 "Sbros"
#define txt13 "Vkl."
#define txt14 "Otkl."
#define txt15 "Korrect OK"
#define txt16 "Pause"
#define txt17 "< OK >"
#define txt18 "Regim BP"
#define txt19 "<Stop>"
#define txt20 " min "
#define txt21 " error"
#define txt22 "Volt"
#define txt23 "Amper"
#define txt24 "!-PROBIT Q1-!"
#define txt25 "Vin "  //  Напряж БП превыш
//#define txt26 "Akb razryazen!"
//const char err[] PROGMEM = "error";
#else
#error "Не правильный номер языка интерфейса"
#endif

enum Menu_main {
  main_profil,        // 0
  main_akb_capacity,  // 1
  main_akb_type,      // 2
  main_akb_voltage,   // 3
  main_mode,          // 4
  main_settings,      // 5
  main_system,        // 6
#if (STATISTIC == 1)
  main_statistic,     // 7
#endif
#if (RESIST == 1)
  main_resist_akb,    // 8
#endif
};

const char* const menuTxt[] PROGMEM = {
  menu_profil,        // 0
  menu_akb_capacity,  // 1
  menu_akb_type,      // 2
  menu_akb_volt,      // 3
  menu_mode,          // 4
  menu_settings,      // 5
  menu_system,        // 6
#if (STATISTIC == 1)
  menu_statistic,     // 7
#endif
#if (RESIST == 1)
  menu_resist_akb,    // 8
#endif
  //menu_sensors,       // 9
};

const char* const modeTxt[] PROGMEM = {
  mode_charge,
  mode_addcharge,
  mode_discharge,
  mode_storage,
  mode_asimm,
  mode_ktc,
#if (BUFFER)
  mode_bufer,
#endif
#if (BRRANIMIR)
  mode_branimir,  
#endif
};

const char* const systema[] PROGMEM = {
  system_calibration,
  system_setting,
  system_reset
};


// пункты меню настроек
const char *const settings_charge[] PROGMEM = {
    // Заряд
    sett_volt,
    sett_curr,
    sett_curr_min,
    sett_time,
    sett_voltDecrCurr,
    sett_precharge,
    sett_precharge_vc,
    sett_precharge_vc,
    sett_charge_oscil,
    mode_addcharge,
    // Дозаряд
    sett_volt,
    sett_curr,
    sett_curr_min,
    sett_time,
    // Разряд
    sett_volt,
    sett_curr,
    sett_curr_min,
    // Хранение
    sett_volt,
    sett_curr,
    // Асиметричный заряд
    sett_volt,
    mode_charge,    // sett_curr,
    mode_discharge, // sett_discharge_curr,
    sett_asym_period_charge,
    sett_asym_period_discharge,
    sett_asym_pause,
    sett_time,
#if (BUFFER)
    // Буфер
    sett_volt,
    sett_curr,
#endif
    sett_round,
};


// пункты текущего режима
const char* const regims_txt[] PROGMEM = {
  sett_precharge,     /*предзаряд*/
  mode_charge,        /*заряд*/
  sett_charge_oscil,  /*качели*/
  mode_addcharge,     /*дозаряд*/
  mode_discharge,     /*разряд*/
#if (BRRANIMIR)
  boiling,            /*кипение*/
#endif
  mode_pause,         /*Пауза*/
};

// пункты сброса настроек
const char* const reset_txt[] PROGMEM = {
  reset_exit, reset_all, reset_profils, reset_calibr, system_setting
};


const char* const calibr[] PROGMEM = { namc1, namc2, namc3 };

// число пунктов Меню - 0-9
#define POINTMENU (uint8_t)(sizeof(menuTxt) / sizeof(menuTxt[0]) - 1)

// число пунктов Режимов работы - 0-7
#define POINTMODE (uint8_t)(sizeof(modeTxt) / sizeof(modeTxt[0]) - 1)

// число пунктов Калибровок 0-2
#define POINTCALIBRS (uint8_t)(sizeof(calibr) / sizeof(calibr[0]) - 1)  

// система 0-2
#define POINTSYSTEM (uint8_t)(sizeof(systema) / sizeof(systema[0]) - 1)

// число пунктов меню настроек
#define POINTSETTINGS (uint8_t)(sizeof(settings_charge) / sizeof(settings_charge[0]) - 1)

// число пунктов сброса настроек
#define POINTRESET (uint8_t)(sizeof(reset_txt) / sizeof(reset_txt[0]) - 1)
