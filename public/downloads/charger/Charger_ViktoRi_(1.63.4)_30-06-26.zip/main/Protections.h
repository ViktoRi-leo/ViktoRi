// Все защиты
#pragma once
#include "global.h"

// структура для контроля критических изменений тока заряда
// и контроля скорости снижения тока
struct Curr_critical_check {
private:
  // значения изменения тока мА которые проверяются каждые 60, 600, 1800 сек
  // (в будующем заменить на проценты от минимального текущего тока)
  const int16_t curr_step[3]{150, 100, 30};
  // счет 60, 600, 1800 сек
  uint16_t counter[3]{60, 900, 1800};
  // предыдущее значение
  int16_t curr_previous = 0;
  // значение изменения тока
  int16_t curr_critical_int = 0;

  // таймер скорости снижения тока
  uint16_t counterCurrSpeed = Time_Curr_decrease;
  // предыдущее значение
  int16_t curr_speed_previous = 0;
  // значение изменения тока
  float curr_speed = 0.0;

public:
  // значение изменения тока
  float curr_critical = 0.0;

  void reset();

  // проверка тока на увеличение
  Reason offset_critical_current(bool v_max, int16_t charge_current_aver);
};

// структура для контроля критических изменений напряжения заряда
struct Volt_critical_check {
private:
  // значения изменения напряжения мВ которые проверяются каждые 60, 600, 1800
  // сек (в будующем заменить на проценты от максимального)
  const int16_t volt_step[3]{-150, -100, -30};
  // счет 60, 600, 1800 сек
  uint16_t counter[3]{60, 600, 1800};
  // предыдущее значение
  uint16_t volt_previous = 0;
  // значение изменения напряжения
  int16_t volt_critical_int = 0;

public:
  // значений изменения напряжения
  float volt_critical = 0.0;

  void reset();

  // проверка напряжение на уменьшение
  Reason offset_critical_voltage(uint16_t charge_volt_aver);
};

// структура для фиксации достижения максимального напряжения заряда
struct Volt_max_check {
  // флаг достижения максимального напряжения
  bool volt_max = false;

  // функция достижения максимального напряжения заряда
  void max_volt_check(uint16_t charge_volt_init, uint16_t voltage,
                      int16_t current);
};

struct TimeCount {
  // сюда сохраняем время заряда из памяти в сек (при запуске заряда)
  uint32_t local;
  // сюда рассчитывается полное время заряда (каждую секунду)
  uint32_t real_tm;
  // рассчитать количество всех секунд заряда (каждую секунду)
  void cal_real_tm(void);
};

//  защита отключает заряд через 5 сек при снятии клеммы
struct Disconnect_battery {
private:
  uint8_t time = TYME_OFF_CHARGE;
  // таймер до начала контроля акб
  uint8_t timer = 10;

public:
  uint8_t check(int16_t current);

  // сброс таймера
  void reset_timer(void);
};

// структура для контроля наличия напряжения от БП
struct Waiting_power {
  // флаг отключения/включения напряжения от БП
  bool flag_power = false;

  // функция контроля напряжения от БП
  bool power_check(void);
};

// Структура для изменения напряжения или тока заряда
// Отдельная функция проверки на превышение тока и напряжения.
/*
Хранит указатели на переменные максимальных напряжения и тока заряда.
Рассчитывает и хранит переменные защиты от повышенного напряжения и тока,
изменяет их при изменения максимальных напряжения или тока заряда.
*/
struct Change_charge {
public:
  Change_charge(uint16_t *max_voltage, int16_t *max_current)
      : max_voltage(max_voltage), max_current(max_current) {
    calc_crash();
  }

  // флаг изменения
  bool flag = false;
  // флаг изменения напряжения или тока заряда
  bool flag_change = true;

  // функция изменения напряжения или тока заряда
  void change_charge(void);

  // функция проверки на превышение тока и напряжения
  bool check_charge(void);

  // функция рассчета переменных защиты от повышенного напряжения и тока
  void calc_crash(void);

private:
  // указатели на переменные максимальных напряжения и тока заряда.
  uint16_t *max_voltage;
  int16_t *max_current;

  // переменные защиты от повышенного напряжения и тока
  uint16_t volt_crash;
  int16_t current_crash;
};

// функция контроля температуры акб
bool CheckTempBattery(void);

// функции управления модулем защиты
namespace Protect {
// функция включения блокировки модуля защиты в зависимости от напряжения акб
// включает блокировку при напряжении акб менее 5 Вольт и отключает при напр.
// более 6 Вольт
void Guard(void);

// принудительно закрыть защитный транзистор
void Close(bool x);

// подать 12 вольт на транзисор модуля защиты - true
// отключить подачу 12 вольт на транзисор модуля защиты - false
void Open(bool x);

} // namespace Protect

// Реле 220В
// время (сек) до отключения ЗУ в режиме ожидания
extern uint16_t relay_timer;

// сбросить таймер
void Relay_butt_tick(void);
// функция управления реле подключения к сети 220В.
void Relay(void);
// функция отключения реле 220В если не включен ни какой режим и акб отключен.
void Relay_off(void);
// (true - включить реле, false - отключить реле)
void Relay_on(bool vkl);

