#pragma once
/*
Типы акб
*/
#include <Arduino.h>

enum Akb_type: uint8_t {
  PB_CACA, PB_CASUR, PB_SUR, PB_AGM, PB_GEL, LI_ION, LI_POL, LI_FER, LI_TIT, NI_CD, NI_MG,
};

// названия типов аккумуляторов
const char akb_pb_caca[] PROGMEM  = "PB_Ca/Ca";
const char akb_pb_casur[] PROGMEM = "PB_CA+";
const char akb_pb_sur[] PROGMEM  = "PB_Sur";
const char akb_pb_agm[] PROGMEM = "PB_AGM";
const char akb_pb_gel[] PROGMEM  = "PB_GEL";
const char akb_li_ion[] PROGMEM  = "Li-Ion";
const char akb_li_pol[] PROGMEM  = "Li-Pol";
const char akb_li_fer[] PROGMEM = "LI_Fer";
const char akb_li_tit[] PROGMEM = "Li-Tit";
const char akb_ni_cd[] PROGMEM = "NI_Cd";
const char akb_ni_mg[] PROGMEM  = "NI_Mg";

// архив с названиями типов аккумуляторов
const char* const akb_name_list[] PROGMEM = {
    akb_pb_caca, akb_pb_casur, akb_pb_sur, akb_pb_agm, akb_pb_gel, akb_li_ion, akb_li_pol, akb_li_fer, akb_li_tit, akb_ni_cd, akb_ni_mg
};

// количество типов акб 11
#define AKB_COUNT (uint8_t)(sizeof(akb_name_list) / sizeof(akb_name_list[0]) - 1)

struct Battery {
  /*напряжение одной ячейки АКБ*/ 
  uint16_t volt_cell;  
  /*напряжение заряда ячейки АКБ*/ 
  uint16_t volt_cell_charge; 
  /*напряжение дозаряда ячейки АКБ - только для свинцово-кислотных*/ 
  uint16_t volt_cell_add_charge;  
  /*напряжение разряда ячейки АКБ*/ 
  uint16_t volt_cell_discharge;

  /*ток заряда ячейки АКБ, указано в процентах от емкости АКБ*/ 
  uint8_t curr_cell_charge;
  /*ток дозаряда ячейки АКБ*/ 
  uint8_t curr_cell_addcharge;
  /*ток разряда ячейки АКБ*/ 
  uint8_t curr_cell_discharge;
};

// Массив структур аккумуляторов
extern const Battery PROGMEM batteries[];

// диапазон рабочих температур для разных типов акб
const int8_t PROGMEM sett_count[][2]{
    {-15, 40}, // PB_CACA
    {-15, 40}, // PB_CASUR 
    {-15, 40}, // PB_SUR  
    {-15, 40}, // PB_AGM 
    {-15, 40}, // PB_GEL 
    {10, 40},  // LI_ION
    {10, 40},  // LI_POL
    {10, 45},  // LI_FER
    {-10, 50}, // LI_TIT
    {5, 45},   // NI_CD
    {5, 45},   // NI_MG
};


/*
// названия типов аккумуляторов для Menu
const char akb_name[] =
    "PB_Ca/Ca;PB_CA/SUR;PB_Sur;PB_AGM;PB_GEL;Li-Ion;Li-Pol;LI_Fer;Li-Tit;NI_Cd;NI_Mg";
*/    