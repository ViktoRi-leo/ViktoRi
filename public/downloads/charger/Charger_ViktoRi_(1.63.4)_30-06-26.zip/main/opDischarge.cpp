#include "DCDC.h"
#include "Display.h"
#include "INA226int.h"
#include "global.h"
#include "operations.h"

// Функция разряда аккумулятора
void Discharge(void) {
  regims = Regims::REGIM_DISCHARGE;
  // вывод режима, напряжения и тока заряда/разряда
  print_volt_current(profil.disch.voltage_end, profil.disch.current);
  printCykl();                     // вывод количества циклов
  const uint16_t s1 = ina.voltsec; // текущее наряжение акб
  bool dischar = true;             // разряд включен

  uint8_t step = 0;
  TimeCount tyme;
  tyme.local = profil.disch.stat.time;

  Change_charge chg(&profil.disch.voltage_end, &profil.disch.current);

#if (FAN > 0 and FAN_DISCHAR_ON == 1)
  fan.ONonse(true); // запустить кулер
  Delay(500);       // задержка пока кулер раскрутится
#endif

#if (POWER == 1)
  /* После отключения реле 220В, замеряем ток потребления зарядника от акб.
   Если ток при завершении разряда менее тока потребления самого зарядника
   (ЗУ*2) реле 220В включится.
   Это нужно чтобы убрать проблему при низком токе разряда -
   когда ток разряда снижается до тока потребления ЗУ ПИД регулятор
   уже снизил ШИМ до нуля и не может больше контролировать разряд. */

  // если разрешено отключать реле 220В
  if (sysFlagGetBits(FlagsName::RELEY_OFF)) {
    Relay_on(LOW); // отключить реле
    Delay(5000);   // ожидание не уменьшать если POWER == 1 !!!
    if (profil.disch.current_end <= (abs(ina.ampersec) * 2))
      Relay_on(HIGH); // включить реле
  } else {
    Delay(3000);
  }
#else
  Delay(3000);
#endif

  uint16_t time10 = 600; // выполнить раз в 600 сек (10 мин)

  dcdc.start(DCDC_DISCHARGE);
  dcdc.begin(profil.disch.voltage_end, profil.disch.current);

  lcd.clear();

  start_second_usr();
  // цикл разряда 35 часов максимум (35*60*60=126000 сек)
  while (dischar and bitRead(profil.flags, Pr_flags::ACTIVITI)) {
    sensor_survey();

    if (butt.tick) {
      // если кнопка нажата
      if (chg.flag) {
        // производится корректировка напряжения и тока
        chg.change_charge();
      } else {
        if (op_window == WINDC and butt.tick == Butt::OKHELD) {
          // начать корректировку напряжения и тока
          chg.flag = true;
        } else {
          switch (butt.tick) {
          case Butt::STOPHELD:
          case Butt::OKHELD:
            // завершить заряд
            if (op_window == 0)
              bitClear(profil.flags, Pr_flags::ACTIVITI);
            break;
          case Butt::RIGHT:
          case Butt::LEFT:
            // изменение номера экрана
            window_change(WINDC);
            break;
          }
        }
      }
    }

    if (get_second()) {
      step = 5;
    }

    // если прошла секунда
    if (step) {
      switch (step) {
      case 5:
        profil.disch.stat.ah += Calc_AhWh((int32_t)abs(ina.ampersec));
        profil.disch.stat.wh += Calc_AhWh(ina.getsPower());
        // рассчитать количество всех секунд разряда
        tyme.cal_real_tm();
        profil.disch.stat.time = tyme.real_tm;
        if (profil.disch.stat.time > 126000)
          dischar = false;
        break;
      case 4: {
        int16_t ampsec = abs(ina.ampersec);
        // напряжение уменьшилось до установленного и ток
        // уменьшился до установленного то завершить разряд
        if (ina.volt_aver <= profil.disch.voltage_end and
            ampsec <= profil.disch.current_end)
          dischar = false;
      } break;
      case 3:
        // вывод на дисплей
        Display_print(
            profil.disch.stat.ah, profil.disch.stat.wh, profil.disch.stat.time,
            map_my(ina.voltsec, profil.disch.voltage_end, s1, 0, 100));

        // обратный отсчет время отображения экрана
        disp_time();
        break;

      case 2:
#if (BATT_TEMP_CONTROL and SENSTEMP2)
        // контроль температуры Акб
        if (CheckTempBattery()) {
          // если была пауза по температуре
          dcdc.start(DCDC_DISCHARGE);
          time10 = 600;
          step = 0;
        }
#endif

#if (TIME_LIGHT)
        disp.Light_low();
#endif
        break;
      case 1:
#if (PROTECT_BLOCK)
        Protect::Guard();
#endif
#if (LOGGER)
#if (LOGGER == 4)
        Sout.create_advanced(-profil.disch.stat.ah, 0, 0,
                             profil.disch.stat.time);
#else
        Sout.create(-profil.disch.stat.ah);
#endif
#endif
        // выполнить раз в 10 мин
        if (--time10 == 0) {
          time10 = 600;
          eepSavedStruct(); // сохранить настройки
        }
        break;
      }
      step--;
    }
    // выполнить раз в секунду
  }
  // цикл разряда
  dcdc.Off(); // отключить заряд, разряд.
#if (PROTECT_BLOCK)
  Protect::Open(false);
#endif
#if (FAN > 0 and FAN_DISCHAR_ON == 1)
  fan.ONonse(false); // автоматический режим кулера
#endif
  eepSavedStruct(); // сохранить настройки
#if (POWER == 1)
  Relay_on(true); // включить сеть 220В
#endif
}
