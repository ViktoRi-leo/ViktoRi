#include "global.h"
#include "Display.h"
#include "Menu.h"


// номера пунктов настроек в зависимости от выбранного режима
const uint8_t sett_count[][2]{
    {0, 9},   // Заряд
    {10, 13}, // Дозаряд
    {14, 16}, // Разряд
    {17, 18}, // Хранение
    {19, 25}, // Ассиметричный заряд
    {0, 18},  // КТС
    {26, 27}, // Буферный режим
};

// текущий пункт настроек
uint8_t sett_point = 0;

// флаг циклов
bool fl_round = false;

// установить пункт настроек в начало
void SettPointToStart(void) { sett_point = sett_count[profil.Regim][0]; }

// вывод/изменение пунктов настроек
void Settings_3(int16_t x) {
  uint8_t point = sett_point;

  if (fl_round) {
    disp.printFromPGM((int)(&settings_charge[POINTSETTINGS]));
    point = POINTSETTINGS;
  } else {
    // строка 0 название параметра
    disp.printFromPGM((int)(&settings_charge[sett_point]));
  }
  lcd.print(':');
  lcd.print(x ? '>' : ' ');

  switch (point) {
  // Заряд
  case 0:
    // напряжение
    profil.charge.voltage = volt_step(profil.charge.voltage, x);
    print_volt(profil.charge.voltage);
    break;
  case 1: {
    // ток заряда
    int16_t step = x * (int16_t)STEP_CURR;
    profil.charge.current = constrain_my(profil.charge.current, CUR_CHARGE_MIN,
                                         CURRMAXINT - 500, step);
    if (x)
      ChargeTimeCalc(); // расчет времени заряда
    print_current(profil.charge.current);
    if (profil.charge.current_pre > profil.charge.current)
      profil.charge.current_pre = profil.charge.current;
  } break;
  case 2: {
    // минимальный ток заряда
    int16_t step = x * 10;
    profil.charge.current_end = constrain_my(profil.charge.current_end, CURMIN,
                                             profil.charge.current, step);
    print_current(profil.charge.current_end);
  } break;
  case 3:
    // время заряда
    profil.charge.time = constrain_my(profil.charge.time, 1, 255, x);
    print_hour(profil.charge.time);
    break;
  case 4:
    // Напряжение при котором начинает снижаться ток
    profil.charge.voltage_decr_cur =
        constrain_my(profil.charge.voltage_decr_cur, STEP_VOLT * 10,
                     profil.charge.voltage, x * STEP_VOLT);
    print_volt(profil.charge.voltage_decr_cur);
    break;
  case 5:
    // предзаряд
    if (x)
      InvBit(profil.flags, Pr_flags::PRECHAR);
    PrintOnOff(bitRead(profil.flags, Pr_flags::PRECHAR));
    break;
  case 6:
    // напряжение предзаряда
    profil.charge.voltage_pre = volt_step(profil.charge.voltage_pre, x);
    print_volt(profil.charge.voltage_pre);
    break;
  case 7: {
    // ток предзаряда
    int16_t step = x * 10;
    profil.charge.current_pre = constrain_my(
        profil.charge.current_pre, CUR_CHARGE_MIN, profil.charge.current, step);
    print_current(profil.charge.current_pre);
  } break;
  case 8:
    // режим качели
    if (x)
      InvBit(profil.flags, Pr_flags::OSCIL); // инвертировать бит
    PrintOnOff(bitRead(profil.flags, Pr_flags::OSCIL));
    break;
  case 9:
    // дозаряд вкл/откл
    if (x)
      InvBit(profil.flags, Pr_flags::CHARGE_ADD); // инвертировать бит
    PrintOnOff(bitRead(profil.flags, Pr_flags::CHARGE_ADD));
    break;

  // Дозаряд
  case 10:
    // напряжение
    profil.add.voltage = volt_step(profil.add.voltage, x);
    print_volt(profil.add.voltage);
    break;
  case 11: {
    // ток
    int16_t step = x * STEP_CURR_ADD;
    profil.add.current = constrain_my(profil.add.current, CUR_CHARGE_MIN,
                                      CURRMAXINT - 500, step);
    print_current(profil.add.current);
  } break;
  case 12: {
    // минимальный ток
    int16_t step = x * 10;
    profil.add.current_min = constrain_my(
        profil.add.current_min, CUR_CHARGE_MIN, profil.add.current, step);
    print_current(profil.add.current_min);
  } break;
  case 13:
    // время
    profil.add.time = constrain_my(profil.add.time, 1, 252, x);
    print_hour(profil.add.time);
    break;

  // Разряд
  case 14:
    // напряжение
    profil.disch.voltage_end = volt_step(profil.disch.voltage_end, x);
    print_volt(profil.disch.voltage_end);
    break;
  case 15: {
    // ток
    int16_t step = x * (int16_t)STEP_CURR;
    profil.disch.current = constrain_my(profil.disch.current, CUR_CHARGE_MIN,
                                        CURRMAXINT - 500, step);
    profil.disch.current_end = profil.disch.current; // ток завершения разряда
    print_current(profil.disch.current);
  } break;
  case 16: {
    // ток завершения разряда
    int16_t step = x * 10;
    profil.disch.current_end =
        constrain_my(profil.disch.current_end, 20, profil.disch.current, step);
    print_current(profil.disch.current_end);
  } break;

  // Хранение
  case 17:
    // напряжение
    profil.storage.voltage = volt_step(profil.storage.voltage, x);
    print_volt(profil.storage.voltage);
    break;
  case 18: {
    // ток
    int16_t step = x * (int16_t)STEP_CURR;
    profil.storage.current = constrain_my(
        profil.storage.current, CUR_CHARGE_MIN, CURRMAXINT - 500, step);
    print_current(profil.storage.current);
  } break;

  // Асимметрия
  case 19:
    // напряжение заряда
    profil.asym.voltage = volt_step(profil.asym.voltage, x);
    print_volt(profil.asym.voltage);
    break;
  case 20: {
    // ток заряда
    int16_t step = x * (int16_t)STEP_CURR;
    profil.asym.current = constrain_my(profil.asym.current, CUR_CHARGE_MIN,
                                       CURRMAXINT - 500, step);
    print_current(profil.asym.current);
  } break;
  case 21: {
    // ток разряда
    int16_t step = x * (int16_t)STEP_CURR;
    profil.asym.current_discharge = constrain_my(
        profil.asym.current_discharge, CUR_CHARGE_MIN, CURRMAXINT - 500, step);
    print_current(profil.asym.current_discharge);
  } break;
  case 22:
    // период заряда
    profil.asym.period_charge =
        constrain_my(profil.asym.period_charge, 1, 255, x);
    print_sec(profil.asym.period_charge);
    break;
  case 23:
    // период разряда
    profil.asym.period_discharge =
        constrain_my(profil.asym.period_discharge, 1, 255, x);
    print_sec(profil.asym.period_discharge);
    break;
  case 24:
    // пауза сек
    profil.asym.pause = constrain_my(profil.asym.pause, 1, 255, x);
    print_sec(profil.asym.pause);
    break;
  case 25:
    // время заряда
    profil.asym.time = constrain_my(profil.asym.time, 1, 255, x);
    print_hour(profil.asym.time);
    break;

#if (BUFFER)
  // Буфер
  case 26:
    // напряжение
    profil.buffer.voltage = volt_step(profil.buffer.voltage, x);
    print_volt(profil.buffer.voltage);
    break;
  case 27: {
    // ток
    int16_t step = x * (int16_t)STEP_CURR;
    profil.buffer.current = constrain_my(profil.buffer.current, CUR_CHARGE_MIN,
                                         CURRMAXINT - 500, step);
    print_current(profil.buffer.current);
  } break;
#endif

  // циклы
  case POINTSETTINGS:
    profil.round = constrain_my(profil.round, 1, 5, x);
    lcd.print(profil.round);
    break;
  }
}

// все настройки
void Settings_pre(int8_t x, bool modify) {

  if (!modify) {

    uint8_t count = (profil.Regim == Modes::CHARGE and
                     bitRead(profil.flags, Pr_flags::CHARGE_ADD))
                        ? Modes::ADDCHARGE
                        : profil.Regim;

    // циклы
    if (fl_round and x < 0) {
      sett_point == sett_count[count][1];
      fl_round = false;
    } else if (sett_point == sett_count[count][1] and x > 0) {
      fl_round = true;
    } else {
      sett_point = constrain_my(sett_point, sett_count[profil.Regim][0],
                                sett_count[count][1], x);
    }

    x = 0;
  }

  uint8_t sett_mode = 0;
  switch (sett_point) {
  case 0 ... 9:
    sett_mode = Modes::CHARGE;
    break;
  case 10 ... 13:
    sett_mode = Modes::ADDCHARGE;
    break;
  case 14 ... 16:
    sett_mode = Modes::DISCHARGE;
    break;
  case 17 ... 18:
    sett_mode = Modes::STORAGE;
    break;
  case 19 ... 24:
    sett_mode = Modes::ASYMMETRIC;
    break;
#if (BUFFER)
  case 25 ... 26:
    sett_mode = Modes::BUFER;
    break;
#endif
  }

  setCursorx();
  disp.printFromPGM((int)(&modeTxt[sett_mode])); //  режим
  setCursory();

  Settings_3(x);
}

/*
  case Modes::ADDCHARGE:

    break;
  case Modes::ASYMMETRIC:

    break;
  case Modes::DISCHARGE:

    break;
  case Modes::STORAGE:

    break;
  case Modes::BUFER:

    break;
*/