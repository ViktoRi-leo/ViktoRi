#pragma once
// #include "User_Setup_Loader.h"
#include "global.h"
#include "Protections.h"

void Operations(void);

// Функция заряда.
// напряжение заряда (мВ), ток заряда (мА), минимальный ток заряда (мА),
// ограничение времени заряда в часах
void Charge(uint16_t volt_charge_init, int16_t curr_charge_init,
            int16_t curr_min, uint32_t time_charge);

// Функция разряда аккумулятора
void Discharge(void);

// функция Дозаряда
void AddCharge(uint16_t volt_charge_init, int16_t curr_charge_init,
               int16_t curr_min, uint32_t time_charge);

// функция заряда по Бранимиру (напряжение, ток, минимальный ток, время заряда)
void Branimir(uint16_t volt_charge_init, int16_t curr_charge_init,
              int16_t curr_min, uint32_t time_charge);

// функция Асимметричного заряда
void Asymmetric(void);

// Хранение
void Storage(void);

// Буферный режим
void Buffer(void);

