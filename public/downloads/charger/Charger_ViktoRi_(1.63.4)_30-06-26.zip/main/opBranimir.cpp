#include "global.h"
#include "DCDC.h"
#include "Display.h"
#include "INA226int.h"
#include "operations.h"

// функция заряда по Бранимиру (напряжение, ток, минимальный ток, время заряда)
void Branimir(uint16_t volt_charge_init, int16_t curr_charge_init,
              int16_t curr_min, uint32_t time_charge) {
#if (PROTECT_BLOCK)
  Protect::Guard();
#endif

  // вывод напряжения и тока заряда
  print_volt_current(volt_charge_init, curr_charge_init);
  print_hour((uint8_t)time_charge); // вывод времени

  time_charge *= 3600;

  TimeCount tyme;
  // время заряда или дозаряда
  tyme.local = profil.charge.stat.time;

  // флаг активности режима
  bool activiti = true;

  // 10 мин
  uint16_t sec_600 = 600;
  // шаги
  uint8_t step = 0;
  // 20 часов
  uint32_t tyme_20h = 0;

  Curr_critical_check cc;
  Volt_critical_check vc;
  Volt_max_check vmax;
  Disconnect_battery dbat;
#if (VOLTIN == 1)
  Waiting_power wpower;
#endif
  Change_charge chg(&volt_charge_init, &curr_charge_init);

  Delay(3000);
  lcd.clear();
  dcdc.start(DCDC_CHARGE);
  dcdc.begin(volt_charge_init, curr_charge_init);

  lcd.clear();

  // старт счета времени
  start_second_usr();
  // цикл заряда
  while (activiti and bitRead(profil.flags, Pr_flags::ACTIVITI)) {
    sensor_survey();

    if (butt.tick) {
      // если кнопка нажата
      if (chg.flag) {
        // производится корректировка напряжения и тока заряда
        chg.change_charge();
        cc.reset();
        vc.reset();
        vmax.volt_max = false;
      } else {
        if (op_window == WINDC and butt.tick == Butt::OKHELD) {
          // начать корректировку напряжения и тока
          chg.flag = true;
        } else {
          switch (butt.tick) {
          case Butt::STOPHELD:
          case Butt::OKHELD:
            // завершить заряд
            if (op_window == 0)
              bitClear(profil.flags, Pr_flags::ACTIVITI);
            break;
          case Butt::RIGHT:
          case Butt::LEFT:
            // изменение номера экрана
            window_change(WINDC);
            break;
          }
        }
      }
    }

    // выполнить раз в секунду...
    if (get_second()) {

#if (VOLTIN == 1)
      // если произошло изменение состояния питания
      if (wpower.power_check()) {
        dcdc.start(DCDC_CHARGE);
      }
#endif

      step = sysFlagGetBits(FlagsName::POWERON);

#if (LOGGER == 4)
      Sout.create_advanced(profil.charge.stat.ah, ina.volt_aver, ina.curr_aver,
                           tyme.real_tm);
#elif (LOGGER > 0)
      Sout.create(profil.charge.stat.ah, ina.volt_aver, ina.curr_aver);
#endif

#if (TIME_LIGHT > 0)
      disp.Light_low();
#endif
    }

    // выполнить раз в секунду шаги...
    switch (step) {
    case 0:
      // тут не должно ни чего быть
      _NOP();
      break;

    case 1:
      // рассчитать количество всех секунд заряда
      tyme.cal_real_tm();
      // статистика
      profil.charge.stat.time = tyme.real_tm;
      profil.charge.stat.ah += Calc_AhWh((int32_t)ina.ampersec);
      profil.charge.stat.wh += Calc_AhWh(ina.getsPower());

      if (tyme.real_tm > time_charge) {
        //  если время больше установленного завершить работу
        activiti = false;
        regim_end = Reason::out_time; // закончилось время
      }
      break;

    case 2:
      // вывод на дисплей
      Display_print(profil.charge.stat.ah, profil.charge.stat.wh, tyme.real_tm,
                    Percentage(curr_min));
      break;

    case 3:
      // выполнить раз в 600 сек
      if (--sec_600 == 0) {
        sec_600 = 600;

        // сохранить настройки и статистику в EEPROM
        eepSavedStruct();
      }
      break;

    case 4:
#if (PROTECT_BLOCK)
      Protect::Guard();
#endif

#ifdef TYME_OFF_CHARGE
      // если ток заряда меньше или равен 10 mA 
      switch (dbat.check(ina.ampersec)) {
      case 1:
        // сбросить значения
        cc.reset();
        vc.reset();
        vmax.volt_max = false;
        break;

      case 2:
      // то отключить заряд
        bitClear(profil.flags, Pr_flags::ACTIVITI);
        break;
      }
#endif
      break;

    case 5:
      // когда напряжение достигнет максимального то устанавливается
      // соответствующий флаг если напряджение снизилось менее 200 мВ то флаг
      // снимается
      if (!chg.flag)
        vmax.max_volt_check(volt_charge_init, ina.volt_aver, ina.curr_aver);
      if (vmax.volt_max) {
        tyme_20h = 1; // запуск отсчета времени
      }

      // если напряжение достигло максимального начинаем отсчет времени
      if (tyme_20h) {
        // отсчет времени
        // если прошло более 20 часов останавливаем заряд и перемешиваем
        if (++tyme_20h >= 72000) {
          activiti = false;
          continue;
        }
      }

      // проверка критических значений - тока
      regim_end = cc.offset_critical_current(vmax.volt_max, ina.curr_aver);

      // если напряжение достигло максимального и ток увеличивается
      if (regim_end == Reason::curr_increased) {
        bitClear(profil.flags, Pr_flags::ACTIVITI); // завершить заряд
        // следующая итерация цикла
        continue;
      }

      // проверка напряжение на уменьшение
      regim_end = vc.offset_critical_voltage(ina.volt_aver);

      // если напряжение начало уменьшаться
      if (regim_end == Reason::volt_decreased) {
        bitClear(profil.flags, Pr_flags::ACTIVITI); // завершить заряд
        // следующая итерация цикла
        continue;
      }

      break;
    } // ...выполнить раз в секунду шаги

    if (step > 0) {
      if (++step >= 5)
        step = 0;
    }
  }
  // цикл заряда

  dcdc.Off();       // отключить заряд, разряд.
  eepSavedStruct(); // сохранить настройки
}