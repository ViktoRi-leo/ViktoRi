#include "global.h"
#include "Display.h"
#include <EEPROM.h>

// сброс настроек при первой прошивке МК
void first_firmware(void) {
#if defined(__LGT8FX8P__)
  if (lgt_eeprom_read_byte(MEM_RESET) != MEMVER)
    Reset_settings(1);
#else
  if (EEPROM.read(MEM_RESET) != MEMVER)
    Reset_settings(1);
#endif
}

// сброс настроек по умолчанию
void Reset_settings(uint8_t sett) {
  bool ext = true;
  do {
    setCursory();
    lcd.print('>');
    disp.printFromPGM((int)(&reset_txt[sett]));
    ClearStr(12);
    // пауза до сигала от кнопок или энкодера
    do {
      butt.Tick(); // опрос кнопок и энкодера
    } while (!butt.tick);

    switch (butt.tick) {
    case Butt::LEFT:
    case Butt::RIGHT:
      sett = constrain_my(sett, 0, POINTRESET, butt.tick);
      break;
    case Butt::STOPCLICK:
    case Butt::OKHELD:
      return; // выйти
    case Butt::OKCLICK:
      ext = false; // выйти из цикла
      break;
    }
  } while (ext);

  switch (sett) {
  case 0:
    break; // выйти
  case 1:
  // сбросить все
  case 2:
    // сбросить настройки по умолчанию - загрузить из PROGMEM
    memcpy_P(&profil, &profil_default, sizeof(Profils));
    setCursory();
    ClearStr(DISPLAYx);
    setCursory();
    for (uint8_t num = 0; num <= PROFIL; num++) {
      eeSave_profil(num);
      lcd.write('.'); // ........
    }
    Res_ktc(); // очистить память КТЦ
    eeSetRound(1);
    eeSetModeNumber(1);
    if (sett == 2)
      break;
  case 3:
    // сбросить калибровки по умолчанию
    vkr.Ohms = OHMS; // кооффицмент коррекции напряжения 0-255
    vkr.profil = 0;  // текущий профиль 0-6
#ifdef VKORRECT
    // коэффициент для калибровки напряжения БП  // REF
    vkr.Vref = VKORRECT;
#else
    vkr.Vref = 1000; // коэффициент для калибровки напряжения БП
#endif
    vkr.shunt = (uint16_t)((float)SHUNT * 100000); // значение шунта
    vkr.inaKoof = INAVOLTKOOF;
    // сохранить структуру vkr
    eeSave_vkr();
    if (sett == 3)
      break;
  case 4:
    // сброс сервисных параметров
    eepResetService();
    break;
  }

  if (sett) {
#if defined(__LGT8FX8P__)
    lgt_eeprom_update_byte(MEM_RESET, MEMVER);
#else
    EEPROM.update(MEM_RESET, MEMVER);
#endif
    resetFunc();
  }

  lcd.clear();
}

// функция сброса значений заряда
void Res_mem_char(void) {
  profil.charge.stat.ah = 0;
  profil.charge.stat.wh = 0;
  profil.charge.stat.time = 0;
}

void Res_mem_addchar(void) {
  profil.add.stat.ah = 0;
  profil.add.stat.wh = 0;
  profil.add.stat.time = 0;
}

// функция сброса значений разряда
void Res_mem_dischar(void) {
  profil.disch.stat.ah = 0;
  profil.disch.stat.wh = 0;
  profil.disch.stat.time = 0;
}

// функция сброса значений разряда
void Res_mem_asym(void) {
  profil.asym.stat.ah = 0;
  profil.asym.stat.wh = 0;
  profil.asym.stat.time = 0;
}

// очистить память значений КТЦ
#if defined(__LGT8FX8P__)
void Res_ktc(void) {
  for (uint16_t i = 0; i < (uint8_t)(5 * 16); i++)
    lgt_eeprom_update_byte(MEM_KTC + i, 0);

  Res_mem_char();
  Res_mem_addchar();
  Res_mem_dischar();
}
#else
void Res_ktc(void) {
  for (uint16_t i = 0; i < (uint8_t)(5 * 16); i++)
    EEPROM.update(MEM_KTC + i, 0);

  Res_mem_char();
  Res_mem_addchar();
  Res_mem_dischar();
}
#endif
