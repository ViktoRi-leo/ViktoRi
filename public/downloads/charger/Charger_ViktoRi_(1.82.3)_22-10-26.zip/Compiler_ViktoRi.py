#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
=====================================================================
 Компилятор ViktoRi
=====================================================================
Программа компиляции и прошивки зарядного устройства ViktoRi
(Python 3 + PlatformIO + Tkinter). Работает в Windows и Linux.

Запуск:
    python Compiler_ViktoRi.py            (Windows / Linux)
    Compiler_ViktoRi_start_windows.bat    (Windows, двойной клик)
    ./Compiler_ViktoRi_start_linux.sh     (Linux)

Программа должна находиться в корневой папке проекта Charger_ViktoRi,
рядом с файлом platformio.ini.

Требования:
    Python 3.8 или новее
    tkinter (Linux: sudo apt install python3-tk)
    PlatformIO (python -m pip install platformio) - проверяется при запуске
=====================================================================
(создана SourseCraft Code Assistant)
=====================================================================
"""

import os
import queue
import re
import shutil
import subprocess
import sys
import threading
from datetime import datetime

APP_TITLE = "Компилятор ViktoRi 1.1"

# Каталог программы = корень проекта Charger_ViktoRi
APP_DIR = os.path.dirname(os.path.abspath(__file__))

PLATFORMIO_INI = os.path.join(APP_DIR, "platformio.ini")
SETUP_SYSTEM_H = os.path.join(APP_DIR, "main", "1_User_Setup.h")
BUILD_ROOT = os.path.join(APP_DIR, ".pio", "build")
BIN_DIR = os.path.join(APP_DIR, "bin")

try:
    import tkinter as tk
    from tkinter import font as tkfont
    from tkinter import filedialog, messagebox, ttk
except ImportError:
    print("Ошибка: не найден модуль tkinter (Tk).", file=sys.stderr)
    print("  Linux (Debian/Ubuntu):  sudo apt install python3-tk", file=sys.stderr)
    print("  Windows: установите Python с сайта https://www.python.org (включая tcl/tk).",
          file=sys.stderr)
    sys.exit(1)


# ======================================================================
#  Служебные функции
# ======================================================================

def check_platformio():
    """Проверяет наличие модуля platformio. Возвращает (True, '') или (False, причина)."""
    try:
        import platformio  # noqa: F401
        return True, ""
    except Exception as exc:
        return False, str(exc)


def parse_boards(ini_path):
    """
    Парсит секции [env:...] файла platformio.ini.
    Возвращает список кортежей (имя_окружения, описание_из_комментария).
    """
    boards = []
    comments = []
    with open(ini_path, "r", encoding="utf-8", errors="replace") as fh:
        for line in fh:
            stripped = line.strip()
            if stripped.startswith(";"):
                comments.append(stripped.lstrip(";").strip())
                continue
            if not stripped:
                comments = []
                continue
            match = re.match(r"^\[env:([^\]]+)\]$", stripped)
            if match:
                name = match.group(1).strip()
                desc = " ".join(comments).strip()
                boards.append((name, desc))
                comments = []
            elif stripped.startswith("["):
                comments = []
    return boards


def read_firmware_version(path):
    """
    Ищет в первой строке файла запись вида '// версия 0.6.0'
    и возвращает версию '0.6.0' (или None).
    """
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            for line in fh:
                match = re.search(r"версия\s*[:=]?\s*(\d+\.\d+(?:\.\d+)?)",
                                  line, re.IGNORECASE)
                if match:
                   return match.group(1)
    except OSError:
        pass
    return None


_PIO_CMD = None


def get_pio_command():
    """
    Определяет команду запуска PlatformIO CLI:
    1) исполняемые файлы pio/platformio из PATH;
    2) иначе - текущий интерпретатор Python с модулем platformio.
    """
    global _PIO_CMD
    if _PIO_CMD is None:
        for exe in ("pio", "platformio"):
            path = shutil.which(exe)
            if path:
                _PIO_CMD = [path]
                break
        else:
            _PIO_CMD = [sys.executable, "-m", "platformio"]
    return list(_PIO_CMD)


def decode_bytes(raw):
    """Декодирует байты вывода процесса, перебирая кодировки UTF-8 -> cp1251."""
    for enc in ("utf-8", "cp1251", "latin-1"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", errors="replace")


class TaskRunner(threading.Thread):
    """
    Запускает внешний процесс в отдельном потоке.
    Вывод и результат передаются через queue, чтобы не блокировать Tk.
    """

    def __init__(self, cmd, cwd, on_output, on_done, on_error):
        super().__init__(daemon=True)
        self.cmd = cmd
        self.cwd = cwd
        self.on_output = on_output
        self.on_done = on_done
        self.on_error = on_error
        self.queue = queue.Queue()

    def run(self):
        try:
            flags = 0
            if os.name == "nt":
                flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
            proc = subprocess.Popen(
                self.cmd, cwd=self.cwd,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                bufsize=0, creationflags=flags,
            )
            while True:
                raw = proc.stdout.readline()
                if not raw:
                    break
                self.queue.put(("out", decode_bytes(raw).rstrip("\r\n")))
            returncode = proc.wait()
            self.queue.put(("done", returncode))
        except Exception as exc:
            self.queue.put(("err", str(exc)))


# ======================================================================
#  Диалог установки PlatformIO (если модуль не найден)
# ======================================================================

class InstallDialog(tk.Tk):
    """Окно: модуль platformio не найден -> предложить установку."""

    def __init__(self, error_text):
        super().__init__()
        self.title("Установка PlatformIO")
        self.resizable(False, False)

        self.running = False
        self.runner = None
        self.installed = False

        width, height = 620, 460
        self.geometry("%dx%d" % (width, height))
        self._center(width, height)
        self.lift()
        self.focus_force()

        frame = ttk.Frame(self, padding=12)
        frame.pack(fill="both", expand=True)

        ttk.Label(frame, text="Модуль 'platformio' не найден в Python.",
                  font=("", 11, "bold")).pack(anchor="w")
        ttk.Label(frame, text=(
            "Для компиляции и прошивки необходима установка PlatformIO.\n"
            "Нажмите кнопку ниже, чтобы установить автоматически, либо\n"
            "выполните вручную в терминале:\n\n"
            "    python -m pip install platformio\n\n"
            "Подробности ошибки: %s" % error_text),
            justify="left", anchor="w", wraplength=560).pack(anchor="w", pady=(4, 10))

        btns = ttk.Frame(frame)
        btns.pack(fill="x", pady=(0, 8))
        self.btn_install = ttk.Button(
            btns, text="Установить platformio (pip install platformio)",
            command=self.install)
        self.btn_install.pack(side="left")
        ttk.Button(btns, text="Закрыть", command=self.destroy).pack(side="right")

        ttk.Label(frame, text="Журнал установки:").pack(anchor="w")
        tf = ttk.Frame(frame)
        tf.pack(fill="both", expand=True)
        self.txt = tk.Text(tf, height=8, wrap="word", state="disabled",
                           font=tkfont.nametofont("TkFixedFont"))
        self.txt.tag_configure("err", foreground="#cc0000")
        self.txt.tag_configure("ok", foreground="#007a00")
        sb = ttk.Scrollbar(tf, command=self.txt.yview)
        self.txt.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.txt.pack(side="left", fill="both", expand=True)

    def _center(self, width, height):
        self.update_idletasks()
        x = max(0, (self.winfo_screenwidth() - width) // 2)
        y = max(0, (self.winfo_screenheight() - height) // 2)
        self.geometry("+%d+%d" % (x, y))

    # ----------------------------- установка -----------------------------
    def install(self):
        if self.running:
            return
        self.running = True
        self.btn_install.configure(state="disabled")
        cmd = [sys.executable, "-m", "pip", "install", "--upgrade", "platformio"]
        self._log("Установка: %s" % " ".join(cmd))
        self.runner = TaskRunner(cmd, APP_DIR, self._on_output, self._on_done,
                                 self._on_error)
        self.runner.start()
        self.after(60, self._poll)

    def _poll(self):
        if self.runner is None:
            return
        try:
            while True:
                kind, payload = self.runner.queue.get_nowait()
                if kind == "out":
                    self._on_output(payload)
                elif kind == "err":
                    self._on_error(payload)
                elif kind == "done":
                    self._on_done(payload)
                    return
        except queue.Empty:
            pass
        self.after(60, self._poll)

    def _on_output(self, line):
        self._log(line)

    def _on_error(self, msg):
        self._log("ОШИБКА: %s" % msg, "err")
        self.running = False
        self.btn_install.configure(state="normal")

    def _on_done(self, returncode):
        self.running = False
        if returncode == 0:
            self._log("PlatformIO успешно установлен.", "ok")
            self.installed = True
            messagebox.showinfo(APP_TITLE, "PlatformIO успешно установлен.\n"
                                           "Программа продолжит запуск.", parent=self)
            self.destroy()
        else:
            self._log("Установка завершилась с ошибкой (код %d)." % returncode, "err")
            self._log("Попробуйте выполнить вручную: python -m pip install platformio",
                      "err")
            self.btn_install.configure(state="normal")

    def _log(self, message, tag=None):
        stamp = datetime.now().strftime("%H:%M:%S")
        self.txt.configure(state="normal")
        self.txt.insert("end", "[%s] %s\n" % (stamp, message), tag)
        self.txt.see("end")
        self.txt.configure(state="disabled")


# ======================================================================
#  Главное окно «Компилятор ViktoRi»
# ======================================================================

class CompilerApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_TITLE)
        self.minsize(720, 540)
        self.geometry("820x600")
        self._center(820, 600)
        self.protocol("WM_DELETE_WINDOW", self._on_close)

        self.boards = []          # [(имя, описание), ...]
        self.board_map = {}       # строка в комбобоксе -> имя env
        self.task = None
        self.running = False
        self.current_action = None
        self.current_env = None
        self.selected_binary = None   # путь к выбранному бинарнику (или None)

        self._build_ui()
        self._load_project()

    # ------------------------------ интерфейс ----------------------------
    def _center(self, width, height):
        self.update_idletasks()
        x = max(0, (self.winfo_screenwidth() - width) // 2)
        y = max(0, (self.winfo_screenheight() - height) // 2)
        self.geometry("%dx%d+%d+%d" % (width, height, x, y))

    def _build_ui(self):
        root = ttk.Frame(self, padding=10)
        root.pack(fill="both", expand=True)

        # --- информация о прошивке и платах
        info = ttk.LabelFrame(root, text="Прошивка", padding=8)
        info.pack(fill="x", pady=(0, 8))

        row1 = ttk.Frame(info)
        row1.pack(fill="x")
        ttk.Label(row1, text="Версия прошивки:").pack(side="left")
        self.lbl_version = ttk.Label(row1, text="—", font=("", 10, "bold"))
        self.lbl_version.pack(side="left", padx=(6, 0))

        row2 = ttk.Frame(info)
        row2.pack(fill="x", pady=(6, 0))
        ttk.Label(row2, text="Плата:").pack(side="left")
        self.board_var = tk.StringVar()
        self.cmb_board = ttk.Combobox(row2, textvariable=self.board_var,
                                      state="readonly", width=72)
        self.cmb_board.pack(side="left", padx=(6, 0))

        row3 = ttk.Frame(info)
        row3.pack(fill="x", pady=(6, 0))
        self.btn_select_bin = ttk.Button(row3, text="Выбрать бинарник",
                                         command=self.on_select_binary)
        self.btn_select_bin.pack(side="left", padx=(0, 6))
        self.btn_clear_bin = ttk.Button(row3, text="Убрать бинарник",
                                        command=self.on_clear_binary)
        self.btn_clear_bin.pack(side="left", padx=(0, 6))
        self.binary_var = tk.StringVar(value="Бинарник не выбран")
        ttk.Label(row3, textvariable=self.binary_var,
                  foreground="#0000aa").pack(side="left", padx=(6, 0))

        # --- кнопки действий
        actions = ttk.Frame(root)
        actions.pack(fill="x", pady=(0, 8))
        self.btn_compile = ttk.Button(actions, text="Скомпилировать",
                                      command=self.on_compile)
        self.btn_compile.pack(side="left", padx=(0, 6))
        self.btn_upload = ttk.Button(actions, text="Прошить",
                                     command=self.on_upload)
        self.btn_upload.pack(side="left", padx=(0, 6))
        self.btn_both = ttk.Button(actions, text="Скомпилировать и прошить",
                                   command=self.on_both)
        self.btn_both.pack(side="left")

        # --- окно вывода логов
        logf = ttk.LabelFrame(root, text="Лог компиляции и прошивки", padding=8)
        logf.pack(fill="both", expand=True)

        self.txt_log = tk.Text(logf, height=14, wrap="word", state="disabled",
                               font=tkfont.nametofont("TkFixedFont"))
        self.txt_log.tag_configure("err", foreground="#cc0000")
        self.txt_log.tag_configure("ok", foreground="#007a00")
        sb = ttk.Scrollbar(logf, command=self.txt_log.yview)
        self.txt_log.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.txt_log.pack(side="top", fill="both", expand=True)

        ttk.Button(logf, text="Очистить логи", command=self.clear_log).pack(
            anchor="e", pady=(6, 0))

        # --- строка состояния
        status = ttk.Frame(root)
        status.pack(fill="x", pady=(8, 0))
        self.progress = ttk.Progressbar(status, mode="indeterminate", length=140)
        self.progress.pack(side="left", padx=(0, 8))
        self.status_var = tk.StringVar(value="Готов к работе")
        ttk.Label(status, textvariable=self.status_var).pack(side="left")

    # --------------------------- загрузка проекта ------------------------
    def _load_project(self):
        self.log("Каталог проекта: %s" % APP_DIR)

        # platformio.ini
        if not os.path.isfile(PLATFORMIO_INI):
            msg = ("Файл platformio.ini не найден:\n%s\n\n"
                   "Программа должна находиться в папке проекта Charger_ViktoRi."
                   % PLATFORMIO_INI)
            self.log(msg, "err")
            messagebox.showerror(APP_TITLE, msg, parent=self)
            return

        try:
            self.boards = parse_boards(PLATFORMIO_INI)
        except OSError as exc:
            msg = "Не удалось прочитать platformio.ini: %s" % exc
            self.log(msg, "err")
            messagebox.showerror(APP_TITLE, msg, parent=self)
            return

        if not self.boards:
            msg = "В platformio.ini не найдено ни одного окружения [env:...]."
            self.log(msg, "err")
            messagebox.showerror(APP_TITLE, msg, parent=self)
            return

        values = []
        for name, desc in self.boards:
            display = ("%s  —  %s" % (name, desc)) if desc else name
            self.board_map[display] = name
            values.append(display)
        self.cmb_board.configure(values=values)
        self.cmb_board.current(0)
        self.log("Найдено плат: %d" % len(self.boards))
        for name, desc in self.boards:
            self.log("  [env:%s]  %s" % (name, desc))

        # версия прошивки из первой строки src/Setup_system.h ('// версия 0.6.0')
        if os.path.isfile(SETUP_SYSTEM_H):
            version = read_firmware_version(SETUP_SYSTEM_H)
            if version:
                self.lbl_version.configure(text=version)
                self.log("Версия прошивки: %s" % version)
            else:
                self.lbl_version.configure(text="не найдена")
                self.log("Строка '// версия X.Y.Z' не найдена "
                         "в первой строке src/Setup_system.h", "err")
        else:
            self.lbl_version.configure(text="нет файла Setup_system.h")
            self.log("Файл src/Setup_system.h не найден.", "err")

    # ------------------------------ действия -----------------------------
    def on_compile(self):
        self._reset_binary_for_build()
        self._start_task("compile", "Скомпилировать")

    def on_upload(self):
        if self.selected_binary:
            self._start_task("upload_bin", "Прошить выбранный бинарник")
        else:
            self._start_task("upload", "Прошить")

    def on_both(self):
        self._reset_binary_for_build()
        self._start_task("both", "Скомпилировать и прошить")

    def _start_task(self, action, title):
        if self.running:
            return
        env = self.board_map.get(self.board_var.get())
        if not env:
            messagebox.showwarning(APP_TITLE, "Сначала выберите плату.", parent=self)
            return
        if action == "upload_bin":
            target, err = self._prepare_upload_bin(env)
            if err:
                messagebox.showerror(APP_TITLE, err, parent=self)
                return
            self.log("Выбранный бинарник скопирован в каталог сборки: %s"
                     % os.path.join(BUILD_ROOT, env, target), "ok")
        cmd = self._build_cmd(action, env)
        self._set_busy(True)
        self.current_action = action
        self.current_env = env
        self.status_var.set("Выполняется: %s (%s)..." % (title, env))
        self.log("")
        self.log("Запуск задачи «%s» для платы %s" % (title, env))
        self.log("Команда: %s" % " ".join(cmd))
        self.task = TaskRunner(cmd, APP_DIR, self._on_output, self._on_done,
                               self._on_error)
        self.progress.start(12)
        self.task.start()
        self.after(60, self._poll_task)

    @staticmethod
    def _build_cmd(action, env):
        base = get_pio_command()
        if action in ("upload", "both", "upload_bin"):
            # upload сам выполняет компиляцию перед прошивкой
            return base + ["run", "-e", env, "-t", "upload"]
        return base + ["run", "-e", env]

    # ----------------------- выбор бинарника для прошивки -----------------
    def on_select_binary(self):
        """Открывает диалог выбора бинарного файла прошивки в папке программы."""
        if self.running:
            return
        path = filedialog.askopenfilename(
            parent=self,
            title="Выберите бинарный файл прошивки",
            initialdir=APP_DIR,
            filetypes=[("Бинарные файлы", "*.bin *.hex"), ("Все файлы", "*.*")],
        )
        if path:
            self.selected_binary = path
            self.binary_var.set("Выбран бинарник : %s" % os.path.basename(path))
            self.log("Выбран бинарник: %s" % path, "ok")

    def on_clear_binary(self):
        """Сбрасывает выбранный бинарник."""
        if self.selected_binary:
            self.log("Выбранный бинарник сброшен: %s"
                     % os.path.basename(self.selected_binary))
        self.selected_binary = None
        self.binary_var.set("Бинарник не выбран")

    def _reset_binary_for_build(self):
        """Если выбран бинарник - сбрасывает его перед компиляцией/прошивкой платы."""
        if self.selected_binary:
            self.on_clear_binary()
            self.log("Бинарник сброшен: выполняется сборка для выбранной платы.")

    def _prepare_upload_bin(self, env):
        """
        Копирует выбранный бинарник в каталог сборки как firmware.bin/hex,
        чтобы PlatformIO при «upload» прошил именно этот файл без пересборки.
        Возвращает (имя_файла, None) или (None, сообщение_об_ошибке).
        """
        if not self.selected_binary:
            return None, "Сначала выберите бинарник."
        fname = os.path.basename(self.selected_binary).lower()
        if fname.endswith(".bin"):
            target = "firmware.bin"
        elif fname.endswith(".hex"):
            target = "firmware.hex"
        else:
            return None, "Поддерживаются только файлы прошивки *.bin и *.hex."
        build_dir = os.path.join(BUILD_ROOT, env)
        try:
            os.makedirs(build_dir, exist_ok=True)
            dst = os.path.join(build_dir, target)
            shutil.copy2(self.selected_binary, dst)
            os.utime(dst, None)  # гарантируем, что файл новее исходников
            return target, None
        except OSError as exc:
            return None, "Не удалось подготовить бинарник к прошивке: %s" % exc

    def _poll_task(self):
        if self.task is None:
            return
        try:
            while True:
                kind, payload = self.task.queue.get_nowait()
                if kind == "out":
                    self._on_output(payload)
                elif kind == "err":
                    self._on_error(payload)
                elif kind == "done":
                    self._on_done(payload)
                    return
        except queue.Empty:
            pass
        self.after(60, self._poll_task)

    def _on_output(self, line):
        if re.search(r"\b(error|fatal|failed|undefined reference|ошибка)\b",
                     line, re.IGNORECASE):
            self.log(line, "err")
        else:
            self.log(line)

    def _on_error(self, msg):
        self.log("ОШИБКА: %s" % msg, "err")
        self.progress.stop()
        self._set_busy(False)
        self.task = None
        self.current_action = self.current_env = None
        self.status_var.set("Ошибка запуска процесса")

    def _on_done(self, returncode):
        action, env = self.current_action, self.current_env
        self.progress.stop()
        self._set_busy(False)
        self.task = None
        self.current_action = self.current_env = None
        if returncode == 0:
            if action == "compile":
                self.log("Компиляция успешно завершена.", "ok")
                self._copy_artifacts(env)
                self.status_var.set("Готово. Бинарные файлы сохранены в bin/")
            elif action == "upload":
                self.log("Прошивка успешно завершена.", "ok")
                self.status_var.set("Готово. Прошивка завершена")
            elif action == "upload_bin":
                self.log("Прошивка выбранного бинарника успешно завершена.", "ok")
                self.status_var.set("Готово. Прошивка завершена")
            else:
                self.log("Компиляция и прошивка успешно завершены.", "ok")
                self._copy_artifacts(env)
                self.status_var.set("Готово. Прошивка завершена")
        else:
            self.log("Процесс завершился с ошибкой (код %d)." % returncode, "err")
            self.status_var.set("Ошибка (код %d)" % returncode)

    # ------------------------- сохранение бинарников ---------------------
    def _copy_artifacts(self, env):
        src_dir = os.path.join(BUILD_ROOT, env)
        if not os.path.isdir(src_dir):
            self.log("Папка сборки не найдена: %s" % src_dir, "err")
            return
        try:
            os.makedirs(BIN_DIR, exist_ok=True)
        except OSError as exc:
            self.log("Не удалось создать каталог bin/: %s" % exc, "err")
            return
        copied = 0
        for fname in ("firmware.hex", "firmware.bin", "firmware.elf"):
            src = os.path.join(src_dir, fname)
            if os.path.isfile(src):
                dst = os.path.join(BIN_DIR, "%s_%s" % (env, fname))
                try:
                    shutil.copy2(src, dst)
                    self.log("Сохранено: %s" % dst, "ok")
                    copied += 1
                except OSError as exc:
                    self.log("Не удалось сохранить %s: %s" % (dst, exc), "err")
        if copied == 0:
            self.log("Бинарные файлы не найдены в %s" % src_dir, "err")

    # ------------------------------ служебное ----------------------------
    def log(self, message, tag=None):
        stamp = datetime.now().strftime("%H:%M:%S")
        self.txt_log.configure(state="normal")
        self.txt_log.insert("end", "[%s] %s\n" % (stamp, message), tag)
        self.txt_log.see("end")
        self.txt_log.configure(state="disabled")

    def clear_log(self):
        self.txt_log.configure(state="normal")
        self.txt_log.delete("1.0", "end")
        self.txt_log.configure(state="disabled")

    def _set_busy(self, busy):
        self.running = busy
        state = "disabled" if busy else "normal"
        for btn in (self.btn_compile, self.btn_upload, self.btn_both,
                    self.btn_select_bin, self.btn_clear_bin):
            btn.configure(state=state)
        self.cmb_board.configure(state="disabled" if busy else "readonly")

    def _on_close(self):
        if self.running:
            if not messagebox.askokcancel(
                    APP_TITLE, "Идёт выполнение задачи.\nВсё равно выйти?",
                    parent=self):
                return
        self.destroy()


# ======================================================================
#  Точка входа
# ======================================================================

def main():
    ok, error_text = check_platformio()
    if not ok:
        # отдельное главное окно установки PlatformIO
        dialog = InstallDialog(error_text)
        dialog.mainloop()
        # повторная проверка после возможной установки
        ok, error_text = check_platformio()
        if not ok:
            print("Модуль platformio не установлен. Программа завершена.",
                  file=sys.stderr)
            sys.exit(1)

    CompilerApp().mainloop()


# ----------------------------------------------------------------------
#  Глобальный обработчик ошибок: печать в консоль и запись в лог-файл
# ----------------------------------------------------------------------

def _excepthook(exc_type, exc_value, exc_tb):
    import traceback
    tb = "".join(traceback.format_exception(exc_type, exc_value, exc_tb))
    print(tb, file=sys.stderr)
    try:
        with open(os.path.join(APP_DIR, "compiler_viktori.log"), "a",
                  encoding="utf-8") as fh:
            fh.write("\n[%s]\n%s" % (datetime.now().isoformat(), tb))
    except OSError:
        pass


sys.excepthook = _excepthook


if __name__ == "__main__":
    main()