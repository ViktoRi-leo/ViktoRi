#include "logger.h"
#include "../core/global.h"
#include "INA226int.h"
#include "sensors.h"

/*======== отправка значений в сетевой порт ========*/

#if (LOGGER == 1)
// буфер отправки - байт
#define MU_TX_BUF 16
// буфер приема
#if (REMOTE_CONTROL)
#define MU_RX_BUF 8
#else
#define MU_TX_BUF 4
#endif

#elif (LOGGER == 4)
// буфер отправки - байт
#define MU_TX_BUF 34
// буфер приема
#if (REMOTE_CONTROL)
#define MU_RX_BUF 8
#else
#define MU_TX_BUF 4
#endif

#elif (LOGGER == 2 or LOGGER == 3)
// подключить Print.h
#define MU_PRINT
// буфер отправки - байт
#define MU_TX_BUF 32
#define MU_RX_BUF 4
#endif

#include <MicroUART.h>
MicroUART mSerial;

void MU_serialEvent(void) {}

void serial_begin(void) {
  mSerial.begin(SERIAL_SPEED); // 9600   115200
#if (LOGGER > 0)
  Sout.mode = logger_modes::logWAIT;
#endif
}

#if (REMOTE_CONTROL)
bool loggerAvailable(void) { return mSerial.available(); }

uint8_t loggerRead(void) { return mSerial.read(); }

void loggerWrite(const uint8_t *data, uint8_t len) { mSerial.write(data, len); }
#endif

// вернуть мАч, мВтч
int32_t get_mAmW(int32_t x) {
#if defined(__LGT8FX8P__)
  // Полученная_отданная емкость АКБ (А/ч)) /1000
  x = x ? DSC_DIV_get((int32_t)(x + 500), (uint16_t)1000) : 0;
#else
  // Полученная_отданная емкость АКБ (А/ч)) /1000
  x = x ? (x + 500) / 1000 : 0;
#endif
  return x;
}

// формируем основные данные
void Serial_Out::create(void) {
  if (--_tm == 0) {
    _tm = LOGGTIME;
    send_log.volt = ina.volt_aver;
    send_log.amper = ina.curr_aver;

    switch (mode) {
    case logger_modes::logCHARGE:
#if (BRRANIMIR)
    case logger_modes::logBRANIMIR:
#endif
      send_log.Achas = get_mAmW(profil.charge.stat.ah);
      break;
    case logger_modes::logADDCHARGE:
      send_log.Achas = get_mAmW(profil.add.stat.ah);
      break;
    case logger_modes::logASYMMETRIC:
      send_log.Achas = get_mAmW(profil.asym.stat.ah);
      break;
    case logger_modes::logDISCHARGE:
      send_log.Achas = -get_mAmW(profil.disch.stat.ah);
      break;
    default:
      send_log.Achas = 0;
      break;
    }

#if (VOLTIN == 1)
    send_log.volt_in = getPower(); // напряжение от БП (милливольт) /1000
#endif
#if (SENSTEMP1 > 0)
    send_log.tQ1 = temp_Q1; // Температура на Q1 (градусы)
#endif
#if (SENSTEMP2 > 0)
    send_log.tAkb = temp_akb; // 6 Температура АКБ (градусы)
#endif

    Serial_Out::Serial_out();
  }
}

// Расширенные данные LOGGER = 4
void Serial_Out::create_advanced(void) {
  if (--_tm == 0) {
    _tm = LOGGTIME;
    send_log_adv.volt = ina.volt_aver;
    send_log_adv.amper = ina.curr_aver;

    switch (mode) {
    case logger_modes::logCHARGE:
#if (BRRANIMIR)
    case logger_modes::logBRANIMIR:
#endif
      send_log_adv.Achas = get_mAmW(profil.charge.stat.ah);
      send_log_adv.Wh_charge = get_mAmW(profil.charge.stat.wh);
      send_log_adv.time_charge = profil.charge.stat.time;
      break;
    case logger_modes::logADDCHARGE:
      send_log_adv.Achas = get_mAmW(profil.add.stat.ah);
      send_log_adv.Wh_charge = get_mAmW(profil.add.stat.wh);
      send_log_adv.time_charge = profil.add.stat.time;
      break;
    case logger_modes::logASYMMETRIC:
      send_log_adv.Achas = get_mAmW(profil.asym.stat.ah);
      send_log_adv.Wh_charge = get_mAmW(profil.asym.stat.wh);
      send_log_adv.time_charge = profil.asym.stat.time;
      break;
    case logger_modes::logDISCHARGE:
      send_log_adv.Achas = -get_mAmW(profil.disch.stat.ah);
      send_log_adv.Wh_charge = -get_mAmW(profil.disch.stat.wh);
      send_log_adv.time_charge = profil.disch.stat.time;
      break;
    default:
      send_log_adv.Achas = 0;
      send_log_adv.Wh_charge = 0;
      send_log_adv.time_charge = get_second_usr();
      send_log_adv.soc = 0;
      break;
    }

#if (VOLTIN == 1)
    send_log_adv.volt_in = getPower();
#endif
#if (SENSTEMP1 > 0)
    send_log_adv.tQ1 = temp_Q1;
#endif
#if (SENSTEMP2 > 0)
    send_log_adv.tAkb = temp_akb;
#endif

    // Дополнительные данные
    send_log_adv.mode = profil.Regim;
    send_log_adv.type_akb = profil.akb.type;
    send_log_adv.capacity = profil.akb.capacity;
    send_log_adv.active_flag = bitRead(profil.flags, Pr_flags::ACTIVITI);
    send_log_adv.round_current = eeGetRound();
    send_log_adv.profil = vkr.profil;
    send_log_adv.soc = percent;
    send_log_adv.regim_end = (uint8_t)regim_end;
    send_log_adv.regims = (uint8_t)regims;

    Serial_Out::Serial_out();
  }
}

// Вывод логов в сетевой порт. Вызывать постоянно раз в секунду
void Serial_Out::Serial_out(void) {

#if (LOGGER == 1)
  uint8_t *ptr = ((uint8_t *)&send_log);
  send_log.crc = 0;
  for (uint8_t i = 0; i < sizeof(LogSend) - 1; i++) {
    send_log.crc += ptr[i]; // Расчет контрольной суммы
    mSerial.write(ptr[i]);  // передать данные
  }
  mSerial.write(ptr[sizeof(LogSend) - 1]); // передать символ CRC

#elif (LOGGER == 2)
  _time += LOGGTIME;
  mSerial.print(F(txt_ViktoRi)); // ViktoRi  // начало посылки
  mSerial.write(';');
  mSerial.print(_time); // время
  mSerial.write(';');
  serial_print(send_log.volt, 3);
  serial_print(send_log.amper, 3);
  serial_print(send_log.Achas, 4);
  serial_print(send_log.volt_in, 3);    // напряжение от БП Вольт
  mSerial.print((int16_t)send_log.tQ1); // Температура на Q1 (градусы)
  mSerial.write(';');
  mSerial.print((int16_t)send_log.tAkb); // 6 Температура АКБ (градусы)
  mSerial.write(';');
  mSerial.println(); // конец посылки

#elif (LOGGER == 3)
  mSerial.write('$'); // начало посылки
  serial_print(send_log.volt);
  serial_print(send_log.amper);
  serial_print(send_log.Achas);
  serial_print(send_log.volt_in); // напряжение от БП (милливольт)/1000
  serial_print(send_log.tQ1);     // Температура на Q1 (градусы)
  serial_print(send_log.tAkb);    // 6 Температура АКБ (градусы)
  mSerial.write(';');             // конец посылки

#elif (LOGGER == 4)
  // Расширенный лог
  uint8_t *ptr_adv = ((uint8_t *)&send_log_adv);
  send_log_adv.crc = 0;
  for (uint8_t i = 0; i < sizeof(LogSendAdvanced) - 1; i++) {
    send_log_adv.crc += ptr_adv[i]; // Расчет контрольной суммы
    mSerial.write(ptr_adv[i]);      // передать данные
  }
  // передать символ CRC
  mSerial.write(ptr_adv[sizeof(LogSendAdvanced) - 1]);
#endif
}

#if (LOGGER == 2)
// вывод значения в тысячных долях (мВ -> В, мА -> А, мАч -> Ач) с y знаками
// после запятой и разделителем ';'
// целочисленный эквивалент mSerial.print(x / 1000.0, y)
void Serial_Out::serial_print(int32_t x, uint8_t y) {
  if (x < 0) {
    mSerial.write('-');
    x = -x;
  }
  mSerial.print((uint32_t)(x / 1000)); // целая часть
  if (y) {
    mSerial.write('.');
    uint16_t f = (uint16_t)(x % 1000);
    uint16_t d = 100;
    while (y--) {
      // после третьего знака разрядность исчерпана - дописываются нули
      mSerial.write('0' + (uint8_t)(d ? (f / d) % 10 : 0));
      d /= 10;
    }
  }
  mSerial.write(';');
}
#endif

#if (LOGGER == 3)
void Serial_Out::serial_print(int32_t x) {
  mSerial.print(x);
  mSerial.write(' ');
}
#endif

Serial_Out Sout;