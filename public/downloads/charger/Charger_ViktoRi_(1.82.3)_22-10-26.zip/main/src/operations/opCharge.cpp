#include "../core/global.h"
#include "../display/Display.h"
#include "../hardware/DCDC.h"
#include "../hardware/INA226int.h"
#include "operations.h"

/*
Реализованы режимы работы:
- предзаряд;
- заряд;
- качели.
Если в настройках включен Предзаряд то сперва включается Предзаряд.
Когда напряжение достигает напряжения предзаряда, то включается
обычный Заряд.
В заряде - когда ток перестает снижаться или достигает значения минимального
тока, установленного в настройках, то если в настройках включен режим Качели то
включаются Качели. Иначе заряд отключается.
В качелях - когда включен ток и инапряжение достигает максимального, идет замер
тока, если ток снизился ниже минимального то включается режим Заряд, Качели
больше не включатся. Заряд продолжается до снижения тока до минимального или
когда ток перестанет снижаться или завершится максимальное время заряда.
*/

// флаги управления зарядом
enum Flags_charge : uint8_t {
  CHARGEZ,   // заряд включен
  OSCILZ,    // флаг изменения тока в предзаряде и качелях
  OSCILDONE, // осциляция проведена
};

// Функция заряда.
// напряжение заряда (мВ), ток заряда (мА), минимальный ток заряда (мА),
// ограничение времени заряда в часах
void Charge(uint16_t volt_charge_init, int16_t curr_charge_init,
            int16_t curr_min, uint32_t time_charge) {

  // установить флаги Flags_charge
  uint8_t flagsz = 0b00000011;
  if (bitRead(profil.flags, Pr_flags::OSCIL))
    bitSet(flagsz, Flags_charge::OSCILDONE);

#if (PROTECT_BLOCK)
  Protect::Guard();
#endif
  // вывод значений заряда
  // вывод напряжения и тока заряда
  print_volt_current(volt_charge_init, curr_charge_init);
  print_hour((uint8_t)time_charge); // вывод времени
  lcd.setCursor(DISPLAYx - 2, 0);
  printCykl(); // вывод количества циклов

  time_charge *= 3600; // перевел часы в секунды

  Curr_critical_check cc;
  Volt_critical_check vc;
  Volt_max_check vmax;
  Disconnect_battery dbat;
  Change_charge chg(&volt_charge_init, &curr_charge_init);

  TimeCount tyme;
  // время заряда или дозаряда
  tyme.local = profil.charge.stat.time;

  regims = bitRead(profil.flags, Pr_flags::PRECHAR) ? Regims::REGIM_PRECHARGE
                                                    : Regims::REGIM_CHARGE;

  uint8_t pre_minut = 60; // таймер 60 секунд для предзаряда
  uint16_t sec_600 = 600; // время 10 минут

  uint16_t Timezar = 0;       // время до завершения заряда секунды
  uint16_t v1 = 0;            // переменная для сохранения напряжения
  uint8_t step = 0;           // шаги
  bool cur_stop_flag = false; // флаг остановки по току

#if (CURRENT_REDUCTION == 1)
  const int16_t cur_max = curr_charge_init;
  int16_t curr_charge_cr = curr_charge_init;
#endif

#if (POWER == 1)
  // Relay_on(true);                       // включить сеть 220В
#endif

  Delay(3000);
  lcd.clear();
  dcdc.start(DCDC_CHARGE);
  dcdc.begin(volt_charge_init, (bitRead(profil.flags, Pr_flags::PRECHAR)
                                    ? profil.charge.current_pre >> 1
                                    : curr_charge_init));
  start_second_usr();
  // цикл заряда
  while (bitRead(flagsz, Flags_charge::CHARGEZ) and
         bitRead(profil.flags, Pr_flags::ACTIVITI)) {
    sensor_survey();

    if (butt.tick) {
      // если кнопка нажата
      if (chg.flag) {
        // производится корректировка напряжения и тока заряда
        chg.change_charge();
        cc.reset();
        vc.reset();
        vmax.volt_max = false;
#if (CURRENT_REDUCTION == 1)
        curr_charge_cr = curr_charge_init;
#endif
      } else {
        if (op_window == WINDC and butt.tick == Butt::OKHELD) {
          // начать корректировку напряжения и тока
          chg.flag = true;
        } else {
          // общие кнопки режима
          op_buttons(WINDC);
        }
      }
    }

    // выполнить раз в секунду...
    if (get_second()) {
      step = 10;
      if (sysFlagsError()) {
        // если чтото не так, то выходим
        // activiti = false;
        bitClear(flagsz, Flags_charge::CHARGEZ);
        step = 0;
      }
    } // ... выполнить раз в секунду

    switch (step) {
    case 0:
      // тут не должно ни чего быть
      _NOP();
      break;
    case 10:
#if (PROTECT_BLOCK)
      Protect::Guard();
#endif
      break;
    case 9:
      // рассчитать количество всех секунд заряда
      tyme.cal_real_tm();

      if (tyme.real_tm > time_charge) {
        //  если время больше установленного завершить работу
        bitClear(flagsz, Flags_charge::CHARGEZ);
        regim_end = Reason::out_time; // закончилось время
      }

      profil.charge.stat.time = tyme.real_tm;
      // расчет ампер/часов
      profil.charge.stat.ah += Calc_AhWh((int32_t)ina.ampersec);
      // расчет ватт/часов
      profil.charge.stat.wh += Calc_AhWh(ina.getsPower());

      // таймер продления заряда: окно истекло без повторной остановки
      // тока - значит ток снова снижается, заряд продолжается
      if (Timezar) {
        if (--Timezar == 0)
          cur_stop_flag = false;
      }
      break;

    case 8:
      switch (regims) {
      case Regims::REGIM_PRECHARGE:
        //  включен предварительный заряд
        // если напряжение больше напряжения предзаряда то отключить
        // предварительный заряд
        if (ina.volt_aver > profil.charge.voltage_pre) {
          // отключить предварительный заряд
          regims = Regims::REGIM_CHARGE;
          // обычный заряд
          dcdc.setCur_charge(curr_charge_init);
          bitSet(flagsz, Flags_charge::OSCILZ);
        } else if (--pre_minut == 0) {
          pre_minut = 60;
          // ток заряда увеличивается и уменьшается раз в минуту в течении 10
          // минут
          if (bitRead(flagsz, Flags_charge::OSCILZ)) {
            // увеличение тока заряда
            dcdc.setCur_charge(dcdc.getCur_charge() +
                               (profil.charge.current_pre >> 4));
            // когда ток достигнет максимального
            // переключить флаг на уменьшение
            if (dcdc.getCur_charge() >= profil.charge.current_pre)
              bitClear(flagsz, Flags_charge::OSCILZ);

          } else {
            // увеличение тока заряда
            dcdc.setCur_charge(dcdc.getCur_charge() -
                               (profil.charge.current_pre >> 4));
            // когда ток достигнет минимального переключить флаг на увеличение
            if (dcdc.getCur_charge() <= profil.charge.current_pre >> 1)
              bitSet(flagsz, Flags_charge::OSCILZ);
          }
        }
        break;

      case Regims::REGIM_CHARGE:
        // включен заряд
#if (CURRENT_REDUCTION == 1)
        // начать снижение тока заряда когда напряжение достигнет
        // установленного и ток заряда - максимальный деленный на 4
        if (eepGetService_flag(Serviceflags::FLAG_CURREDUCT) and !chg.flag and
            (profil.charge.voltage_decr_cur < volt_charge_init) and
            (ina.voltsec > profil.charge.voltage_decr_cur) and
            (ina.ampersec > (cur_max >> 2))) {
          curr_charge_cr = map_my(ina.voltsec, profil.charge.voltage_decr_cur,
                                  volt_charge_init, cur_max, (cur_max >> 2));
          dcdc.setCur_charge(curr_charge_cr);
        }
#endif
        // проверка критических значений - тока
        regim_end = cc.offset_critical_current(vmax.volt_max, ina.curr_aver);

        // если напряжение достигло максимального и ток увеличивается
        if (regim_end == Reason::curr_increased) {
          bitClear(profil.flags, Pr_flags::ACTIVITI); // завершить заряд
          break;
        } else if (regim_end == Reason::cur_stop) {
          // если ток перестал снижаться
          // включение режима Осчиляция(Качели) при завершении заряда
          if (bitRead(flagsz, Flags_charge::OSCILDONE)) {
            regims = Regims::REGIM_OSCIL;
            break;
          } else if (!cur_stop_flag) {
            // первая остановка тока - продлить заряд на контрольное окно
            cur_stop_flag = true;
            Timezar = Time_Curr_decrease + 2;
          } else {
            // ток не снижается второе окно подряд - завершить заряд
            bitClear(flagsz, Flags_charge::CHARGEZ);
            break;
          }
        }

        // проверка напряжение на уменьшение
        regim_end = vc.offset_critical_voltage(ina.volt_aver);

        // если напряжение начало уменьшаться
        if (regim_end == Reason::volt_decreased) {
          bitClear(profil.flags, Pr_flags::ACTIVITI); // завершить заряд
        }
        break;

      case Regims::REGIM_OSCIL: {
        // если в настройках включена Осциляция(Качели) то при снижении тока
        // менее curr_min*2 включается Режим осциляции - включение и
        // отключение тока
        auto vt = difference(ina.volt_aver, v1);
        if (abs(vt) < 10) {
          InvBit(flagsz, Flags_charge::OSCILZ); // инвертируем флаг
          if (bitRead(flagsz, Flags_charge::OSCILZ))
            dbat.reset_timer();
#if (MCP4725DAC)
          if (BitIsClear(flagsz, Flags_charge::OSCILZ))
            dac.setVoltage(0);
#else
          dcdc.pause(bitRead(flagsz, Flags_charge::OSCILZ));
#endif
        } else
          v1 = ina.volt_aver;

        // когда включен зарядный ток и напряжение достигло максимального и
        // ток снизился до минимального то перейти в Заряд
        if (bitRead(flagsz, Flags_charge::OSCILZ) and vmax.volt_max and
            (ina.curr_aver <= curr_min)) {
          // перейти в обычный режим заряда
          regims = Regims::REGIM_CHARGE;
          bitClear(flagsz, Flags_charge::OSCILDONE);
          break;
        }
        break;
      }
      default:
        break;
      }
      break;

    case 7:
      // вывод на дисплей 1602
#if (DISPLAYy == 2)
      // вывод текущих значений напряжения, тока.  Вывод Ватт-часов.
      Display_print(profil.charge.stat.ah, profil.charge.stat.wh, tyme.real_tm,
                    Percentage(curr_min, curr_charge_init));
      switch (op_window) {
      case 2:
        // экран 2
        // выполнить если включен таймер завершения заряда
        if (Timezar) {
          print_space();
          lcd.print(Timezar);
        }
        break;
        // *58.3Wh 45C 25C  *
        // *24.1V C1 N1     *
      case 3:
        // экран 3
        setCursorx();
        print_volt_current(ina.volt_aver, ina.curr_aver, 3);
        setCursory();
        // значения в формате Q8: x*1000/256 == x*125/32
        print_milli((cc.curr_critical * 125) >> 5, 1);
        print_space();
        print_milli((vc.volt_critical * 125) >> 5, 1);
        print_space();
        break;
      case 4:
        // экран 4
        // изменение напряжения и тока заряда
        if (chg.flag) {
          setCursorx();
          print_volt_current(ina.voltsec, ina.ampersec);
          setCursory();
          Write_x(chg.flag_change);        // > or  пробел
          print_volt(volt_charge_init);    // Напряжение и ток заряда
          Write_x(!chg.flag_change);       // > or  пробел
          print_current(curr_charge_init); // Напряжение и ток заряда
        } else {
          Display_print(0, 0, 0, 0);
        }
        break;
      }
#endif
// вывод на дисплей 2004
#if (DISPLAYy == 4)
      Display_print(profil.charge.stat.ah, profil.charge.stat.wh, tyme.real_tm,
                    Percentage(curr_min, curr_charge_init));
      switch (op_window) {
      case 1:
        if (Timezar) {
          print_space();
          // выполнить если включен таймер завершения заряда
          lcd.print(Timezar);
        }
        break;
      // изменение напряжения и тока заряда
      case 2:
        // изменение напряжения и тока заряда
        if (chg.flag) {
          setCursorx();
          print_volt_current(ina.voltsec, ina.ampersec);
          setCursory();
          Write_x(chg.flag_change);        // > or  пробел
          print_volt(volt_charge_init);    // Напряжение и ток заряда
          Write_x(!chg.flag_change);       // > or  пробел
          print_current(curr_charge_init); // Напряжение и ток заряда
        } else {
          Display_print(0, 0, 0, 0);
        }
        break;
      }
#endif
      if (!chg.flag) {
        // обратный отсчет время отображения экрана
        disp_time();
      }
      break;
    case 6:
      // когда напряжение достигнет максимального то устанавливается
      // соответствующий флаг если напряджение снизилось менее 200 мВ то флаг
      // снимается
      if (!chg.flag)
        vmax.max_volt_check(volt_charge_init, ina.volt_aver, ina.curr_aver);
      break;

    case 5:
      // выполнить каждые 10 минут
      if (--sec_600 == 0) {
        sec_600 = 600;

        switch (regims) {
        case Regims::REGIM_CHARGE:
          // включен заряд

          if (vmax.volt_max) {
            // если напряжение достигло максимального

            if (ina.curr_aver <= curr_min) {
              // напряжение достигло максимума, ток минимума
              // включение режима Осчиляция(Качели)
              if (bitRead(flagsz, Flags_charge::OSCILDONE)) {
                // перейти в режим Качели
                regims = Regims::REGIM_OSCIL;
              } else {
                regim_end = Reason::volt_maxCur_min;
                // завершить заряд
                bitClear(flagsz, Flags_charge::CHARGEZ);
              }
            }
          }
          break;
        default:
          break;
        }
        eepSavedStruct();
        // ---выполнить раз в 10 минут.
      }

      break;

    case 4:
      // защита от повышенного тока и напряжения
      if (chg.check_charge()) {
        cc.reset();
        vc.reset();
        vmax.volt_max = false;
        pre_minut = 60; // таймер 60 секунд для предзаряда
        sec_600 = 600;  // время 10 минут
        Timezar = 0;    // время до завершения заряда секунды
        cur_stop_flag = false;
        v1 = 0;   // переменная для сохранения напряжения
        step = 0; // шаги
        // установить флаги Flags_charge
        flagsz = 0b00000011;
        if (bitRead(profil.flags, Pr_flags::OSCIL))
          bitSet(flagsz, Flags_charge::OSCILDONE);
        dcdc.Off();
        Delay(3000);
        dcdc.start(DCDC_CHARGE);
      }
      break;

    case 3:
#ifdef TYME_OFF_CHARGE
      if (dcdc.get_pause()) {
        // если ток заряда меньше или равен 10 mA
        switch (dbat.check(ina.ampersec)) {
        case 1:
          // сбросить значения
          cc.reset();
          vc.reset();
          vmax.volt_max = false;
          break;

        case 2:
          // то отключить заряд
          bitClear(profil.flags, Pr_flags::ACTIVITI);
          break;
        }
      }
#endif
      break;

    case 2:
      break;
    case 1:
#if (TIME_LIGHT)
      disp.Light_low();
#endif
      break;
    }
    if (step > 0)
      step--;
  }
  // цикл заряда
  dcdc.Off(); // отключить заряд, разряд.
#if (FAN > 0)
  // автоматический режим кулера
  fan.ONonse(false);
#endif
#if (PROTECT_BLOCK)
  Protect::Open(false);
#endif
  eepSavedStruct(); // сохранить настройки
}
