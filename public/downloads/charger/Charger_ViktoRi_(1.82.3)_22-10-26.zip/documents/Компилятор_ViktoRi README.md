# Компилятор ViktoRi

## Описание

Программа компиляции и прошивки зарядного устройства ViktoRi (Python 3 + PlatformIO + Tkinter).

Работает в Windows и Linux.

(создана SourseCraft Code Assistant)

    "Compiler_ViktoRi.py"

Программа позволяет компилировать прошивку и прошивать микроконтроллер.

## Требования

    Python 3.8 или новее
    tkinter (Linux: sudo apt install python3-tk)
    PlatformIO (python -m pip install platformio) - проверяется при запуске

## Установка дополнительных библиотек

Требуется установить Python 3 и platformio.

Установите Python с сайта <https://www.python.org/downloads/>  
и отметьте галочку "Add python.exe to PATH".

После установки Python 3 установить пакет platformio в командной строке (cmd) командой:  

      pip install platformio

## Запуск

Программа должна находиться в корневой папке проекта Charger_ViktoRi, рядом с файлом "platformio.ini".

Запуск:

    - python Compiler_ViktoRi.py            (Windows / Linux)
    - Compiler_ViktoRi_start_windows.bat    (Windows, двойной клик)
    - ./Compiler_ViktoRi_start_linux.sh     (Linux)

## Возможности

### Проверка platformio при запуске (check_platformio())

Если модуль не найден, открывается окно установки с кнопкой «Установить platformio (pip install platformio)», которая выполняет python -m pip install --upgrade platformio с журналом установки, и подсказкой ручной команды. После установки программа продолжает запуск.

### Чтение platformio.ini

При отсутствии — окно ошибки. Парсятся все секции [env:...], в выпадающий список попадают платы с описаниями из комментариев: gyver328, lgt8f328p, metro.

### Версия прошивки

Из main/1_User_Setup.h по строке // версия 1.82.0 извлекается и выводится версия (на тесте получено 1.82.0).

### Интерфейс

Три кнопки: «Скомпилировать», «Прошить», «Скомпилировать и прошить» — запускают pio run -e <плата> / pio run -e <плата> -t upload в потоке, с прогресс-баром и блокировкой кнопок на время работы.

Окно логов с прокруткой, подсветкой ошибок (красным) и успеха (зелёным), кнопка «Очистить логи».

### Сохранение бинарников

После успешной компиляции файлы firmware.hex, firmware.bin, firmware.elf копируются из .pio/build/<плата>/ в папку bin/ с именем <плата>_firmware.* (папка создаётся автоматически).