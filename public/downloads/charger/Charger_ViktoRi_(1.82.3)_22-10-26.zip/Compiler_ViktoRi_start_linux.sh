#!/usr/bin/env bash
# Запуск «Компилятора ViktoRi» в Linux
set -e
cd "$(dirname "$0")"

if ! command -v python3 >/dev/null 2>&1; then
    echo "python3 не найден. Установите: sudo apt install python3 python3-tk"
    exit 1
fi

exec python3 Compiler_ViktoRi.py