@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"

where python >nul 2>nul
if errorlevel 1 (
    echo.
    echo Python не найден в PATH.
    echo Установите Python с сайта https://www.python.org/downloads/
    echo и отметьте галочку "Add python.exe to PATH".
    echo.
    pause
    exit /b 1
)

python "%~dp0Compiler_ViktoRi.py"
if errorlevel 1 (
    echo.
    echo Программа завершилась с ошибкой.
    pause
)
endlocal