#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ViktoRi Flash Server"""

import http.server
import json
import os
import socket
import socketserver
import subprocess
import sys
import threading
import time
import queue
import shutil
import traceback
import signal
from pathlib import Path

PORT = 42789
PID_FILE_NAME = "flash_server.pid"

if getattr(sys, "frozen", False):
    SCRIPT_DIR = Path(sys.executable).resolve().parent
else:
    SCRIPT_DIR = Path(__file__).resolve().parent


def _is_project_dir(d):
    """Считаем каталог проектом, если есть platformio.ini или папка main."""
    return (d / "platformio.ini").exists() or (d / "main").exists()


def _resolve_charger_dir(script_dir):
    """Определяем корень проекта ViktoRi.

    1. Скрипт лежит рядом с папкой Charger_ViktoRi (старая раскладка).
    2. Скрипт лежит непосредственно внутри проекта Charger_ViktoRi.
    3. Иначе используем папку самого скрипта.
    """
    nested = script_dir / "Charger_ViktoRi"
    if nested.exists() and _is_project_dir(nested):
        return nested
    if _is_project_dir(script_dir):
        return script_dir
    return script_dir


CHARGER_DIR = _resolve_charger_dir(SCRIPT_DIR)
PID_FILE = SCRIPT_DIR / PID_FILE_NAME

CREATE_NO_WINDOW = 0x08000000
CREATION_FLAGS = CREATE_NO_WINDOW if sys.platform == "win32" else 0

REQUIRED_ENVS = ["gyver328", "lgt8f328p"]

PLATFORMIO_INI = (
    "[platformio]\n"
    "src_dir = main\n"
    "\n"
    "[env]\n"
    "framework = arduino\n"
    "monitor_speed = 9600\n"
    "lib_extra_dirs = libraries\n"
    "\n"
    "build_flags =\n"
    "   -std=gnu++17\n"
    "   -g -Os\n"
    "   -flto\n"
    "   -Wl,--relax\n"
    "   -mcall-prologues\n"
    "   -fno-split-wide-types\n"
    "\n"
    "; GyverCore ATmega328 + Optiboot 8 (32256 Flash)\n"
    "[env:gyver328]\n"
    "platform = atmelavr\n"
    "board = ATmega328P\n"
    "board_build.mcu = atmega328p\n"
    "board_build.f_cpu = 16000000L\n"
    "upload_protocol = arduino\n"
    "upload_speed = 115200\n"
    "upload_flags = -V\n"
    "\n"
    "; LGT8F328P Logic Green (32MHz, 32256 Flash)\n"
    "[env:lgt8f328p]\n"
    "platform = lgt8f\n"
    "board = LGT8F328P\n"
    "board_build.f_cpu = 32000000L\n"
    "board_build.clock_source = 1\n"
    "build_unflags = -Wl,--relax"
)

log_clients = []
log_lock = threading.Lock()
current_process = None
process_lock = threading.Lock()
build_output = []


def _startupinfo():
    if sys.platform != "win32":
        return None
    si = subprocess.STARTUPINFO()
    si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    si.wShowWindow = 0
    return si


def _run_kwargs():
    kw = {"creationflags": CREATION_FLAGS}
    si = _startupinfo()
    if si is not None:
        kw["startupinfo"] = si
    return kw


def write_pid():
    try:
        PID_FILE.write_text(str(os.getpid()), encoding="utf-8")
    except Exception:
        pass


def remove_pid():
    try:
        if PID_FILE.exists():
            PID_FILE.unlink()
    except Exception:
        pass


def check_single_instance():
    try:
        if PID_FILE.exists():
            old_pid = int(PID_FILE.read_text(encoding="utf-8").strip())
            if sys.platform == "win32":
                result = subprocess.run(
                    ["tasklist", "/FI", "PID eq " + str(old_pid)],
                    capture_output=True, text=True,
                    **_run_kwargs(),
                )
                if str(old_pid) in result.stdout:
                    return False
            else:
                try:
                    os.kill(old_pid, 0)
                    return False
                except OSError:
                    pass
    except Exception:
        pass
    write_pid()
    return True


def ensure_platformio_ini():
    ini_path = CHARGER_DIR / "platformio.ini"
    try:
        if not CHARGER_DIR.exists():
            return False
        if ini_path.exists():
            content = ini_path.read_text(encoding="utf-8-sig")
            if content.strip() == PLATFORMIO_INI.strip():
                return True
            # Не перезаписываем пользовательский конфиг, если в нём уже есть нужные среды
            if all("[env:" + e + "]" in content for e in REQUIRED_ENVS):
                return True
            # Перед перезаписью сохраняем резервную копию
            try:
                bak = ini_path.with_suffix(ini_path.suffix + ".bak")
                shutil.copy2(str(ini_path), str(bak))
            except Exception:
                pass
        ini_path.write_text(PLATFORMIO_INI, encoding="utf-8")
        return True
    except Exception:
        return False


def find_pio():
    pio_home = SCRIPT_DIR / ".platformio"
    if pio_home.exists():
        os.environ["PLATFORMIO_CORE_DIR"] = str(pio_home)

    home_dir = Path.home()
    if sys.platform == "win32":
        home_dir = Path(os.environ.get("USERPROFILE", str(home_dir)))
    pio_home_user = home_dir / ".platformio"
    search_dirs = [
        SCRIPT_DIR / "python" / "Scripts",
        SCRIPT_DIR / "python" / "bin",
        SCRIPT_DIR / ".platformio" / "penv" / "Scripts",
        SCRIPT_DIR / ".platformio" / "penv" / "bin",
        pio_home_user / "penv" / "Scripts",
        pio_home_user / "penv" / "bin",
        SCRIPT_DIR,
    ]
    for d in search_dirs:
        if not d.exists():
            continue
        for name in ("pio.exe", "pio", "platformio.exe", "platformio"):
            p = d / name
            if p.exists():
                return [str(p)]

    pio = shutil.which("pio")
    if pio:
        return [pio]
    pio = shutil.which("platformio")
    if pio:
        return [pio]

    py_candidates = []
    if sys.platform == "win32":
        py_candidates += [
            SCRIPT_DIR / "python" / "python.exe",
            SCRIPT_DIR / "python" / "python3.exe",
            SCRIPT_DIR / "python" / "pythonw.exe",
        ]
    else:
        py_candidates += [
            SCRIPT_DIR / "python" / "python",
            SCRIPT_DIR / "python" / "python3",
        ]
    if not getattr(sys, "frozen", False):
        py_candidates.append(Path(sys.executable))

    for p in py_candidates:
        if p.exists():
            try:
                r = subprocess.run(
                    [str(p), "-m", "platformio", "--version"],
                    capture_output=True, timeout=15,
                    **_run_kwargs(),
                )
                if r.returncode == 0:
                    return [str(p), "-m", "platformio"]
            except Exception:
                pass
    return None


def get_pio_cmd():
    pio = find_pio()
    if pio is None:
        return None
    return pio


def get_serial_ports():
    ports = []
    if sys.platform == "win32":
        try:
            import winreg
            key = winreg.OpenKey(
                winreg.HKEY_LOCAL_MACHINE,
                r"HARDWARE\DEVICEMAP\SERIALCOMM",
            )
            i = 0
            while True:
                try:
                    name, value, _ = winreg.EnumValue(key, i)
                    port_name = value.strip()
                    friendly = name.replace("\\Device\\", "")
                    ports.append(port_name + " - " + friendly)
                    i += 1
                except OSError:
                    break
            winreg.CloseKey(key)
        except Exception:
            pass
        return ports

    # Linux/Unix: scan serial devices in /dev
    import glob
    patterns = [
        "/dev/ttyUSB*",
        "/dev/ttyACM*",
        "/dev/ttyAMA*",
        "/dev/serial/by-id/*",
    ]
    seen = set()
    for pattern in patterns:
        try:
            for dev in sorted(glob.glob(pattern)):
                if dev in seen:
                    continue
                seen.add(dev)
                if "/dev/serial/by-id/" in dev:
                    try:
                        target = os.path.realpath(dev)
                        ports.append(dev + " -> " + target)
                    except Exception:
                        ports.append(dev)
                else:
                    ports.append(dev)
        except Exception:
            pass
    return ports


def broadcast_log(msg):
    data = json.dumps({"msg": msg}, ensure_ascii=False)
    with log_lock:
        dead = []
        for q in log_clients:
            try:
                q.put_nowait(data)
            except queue.Full:
                dead.append(q)
        for q in dead:
            log_clients.remove(q)


def broadcast_done():
    data = json.dumps({"msg": "__FLASH_DONE__"})
    with log_lock:
        dead = []
        for q in log_clients:
            try:
                q.put_nowait(data)
            except queue.Full:
                dead.append(q)
        for q in dead:
            log_clients.remove(q)


def run_command(cmd, cwd=None):
    global current_process
    proc = None
    try:
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            cwd=cwd,
            bufsize=1,
            text=True,
            encoding="utf-8",
            errors="replace",
            **_run_kwargs(),
        )
        with process_lock:
            current_process = proc
        for raw_line in iter(proc.stdout.readline, ""):
            line = raw_line.rstrip("\r\n")
            if line:
                broadcast_log(line)
                build_output.append(line)
        proc.stdout.close()
        proc.wait()
        return proc.returncode
    except Exception as e:
        broadcast_log("[ERROR] " + str(e))
        return -1
    finally:
        with process_lock:
            current_process = None


def cmd_flash(env, port, mode):
    try:
        del build_output[:]
        pio_cmd = get_pio_cmd()
        if pio_cmd is None:
            broadcast_log("[ERROR] PlatformIO ne nayden!")
            broadcast_log("[INFO] Umesto PlatformIO v papke servera")
            broadcast_done()
            return

        ensure_platformio_ini()
        broadcast_log("[INFO] platformio.ini updated")
        broadcast_log("")
        broadcast_log("--- ViktoRi Flash Server ---")
        broadcast_log("Project: " + str(CHARGER_DIR))
        broadcast_log("Env: " + env + " | Port: " + (port or "auto"))
        broadcast_log("")

        if mode in ("all", "build"):
            cmd = pio_cmd + ["run", "-e", env]
            broadcast_log("=== Build: pio run -e " + env + " ===")
            rc = run_command(cmd, cwd=str(CHARGER_DIR))
            if rc != 0:
                broadcast_log("")
                broadcast_log("[ERROR] Compilation failed (code " + str(rc) + ")")
                broadcast_done()
                return
            broadcast_log("")

        if mode in ("all", "upload"):
            cmd = pio_cmd + ["run", "-e", env, "--target", "upload"]
            if port:
                cmd += ["--upload-port", port]
            broadcast_log("=== Upload: pio run -e " + env + " upload ===")
            rc = run_command(cmd, cwd=str(CHARGER_DIR))
            if rc == 0:
                broadcast_log("")
                broadcast_log("== [SUCCESS] ==")
            else:
                broadcast_log("")
                broadcast_log("[ERROR] Upload failed (code " + str(rc) + ")")

        broadcast_done()
    except Exception as e:
        try:
            broadcast_log("[ERROR] " + str(e))
            broadcast_done()
        except Exception:
            pass


class ThreadedHTTPServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = True
    request_queue_size = 32

    def server_bind(self):
        self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        super().server_bind()

    def handle_error(self, request, client_address):
        pass


class FlashHandler(http.server.BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass

    def _cors_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")

    def _json(self, data, status=200):
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self._cors_headers()
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        self.send_response(204)
        self._cors_headers()
        self.end_headers()

    def do_GET(self):
        try:
            path = self.path.split("?")[0]

            if path == "/api/status":
                self._json({"project": str(CHARGER_DIR)})
                return

            if path == "/api/envs":
                envs = []
                ini_path = CHARGER_DIR / "platformio.ini"
                if ini_path.exists():
                    try:
                        content = ini_path.read_text(encoding="utf-8-sig")
                        for env_name in REQUIRED_ENVS:
                            if "[env:" + env_name + "]" in content:
                                envs.append(env_name)
                    except Exception:
                        pass
                if not envs:
                    envs = REQUIRED_ENVS[:]
                self._json({"envs": envs})
                return

            if path == "/api/ports":
                self._json({"ports": get_serial_ports()})
                return

            if path == "/api/log":
                q = queue.Queue(maxsize=200)
                with log_lock:
                    log_clients.append(q)
                self.send_response(200)
                self.send_header("Content-Type", "text/event-stream; charset=utf-8")
                self.send_header("Cache-Control", "no-cache")
                self.send_header("Connection", "keep-alive")
                self._cors_headers()
                self.end_headers()
                try:
                    while True:
                        try:
                            data = q.get(timeout=15)
                            self.wfile.write(("data: " + data + "\n\n").encode("utf-8"))
                            self.wfile.flush()
                        except queue.Empty:
                            self.wfile.write(b": ping\n\n")
                            self.wfile.flush()
                except Exception:
                    pass
                finally:
                    with log_lock:
                        if q in log_clients:
                            log_clients.remove(q)
                return

            if path == "/":
                html_path = CHARGER_DIR / "main" / "\u041a\u043e\u043d\u0444\u0438\u0433\u0443\u0440\u0430\u0442\u043e\u0440.html"
                if not html_path.exists():
                    for f in (CHARGER_DIR / "main").glob("*.html"):
                        html_path = f
                        break
                if html_path.exists():
                    content = html_path.read_bytes()
                    self.send_response(200)
                    self.send_header("Content-Type", "text/html; charset=utf-8")
                    self.send_header("Content-Length", str(len(content)))
                    self.end_headers()
                    self.wfile.write(content)
                else:
                    self.send_error(404, "HTML not found")
                return

            self.send_error(404)
        except Exception:
            pass

    def do_POST(self):
        try:
            path = self.path.split("?")[0]

            if path == "/api/flash":
                length = int(self.headers.get("Content-Length", 0))
                body = self.rfile.read(length)
                try:
                    data = json.loads(body)
                except Exception:
                    self._json({"error": "Invalid JSON"}, 400)
                    return
                env = data.get("env", "gyver328")
                port = data.get("port", "")
                mode = data.get("mode", "all")
                if env not in REQUIRED_ENVS:
                    self._json({"error": "Unknown env: " + env}, 400)
                    return
                with process_lock:
                    if current_process is not None:
                        self._json({"error": "Already running"}, 409)
                        return
                t = threading.Thread(target=cmd_flash, args=(env, port, mode), daemon=True)
                t.start()
                self._json({"ok": True})
                return

            self.send_error(404)
        except Exception:
            pass


def main():
    if not check_single_instance():
        return

    ensure_platformio_ini()

    server = ThreadedHTTPServer(("localhost", PORT), FlashHandler)
    def shutdown_handler(signum, frame):
        server.shutdown()

    if sys.platform == "win32":
        try:
            signal.signal(signal.SIGBREAK, shutdown_handler)
        except Exception:
            pass
    signal.signal(signal.SIGTERM, shutdown_handler)
    signal.signal(signal.SIGINT, shutdown_handler)

    try:
        server.serve_forever()
    except Exception:
        pass
    finally:
        server.server_close()
        remove_pid()


if __name__ == "__main__":
    main()
