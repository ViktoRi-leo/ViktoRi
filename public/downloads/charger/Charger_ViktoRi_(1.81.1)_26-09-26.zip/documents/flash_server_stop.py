#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ViktoRi Flash Server - Stop"""

import os
import signal
import subprocess
import sys
import time
from pathlib import Path

if getattr(sys, "frozen", False):
    SCRIPT_DIR = Path(sys.executable).resolve().parent
else:
    SCRIPT_DIR = Path(__file__).resolve().parent

PID_FILE = SCRIPT_DIR / "flash_server.pid"

USE_GUI = getattr(sys, "frozen", False)  # exe без консоли -> окна сообщений

# Скрываем окно консоли для дочерних процессов (Windows)
CREATE_NO_WINDOW = 0x08000000
RUN_KW = {"creationflags": CREATE_NO_WINDOW} if sys.platform == "win32" else {}


def show_info(text):
    if USE_GUI:
        import tkinter.messagebox as mb
        mb.showinfo("ViktoRi Flash Server", text)
    else:
        print(text)


def show_error(text):
    if USE_GUI:
        import tkinter.messagebox as mb
        mb.showerror("ViktoRi Flash Server", text)
    else:
        print(text)


def process_alive(pid):
    """Проверка процесса без запуска внешних программ."""
    if sys.platform == "win32":
        import ctypes
        kernel32 = ctypes.windll.kernel32
        handle = kernel32.OpenProcess(0x1000, False, pid)  # PROCESS_QUERY_LIMITED_INFORMATION
        if not handle:
            return False
        try:
            code = ctypes.c_ulong()
            if kernel32.GetExitCodeProcess(handle, ctypes.byref(code)):
                return code.value == 259  # STILL_ACTIVE
            return False
        finally:
            kernel32.CloseHandle(handle)
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def kill_process(pid, force=False):
    if sys.platform == "win32":
        cmd = ["taskkill", "/PID", str(pid)]
        if force:
            cmd.append("/F")
        subprocess.run(cmd, capture_output=True, **RUN_KW)
    else:
        os.kill(pid, signal.SIGKILL if force else signal.SIGTERM)


def main():
    if not PID_FILE.exists():
        show_info("PID-файл не найден.\nСервер, скорее всего, не запущен.")
        return

    try:
        pid = int(PID_FILE.read_text(encoding="utf-8").strip())
    except Exception:
        PID_FILE.unlink(missing_ok=True)
        show_info("PID-файл повреждён - удалён.")
        return

    if not process_alive(pid):
        PID_FILE.unlink(missing_ok=True)
        show_info("Процесс %d не найден.\nУстаревший PID-файл удалён." % pid)
        return

    try:
        kill_process(pid, force=False)
    except Exception as e:
        show_error("Ошибка остановки:\n%s" % e)
        return

    for _ in range(15):
        if not process_alive(pid):
            break
        time.sleep(0.2)

    if process_alive(pid):
        try:
            kill_process(pid, force=True)
        except Exception:
            pass
        time.sleep(0.5)

    PID_FILE.unlink(missing_ok=True)
    show_info("Сервер остановлен.")


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        show_error("Ошибка: %s" % e)
