#pragma once

#include <Arduino.h>

/*======== отправка значений в сетевой порт ========*/

// инициализация серийного порта
void serial_begin(void);

#if (LOGGER > 0 && REMOTE_CONTROL)
bool loggerAvailable(void);
uint8_t loggerRead(void);
void loggerWrite(const uint8_t *data, uint8_t len);
#endif

#pragma pack(push, 1)
struct LogSend {
  uint8_t start_send; // маркер старта
  uint8_t len_send;   // длина посылки
  uint8_t cod_send;   // код данных

  uint16_t volt; // 1 напряжение на АКБ (милливольт)
  int16_t amper; // 2 ток АКБ (миллиампер)
  int32_t Achas; // 5 Полученная_отданная емкость АКБ в Ач

  uint16_t volt_in; // 4 напряжение от БП (милливольт)
  int8_t tQ1;       // 3 Температура на Q1 (градусы)
  int8_t tAkb;      // 6 Температура АКБ (градусы)
  uint8_t crc;      // контролная сумма
};
#pragma pack(pop)

// Расширенный лог (LOGGER == 4) // 28 байт
#pragma pack(push, 1)
struct LogSendAdvanced {
  uint8_t start_send;   // маркер старта ":" (0x3A)
  uint8_t cod_send : 4; // код данных '4' (0-15)

  uint16_t volt;    // напряжение АКБ (мВ)
  int16_t amper;    // ток АКБ (мА)
  int32_t Achas;    // емкость заряда А/ч
  uint16_t volt_in; // напряжение БП (мВ)
  int8_t tQ1;       // температура транзистора
  int8_t tAkb;      // температура АКБ

  // Дополнительные параметры
  uint8_t mode : 4;          // индекс режима работы (0-15)
  uint8_t type_akb : 4;      // индекс типа АКБ (0-15)
  uint8_t capacity;          // емкость АКБ (Ач)
  uint8_t active_flag : 4;   // устройство в работе (0/1)
  uint8_t round_current : 4; // текущий круг/цикл (0-15)
  uint8_t profil : 4;        // номер активного профиля (0-15)

  uint32_t time_charge;  // время с начала зарядки (сек)
  int32_t Wh_charge;     // энергия заряда (Вт/ч)
  uint8_t regim_end : 4; // причина завершения (0-15)
  uint8_t regims : 4;    // текущий режим работы (0-15)

  uint8_t crc; // контрольная сумма
};
#pragma pack(pop)

class Serial_Out {
public:
  // Serial_Out(){}

  // формируем основные данные
  void create(void);

  // Расширенные данные LOGGER = 4
  void create_advanced(void);

  // Вывод логов в сетевой порт. Вызывать постоянно раз в секунду
  void Serial_out(void);

private:
  uint8_t _tm = 2;

  LogSend send_log{':', sizeof(LogSend), 1, 0, 0, 0, 0, 0, 0, 0};

  LogSendAdvanced send_log_adv{':', 4, 0, 0, 0, 0, 0, 0, 0, 0,
                               0,   0, 0, 0, 0, 0, 0, 0, 0};

  // вывод значения в тысячных долях с y знаками после запятой (LOGGER == 2)
  void serial_print(int32_t x, uint8_t y);

  uint32_t _time = 1;

  void serial_print(int32_t x);
};

extern Serial_Out Sout;

