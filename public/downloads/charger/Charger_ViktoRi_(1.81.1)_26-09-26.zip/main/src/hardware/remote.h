#pragma once

#include <Arduino.h>

#include "../core/User_Setup_Loader.h"

#if (LOGGER > 0 && REMOTE_CONTROL)

// Обработчик. Читает все доступные байты из порта.
void remote_tick(void);

// Возвращает true, если было изменение состояния зарядного устройства.
bool remote_taken(void);

#else

static inline void remote_tick(void) {}
static inline bool remote_taken(void) { return false; }

#endif
