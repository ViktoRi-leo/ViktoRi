#include "remote.h"

/*
Управление зарядным по сетевому порту.
Автор NIK007. 
Правки Aidar.
*/

/*
Описание.

Файл remote.cpp реализует удалённое управление зарядным устройством по сетевому
(серийному) порту. Весь код защищён условием компиляции, поэтому активен только
при включённом логгере и поддержке дистанционного управления.

Назначение
Модуль принимает по UART короткие команды (профиль, старт, стоп, запрос
информации), проверяет контрольную сумму и исполняет их, меняя состояние
зарядного устройства. На каждую команду отвечает кадром-подтверждением (ACK или
REJECT).

Протокол кадра
Каждая команда и ответ — фиксированный массив из 4 байт:
[MARKER(0xA5)] [команда] [аргумент] [CRC]
где CRC — это XOR всех трёх предыдущих байт (MARKER ^ cmd ^ arg), что позволяет
отбрасывать испорченные при передаче кадры.

Константы
MARKER = 0xA5 — стартовый маркер кадра.
CMD_PROFIL = 0x01 — установить номер профиля.
CMD_START = 0x02 — запустить зарядку.
CMD_STOP = 0x03 — остановить зарядку.
CMD_INFO = 0x04 — запрос информации о количестве профилей.
ACK = 0x80 — бит, выставляемый в команде ответа (признак «это ответ»).
REJECT = 0xFF — аргумент ответа при отказе выполнить команду.

Служебные функции
reply()
Формирует ответный кадр {MARKER, cmd, arg, CRC} и отправляет его в сетевой порт
через loggerWrite(). Бит ACK уже заложен в передаваемый cmd.

execute()
Центральный обработчик команд. В начале считывает флаг активности из
profil.flags (бит Pr_flags::ACTIVITI) — идёт ли в данный момент зарядка. Затем
разбирает команду:

CMD_PROFIL — смена профиля. Если зарядка активна — отвечает REJECT (нельзя
менять профиль на ходу). Иначе устанавливает vkr.profil = constrain(arg, 0,
PROFIL) (ограничение в допустимый диапазон), подгружает параметры профиля из
EEPROM через eeGet_profil(), помечает changed = true и отвечает новым номером
профиля.
CMD_START — запуск. Если уже активна — отказ. Иначе взводит флаг
ACTIVITI в profil.flags, помечает changed = true и отвечает номером профиля.
CMD_STOP — остановка. Сбрасывает флаг ACTIVITI, отвечает 0 (успех). Выполняется
всегда, даже если зарядка не шла.
CMD_INFO — отвечает значением PROFIL + 1
(сколько всего профилей доступно). Переменная changed (внутри анонимного
namespace) — флаг «состояние изменилось», который основная программа опрашивает
через remote_taken().

Публичные функции
remote_tick()
Обработчик, который нужно вызывать постоянно (в главном цикле). Читает все
доступные байты из порта через loggerAvailable()/loggerRead(), собирает кадр в
буфер buf[4]:
Пока позиция 0, игнорирует всё, что не равно MARKER.
Копит байты; как только набраны все 4 — проверяет контрольную сумму buf[3] ==
buf[0]^buf[1]^buf[2]. Если сумма сходится — вызывает execute(buf[1], buf[2]).
Иначе кадр просто отбрасывается.

remote_taken()
Возвращает значение флага changed и сразу сбрасывает его в false. Используется
внешним кодом, чтобы узнать, было ли изменено состояние зарядного устройства по
сети (и, например, обновить дисплей или записать настройки).

*/

#if (LOGGER > 0 && REMOTE_CONTROL)

#include "../core/global.h"
#include "logger.h"

/*======== управление зарядным по сетевому порту ========*/

namespace {

constexpr uint8_t MARKER = 0xA5; // стартовый маркер кадра

constexpr uint8_t CMD_PROFIL = 0x01; // установить номер профиля
constexpr uint8_t CMD_START = 0x02;  // запустить зарядку
constexpr uint8_t CMD_STOP = 0x03;   // остановить зарядку
constexpr uint8_t CMD_INFO = 0x04;   // запрос информации о количестве профилей

constexpr uint8_t ACK = 0x80;     // бит, выставляемый в команде ответа (признак «это ответ»).
constexpr uint8_t REJECT = 0xFF;  // аргумент ответа при отказе выполнить команду.

bool changed = false;

// Формирует ответный кадр {MARKER, cmd, arg, CRC} и отправляет его в сетевой порт.
void reply(uint8_t cmd, uint8_t arg) {
  const uint8_t frame[4]{MARKER, cmd, arg, (uint8_t)(MARKER ^ cmd ^ arg)};
  loggerWrite(frame, sizeof(frame));
}

// Центральный обработчик команд.
void execute(uint8_t cmd, uint8_t arg) {
  const bool active = bitRead(profil.flags, Pr_flags::ACTIVITI);

  switch (cmd) {
  case CMD_PROFIL:
    if (active) {
      reply(CMD_PROFIL | ACK, REJECT);
      break;
    }
    vkr.profil = constrain(arg, (uint8_t)0, (uint8_t)PROFIL);
    eeGet_profil();
    changed = true;
    reply(CMD_PROFIL | ACK, vkr.profil);
    break;

  case CMD_START:
    if (active) {
      reply(CMD_START | ACK, REJECT);
      break;
    }
    bitSet(profil.flags, Pr_flags::ACTIVITI);
    changed = true;
    reply(CMD_START | ACK, vkr.profil);
    break;

  case CMD_STOP:
    bitClear(profil.flags, Pr_flags::ACTIVITI);
    changed = true;
    reply(CMD_STOP | ACK, 0);
    break;

  case CMD_INFO:
    reply(CMD_INFO | ACK, PROFIL + 1);
    break;
  }
}

} // namespace

// Обработчик. Читает все доступные байты из порта.
void remote_tick(void) {
  static uint8_t buf[4];
  static uint8_t pos = 0;

  while (loggerAvailable()) {
    const uint8_t byte = loggerRead();

    if (pos == 0 and byte != MARKER)
      continue;

    buf[pos++] = byte;

    if (pos < sizeof(buf))
      continue;

    pos = 0;
    if (buf[3] == (uint8_t)(buf[0] ^ buf[1] ^ buf[2]))
      execute(buf[1], buf[2]);
  }
}

// Возвращает true, если было изменение состояния зарядного устройства.
bool remote_taken(void) {
  const bool state = changed;
  changed = false;
  return state;
}

#endif
