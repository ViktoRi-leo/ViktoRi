#include "../display/Display.h"
#include "global.h"
#include <EEPROM.h>

// сброс настроек при первой прошивке МК
void first_firmware(void) {
  if (eepromReadByte(MEM_RESET) != MemoryMap::EEPROM_LAYOUT_VERSION)
    Reset_settings(1);
}

// сброс настроек по умолчанию
void Reset_settings(uint8_t sett) {
  bool ext = true;
  bool verified = true;
  do {
    setCursory();
    lcd.print('>');
    disp.printFromPGM((int)(&reset_txt[sett]));
    ClearStr(12);
    // пауза до сигала от кнопок или энкодера
    do {
      butt.Tick(); // опрос кнопок и энкодера
    } while (!butt.tick);

    switch (butt.tick) {
    case Butt::LEFT:
    case Butt::RIGHT:
      sett = constrain_u8(sett, 0u, POINTRESET, butt.tick);
      break;
    case Butt::STOPCLICK:
    case Butt::OKHELD:
      return; // выйти
    case Butt::OKCLICK:
      ext = false; // выйти из цикла
      break;
    }
  } while (ext);

  switch (sett) {
  case 0:
    break; // выйти
  case 1:
    // сбросить все
    // сбросить счетчик ремонта
    EEPROM.update(MemoryMap::EepromAddr::REPAIR_COUNT, 0);
  case 2:
    // сбросить настройки профилей по умолчанию
    // загрузить из PROGMEM в оперативку
    memcpy_P(&profil, &profil_default, sizeof(Profils));
    setCursory();
    ClearStr(DISPLAYx);
    setCursory();
    for (uint8_t num = 0; num <= (uint8_t)PROFIL; num++) {
      eeSave_profil(num);
      const int16_t address = (int16_t)sizeof(Profils) * num + MEM_PAM;
      // Сравнить диапазон EEPROM с буфером в оперативной памяти.
      verified =
          verifyEepromBlock(address, (uint8_t *)&profil, sizeof(Profils));
      lcd.write('.'); // ........
    }
    Res_ktc(); // очистить память КТЦ
    eeSetRound(1);
    eeSetKtcRounds(0);
    eeSetModeNumber(1);
    if (sett == 2)
      break;
  case 3:
    // сбросить калибровки по умолчанию
    vkr.Ohms = (uint8_t)OHMS; // кооффицмент коррекции напряжения 0-255
    vkr.profil = 0;  // текущий профиль 0-6
#ifdef VKORRECT
    // коэффициент для калибровки напряжения БП  // REF
    vkr.Vref = (uint16_t)VKORRECT;
#else
    vkr.Vref = 1000u; // коэффициент для калибровки напряжения БП
#endif
    // значение шунта в мкОм
    vkr.shunt = (uint16_t)((float)SHUNT * 1000000ul);
    vkr.inaKoof = (uint16_t)INAVOLTKOOF;
    // сохранить структуру vkr
    eeSave_vkr();
    // Сравнить диапазон EEPROM с буфером в оперативной памяти.
    verified = verifyEepromBlock(MEM_VKR, (const uint8_t *)&vkr, sizeof(vkr));
    if (sett == 3)
      break;
  case 4:
    // сброс сервисных параметров
    verified = eepResetService();
    break;
  }

  if (!verified)
    reportEepromVerificationError();

  if (sett) {
#if defined(__LGT8FX8P__)
    lgt_eeprom_update_byte(MEM_RESET, MemoryMap::EEPROM_LAYOUT_VERSION);
#else
    EEPROM.update(MemoryMap::EepromAddr::RESET,
                  MemoryMap::EEPROM_LAYOUT_VERSION);
#endif
    resetFunc();
  }

  lcd.clear();
}

// функция сброса значений заряда
void Res_mem_char(void) {
  profil.charge.stat.ah = 0;
  profil.charge.stat.wh = 0;
  profil.charge.stat.time = 0;
}

void Res_mem_addchar(void) {
  profil.add.stat.ah = 0;
  profil.add.stat.wh = 0;
  profil.add.stat.time = 0;
}

// функция сброса значений разряда
void Res_mem_dischar(void) {
  profil.disch.stat.ah = 0;
  profil.disch.stat.wh = 0;
  profil.disch.stat.time = 0;
}

// функция сброса значений разряда
void Res_mem_asym(void) {
  profil.asym.stat.ah = 0;
  profil.asym.stat.wh = 0;
  profil.asym.stat.time = 0;
}

constexpr uint16_t mem_ktc = 5u * 16u;
// очистить память значений КТЦ
#if defined(__LGT8FX8P__)
void Res_ktc(void) {
  uint32_t ark[4]{0};
  for (uint16_t i = 0; i < mem_ktc; i += 16) {
    lgt_eeprom_writeSWM(MEM_KTC + i, ((uint32_t *)&ark),
                        (uint16_t)sizeof(ark) / sizeof(uint32_t));
  }
  // for (uint16_t i = 0; i < mem_ktc; i++)
  //  lgt_eeprom_update_byte(MEM_KTC + i, 0);
  Res_mem_char();
  Res_mem_addchar();
  Res_mem_dischar();
}
#else
void Res_ktc(void) {
  for (uint16_t i = 0; i < mem_ktc; i++)
    EEPROM.update(MEM_KTC + i, 0);

  Res_mem_char();
  Res_mem_addchar();
  Res_mem_dischar();
}
#endif
