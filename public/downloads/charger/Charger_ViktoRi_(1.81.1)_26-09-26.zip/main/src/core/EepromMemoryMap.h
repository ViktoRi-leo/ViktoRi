#pragma once

#include <Arduino.h>

/* ******** EEPROM ******** */

/*
Карта организации памяти EPRROM
0	- значение сброса настроек
1	  9	- struct vkr 8 байт
10	25	- архив 16 байт сервисные параметры зарядника
30	126	Профиль 0
127	223	Профиль 1
224	320	Профиль 2
321	417	Профиль 3
418	514	Профиль 4
515	611	Профиль 5
612	708	Профиль 6
709	805	Профиль 7
806	902	Профиль 8
903	919	КТЦ-1
920	936	КТЦ-2
937	953	КТЦ-3
954	970	КТЦ-4
971	987	КТЦ-5
988 - 1017 резерв 32 байта
1018  количество выполненных ремонтов EEPROM.
1019  номер операции
1020	число кругов последнего КТЦ
1021	текущий режим работы
1022		текущий круг
*/

namespace MemoryMap {
// карта организации памяти EEPROM
// важно: при изменении расположения данных обновлять EEPROM_LAYOUT_VERSION и миграцию данных
constexpr uint8_t EEPROM_LAYOUT_VERSION = 111;

enum EepromAddr : uint16_t {
  // адрес начальной ячейки памяти для значения сброса настроек
  RESET = 0,
  // адрес начальной ячейки памяти для структуры vkr
  VKR = 1,
  // адрес начальной ячейки памяти для сервисных параметров
  SERV = 10,
  // адрес начальной ячейки памяти для структур profil
  PROFILS = 30,
  // адрес начальной ячейки памяти для результатов замера емкости КТЦ.
  KTC = 903,
  // количество выполненных ремонтов EEPROM.
  REPAIR_COUNT = 1018,
  // адрес ячейки памяти для номера операции
  NUMBER = 1019,
  // адрес ячейки памяти для числа кругов последнего КТЦ
  KTC_ROUNDS = 1020,
  // адрес ячейки памяти для текущего режима работы
  MODE = 1021,
  // адрес ячейки памяти для текущего круга
  ROUND = 1022,
};
} // namespace MemoryMap

// Адреса EEPROM для совместимости с предыдущими версиями
#define MEM_RESET MemoryMap::EepromAddr::RESET
#define MEM_VKR MemoryMap::EepromAddr::VKR
#define MEM_SERV MemoryMap::EepromAddr::SERV
#define MEM_PAM MemoryMap::EepromAddr::PROFILS
#define MEM_KTC MemoryMap::EepromAddr::KTC
#define MEM_REPAIR_COUNT MemoryMap::EepromAddr::REPAIR_COUNT
#define MEM_MODE MemoryMap::EepromAddr::MODE
#define MEM_KTC_ROUNDS MemoryMap::EepromAddr::KTC_ROUNDS
#define MEM_ROUND MemoryMap::EepromAddr::ROUND
#define MEM_NUMBER MemoryMap::EepromAddr::NUMBER
