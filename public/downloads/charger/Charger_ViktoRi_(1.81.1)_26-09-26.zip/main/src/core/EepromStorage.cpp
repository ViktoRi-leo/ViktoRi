#include "EepromStorage.h"
#include "global.h"
#include <EEPROM.h>

// считать из EEPROM номер режима работы
uint8_t eeGetModeNumber(void) {
  return eepromReadByte(MEM_NUMBER);
}

// сохранить в EEPROM номер режима работы
void eeSetModeNumber(uint8_t mode) {
  eepromUpdateByte(MEM_NUMBER, mode);
}

// считать из EEPROM текущий круг
uint8_t eeGetRound(void) {
  return eepromReadByte(MEM_ROUND);
}

// сохранить в EEPROM текущий круг
void eeSetRound(uint8_t round) {
  eepromUpdateByte(MEM_ROUND, round);
}

// считать из EEPROM число кругов последнего КТЦ
uint8_t eeGetKtcRounds(void) {
  uint8_t r = eepromReadByte(MEM_KTC_ROUNDS);
  return (r > 5) ? 0 : r;
}

// сохранить в EEPROM число кругов последнего КТЦ
void eeSetKtcRounds(uint8_t rounds) {
  eepromUpdateByte(MEM_KTC_ROUNDS, rounds);
}

// сохранить в EEPROM выбранный режим работы
void eeSetMode(void) {
  eepromUpdateByte(MEM_MODE, profil.Regim);
}

// считать из EEPROM выбранный режим работы
void eeGetMode(void) {
  profil.Regim = eepromReadByte(MEM_MODE);
  eepSavedStruct();
}

// сохранить структуру vkr
void eeSave_vkr(void) {
#if defined(__LGT8FX8P__)
  // lgt_eeprom_update_block(((uint8_t*)&vkr), MEM_VKR, sizeof(vkr));
  lgt_eeprom_writeSWM((uint16_t)MEM_VKR, ((uint32_t *)&vkr),
                      (uint16_t)sizeof(vkr) / sizeof(uint32_t));
#else
  EEPROM.put((int)MEM_VKR, vkr);
#endif
}

// считать структуру vkr
void eeGet_vkr(void) {
#if defined(__LGT8FX8P__)
  // lgt_eeprom_read_block(((uint8_t*)&vkr), MEM_VKR, sizeof(vkr));
  lgt_eeprom_readSWM((uint16_t)MEM_VKR, ((uint32_t *)&vkr),
                     (uint16_t)sizeof(vkr) / sizeof(uint32_t));
#else
  EEPROM.get((int)MEM_VKR, vkr);
#endif
}

// сохранить структуру profil
void eeSave_profil(uint8_t profil_number) {
#if defined(__LGT8FX8P__)
  const uint16_t address = (uint16_t)sizeof(profil) * profil_number + MEM_PAM;
  // lgt_eeprom_update_block(((uint8_t *)&profil), address, sizeof(profil));
  lgt_eeprom_writeSWM(address, ((uint32_t *)&profil),
                      (uint16_t)sizeof(Profils) / sizeof(uint32_t));
#else
  const int16_t address = (int16_t)sizeof(Profils) * profil_number + MEM_PAM;  
  // запись данных в EEPROM
  EEPROM.put(address, profil);
#endif
}

// считать структуру profil
void eeGet_profil(void) {
#if defined(__LGT8FX8P__)
  const uint16_t eeAddr = (uint16_t)sizeof(profil) * vkr.profil + MEM_PAM;
  // lgt_eeprom_read_block(((uint8_t *)&profil), eeAddr, sizeof(profil));
  lgt_eeprom_readSWM(eeAddr, ((uint32_t *)&profil),
                     (uint16_t)sizeof(Profils) / sizeof(uint32_t));
#else
  const int16_t eeAddr = (int16_t)sizeof(Profils) * vkr.profil + MEM_PAM;
  EEPROM.get(eeAddr, profil);
#endif
}

// функция сохранения настроек
void eepSavedStruct(void) {
  eeSave_vkr();
  eeSave_profil(vkr.profil);
}

// чтение структур из EEPROM
void eepGetStruct(void) {
  eeGet_vkr();
  eeGet_profil();
}

// Чтение байта EEPROM.
uint8_t eepromReadByte(uint16_t address) {
#if defined(__LGT8FX8P__)
   return lgt_eeprom_read_byte(address);
#else
   return EEPROM.read(address);
#endif  
}

// Обновить байт в EEPROM.
void eepromUpdateByte(uint16_t address, uint8_t value) {
#if defined(__LGT8FX8P__)
   lgt_eeprom_update_byte(address, value);
#else
   EEPROM.update(address, value);
#endif
}

// Сравнить диапазон EEPROM с буфером в оперативной памяти.
bool verifyEepromBlock(uint16_t address, const uint8_t *expected,
                       uint16_t length) {
  for (uint16_t index = 0; index < length; index++) {
    if (eepromReadByte(address + index) != expected[index])
      return false;
  }
  return true;
}

// Сравнить диапазон EEPROM с эталоном, размещенным в PROGMEM.
bool verifyEepromProgmemBlock(uint16_t address, const void *expected,
                              uint16_t length) {
  for (uint16_t index = 0; index < length; index++) {
    if (eepromReadByte(address + index) !=
        pgm_read_byte((const uint8_t *)expected + index))
      return false;
  }
  return true;
}

// Записать данные из PROGMEM в EEPROM.
/*
address - адрес в EEPROM, куда нужно записать данные
expected - указатель на данные в PROGMEM, которые нужно записать
length - длина данных
*/
void ProgmemWriteEeprom(uint16_t address, const void *expected,
                        uint16_t length) {
  for (uint16_t index = 0; index < length; index++) {
#if defined(__LGT8FX8P__)
    lgt_eeprom_update_byte(address + index,
                           pgm_read_byte((const uint8_t *)expected + index));
#else
    EEPROM.write(address + index,
                 pgm_read_byte((const uint8_t *)expected + index));
#endif                 
  }
}

// Записать данные из PROGMEM в EEPROM.
//      ProgmemWriteEeprom(address, (uint8_t *)&profil, sizeof(Profils));