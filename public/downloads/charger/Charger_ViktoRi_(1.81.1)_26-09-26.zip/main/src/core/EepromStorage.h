#pragma once

#include <Arduino.h>
#include "EepromMemoryMap.h"

// считать из EEPROM номер операции
uint8_t eeGetModeNumber(void);

// сохранить в EEPROM номер операции
void eeSetModeNumber(uint8_t mode);

// считать из EEPROM текущий круг
uint8_t eeGetRound(void);

// сохранить в EEPROM текущий круг
void eeSetRound(uint8_t round);

// считать из EEPROM число кругов последнего КТЦ
uint8_t eeGetKtcRounds(void);

// сохранить в EEPROM число кругов последнего КТЦ
void eeSetKtcRounds(uint8_t rounds);

// сохранить в EEPROM выбранный режим работы
void eeSetMode(void);

// считать из EEPROM выбранный режим работы
void eeGetMode(void);

void eeGetKtc(uint8_t round, int32_t *values);

// сохранить структуру vkr
void eeSave_vkr(void);

// считать структуру vkr
void eeGet_vkr(void);

// сохранить структуру profil
void eeSave_profil(uint8_t profil_number);

// считать структуру profil
void eeGet_profil(void);

// сохранение структур в EEPROM
void eepSavedStruct(void);

// чтение структур из EEPROM
void eepGetStruct(void);


/* *** */
// Чтение байта EEPROM.
uint8_t eepromReadByte(uint16_t address);

// Обновить байт в EEPROM.
void eepromUpdateByte(uint16_t address, uint8_t value);

// Сравнить диапазон EEPROM с буфером в оперативной памяти.
bool verifyEepromBlock(uint16_t address, const uint8_t *expected,
                       uint16_t length);

// Сравнить диапазон EEPROM с эталоном, размещенным в PROGMEM.
bool verifyEepromProgmemBlock(uint16_t address, const void *expected,
                              uint16_t length);

// Записать данные из PROGMEM в EEPROM.
/*
address - адрес в EEPROM, куда нужно записать данные
expected - указатель на данные в PROGMEM, которые нужно записать
length - длина данных
*/
void ProgmemWriteEeprom(uint16_t address, const void *expected,
                             uint16_t length);                              