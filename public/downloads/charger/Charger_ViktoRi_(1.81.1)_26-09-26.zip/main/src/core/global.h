#pragma once
#include "../display/menu_txt.h"
#include "../hardware/buttons.h"
#include "../hardware/cooler.h"
#include "../hardware/logger.h"
#include "../hardware/mcp4725.h"
#include "../hardware/sensors.h"
#include "EepromStorage.h"
#include "Functions.h"
#include "Service_parameters.h"
#include "User_Setup_Loader.h"
#include "global_profils.h"
#include "system.h"
#include <Arduino.h>

// функция reset
[[noreturn]] inline void resetFunc() {
  asm volatile("jmp 0" ::: "memory");
  __builtin_unreachable();
}

// флаги системы
enum FlagsName : uint8_t {
  // напряжение блока питания:
  POWERHIGH, // выше максимального (false - в норме)
  POWERLOW,  // ниже минимального  (false - в норме)
  POWERON,   // питание от БП поступает (true - в норме)
  TR_Q1_ERR, // превышена температура на силовом транзисторе (false - в норме)
  RELEY_OFF, // разрешено отключать реле  (true - в норме)
  TEMP_AKB,  // температура акб (false - в норме)
  SECOND     // флаг секунды (false)
};

// флаги системы
extern uint8_t sysFlag;

void sysFlagsBegin(void);

// получить флаги системы
#define sysFlagGetBits(bitt) ((sysFlag >> bitt) & 0x01)

// установить флаги системы
#define sysFlagSetBits(bitt) (sysFlag |= (1 << bitt))

// сбросить флаги системы
#define sysFlagClearBits(bitt) (sysFlag &= ~(1 << bitt))

// вернуть ошибки системы
bool sysFlagsError(void);

// номера режимов работы
enum Modes : uint8_t {
  CHARGE,      // Заряд
  ADDCHARGE,   // Дозаряд
  DISCHARGE,   // Разряд
  STORAGE,     // Режим хранения акб
  ASYMMETRIC,  // ассиметричный заряд
  KTCycle,     // Контрольно тренировочный цикл
  BUFER,       // Буферный режим
  BRANIMIR,    // Заряд по Бранимиру
  KALIBRATION, // калибровка
  RESISTENSE,  // замер сопротивления
  POWEROUT,    // блок питания
};

// текущий режим работы
enum Regims : uint8_t {
  REGIM_OFF = 0,   // Выключен
  REGIM_PRECHARGE, // Предзаряд (в режиме Заряд включен предзаряд)
  REGIM_CHARGE,    // Заряд
  REGIM_OSCIL,     // осциляция(качели) (в режиме Заряд включен режим осциляции)
  REGIM_ADDCHARGE, // Дозаряд
  REGIM_DISCHARGE, // Разряд
#if (BRRANIMIR)
  REGIM_MIXING, // перемешивание для Бранимира
#endif
  WAIT, // ожидание
};

extern Regims regims;

// причина завершения заряда
enum Reason : uint8_t {
  begin,           // 0
  out_time,        // 1 закончилось время
  volt_maxCur_min, // 2 напряжение достигло максимума ток минимума
  cur_stop,        // 3 напряжение достигло максимума, ток перестал уменьшаться
  volt_decreased,  // 4 напряжение стало уменьшаться
  curr_increased,  // 5 ток стал увеличиваться
  disconnect_batt, // 6 акб отключена
  batt_temp_error, // 7 температура акб вышла за пределы
};

// номер причины завершения заряда
extern Reason regim_end;

// структура должена быть кратна 4 байтам
#pragma pack(push, 1)
struct Intls {
  // кооффициент коррекции напряжения 0-255 (сопротивление линии до акб)
  uint8_t Ohms;
  // текущий профиль
  uint8_t profil;
  // коэффициент для калибровки напряжения БП - VKORRECT (1000 по умолчанию)
  uint16_t Vref;
  // сопротивление шунта в микроомах (10000 это 10.000 мОм) 0,5 - 65,5 мОм
  uint16_t shunt;
  // коэффициент для калибровки напряжения INA226 (12500 по умолчанию)
  uint16_t inaKoof;
};
#pragma pack(pop)

extern Intls vkr;

extern Profils profil;

// функция рассчета профиля по параметрам аккумулятора
void calcProfile();

// напряжение аккумулятора
uint16_t bat_volt(uint8_t bat_type);

// флаг секунды
bool get_second(void);

// ждать N секунд
void delay_sec(uint8_t sec);

uint16_t volt_step(uint16_t volt, int8_t x);

// пошаговое изменение значения с ограничением диапазоном [low, high]:
int16_t constrain_i16(int16_t amt, int16_t low, int16_t high, int16_t x);

uint16_t constrain_u16(uint16_t amt, uint16_t low, uint16_t high, int16_t x);

uint8_t constrain_u8(uint8_t amt, uint8_t low, uint8_t high, int8_t x);

int16_t difference(int32_t diff_1, int32_t diff_2);

// функция быстрого переключения "ног"
void digitalWrite_speed(uint8_t pin, bool x);

void analogWrite_my(uint8_t pin, uint16_t duty);

#if defined(__LGT8FX8P__)
int16_t map_my(int16_t x, int16_t in_min, int16_t in_max, int16_t out_min,
               int16_t out_max);
#else
int16_t map_my(int32_t x, int16_t in_min, int16_t in_max, int16_t out_min,
               int16_t out_max);
#endif

//  nvBit(tmp,6);    //инвертировать шестой бит переменной tmp
#define InvBit(reg, bit) reg ^= (1 << bit)
#define BitIsClear(reg, bit) ((reg & (1 << bit)) == 0)

#if (PROFIL > 8)
#error "Максимальное количество профилей не может быть больше 8"
#endif

#if defined(BUFER_PIN) and (BUFER_PIN == PROTECT_OPEN_PIN)
#error                                                                         \
    "Пин буфера (BUFER_PIN) и пина защиты открытия (PROTECT_OPEN_PIN) совпадают."
#endif

static_assert(SHUNT >= 0.0005f and SHUNT <= 0.0655f,
              "Сопротивление ШУНТА должно 0,0005 - 0,0655 Ом");

static_assert(CURR_MAX <= (0.08192f / (float)SHUNT),
              "CURR_MAX не должен быть меньше или равен (0.08192f / SHUNT)");
