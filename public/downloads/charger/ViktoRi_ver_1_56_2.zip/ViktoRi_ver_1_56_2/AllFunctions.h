#include <Arduino.h>
void Storage(void);
int32_t aw_ch(int32_t i);
void Res_mem_char(void);
void Res_mem_dischar(void);
void Res_ktc(void);
void Delay(uint16_t t);
void pauses(void);
uint16_t Volt_DCur(void);
void Korrect(uint8_t kof);
void Wait(uint16_t time_charge);
void End(void);
bool Choice(uint8_t secund, bool rez);
int8_t myTick(void);
void Speaker(uint16_t n);
void ChargeTimeCalc(void);
//uint8_t Percentage(uint16_t volt_max, uint16_t volt, int16_t current, int16_t curr_min);
uint8_t Percentage(int16_t curr_min);
void Menu1602();
void Operations();
void ChargeAkb(uint16_t volt_charge_init, int16_t curr_charge_init, int16_t curr_min, uint32_t time_charge, bool add_charge);
void PrintVA(uint16_t volt = 0, int16_t current = 0, int32_t Ah = 0, int32_t Wh = 0, uint8_t x = 2);
void pr_tm(uint16_t tm);
void Print_time(uint32_t time_real, uint8_t x, uint8_t y);
void setCursorx(void);
void setCursory(void);
void printSimb(void);
void print_tr(void);
void PrintOnOff(bool i);
void Write_x(bool x);
void print_mode(uint8_t i);
void print_Capacity(void);
void printCykl(void);
void Vout(void);
void ClearStr(uint8_t i);
void Saved();
void Reset_settings(uint8_t sett);
void Freq(const uint8_t frq);
void Settings_point(uint8_t point, bool edit, int16_t x);
void Prstatistic(int i, uint32_t time_i, int32_t Ah, int32_t Wh);
void Statistics_point(uint8_t point);
void calculate(uint8_t i);
void sensor_survey(void);
void digitalWrite_speed(uint8_t pin, bool x);  // функция быстрого переключения "ног"
void analogWrite_my(uint8_t pin, uint16_t duty);
void BP_vvcc(void); // режим БП
#if (VOLTIN == 1)
void check_Q1(void);
#endif
#if (POWPIN == 1)
void Relay(void);
void Relay_on(bool vkl);
#endif
#if (GUARDA0)
void Guard(void);
#endif
#if (CORRECTCUR == 1 and SENSTEMP2 > 0)
void Control_trAkb();
#endif

#if (DISCHAR == 1)
void Discharge();
#endif
#if (RESIST == 1)
void Resist();
#endif
#if ((DISPLAYx == 16 and DISPLAYy == 2) or (DISPLAYx == 20 and DISPLAYy == 2))
void Display_print(int32_t Ah, uint32_t time_real, uint8_t prc, bool add);
#endif
#if (DISPLAYx == 20 and DISPLAYy == 4)
void Display_print(int32_t Ah, int32_t Wh, uint32_t time_real, int8_t tr, uint8_t prc);
#endif
#if (DISPLAYx == 16 and DISPLAYy == 4)
void Display_print(int32_t Ah, int32_t Wh, uint32_t time_real, int8_t tr, uint8_t prc);
#endif
#if (SERVICE == 1)
void serviceparam(void);
#endif
#if defined(__LGT8FX8P__)
int16_t map_my(int16_t x, int16_t in_min, int16_t in_max, int16_t out_min, int16_t out_max);
#else
int16_t map_my(int32_t x, int16_t in_min, int16_t in_max, int16_t out_min, int16_t out_max);
#endif
int16_t difference(int32_t diff_1, int32_t diff_2);

#define constrain_my(amt, low, high, x) (((amt) <= (low) and ((x) < 0)) or ((amt) >= (high) and ((x) > 0))) ? (amt) : ((amt) + (x))

#if defined(__LGT8FX8P__)
void lgt_eeprom_update_byte( uint16_t address, uint8_t value );
void lgt_eeprom_update_block(uint8_t* pbuf, uint16_t address, uint16_t len);
#endif

bool get_second(void);

void delay_sec(uint8_t sec);

// функция ожидания (t - милисекунды)
void delay_my(uint16_t ms);
