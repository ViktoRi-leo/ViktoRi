#pragma once
#include <Arduino.h>

#ifdef LGT8_TIMER3
volatile bool t3_second_flag = false;      // флаг секунды
volatile unsigned long t3_second_usr = 0;  // счетчик секунд пользователя
volatile bool t3_second_flag_usr = false;  // флаг включения/отключения счета секунд пользователя
#endif

//#define INT_OSC 0  // внутренний источник тактирования
//#define EXT_OSC 1  // внешний источник тактирования

void lgt8_sysClock(uint8_t mode) {
  switch (mode) {
    case EXT_OSC:
      // set to right prescale - установите правильное предварительное масштабирование
      CLKPR = 0x80;
      CLKPR = 0x01;

      asm volatile("nop");
      asm volatile("nop");

      // enable external crystal
      PMCR = 0x80;
      PMCR = 0x97;  // bin - 10010111

      // waiting for crystal stable - ожидание стабильности кристала
      for (GPIOR0 = 0xff; GPIOR0 > 0; --GPIOR0)
        ;
      for (GPIOR0 = 0xff; GPIOR0 > 0; --GPIOR0)
        ;

      // переключитесь на внешний кристалл
      PMCR = 0x80;
      PMCR = 0xb7;  // bin - 10110111

      // waiting for crystal stable  - ожидание стабильности кристала
      for (GPIOR0 = 0xff; GPIOR0 > 0; --GPIOR0)
        ;
      for (GPIOR0 = 0xff; GPIOR0 > 0; --GPIOR0)
        ;
      // set to right prescale - установите правильное предварительное масштабирование
      CLKPR = 0x80;
      CLKPR = 0x00;
      break;
    case INT_OSC:
      // prescaler settings
      CLKPR = 0x80;
      CLKPR = 0x01;

      // switch to internal crystal - переключитесь на внутренний кристалл
      GPIOR0 = PMCR & 0x9f;
      PMCR = 0x80;
      PMCR = GPIOR0;

      // disable external crystal - отключить внешний кристалл
      GPIOR0 = PMCR & 0xfb;
      PMCR = 0x80;
      PMCR = GPIOR0;
      break;
  }
}

// START CHANGE BY DBUEZAS & SEISFELD & JG1UAA
void lgt8fx8x_clk_src() {
#if defined(__LGT8F_SSOP20__)
  GPIOR0 = PMXCR | 0x07;
  PMXCR = 0x80;
  PMXCR = GPIOR0;
#endif
// select clock source
#if defined(CLOCK_SOURCE)
// override bootloader setting
#if CLOCK_SOURCE == 1
  lgt8_sysClock(INT_OSC);
#elif CLOCK_SOURCE == 2
  lgt8_sysClock(EXT_OSC);
#else
#error "Не указан CLOCK_SOURCE"
#endif
#endif

// select clock prescaler
#if defined(F_CPU) && defined(F_OSC)
#if !defined(F_DIV)
#define F_DIV (F_OSC / F_CPU)
#endif
  CLKPR = 0x80;
#if F_DIV <= 1
  CLKPR = 0x00;
#elif F_DIV <= 2
  CLKPR = 0x01;
#elif F_DIV <= 4
  CLKPR = 0x02;
#elif F_DIV <= 8
  CLKPR = 0x03;
#elif F_DIV <= 16
  CLKPR = 0x04;
#elif F_DIV <= 32
  CLKPR = 0x05;
#elif F_DIV <= 64
  CLKPR = 0x06;
#elif F_DIV <= 128
  CLKPR = 0x07;
#else
  CLKPR = 0x08;
#endif
#endif
}


// включить выходной ток пина 80 мА
void current_80mA(uint8_t pin) {
  switch (pin) {
    case 5:  // D5
      HDR |= (1 << HDR0);
      break;
    case 6:  // D6
      HDR |= (1 << HDR1);
      break;
    case 1:  // TX
      HDR |= (1 << HDR2);
      break;
    case 2:  // D2
      HDR |= (1 << HDR3);
      break;
    case 103:  // нога 3 мк (на плате не подключчена)
      HDR |= (1 << HDR4);
      break;
    case 106:  // нога 6 мк (на плате не подключчена)
      HDR |= (1 << HDR5);
      break;
  }
}

#ifdef LGT8_TIMER3
// Таймер 3 в режиме 1 секунда
inline void timer3_init() {
#if F_CPU >= 32000000
  // TIMER_3 1 SEC
  // (32000000/((31249+1)x1024))=1 Hz
  // TCCR3A = 0; TCCR3B = 0; TCNT3 = 0;
  TCCR3B = (1 << CS32) | (1 << CS30) | (1 << WGM32);
  TIMSK3 = (1 << OCIE3A);  // Разрешаем прерывание при совпадении значения OCR0A
  OCR3A = 31249;
#elif F_CPU >= 16000000
  // TIMER_3 1 SEC
  // (16000000/((15624+1)x1024))=1 Hz
  // TCCR3A = 0; TCCR3B = 0; TCNT3 = 0;
  TCCR3B = (1 << CS32) | (1 << CS30) | (1 << WGM32);
  TIMSK3 = (1 << OCIE3A);
  OCR3A = 15624;
#else
#error "CPU frequency not supported"
#endif
}

ISR(TIMER3_vect) {
  t3_second_flag = true;                    // флаг 1 секунды
  if (t3_second_flag_usr) t3_second_usr++;  // счет секунд заряда/зазряда
}

unsigned long t3_get_second_usr(void) {
  unsigned long m;
  uint8_t oldSREG = SREG;
  cli();
  m = t3_second_usr;
  SREG = oldSREG;
  return m;
}

void t3_start_second_usr(void) {
  cli();
  t3_second_flag_usr = true;
  t3_second_usr = 0;
  sei();
}
#endif