#include <Arduino.h>
//#include <EEPROM.h>

//причина завершения заряда
enum : uint8_t {
  beg,               // 0
  out_time,          // 1 закончилось время
  volt_maxCur_min,   // 2 напряжение достигло максимума ток минимума
  cur_stop,          // 3 напряжение достигло максимума, ток перестал уменьшаться
  volt_decreased,    // 4 напряжение стало уменьшаться
  curr_increased,    // 5 ток стал увеличиваться
} regim_end{ beg };  // номер причины завершения заряда

// названия аккумуляторов
enum : uint8_t {
  PB_CACA,   // 0 Pb Ca/Ca
  PB_CASUR,  // 1 Pb Ca+
  PB_SUR,    // 2 Pb Sur
  PB_AGM,    // 3 Pb AGM
  PB_GEL,    // 4 Pb Gel
  LI_ION,    // 5 Li-ion
  LI_FER,    // 6 LiFePo4
  LI_TIT,    // 7 LiTit
  NI_Cd,     // 8 NiCd/Mh
};

// номера режимов работы
enum : uint8_t {
  CHARGE,            // 0 Заряд
  CHARGE_ADDCHARGE,  // 1 Заряд-Дозаряд  
  ASYMMETRIC,        // 2 ассиметричный заряд 
  BRANIMIR,          // 3 Заряд по Бранимиру
  ADDCHARGE,         // 4 Дозаряд
  DISCHARGE,         // 5 Разряд
  KTCycle,           // 6 Контрольно тренировочный цикл
  STORAGE,           // 7 Режим хранения акб
  BUFER,             // 8 Буферный режим
};

// вывод на дисплей
enum : uint8_t {
  MODE,      // 0 режим работы
  TYPE_AKB,  // 1 тип акб
  ERROR,     // 2 ошибка
  SETTING,   // 3 настройки
  VOLTAGE,   // 4 напряжение во float
};

// названия аккумуляторов
const char name1[] PROGMEM = "Pb Ca/Ca";
const char name2[] PROGMEM = "Pb Ca+";
const char name3[] PROGMEM = "Pb Sur";
const char name4[] PROGMEM = "Pb AGM";
const char name5[] PROGMEM = "Pb Gel";
const char name6[] PROGMEM = "Li-ion";
const char name7[] PROGMEM = "LiFePo4";
const char name8[] PROGMEM = "LiTit";
const char name9[] PROGMEM = "NiCd/Mh";

// объявляем таблицу ссылок
const char* const typeAkb[] PROGMEM = {
  name1,
  name2,
  name3,
  name4,
  name5,
  name6,
  name7,
  name8,
  name9,
};

#define POINTMENU 9       // число пунктов Меню
#define POINTMODE 8       // число пунктов Режимов работы
#define POINTSETTINGS 22  // число пунктов Настроек
#define POINTCALIBRS 2    // число пунктов Калибровок 0-2
#define SYSPARAM 19       // номер системных параметров

// русский (!для дисплеев с поддержкой русского языка!)
#if (INTERFACE == 0)
const char punkt1[] PROGMEM = "Pr:";                                                    //  0   Профиль
const char punkt2[] PROGMEM = "\x45\xBC\xBA\x6F\x63\xBF\xC4 \x41\x4B\xA0";              //  1   Емкость  // АКБ
const char punkt3[] PROGMEM = "\x54\xB8\xBE \x41\x4B\xA0";                              //  2   Тип АКБ
const char punkt4[] PROGMEM = "\x48\x61\xBE\x70\xC7\xB6\x65\xBD\xB8\x65 \x41\x4B\xA0";  //  3   Напряжение АКБ
const char punkt5[] PROGMEM = "\x50\x65\xB6\xB8\xBC \x70\x61\xB2\x6F\xBF\xC3";          //  4   Режим работы
const char punkt6[] PROGMEM = "\x48\x61\x63\xBF\x70\x6F\xB9\xBA\xB8";                   //  5   Настройки
const char punkt7[] PROGMEM = "\x43\x6F\xBE\x70\x6F\xBF\x2E\x41\x4B\xA0";               //  6   Сопрот. АКБ
const char punkt8[] PROGMEM = "\x43\xBF\x61\xBF\xB8\x63\xBF\xB8\xBA\x61";               //  7   Статистика
const char punkt9[] PROGMEM = "\x4B\x61\xBB\xB8\xB2\x70\x6F\xB3\xBA\x61";               //  8   Калибровка
const char punkt10[] PROGMEM = " ";

const char* const menuTxt[] PROGMEM = {
  punkt1,
  punkt2,
  punkt3,
  punkt4,
  punkt5,
  punkt6,
  punkt7,
  punkt8,
  punkt9,
  punkt10,
};

const char regim0[] PROGMEM = "\xA4\x61\x70\xC7\xE3";                                       //  0   Заряд
const char regim1[] PROGMEM = "\xA4\x61\x70\xC7\xE3>\xE0\x6F\xB7\x61\x70\xC7\xE3";          //  1   Заряд>Дозаряд
const char regim2[] PROGMEM = "Acc\xB8\xBC\x65\xBFp. \xB7\x61\x70\xC7\xE3";                 //  2   Aссиметричный заряд
const char regim3[] PROGMEM = "\xA4\x61\x70\xC7\xE3 \xA0\x70\x61\xBD\xB8\xBC\xB8\x70\x61";  //  3   Заряд Бранимир
const char regim4[] PROGMEM = "\xE0\x6F\xB7\x61\x70\xC7\xE3";                               //  4   Дозаряд
const char regim5[] PROGMEM = "\x50\x61\xB7\x70\xC7\xE3";                                   //  5   Разряд
const char regim6[] PROGMEM = "KT\xE5";                                                     //  6   КТЦ (Разр>Зар>Дозар)
const char regim7[] PROGMEM = "\x58\x70\x61\xBD\x65\xBD\xB8\x65";                           //  7   Хранение АКБ
const char regim8[] PROGMEM = "\xA0\x79\xE4.\x70\x65\xB6\xB8\xBC";                          //  8   Буф.режим  // Буферный режим "\xA0\x79\xE4\x65\x70\xBD\xc3\xB9 \x70\x65\xB6\xB8\xBC";

const char* const modeTxt[] PROGMEM = {
  regim0,
  regim1,
  regim2,
  regim3,
  regim4,
  regim5,
  regim6,
  regim7,
  regim8,
};

#if (DISPLAYy == 2)
const char regimr[] PROGMEM = "\xA4\xA4\x41\xA0\xE0\x50K";  // символы вывода режима работы - Заряд, Заряд, Бранимир, Дозаряд, Разряд, КТЦ
#endif

const char sett0[] PROGMEM = "\x48\x61\xBE\x70\xC7\xB6 \xB7\x61\x70\xC7\xE3\x61";              //  0   Напряж. зарядa  *
const char sett1[] PROGMEM = "\x54\x6F\xBA \xB7\x61\x70\xC7\xE3\x61";                          //  1   Ток заряда      *
const char sett2[] PROGMEM = "\x48\x61\xBE\x70\xC7\xB6 \x43\xBD\xB8\xB6.";                     //  2   Напряжение при котором начинает снижаться ток
const char sett3[] PROGMEM = "\x4D\xB8\xBD. \xBF\x6F\xBA \xB7\x61\x70\xC7\xE3\x61";            //  3   Мин. ток заряда *
const char sett4[] PROGMEM = "\x42\x70\x65\xBC\xC7 \xB7\x61\x70\xC7\xE3\x61";                  //  4   Время заряда    *
const char sett5[] PROGMEM = "\xA8\x65\x70\xB8\x6F\xE3 \xB7\x61\x70\xC7\xE3\x61";              //  5   Период заряда
const char sett6[] PROGMEM = "\xA8\x65\x70\xB8\x6F\xE3 \x70\x61\xB7\x70\xC7\xE3\x61";          //  6   Период разряда
const char sett7[] PROGMEM = "\x48\x61\xBE\x70. \xE3\x6F\xB7\x61\x70\xC7\xE3\x61";             //  7   Напр. дозаряда  *
const char sett8[] PROGMEM = "\x54\x6F\xBA \xE3\x6F\xB7\x61\x70\xC7\xE3\x61";                  //  8   Ток дозаряда    *
const char sett9[] PROGMEM = "\x4D\xB8\xBD. \xBF\x6F\xBA \xE3\x6F\xB7\x61\x70\xC7\xE3\x61";    //  9   Мин. ток дозар. *
const char sett10[] PROGMEM = "\x42\x70\x65\xBC\xC7 \xE3\x6F\xB7\x61\x70\xC7\xE3\x61";         //  10  Время дозаряда  *
const char sett11[] PROGMEM = "\x48\x61\xBE\x70. \x70\x61\xB7\x70\xC7\xE3\x61";                //  11  Наряж. разряда  *
const char sett12[] PROGMEM = "\x54\x6F\xBA \x70\x61\xB7\x70\xC7\xE3\x61";                     //  12  Ток разряда     *
const char sett13[] PROGMEM = "\x4D\xB8\xBD. \xBF\x6F\xBA \x70\x61\xB7\x70\xC7\xE3\x61";       //  13  Мин. ток разряда*
const char sett14[] PROGMEM = "\xA0\x79\xE4\x65\x70\xBD\xc3\xB9 \x70\x65\xB6\xB8\xBC";         //  14  Буферный режим  *
const char sett15[] PROGMEM = "\x58\x70\x61\xBD\x65\xBD\xB8\x65";                              //  15  Хранение
const char sett16[] PROGMEM = "\xA8\x70\x65\xE3\xB7\x61\x70\xC7\xE3";                          //  16  Предзаряд       *
const char sett17[] PROGMEM = "\x48\x61\xBE\x70. \xBE\x70\x65\xE3\xB7\x61\x70\xC7\xE3\x61";    //  17  Напряж. предзар.*
const char sett18[] PROGMEM = "\x54\x6F\xBA \xBE\x70\x65\xE3\xB7\x61\x70\xC7\xE3\x61";         //  18  Ток предзаряда  *
const char sett19[] PROGMEM = "\x4B\x61\xC0\x65\xBB\xB8";                                      //  19  Качели          *
const char sett20[] PROGMEM = "\xE1\xB8\xBA\xBB";                                              //  20  Цикл
const char sett21[] PROGMEM = "\x21\x43\xB8\x63\xBF\x65\xBC\x2E\x20\xBE\x61\x70\x61\xBC\x21";  //  21  !Cистем. парам! *
const char sett22[] PROGMEM = "\x43\xB2\x70\x6F\x63 \xBD\x61\x63\xBF\x70\x6F\x65\xBA";         //  22  Сброс настроек  *

const char* const settings[] PROGMEM = {
  sett0,
  sett1,
  sett2,
  sett3,
  sett4,
  sett5,
  sett6,
  sett7,
  sett8,
  sett9,
  sett10,
  sett11,
  sett12,
  sett13,
  sett14,
  sett15,
  sett16,
  sett17,
  sett18,
  sett19,
  sett20,
  sett21,
  sett22,
};

const char namc1[] PROGMEM = "\x48\x61\xBE\x70\xC7\xB6/\x54\x6F\xBA \x41\xBA\xB2";  // Напряж/ток акб
const char namc2[] PROGMEM = "\x48\x61\xBE\x70\xC7\xB6 \xA0\xA8";                   // Напряж. БП
const char namc3[] PROGMEM = "INA Volt";

const char* const calibr[] PROGMEM = { namc1, namc2, namc3 };

#define txt2 " \x63\xB2\x70\x6F\x63"            //  сброc
#define txt3 " \x63\x6F\x78\x70\x21"            //  сохр!
#define txt4 "\x42\x78\x2E\x20\xA0\xA8 "        //  "Вх. БП "
#define txt5 "\x42\xC3\x78\x6F\xE3"             //  Выход
#define txt6 "INA226 \x6F\xC1\xB8\xB2\xBA\x61"  //  INA226
#define txt7 "DS18B20 "                         //  DS18B20
//#define txt8 "!ALERT!"                                         //
#define txt9 "Temp akb:"                                       //  температура акб
#define txt10 "\x42\x63\xA2"                                   //  Всё
#define txt11 "\xA8\x6F\xE3\xBA\xBB\xC6\xC0\xB8 \x41\x4B\xA0"  //  Подключи АКБ
#define txt111 "\xA8\x6F\xE3\xBA\xBB\xC6\xC0\xB8 \xA0\xA8"     //  Подключи БП
#define txt12 "\x43\xB2\x70\x6F\x63"                           //  Сброс
#define txt13 "\x42\xBA\xBB\x2E "                              //  Вкл.
#define txt14 "\x4F\xBF\xBA\xBB\x2E"                           //  Откл.
//#define txt15 "\xAB\x61\x63"                                   //  Час
#define txt16 "\xA8\x61\x79\xB7\x61"  //  Пауза
#define txt17 "\x3C \x4F\x4B \x3E"    // "< OK >"
//#define txt18 "V Bpe\xBC\xC7 "                              //  V Время
#define txt19 "\x3C\x43\xBF\x6F\xBE\x3e"         //  "<Стоп>"
#define txt20 " \xBC\xB8\xBD "                   //  мин
#define txt21 "\x6F\xC1\xB8\xB2\xBA\x61"         //  ошибка
#define txt22 "Volt"                             // Вольт
#define txt23 "Amper"                            // Ампер
#define txt24 "!-\xA8\x50\x4F\xA0\xA5\x54 Q1-!"  //  !-ПРОБИТ Q1-!
#define txt25 "\x56\xB2\xBE "                    //  Vбп
//#define txt26 "\x41\x4B\xA0\x20\x70\x61\xB7\x70\xC7\xB6\x65\xBD\x21"  //  АКБ разряжен!
//const char err[] PROGMEM = "\x6F\xC1\xB8\xB2\xBA\x61";

// английский
#elif (INTERFACE == 1)
const char punkt1[] PROGMEM = "Pr:";
const char punkt2[] PROGMEM = "Capacity Akb";
const char punkt3[] PROGMEM = "Type Akb";
const char punkt4[] PROGMEM = "Voltage Akb";
const char punkt5[] PROGMEM = "Operating mode";
const char punkt6[] PROGMEM = "Settings";
const char punkt7[] PROGMEM = "Resist. akb";
const char punkt8[] PROGMEM = "Statistics";
const char punkt9[] PROGMEM = "Calibration";
const char punkt10[] PROGMEM = " ";

const char* const menuTxt[] PROGMEM = {
  punkt1,
  punkt2,
  punkt3,
  punkt4,
  punkt5,
  punkt6,
  punkt7,
  punkt8,
  punkt9,
  punkt10,
};

const char regim0[] PROGMEM = "Charge";
const char regim1[] PROGMEM = "Charge>AddChar";
const char regim2[] PROGMEM = "Asymmetric charge";
const char regim3[] PROGMEM = "Charge Branim";
const char regim4[] PROGMEM = "Add charge";
const char regim5[] PROGMEM = "Discharge";
const char regim6[] PROGMEM = "Contr.trai.cycle";
const char regim7[] PROGMEM = "Storage";
const char regim8[] PROGMEM = "Buffer";  // "Buffer mode"

const char* const modeTxt[] PROGMEM = {
  regim0,
  regim1,
  regim2,
  regim3,
  regim4,
  regim5,
  regim6,
  regim7,
  regim8,
};

#if (DISPLAYy == 2)
const char regimr[] PROGMEM = "CCABADK";  // символы вывода режима работы - Заряд, Заряд, Бранимир, Дозаряд, Разряд, КТЦ
#endif

const char sett0[] PROGMEM = "Volt charge";        //  0   Напряж. зарядa
const char sett1[] PROGMEM = "Curr. charge";       //  1   Ток заряда
const char sett2[] PROGMEM = "Volt decr.Cur";      //  2   Напряжение при котором начинает снижаться ток
const char sett3[] PROGMEM = "Curr. charge off";   //  3   ток завершения заряда
const char sett4[] PROGMEM = "Time charge";        //  4   Время заряда
const char sett5[] PROGMEM = "Period charge";      //  5   Период заряда
const char sett6[] PROGMEM = "Period discharge";   //  6   Период разряда
const char sett7[] PROGMEM = "Volt add charge";    //  7   Напряж. дозаряда
const char sett8[] PROGMEM = "Curr. add charge";   //  8   Ток дозаряда
const char sett9[] PROGMEM = "Curr.addChar min";   //  9   Мин. ток дозар.
const char sett10[] PROGMEM = "Time add charge";   //  10  Время дозаряда
const char sett11[] PROGMEM = "Volt dischar";      //  11  Наряж. разряда
const char sett12[] PROGMEM = "Curr. dischar";     //  12  Ток разряда
const char sett13[] PROGMEM = "Curr.disch. off";   //  13  Мин. ток разряда
const char sett14[] PROGMEM = "Bufer mode";        //  14  Буферный режим
const char sett15[] PROGMEM = "Storage mode";      //  15  напряжение режима Хранение
const char sett16[] PROGMEM = "Precharge";         //  16  Предзаряд
const char sett17[] PROGMEM = "Volt pre charge";   //  17  Напряж. предзар.
const char sett18[] PROGMEM = "Curr. pre charge";  //  18  Ток предзаряда
const char sett19[] PROGMEM = "Oscillation";       //  19  Качели
const char sett20[] PROGMEM = "Cycle";             //  20  Цикл
const char sett21[] PROGMEM = "!system param!";    //  21  #define SYSPARAM 18       // номер системных параметров
const char sett22[] PROGMEM = "Reset settings";    //  22   Сброс настроек

const char* const settings[] PROGMEM = {
  sett0,
  sett1,
  sett2,
  sett3,
  sett4,
  sett5,
  sett6,
  sett7,
  sett8,
  sett9,
  sett10,
  sett11,
  sett12,
  sett13,
  sett14,
  sett15,
  sett16,
  sett17,
  sett18,
  sett19,
  sett20,
  sett21,
  sett22,
};

const char namc1[] PROGMEM = "Volt/Curr akb";
const char namc2[] PROGMEM = "Volt Power";
const char namc3[] PROGMEM = "INA Volt";

const char* const calibr[] PROGMEM = { namc1, namc2, namc3 };

#define txt2 " reset"
#define txt3 " saved"  // 2 раза
#define txt4 "Power "
#define txt5 "Exit"
#define txt6 "INA226 error"
#define txt7 "DS18B20 "
//#define txt8 "!ALERT!"
#define txt9 "Temp akb:"  //  температура акб
#define txt10 "All"
#define txt11 "Connect batt"
#define txt111 "Connect power"
#define txt12 "Sbros"
#define txt13 "On "
#define txt14 "Off "
//#define txt15 " hour" // 2 раза
#define txt16 "Pause"
#define txt17 "< OK >"
//#define txt18 "V  Time "
#define txt19 "<Stop>"
#define txt20 " min "
#define txt21 "error"  // 6 раз
#define txt22 "Volt"
#define txt23 "Amper"
#define txt24 "!-BROKEN Q1-!"
#define txt25 "Vin "  //  Напряж БП превыш
//#define txt26 "Akb razryazen!"
//const char err[] PROGMEM = "error";

// транстит
#elif (INTERFACE == 2)
const char punkt1[] PROGMEM = "Pr:";
const char punkt2[] PROGMEM = "Emkost akb";
const char punkt3[] PROGMEM = "Tip akb";
const char punkt4[] PROGMEM = "Napryagenie akb";
const char punkt5[] PROGMEM = "Regim raboti";
const char punkt6[] PROGMEM = "Nastroiki";
const char punkt7[] PROGMEM = "Soprot. akb";
const char punkt8[] PROGMEM = "Statistika";
const char punkt9[] PROGMEM = "Kalibrovka";
const char punkt10[] PROGMEM = " ";

const char* const menuTxt[] PROGMEM = {
  punkt1,
  punkt2,
  punkt3,
  punkt4,
  punkt5,
  punkt6,
  punkt7,
  punkt8,
  punkt9,
  punkt10,
};

const char regim0[] PROGMEM = "Zaryad";
const char regim1[] PROGMEM = "Zar.>Dozaryad";
const char regim2[] PROGMEM = "Asymmetric zar.";                            //  2   Aссиметричный заряд
const char regim3[] PROGMEM = "Zar. Branimir";
const char regim4[] PROGMEM = "Dozaryad";
const char regim5[] PROGMEM = "Razryad";
const char regim6[] PROGMEM = "KTC";
const char regim7[] PROGMEM = "Hranenie";
const char regim8[] PROGMEM = "Buf. regim";  // "Bufer regim"

const char* const modeTxt[] PROGMEM = {
  regim0,
  regim1,
  regim2,
  regim3,
  regim4,
  regim5,
  regim6,
  regim7,
  regim8,
};

#if (DISPLAYy == 2)
const char regimr[] PROGMEM = "ZZABDRK";  // символы вывода режима работы - Заряд, Заряд, Бранимир, Дозаряд, Разряд, КТЦ
#endif

const char sett0[] PROGMEM = "Napr. zaryada";
const char sett1[] PROGMEM = "Tok zaryada";
const char sett2[] PROGMEM = "Napr. snigen";  //  2   Напряжение при котором начинает снижаться ток
const char sett3[] PROGMEM = "Min. tok zaryda";
const char sett4[] PROGMEM = "Vremya zaryada";
const char sett5[] PROGMEM = "Period zaryada";    //  5   Период заряда
const char sett6[] PROGMEM = "Period razryada";   //  6   Период разряда
const char sett7[] PROGMEM = "Napr. dozaryada";
const char sett8[] PROGMEM = "Tok dozaryada";
const char sett9[] PROGMEM = "Min. tok dozar.";
const char sett10[] PROGMEM = "Vremya dozaryada";
const char sett11[] PROGMEM = "Napr. razryada";
const char sett12[] PROGMEM = "Tok razryada";
const char sett13[] PROGMEM = "Min. tok razr.";
const char sett14[] PROGMEM = "Bufernii regim";
const char sett15[] PROGMEM = "Xranenie Akb";
const char sett16[] PROGMEM = "Predzaryad";
const char sett17[] PROGMEM = "Napr. predzaryda";
const char sett18[] PROGMEM = "Tok predzaryda";
const char sett19[] PROGMEM = "Regim kacheli";
const char sett20[] PROGMEM = "Cycle";
const char sett21[] PROGMEM = "!system param!";
const char sett22[] PROGMEM = "Sbros nastroek";

const char* const settings[] PROGMEM = {
  sett0,
  sett1,
  sett2,
  sett3,
  sett4,
  sett5,
  sett6,
  sett7,
  sett8,
  sett9,
  sett10,
  sett11,
  sett12,
  sett13,
  sett14,
  sett15,
  sett16,
  sett17,
  sett18,
  sett19,
  sett20,
  sett21,
  sett22,
};

const char namc1[] PROGMEM = "Volt/Curr akb";
const char namc2[] PROGMEM = "Volt Power";
const char namc3[] PROGMEM = "INA Volt";

const char* const calibr[] PROGMEM = { namc1, namc2, namc3 };

#define txt2 " sbros"
#define txt3 " sohr."
#define txt4 "Power "
#define txt5 "Exit"
#define txt6 "INA226 error"
#define txt7 "DS18B20 "
//#define txt8 "!ALERT!"
#define txt9 "Temp akb:"
#define txt10 "Vse"
#define txt11 "Podkluchi AKB"
#define txt111 "Podkluchi BP"
#define txt12 "Sbros"
#define txt13 "Vkl."
#define txt14 "Otkl."
//#define txt15 " chas"
#define txt16 "Pause"
#define txt17 "< OK >"
//#define txt18 "V  Time "
#define txt19 "<Stop>"
#define txt20 " min "
#define txt21 "error"
#define txt22 "Volt"
#define txt23 "Amper"
#define txt24 "!-PROBIT Q1-!"
#define txt25 "Vin "  //  Напряж БП превыш
//#define txt26 "Akb razryazen!"
//const char err[] PROGMEM = "error";
#endif


// ------сервисные параметры-----------
#define SETTINGS_AMOUNT 15  // количество настроек
const char service0[] PROGMEM = "POWER";
const char service1[] PROGMEM = "POWER_MAX";
const char service2[] PROGMEM = "***";
const char service3[] PROGMEM = "CURR_MAX";
const char service4[] PROGMEM = "FAN";
const char service5[] PROGMEM = "DEG_ON";
const char service6[] PROGMEM = "DEG_OFF";
const char service7[] PROGMEM = "DEG_MAX";
const char service8[] PROGMEM = "DEG_CUR";
const char service9[] PROGMEM = "CURFAN_ON";
const char service10[] PROGMEM = "CURFAN_OFF";
const char service11[] PROGMEM = "CURFAN_MAX";
const char service12[] PROGMEM = "TIME_LIGHT";
const char service13[] PROGMEM = "FREQ_CHARGE";
const char service14[] PROGMEM = "FREQ_DISCHAR";

const char* const servicc[] PROGMEM = {
  service0,
  service1,
  service2,
  service3,
  service4,
  service5,
  service6,
  service7,
  service8,
  service9,
  service10,
  service11,
  service12,
  service13,
  service14,
};

// номера ячеек сервисных параметров в EEPROM
enum : uint8_t {
  POWERIN,      // 0 напряжение от БП
  POWERMAX,     // 1 максимальное напряжение от БП
  INAVKOOFV,    // 2 коэффициент напряжения INA226
  CURRMAX,      // 3 максимальный ток
  FANMODE,      // 4 режим работы кулера
  DEGON,        // 5 температура включения вентилятора в градусах
  DEGOFF,       // 6 температура отключения вентилятора в градусах
  DEGMAX,       // 7 значение температуры для максимальных оборотов вентилятора ШИМ.
  DEGCUR,       // 8 температура при которой уменьшается ток заряда
  CURFANON,     // 9 значение тока в Амперах при котором включается вентилятор. (до 25,5А)
  CURFANOFF,    // 10 значение тока в Амперах при котором отключается вентилятор. (до 25,5А)
  CURFANMAX,    // 11 значение тока в Амперах  для максимальных оборотов вентилятора ШИМ. (до 25,5А)
  TIMELIGHT,    // 12 время подсветки дисплея в минутах
  FREQCHARGE,   // 13 частота работы силовогомодуля
  FREQDISCHAR,  // 14 частота работы разрядного модуля
};

uint8_t get_epprom_servise(uint8_t nomer) {
#if defined(__LGT8FX8P__)
  return lgt_eeprom_read_byte(MEM_SERV + nomer);
#else
  return EEPROM.read(MEM_SERV + nomer);
#endif
}

#define POWERINT ((uint16_t)get_epprom_servise(POWERIN) * 1000)  // напряжение от БП
#define CURRMAXINT ((int16_t)get_epprom_servise(CURRMAX) * 100)  // максимальный ток

uint16_t volt_step(uint16_t volt, int8_t x) {
  return constrain_my(volt, STEP_VOLT * 10, POWERINT, x * STEP_VOLT);
}

// символы аккумулятора и заряда
const char simb_array[8][8] PROGMEM = {
  { 0x0E, 0x11, 0x11, 0x11, 0x11, 0x11, 0x11, 0x1F },  // akb 0
  { 0x0E, 0x11, 0x11, 0x11, 0x11, 0x11, 0x1F, 0x1F },  // akb 1
  { 0x0E, 0x11, 0x11, 0x11, 0x11, 0x1F, 0x1F, 0x1F },  // akb 2
  { 0x0E, 0x11, 0x11, 0x11, 0x1F, 0x1F, 0x1F, 0x1F },  // akb 3
  { 0x0E, 0x11, 0x11, 0x1F, 0x1F, 0x1F, 0x1F, 0x1F },  // akb 4
  { 0x0E, 0x11, 0x1F, 0x1F, 0x1F, 0x1F, 0x1F, 0x1F },  // akb 5
  { 0x0E, 0x1F, 0x1F, 0x1F, 0x1F, 0x1F, 0x1F, 0x1F },  // akb 6
  { 0x03, 0x06, 0x0C, 0x18, 0x1F, 0x06, 0x0C, 0x18 },  // заряд 7
};

#if defined(__LGT8FX8P__)
void lgt_eeprom_update_byte(uint16_t address, uint8_t value) {
  if (lgt_eeprom_read_byte(address) != value) lgt_eeprom_write_byte(address, value);
}

void lgt_eeprom_update_block(uint8_t* pbuf, uint16_t address, uint16_t len) {
  uint16_t i;
  uint8_t* p = pbuf;
  for (i = 0; i < len; i++) {
    lgt_eeprom_update_byte(address + i, *p++);
  }
}
#endif

//const char simbols[] PROGMEM = "VAWCNh%()<>:; ";
