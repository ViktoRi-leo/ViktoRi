#if (Time_pause_assimetric == 0)
#undef Time_pause_assimetric
#define Time_pause_assimetric 1
#endif

struct VA_var {
  // Дозаряд
  // два значения напряжений при дозаряде
  uint16_t add_volt_max;  // напряжение при максимальном токе
  uint16_t add_volt_min;  // напряжение при минимальном токе

  // когда разница между напряжениями станет менее 300 мВ то завершить дозаряд
  bool Add_end(void) {
    return ((add_volt_max - add_volt_min) < Volt_difference_mV);
  }

  // Заряд
  uint16_t schet_curr_speed = Time_Curr_decrease;  // счет скорости снижения тока, секунды
  int8_t curr_speed = 0;                           // значение изменения тока
  int16_t curr_speed_previous = 0;                 // предыдущее значение
  // проверка тока на скорость снижения
  bool curr_speed_check(void) {
    // напряжение достигло максимального
    if (schet_curr_speed == Time_Curr_decrease) curr_speed_previous = ina.curr_aver;  // сохраняем значение тока
    if (--schet_curr_speed == 0) {
      // ждем 10 минут
      schet_curr_speed = Time_Curr_decrease;
      int16_t cs = ina.curr_aver - curr_speed_previous;  // высчитываем разницу
      curr_speed = (int8_t)constrain(cs, -127, 127);
      if (curr_speed >= -5) return true;  // если ток снижается менее чем 5 мА за 20 минут то завершить заряд
    }
    return false;
  }

  // критические значения изменения. Сохраняются каждую секунду
  int16_t curr_critical_0 = 0;  // значение изменения тока
  int16_t curr_previous = 0;    // предыдущее значение
  int8_t curr;                  // разница тока за 1 секунду
  bool rise = false;            // ток увеличивается
  uint8_t schet_0 = 60;         // счет 60 сек
  uint16_t schet_1 = 600;       // счет 10 мин
  uint16_t schet_2 = 1800;      // счет 30 мин

  int16_t volt_critical_0 = 0;  // значений изменения напряжения
  int16_t volt_previous = 0;    // предыдущее значение
  int8_t volt_difference;       // разница напряжения за 1 секунду
  bool volt_rise = false;       // напряжениe увеличивается
  uint8_t schet_v0 = 60;        // счет 60 сек
  uint16_t schet_v1 = 600;      // счет 10 мин
  uint16_t schet_v2 = 1800;     // счет 30 мин

  // вызывается раз в 1 секунду
  bool offset_critical(bool v_max) {
    // проверка тока на увеличение
    int16_t cs = ina.curr_aver - curr_previous;
    curr = (int8_t)constrain(cs, -127, 127);
    if (v_max) {
      // напряжение достигло максимального
      if (curr > 0 or curr_critical_0 > 0) {
        // ток увеличивается
        curr_critical_0 += curr;  // увеличение или уменьшение до нуля
        rise = true;
      } else if (rise) {
        rise = false;
        curr_critical_0 = 0;
        schet_0 = 60;    // счет 60 сек
        schet_1 = 600;   // счет 10 мин
        schet_2 = 1800;  // счет 30 мин
      }

      if (curr_critical_0 > 0) {
        if (curr_critical_0 > Curr_Critical_mA) return true;
        if ((--schet_0 == 0) and curr_critical_0 > 100) return true;  // 60 сек
        if ((--schet_1 == 0) and curr_critical_0 > 50) return true;   // 10 мин
        if ((--schet_2 == 0) and curr_critical_0 > 20) return true;   // 30 мин
      }
    }
    curr_previous = ina.curr_aver;

    // проверка напряжение на уменьшение
    cs = difference(ina.volt_aver, volt_previous);
    volt_difference = (int8_t)constrain(cs, -127, 127);
    if (volt_difference and volt_critical_0 <= 0) {
      //
      volt_critical_0 += volt_difference;  // уменьшение или увеличение до нуля
      if (volt_critical_0 > 0) volt_critical_0 = 0;
      if (volt_critical_0) volt_rise = true;
    } else if (volt_rise) {
      volt_rise = false;
      volt_critical_0 = 0;
      schet_v0 = 60;    // счет 60 сек
      schet_v1 = 600;   // счет 10 мин
      schet_v2 = 1800;  // счет 30 мин
    }

    if (volt_critical_0 < 0) {
      if (volt_critical_0 < Volt_Critical_mV) return true;
      if ((--schet_v0 == 0) and volt_critical_0 < -100) return true;  // 60 сек
      if ((--schet_v1 == 0) and volt_critical_0 < -50) return true;   // 10 мин
      if ((--schet_v2 == 0) and volt_critical_0 < -20) return true;   // 30 мин
    }
    volt_previous = ina.volt_aver;
    return false;
  }
};

// Функция заряда. volt_charge_init - напряжение заряда, curr_charge_init - ток заряда, curr_min - минимальный ток заряда, time_charge - время заряда в часах, add_charge - дозаряд вкл/откл
void ChargeAkb(uint16_t volt_charge_init, int16_t curr_charge_init, int16_t curr_min, uint32_t time_charge, bool add_charge) {

  // флаги управления зарядом
  enum : uint8_t {
    CHARGEZ,  // заряд включен
    OSCILZ,   // осциляция
    KORR,     // корректировка напряжения и тока заряда
    KORRVA,   // изменение вольт или ампер
    POWOFF,   // Напряжение от БП пропало
    VMAXM,    // напряжение достигло максимума
    ADD_mm,   // если минимальный ток меньше тока дозаряда - будет работать алгоритм качелей
  };
  // режимы заряда
  enum : uint8_t {
    REGIM_PRECHARGE = 1,  // 1 Предзаряд
    REGIM_CHARGE,         // 2 Заряд
    REGIM_ADDCHARGE,      // 3 Дозаряд
    REGIM_OSCIL,          // 4 осциляция(качели)
    REGIM_BRANIMIR,       // 5 заряд по Бранимиру
    REGIM_ASYMMETRIC,     // 6 ассиметричный заряд
  } typez;

  uint8_t flagsz = 0b00001011;  // флаги
  bitWrite(flagsz, ADD_mm, (curr_min < curr_charge_init));
  //вывод режима, напряжения и тока заряда/разряда
#if (GUARDA0)
  Guard();  // принудительная блокировка модуля защиты при напряжении заряда или разряда акб менее 5 Вольт.
#endif
  // вывод значений заряда
  PrintVA(volt_charge_init, curr_charge_init, 0, 0, 2);  // вывод напряжения и тока заряда
  lcd.print(time_charge);                                // вывод времени заряда/дозаряда
  lcd.write('h');
  lcd.setCursor(DISPLAYx - 2, 0);
  printCykl();                           // вывод количества циклов
  Freq(get_epprom_servise(FREQCHARGE));  // установить частоту работы силового модуля
  time_charge *= 3600;                   // перевел часы в секунды

  VA_var va;
  Tyme tyme;

  tyme.local = add_charge ? pam.Time_addcharge : pam.Time_charge;  // время заряда или дозаряда

  typez = add_charge ? REGIM_ADDCHARGE : (bitRead(pam.MyFlag, PRECHAR) ? REGIM_PRECHARGE : REGIM_CHARGE);  // 1 - Предзаряд, 2 - Заряд, 3 - Дозаряд, 4 - осциляция(качели), 5 - заряд по Бранимиру
#if (BRRANIMIR == 1)
  if (pam.Mode == BRANIMIR) typez = REGIM_BRANIMIR;  // 5 - заряд по Бранимиру
  uint32_t tyme_branim = 0;
#endif
  if (pam.Mode == ASYMMETRIC) typez = REGIM_ASYMMETRIC;
  uint8_t pre_minut = 60;  // таймер 60 секунд для предзаряда
  uint16_t sec_600 = 600;  // время 10 минут

  uint8_t n_disp = 0, ns_disp = 0;  // номер экрана, время отображения
  uint16_t Timezar = 0;             // время до завершения заряда секунды
  uint16_t v1 = 0;                  // переменная для сохранения напряжения
  uint8_t tsw = 10;                 // Дозаряд переменная времени переключения, сек.

  uint16_t period = pam.period_charge;  // счет времени для ассиметричного заряда

  uint8_t time_millis = 0;
  const int16_t cur_max = curr_charge_init;
  const uint16_t volt_crash = volt_charge_init + (volt_charge_init >> 4);  // * 1.025 дополнительная защита от повышенного напряжения
  const int16_t curr_crash = curr_charge_init + (curr_charge_init >> 2);   // * 1.25 дополнительная защита от повышенного тока

#if (Time_pause_assimetric <= 255)
  uint8_t time_pause_assimetric = 0;
#elif (Time_pause_assimetric <= 65535)
  uint16_t time_pause_assimetric = 0;
#else
  uint32_t time_pause_assimetric = 0;
#endif

  uint8_t time_y = Curr_off_charge;  // таймер 5 сек до отключения заряда при снятии клеммы

#if (POWPIN == 1)
  // Relay_on(true);                       // включить сеть 220В
#endif
  const int x[]{ (int)(&settings[16]), (int)(&modeTxt[CHARGE]), (int)(&modeTxt[ADDCHARGE]), (int)(&settings[19]), (int)(&modeTxt[BRANIMIR]), (int)(&modeTxt[ASYMMETRIC]) };  // {предварительный заряд, заряд, дозаряд, Качели, Бранимир}

  ina.start();  // старт замеров INA
  Delay(3000);

  lcd.clear();
  start_second_usr();       // старт счета секунд
  dcdc.start(DCDC_CHARGE);  // режим работы DCDC
  // задает напряжение и ток заряда
  dcdc.begin(volt_charge_init, (add_charge ? curr_charge_init : (bitRead(pam.MyFlag, PRECHAR) ? pam.Current_pre_charge >> 1 : curr_charge_init)));

  // цикл заряда
  while (bitRead(flagsz, CHARGEZ) and bitRead(pam.MyFlag, ACTIVITI)) {
    sensor_survey();  // опрос кнопок, INA226, напряж. от БП., контроль dcdc.

#if (VOLTIN == 1)
    if (BitIsClear(flag_global, POWERON) and BitIsClear(flagsz, POWOFF)) {
      // если пропадет напряжение от БП то отключить ШИМ.
      dcdc.Off();
      bitSet(flagsz, POWOFF);
      second_flag_usr = false;  // счет времени заряда откл.
      va.curr_critical_0 = 0;   // значение изменения тока
      va.volt_critical_0 = 0;   // значений изменения напряжения
      Speaker(100);             // функция звукового сигнала (время в миллисекундах)
    } else if (bitRead(flag_global, POWERON) and bitRead(flagsz, POWOFF)) {
      dcdc.start(DCDC_CHARGE);
      bitClear(flagsz, POWOFF);
      second_flag_usr = true;  // счет времени заряда вкл.
      Speaker(100);            // функция звукового сигнала (время в миллисекундах)
      lcd.clear();
    }
#endif

    if (butt.tick) {
      // если кнопка нажата
      if (bitRead(flagsz, KORR)) {
        // производится корректировка напряжения и тока заряда
        va.curr_critical_0 = 0;  // значение изменения тока
        va.volt_critical_0 = 0;  // значений изменения напряжения
        switch (butt.tick) {
          case RIGHT:  // энкодер вправо
          case LEFT:   // энкодер влево
            // изменение напряжения или тока
            if (bitRead(flagsz, KORRVA)) volt_charge_init = volt_step(volt_charge_init, butt.tick);
            else {
              int8_t step = butt.tick > 0 ? (int8_t)STEP_CURR : -(int8_t)STEP_CURR;
              curr_charge_init = constrain_my(curr_charge_init, CUR_CHARGE_MIN, CURRMAXINT - 500, step);  // butt.tick * STEP_CURR
            }
            dcdc.begin(volt_charge_init, curr_charge_init);
            break;
          case OKCLICK:  // нажать Пуск
            InvBit(flagsz, KORRVA);
            break;
          case OKHELD:               // удержать энкодер
          case STOPCLICK:            // нажать Стоп
            bitClear(flagsz, KORR);  //korr = false;  // выйти из изменения
            setCursory();
            ClearStr(15);  // очистить вторую строку
            break;
        }
      } else {
        if (n_disp == WINDC and butt.tick == OKHELD) {
          bitSet(flagsz, KORR);
        } else {
          switch (butt.tick) {
            case STOPHELD:
            case OKHELD:
              if (n_disp == 0) bitClear(pam.MyFlag, ACTIVITI);  // завершить заряд
              break;
            case RIGHT:
            case LEFT:
              if (bitRead(flag_global, POWERON)) {
                // если питание от БП приходит то выбрать следующее окно
                lcd.clear();
                n_disp = (n_disp == 0 and butt.tick < 0) ? WINDC : n_disp + butt.tick;  // окно отображения
                ns_disp = TIME_DISP;                                                    // время отображения сек
              }
              break;
          }
        }
      }
    }
    if (get_second()) {
      // если прошла секунда
      time_millis = bitRead(flag_global, POWERON) ? 13 : 3;  // раз в секунду запускаем 13 шагов или 3 если отсутствует напряжение от БП
    }

    switch (time_millis) {
      case 0:
        break;  // тут не должно ни чего быть
      case 13:
#if (GUARDA0)
        Guard();  // принудительная блокировка модуля защиты при напряжении заряда или разряда акб менее 5 Вольт.
#endif
        break;
      case 12:
        tyme.cal_real_tm();  // рассчитать количество всех секунд заряда
        if (tyme.real_tm > time_charge) {
          bitClear(flagsz, CHARGEZ);  //  если время больше установленного завершить работу
          regim_end = out_time;       // закончилось время
        }
        if (add_charge) {
          pam.Time_addcharge = tyme.real_tm;
          pam.Ah_addcharge += aw_ch((int32_t)ina.ampersec);  // расчет ампер/часов
          pam.Wh_addcharge += aw_ch(ina.getsPower());        // расчет ватт/часов
        } else {
          pam.Time_charge = tyme.real_tm;
          pam.Ah_charge += aw_ch((int32_t)ina.ampersec);  // расчет ампер/часов
          pam.Wh_charge += aw_ch(ina.getsPower());        // расчет ватт/часов
        }

        // выполнить если включен таймер завершения заряда
        if (Timezar) {
          if (--Timezar == 0) bitClear(flagsz, CHARGEZ);  // если таймер вышел то завершить заряд
        }
        break;
      case 11:
        switch (typez) {
            // выбор типа заряда
          case REGIM_PRECHARGE:
            //  включен предварительный заряд
            // если напряжение больше напряжения предзаряда то отключить предварительный заряд
            if (ina.volt_aver > pam.Volt_pre_charge) {
              typez = REGIM_CHARGE;  // отключить предварительный заряд - вкл. обычный заряд
              dcdc.setCur_charge(curr_charge_init);
              bitSet(flagsz, OSCILZ);
            } else if (--pre_minut == 0) {
              pre_minut = 60;
              // ток заряда увеличивается и уменьшается раз в минуту в течении 10 минут
              if (bitRead(flagsz, OSCILZ)) {
                dcdc.setCur_charge(dcdc.getCur_charge() + (pam.Current_pre_charge >> 4));      // увеличение тока заряда
                if (dcdc.getCur_charge() >= pam.Current_pre_charge) bitClear(flagsz, OSCILZ);  // когда ток достигнет максимального переключить флаг на уменьшение
              } else {
                dcdc.setCur_charge(dcdc.getCur_charge() - (pam.Current_pre_charge >> 4));         // увеличение тока заряда
                if (dcdc.getCur_charge() <= pam.Current_pre_charge >> 1) bitSet(flagsz, OSCILZ);  // когда ток достигнет минимального переключить флаг на увеличение
              }
            }
            break;

          case REGIM_CHARGE:
            // включен заряд
#if (CURRENT_REDUCTION == 1)
            // начать снижение тока заряда когда напряжение достигнет установленного и ток заряда - максимальный деленный на 4
            if ((ina.volt_aver > pam.Volt_decrCur) and (ina.curr_aver > (cur_max >> 2))) {
              curr_charge_init = map_my(ina.volt_aver, pam.Volt_decrCur, volt_charge_init, cur_max, (cur_max >> 2));
              dcdc.setCur_charge(curr_charge_init);
            }
#endif
            if (bitRead(flagsz, VMAXM)) {
              //если напряжение достигло максимального
              if (va.curr_speed_check()) {
                // если ток снижается менее чем на 10 мА за 10 минут
                regim_end = cur_stop;       // ток перестал снижаться
                bitClear(flagsz, CHARGEZ);  // завершить заряд
              }
            }
          case REGIM_BRANIMIR:
            // проверка критических значений - тока и напряжения
            if (va.offset_critical(bitRead(flagsz, VMAXM))) {
              // если ток начал увеличиваться или уменьшаться напряжение то
              bitClear(pam.MyFlag, ACTIVITI);  // завершить заряд
              regim_end = curr_increased;
            }
            break;
          case REGIM_ADDCHARGE:
            // Дозаряд
            if (bitRead(flagsz, ADD_mm)) {
              if (tsw) tsw--;
              auto vt = difference(ina.volt_aver, v1);
              if (!tsw and (abs(vt) < 10)) {
                // если время завершилось и напряжение стабилизировалось
                if ((dcdc.getCur_charge() == curr_charge_init)) {
                  // если ток максимальный
                  va.add_volt_max = ina.volt_aver;                 // сохранить максимальное напряжение
                  dcdc.setCur_charge(pam.Current_add_charge_min);  // установить минимальный ток
                } else {
                  // если ток минимальный
                  va.add_volt_min = ina.volt_aver;       // сохранить минимальное напряжение
                  dcdc.setCur_charge(curr_charge_init);  // установить максимальный ток
                }
                tsw = 10;  // ожидание 10 сек
              } else v1 = ina.volt_aver;
            } else {
              //если напряжение достигло максимального
              if (va.offset_critical(bitRead(flagsz, VMAXM))) {
                // проверка критических значений - тока и напряжения
                // если ток начал увеличиваться или уменьшаться напряжение то
                bitClear(pam.MyFlag, ACTIVITI);  // завершить заряд
                regim_end = curr_increased;
              }
            }
            break;
          case REGIM_OSCIL:
            {
              // если в настройках включена Осциляция(Качели) то при снижении тока менее curr_min*2 включается Режим осциляции - включение и отключение тока
              auto vt = difference(ina.volt_aver, v1);
              if (abs(vt) < 10) {
                InvBit(flagsz, OSCILZ);  // инвертируем флаг
#if (MCP4725DAC)
                if (BitIsClear(flagsz, OSCILZ)) dac.setVoltage(0);
#else
                dcdc.pause(bitRead(flagsz, OSCILZ));  // отключить заряд, разряд.
#endif
              } else v1 = ina.volt_aver;
              break;
            }
          case REGIM_ASYMMETRIC:
            // ассиметричный режим
            if (period > 0) period--;
            else if (time_pause_assimetric == 0) {
              dcdc.Off();  // отключить заряд
              time_pause_assimetric = Time_pause_assimetric;
            } else {
              if (--time_pause_assimetric == 0) {
                if (bitRead(flagsz, OSCILZ)) {
                  // период заряда - переключиться в разряд
                  period = pam.period_discharge;
                  dcdc.start(DCDC_DISCHARGE);
                  dcdc.begin(pam.Volt_discharge, pam.Current_discharge);  // задает напряжение и ток разряда
                } else {
                  // период разряда - переключиться в заряд
                  period = pam.period_charge;
                  dcdc.start(DCDC_CHARGE);
                  dcdc.begin(volt_charge_init, curr_charge_init);  // задает напряжение и ток заряда
                }
                InvBit(flagsz, OSCILZ);  // переключить флаг режима
              }
            }
            break;
        }
        break;
      case 10:
        // вывод на дисплей 1602
#if (DISPLAYy == 2)
        switch (n_disp) {
          case 0:
            // экран 0
            // Display_print((add_charge ? pam.Ah_addcharge : pam.Ah_charge), tyme.real_tm, Percentage(volt_charge_init, ina.volt_aver, ina.curr_aver, curr_min), add_charge);  // вывод текущих значений напряжения, тока. Вывод Ватт-часов.
            Display_print((add_charge ? pam.Ah_addcharge : pam.Ah_charge), tyme.real_tm, Percentage(curr_min), add_charge);  // вывод текущих значений напряжения, тока. Вывод Ватт-часов.
            break;
          case 1:
            // экран 1
            setCursorx();
            print_mode(MODE);
            setCursory();
            disp.printFromPGM(x[typez - 1]);
            printSimb();  // пробел
            //lcd.print(Percentage(volt_charge_init, ina.volt_aver, ina.curr_aver, curr_min));  // процент заряда Акб
            lcd.print(Percentage(curr_min));  // процент заряда Акб
            lcd.write('%');
            break;
            // *Charge>AddChar  *
            // *Charge 45% 125  *
          case 2:
            // экран 2
            setCursorx();
            PrintVA(0, 0, 0, (add_charge ? pam.Wh_addcharge : pam.Wh_charge));
#if (SENSTEMP1 or SENSTEMP2)
            print_tr();  // температура транзистора или акб
#endif
            lcd.setCursor(DISPLAYx - 1, 0);
            lcd.print(regim_end);  // причина завершения заряда

            setCursory();
#if (VOLTIN == 1)
            PrintVA(adc_v.volt, 0, 0, 0, 1);
#endif
            printCykl();
            printSimb();
            lcd.print(dcdc.getTok());  // вывод значения ШИМ заряда
            if (Timezar) {
              printSimb();
              lcd.print(Timezar);  // выполнить если включен таймер завершения заряда
            }
            break;
            // *58.3Wh 45C 25C  *
            // *24.1V C1 N1     *
          case 3:
            // экран 3
            setCursorx();
            // lcd.print((float)ina.getsPower() / 1000, 2);
            //  lcd.write('W');
            //printSimb();
            PrintVA(ina.volt_aver, ina.curr_aver, 0, 0, 3);
            setCursory();
            lcd.print(va.curr_critical_0);
            printSimb();
            lcd.print(va.volt_critical_0);
            printSimb();
            lcd.print(va.curr_speed);
            printSimb();
            lcd.print(va.schet_curr_speed);
            printSimb();
            // print_memoryFree(); // вывод свободной оперативки
            break;
          case 4:
            // экран 4           // изменение напряжения и тока заряда
            setCursorx();
            PrintVA(ina.voltsec, ina.ampersec, 0, 0, 2);  // текущие напряжение и ток
            lcd.setCursor(DISPLAYx - 2, 0);
            lcd.print(F("OK"));
            if (bitRead(flagsz, KORR)) {
              setCursory();
              Write_x(bitRead(flagsz, KORRVA));       // > or  пробел
              PrintVA(volt_charge_init, 0, 0, 0, 1);  // Напряжение и ток заряда
              Write_x(!bitRead(flagsz, KORRVA));      // > or  пробел
              PrintVA(0, curr_charge_init, 0, 0, 1);  // Напряжение и ток заряда
            } else {
              setCursory();
              PrintVA(ina.volt_aver, ina.curr_aver, 0, 0, 3);
            }
            break;
          default:
            n_disp = 0;
            lcd.clear();  // очистить дисплей
            break;
        }
#endif
// вывод на дисплей 2004
#if (DISPLAYy == 4)
        switch (n_disp) {
          // экран 0
          case 0:
            // Display_print((add_charge ? pam.Ah_addcharge : pam.Ah_charge), (add_charge ? pam.Wh_addcharge : pam.Wh_charge), tyme.real_tm, temp_Q1, Percentage(volt_charge_init, ina.volt_aver, ina.curr_aver, curr_min));
            Display_print((add_charge ? pam.Ah_addcharge : pam.Ah_charge), (add_charge ? pam.Wh_addcharge : pam.Wh_charge), tyme.real_tm, temp_Q1, Percentage(curr_min));
            break;
          case 1:
            setCursorx();
            print_mode(MODE);
            setCursory();
            disp.printFromPGM(x[typez - 1]);
            lcd.setCursor(0, 2);
            lcd.print(regim_end);  // причина завершения заряда
            if (Timezar) {
              printSimb();
              lcd.print(Timezar);  // выполнить если включен таймер завершения заряда
            }
            printCykl();
            lcd.setCursor(0, 3);
            lcd.print((float)ina.getsPower() / 1000, 2);
            lcd.write('W');
            break;
          // изменение напряжения и тока заряда
          case 2:
            setCursorx();
            PrintVA(ina.voltsec, ina.ampersec, 0, 0, 2);  // текущие напряжение и ток
            lcd.setCursor(DISPLAYx - 2, 0);
            lcd.print(F("OK"));
            if (bitRead(flagsz, KORR)) {
              setCursory();
              Write_x(bitRead(flagsz, KORRVA));
              PrintVA(volt_charge_init, 0, 0, 0, 1);  // Напряжение и ток заряда
              Write_x(!bitRead(flagsz, KORRVA));
              PrintVA(0, curr_charge_init, 0, 0, 1);  // Напряжение и ток заряда
            } else {
              setCursory();
              PrintVA(ina.volt_aver, ina.curr_aver, 0, 0, 3);
            }
            break;

          case 3:
            break;
          default:
            n_disp = 0;
            break;
        }
#endif
        if (BitIsClear(flagsz, KORR) and n_disp) {
          if (ns_disp) ns_disp--;
          else {
            n_disp = 0;
            lcd.clear();
          }
        }
        break;
      case 9:
        // когда напряжение достигнет максимального то устанавливается соответствующий флаг
        // если напряджение снизилось менее 200 мВ то флаг снимается
        if (BitIsClear(flagsz, VMAXM) and (ina.volt_aver >= volt_charge_init - 30) and va.curr < 0 /* and ina.curr_aver > curr_min*/) {
          // если флаг макс напр не установлен и напряжение достигло максимального то установить этот флаг
          bitSet(flagsz, VMAXM);
        } else if (bitRead(flagsz, VMAXM) and (ina.volt_aver < volt_charge_init - 200)) {
          // иначе если флаг макс напр установлен и напряжение стало ниже максимального то снять этот флаг
          bitClear(flagsz, VMAXM);
          Timezar = 0;
        }
        break;

      case 8:
        // если ток заряда меньше или равен 0 то отключить заряд и выйти в меню.
        if (ina.ampersec <= (uint8_t)Curr_off_charge and bitRead(flagsz, OSCILZ) and time_pause_assimetric == 0) {
          if (--time_y == 0) {
            //dcdc.Off();
            bitClear(pam.MyFlag, ACTIVITI);
            Speaker(300);
            Delay(300);  // пик
            Speaker(300);
            Delay(300);  // пик
          }
        } else time_y = Curr_off_charge;
        break;

      case 7:
        // выполнить каждые 10 минут
        if (--sec_600 == 0) {
          sec_600 = 600;

          switch (typez) {
            case REGIM_CHARGE:
              // включен заряд
              // включение режима Осчиляция(Качели) при снижении тока заряда до curr_min*3, не выполняется заряд по Бранимиру
              if (bitRead(pam.MyFlag, OSCIL) and (ina.curr_aver < constrain(curr_min << 1, curr_min, (int16_t)pam.Capacity * 5))) typez = REGIM_OSCIL;

              if (bitRead(flagsz, VMAXM)) {
                //если напряжение достигло максимального

                if (ina.curr_aver <= curr_min) {
                  // напряжение достигло максимума, ток минимума
                  regim_end = volt_maxCur_min;
                  bitClear(flagsz, CHARGEZ);  // завершить заряд
                }
              }
              break;
            case REGIM_ADDCHARGE:
              // включен дозаряд,
              if (bitRead(flagsz, ADD_mm) and !Timezar and va.Add_end()) {
                // если разница напряжений при максимальном и минимальном тока ниже 0,5 Вольт то включить таймер
                if (!Timezar) Timezar = Time_AddCarge;  //  установить таймер на 30 минут
              }
              break;
            case REGIM_OSCIL:
              // включен режим Качели
              // если минимальный ток меньше тока завершения заряда и напряжение достигло максимального то завершить заряд
              if (bitRead(flagsz, VMAXM) and (ina.curr_aver <= curr_min)) {
                regim_end = volt_maxCur_min;
                bitClear(flagsz, CHARGEZ);  // завершить заряд
                break;
              }
              break;
#if (BRRANIMIR == 1)
            case REGIM_BRANIMIR:
              // заряд по Бранимиру
              // если напряжение достигло максимального начинаем отсчет времени
              if (bitRead(flagsz, VMAXM)) {
                tyme_branim += 600;
                if (tyme_branim >= 72000) {
                  bitClear(flagsz, CHARGEZ);       // если прошло более 20 часов останавливаем заряд и перемешиваем
                  bitSet(pam.MyFlag, BRANIMBOIL);  // установить флаг перемешивания электролита
                }
                if (ina.curr_aver <= curr_min) {
                  // если ток заряда снизился до установленного то устанавливаем флаг об успешном заряде Бранимира и переходим в дозаряд
                  regim_end = volt_maxCur_min;  //  напряжение достигло максимума ток минимума;
                  bitSet(pam.MyFlag, BRANIM);   // установить флаг успешного завершения заряда по Бранимиру
                  bitClear(flagsz, CHARGEZ);    // отключить заряд
                }
              }
              break;
#endif
            case REGIM_ASYMMETRIC:
              // условия завершения работы
              // если минимальный ток меньше тока завершения заряда и напряжение достигло максимального то завершить заряд
              if (bitRead(flagsz, VMAXM) and (ina.ampersec <= curr_min)) {
                regim_end = volt_maxCur_min;
                bitClear(flagsz, CHARGEZ);  // завершить заряд
              }
              break;
          }
          Saved();  // сохранить настройки
                    // ---выполнить раз в 10 минут.
        }

        break;
      case 6:
        // защита от повышенного тока и напряжения
        if (ina.ampersec > curr_crash or (ina.voltsec > volt_crash and ina.ampersec > 20)) {
          dcdc.Off();    // отключить ШИМ
          Speaker(300);  // функция звукового сигнала (время в миллисекундах)
#if (TIME_LIGHT)
          disp.Light_high();  // включение подсветки
#endif
          dcdc.start(DCDC_CHARGE);  // перезапустить dcdc
        }
        break;
      case 3:
        if (BitIsClear(flag_global, POWERON)) {
          // если питание от БП не приходит
#if (TIME_LIGHT)
          disp.Light_power();
#endif
          lcd.clear();
          lcd.print(F(txt4));  // "Power "
          print_mode(ERROR);   // "error"
#if (VOLTIN == 1)
          PrintVA(adc_v.volt, 0, 0, 0, 1);
#endif
          setCursory();
          PrintVA(ina.voltsec, ina.ampersec, 0, 0, 2);
        }
        break;
      case 2:
#if (CORRECTCUR and SENSTEMP2)
        Control_trAkb();  // контроль температуры Акб
#endif
        break;
      case 1:
#if (LOGGER)
#if (LOGGER == 4)
        Sout.create_advanced((add_charge ? pam.Ah_addcharge : pam.Ah_charge), (uint16_t)ina.volt_aver, ina.curr_aver, tyme.real_tm);
#else
        Sout.create((add_charge ? pam.Ah_addcharge : pam.Ah_charge), (uint16_t)ina.volt_aver, ina.curr_aver);
#endif
#endif
#if (TIME_LIGHT)
        disp.Light_low();  // отключение подсветки через 3 минуты, если разрешено отключение
#endif
        break;
    }
    if (time_millis > 0) time_millis--;
  }
  // цикл заряда
  dcdc.Off();  // отключить заряд, разряд.
#if (GUARDA0)
  gio::low(PROTECT_OPEN);
#endif
  Saved();  // сохранить настройки
}
