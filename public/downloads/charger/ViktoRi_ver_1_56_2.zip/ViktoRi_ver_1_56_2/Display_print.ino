
void printSimb(void) {
  lcd.write(' ');
}

// вывод на дисплей во float - напряжение, ток, ампер-часы, ватт-часы, кол. разрядов после запятой.
void PrintVA(uint16_t volt = 0, int16_t current = 0, int32_t Ah = 0, int32_t Wh = 0, uint8_t x = 2) {
  if (volt) {
    lcd.print(((float)volt / 1000), x);  // напряжение
    lcd.print(F("V "));
  }
  if (current) {
    lcd.print(((float)current / 1000), x);  // ток
    lcd.print(F("A "));
  }
  if (Ah) {
    lcd.print(((float)Ah / 1000000), ((Ah < 1000000) ? 2 : 1));  // ампер*часы
    lcd.print(F("Ah "));
  }
  if (Wh) {
    lcd.print(((float)Wh / 1000000), ((Wh < 1000000) ? 2 : 1));  // ватт*часы
    lcd.print(F("Wh "));
  }
}

void pr_tm(uint16_t tm) {
  if (tm < 10) lcd.write('0');
  lcd.print(tm);
}

// функция расчета текущего времени и вывод на дисплей
#if defined(__LGT8FX8P__)
void Print_time(uint32_t time_real, uint8_t x, uint8_t y) {
  lcd.setCursor(x, y);
  // остаток от деления DA = DA/DY, DY = DA%DY
  DSC_MOD(time_real, (uint16_t)3600);
  pr_tm(DA_get_int());  // часы
  lcd.write(':');
  // остаток от деления DA = DA/DY, DY = DA%DY
  DSC_MOD((uint32_t)DY_get(), (uint16_t)60);
  pr_tm(DA_get_int());  // минуты
  lcd.write(':');
  pr_tm(DY_get());  // секунды
}
#else
void Print_time(uint32_t time_real, uint8_t x, uint8_t y) {
  lcd.setCursor(x, y);
  pr_tm((uint16_t)(time_real / 3600ul));  // часы
  lcd.write(':');
  uint32_t t = (time_real % 3600ul);
  pr_tm((uint16_t)(t / 60ul));  // минуты
  lcd.write(':');
  pr_tm((uint16_t)(t % 60ul));  // секунды
}
#endif


void setCursorx(void) {
  lcd.setCursor(0, 0);
}
void setCursory(void) {
  lcd.setCursor(0, 1);
}

#if (SENSTEMP1 or SENSTEMP2)

// печать температуры транзистора или акб
void print_tr(void) {
#if (SENSTEMP1 and SENSTEMP2)
  // если подключены 2 датчика температуры
  static uint8_t _tmr = 0;
  static char _tmp = 'c';  // c
  if (++_tmr >= 3) {
    _tmr = 0;
    _tmp = (_tmp == 'c') ? 'C' : 'c';
    lcd.print((_tmp == 'C') ? temp_Q1 : temp_akb);
    lcd.write(_tmp);
    ClearStr(2);
  }
#endif

#if (SENSTEMP1 > 0 and SENSTEMP2 == 0)
  // если подключен только датчик транзистора
  lcd.print(temp_Q1);
#if (INTERFACE == 0)
  lcd.print(F("C "));  // если русский интерфейс
#else
  lcd.write(223);  // знак градуса // если английский интерфейс
#endif
#endif

#if (SENSTEMP1 == 0 and SENSTEMP2 > 0)
  // если подключен только датчик акб
  lcd.print(temp_akb);
  lcd.print(F("С "));
#endif
}

#endif

bool akbzn = true;
// функция вывод на дисплей
#if ((DISPLAYx == 16 and DISPLAYy == 2) or (DISPLAYx == 20 and DISPLAYy == 2))
void Display_print(int32_t Ah, uint32_t time_real, uint8_t prc, bool add) {
  if ((VOLTIN == 1) and BitIsClear(flag_global, POWERHIGH)) {
#if (TIME_LIGHT)
    disp.Light_high();  // включение подсветки
#endif
    lcd.clear();
    lcd.print(F(txt4));  // "Power "
    PrintVA(adc_v.volt, 0, 0, 0, 1);
    print_mode(ERROR);  // error
    Speaker(500);       // функция звукового сигнала (время в миллисекундах)
    Delay(3000);        // ждать 3 секунды
  } else {
    // 0 строка
    setCursorx();
    if (ina.voltsec < 10000) lcd.print(0);
    PrintVA(ina.voltsec);  // вывод напряжения
    PrintVA(0, 0, Ah, 0);  // вывод напряжения и Ач
    lcd.setCursor(DISPLAYx - 1, 0);
    lcd.print((char)pgm_read_byte(&regimr[(add ? (uint8_t)ADDCHARGE : pam.Mode)]));  // вывод режима работы
    // 1 строка
    setCursory();
    PrintVA(0, ((pam.Mode == DISCHARGE) ? abs(ina.ampersec) : ina.ampersec), 0, 0, ((abs(ina.ampersec) < 10000) ? 3 : 2));
    Print_time(time_real, 7, 1);
    lcd.setCursor(DISPLAYx - 1, 1);
    lcd.write((akbzn ? map_my(prc, 0, 100, 0, 6) : ((pam.Mode == DISCHARGE) ? ' ' : 7)));  // знак акб:  пробел - значек заряда
    akbzn = !akbzn;
  }
}
// *14.81V 0.01Ah Ch*  0
// *10.55A 01:01:01 *  1

// 1 - используется диспплей 20*4
#elif (DISPLAYx == 20 and DISPLAYy == 4)
// функция вывод на дисплей 20*4
void Display_print(int32_t Ah, int32_t Wh, uint32_t time_real, int8_t tr, uint8_t prc) {
  if ((VOLTIN == 1) and BitIsClear(flag_global, POWERHIGH)) {
#if (TIME_LIGHT)
    disp.Light_high();  // включение подсветки
#endif
    lcd.clear();
    lcd.print(F(txt4));  // "Power "
    PrintVA(adc_v.volt);
    print_mode(ERROR);  // error
    Speaker(500);  // функция звукового сигнала (время в миллисекундах)
    Delay(3000);   // ждать 3 секунды
  } else {
    // 0 строка
    setCursorx();
    print_mode(TYPE_AKB);  // вывод типа акб                          // тип Акб
    printSimb();           // пробел
    print_Capacity();
    print_mode(VOLTAGE);  // 12.6V
    // 1 строка
    Print_time(time_real, 0, 1);  // время
    printSimb();                  // пробел
    print_mode(MODE);             // режим работы
    // 2 строка
    lcd.setCursor(0, 2);
    PrintVA(0, 0, Ah, Wh);  // ампер-часы ватт-часы
    lcd.print(prc);         // процент заряда Акб
    lcd.print(F("%  "));
    // 3 строка
    lcd.setCursor(0, 3);
    if (ina.voltsec < 10000) lcd.print(0);
    PrintVA(ina.voltsec);                                                                                                   // вывести Вольт
    PrintVA(0, ((pam.Mode == DISCHARGE) ? abs(ina.ampersec) : ina.ampersec), 0, 0, ((abs(ina.ampersec) < 10000) ? 3 : 2));  // вывести Ампер
#if (SENSTEMP1 or SENSTEMP2)
    print_tr();                                                                                                             // температура транзистора или акб
#endif
    lcd.setCursor(DISPLAYx - 1, 3);
    lcd.write((akbzn ? map_my(prc, 0, 100, 0, 6) : ((pam.Mode == DISCHARGE) ? 32 : 7)));  // знак акб - значек заряда -  пробел
    akbzn = !akbzn;
  }
}
// *PB Ca/Ca 60Ah 12.6V *  0
// *01:01:01 Zaryad>Doza*  1
// *60.56Ah 220.56Wh 56%*  2
// *14.81V 6.555A 35C  ~*  3


// 1 - используется диспплей 16*4
#elif (DISPLAYx == 16 and DISPLAYy == 4)
// функция вывод на дисплей 20*4
void Display_print(int32_t Ah, int32_t Wh, uint32_t time_real, int8_t tr, uint8_t prc) {
  if ((VOLTIN == 1) and BitIsClear(flag_global, POWERHIGH)) {
#if (TIME_LIGHT)
    disp.Light_high();  // включение подсветки
#endif
    lcd.clear();
    lcd.print(F(txt4));  // "Power "
    PrintVA(adc_v.volt);
    print_mode(ERROR);  // error

    Speaker(500);  // функция звукового сигнала (время в миллисекундах)
    Delay(3000);   // ждать 3 секунды
  } else {
    // 0 строка
    setCursorx();
    print_Capacity();
    lcd.print(((float)bat.Volt(volt_cell_charge) / 100), 1);  // напряжение
    lcd.print(F("V "));                                       // V
    print_mode(MODE);                                         // режим работы
    // 1 строка
    Print_time(time_real, 0, 1);  // время
    printSimb();                  // пробел
    lcd.print(prc);               // процент заряда Акб
    lcd.print(F("% "));
#if (SENSTEMP1 or SENSTEMP2)
    print_tr();  // температура транзистора или акб
#endif
    // 2 строка
    lcd.setCursor(0, 2);
    PrintVA(0, 0, Ah, 0);  // ампер-часы ватт-часы
    PrintVA(0, 0, 0, Wh);  // ампер-часы ватт-часы
    // 3 строка
    lcd.setCursor(0, 3);
    if (ina.voltsec < 10000) lcd.print(0);
    PrintVA(ina.voltsec);                                                                                           // вывести Вольт
    PrintVA(0, ((pam.Mode == 4) ? abs(ina.ampersec) : ina.ampersec), 0, 0, ((abs(ina.ampersec) < 10000) ? 3 : 2));  // вывести Ампер
    lcd.setCursor(DISPLAYx - 1, 3);
    lcd.write((akbzn ? map_my(prc, 0, 100, 0, 6) : ((pam.Mode == DISCHARGE) ? ' ' : 7)));  // знак акб - значек заряда -  пробел
    akbzn = !akbzn;
  }
}
// *60Ah 12.6V Zarya*
// *01:01:01 52% 35C*
// *60.56Ah 220.56Wh*
// *14.81V 6.555A  ~*

#endif

// вывести на дисплей - вкл/откл
void PrintOnOff(bool i) {
  lcd.print((i ? F(txt13) : F(txt14)));  // вкл  / откл
}

// вывод на дисплей > или пробел
void Write_x(bool x) {
  lcd.write((x ? '>' : ' '));  // > or  пробел
}

// вывод на дисплей: 0-режим работы, 1-тип акб
void print_mode(uint8_t i) {
  switch (i) {
    case 0: disp.printFromPGM((int)(&modeTxt[pam.Mode])); break;
    case 1: disp.printFromPGM((int)(&typeAkb[pam.typeAkb])); break;
    case 2: lcd.print(F(txt21)); break;                    // "error"
    case 3: disp.printFromPGM((int)(&menuTxt[5])); break;  // "Settings"
    case 4:
      lcd.print(((float)bat.Volt(volt_cell) / 1000), 1);  // напряжение
      lcd.write('V');
      break;
  }
}

void print_Capacity(void) {
  lcd.print(pam.Capacity);
  lcd.print(F("Ah "));
}

void printCykl(void) {
  lcd.write('C');
  lcd.print(pam.Round);
}

// Функция вывода напряжения акб и количество банок
void Vout(void) {
  print_mode(VOLTAGE);  // 12.6V
  lcd.write('(');
  lcd.print(pam.Voltage);
  lcd.write(')');
  ClearStr(4);  // очистить поле
  lcd.setCursor(3, 0);
}

// функция очистки строки дисплея (i символов)
void ClearStr(uint8_t i) {
  while (i--) printSimb();  // очистить поле
}
/*
void print_otval_akb(void) {  
  setCursorx();
  lcd.print(F("Akb"));
  lcd.print(F(txt21));
  PrintVA()
}
*/
/*
// вывод свободной оперативки
void print_memoryFree(void) {
  lcd.setCursor(0, 0);
  lcd.print(memoryFree());
  lcd.write(' ');
}
*/
/*
// Переменные, создаваемые процессом сборки,
// когда компилируется скетч
extern int __bss_end;
extern void *__brkval;

// Функция, возвращающая количество свободного ОЗУ (RAM)
int memoryFree(void) {
  int freeValue;
  if ((int)__brkval == 0)
    freeValue = ((int)&freeValue) - ((int)&__bss_end);
  else
    freeValue = ((int)&freeValue) - ((int)__brkval);
  return freeValue;
}
*/
