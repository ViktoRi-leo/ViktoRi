#include <Arduino.h>
#include <ADCaverage.h>

// параметры для замера напряжения 1
#define DIV_R1 22000  // делитель напряжения R1 Ом
#define DIV_R2 1000   // делитель напряжения R2 Ом
VoltRead volt1(ADC_A7, DIV_R1, DIV_R2);
// параметры для замера напряжения 2
#define DIV_R3 30000  // делитель напряжения R1 Ом
#define DIV_R4 1200   // делитель напряжения R2 Ом
VoltRead volt2(ADC_A3, DIV_R3, DIV_R4);

// параметры для датчика температуры NTC
#define NTC_B1 3435    // B термистора - берется из характеристик термистора
#define NTC_R1 10000   // Ом - сопротивление термистора при 25 градусах.
#define NTC_RS2 10000  // Ом - сопротивление подтягивающего резистора (тем точнее тем лучше)
#define NTC_TEMP 25    // градусы - базовая температура термистора. Подкорректируй если замеряет не правильно.
// параметры для датчика температуры NTC
NTCRead ntc1(ADC_A5, NTC_R1, NTC_RS2, NTC_B1, NTC_TEMP);

void setup() {
    Serial.begin(9600);
    ADC_init(DIVIDER, ADC_1V1);  // инициализация АЦП
}

uint32_t start = millis();

void loop() {
    volt1.sample();  // считываем данные с АЦП с накоплением и усреднением
    volt2.sample();  // считываем данные с АЦП с накоплением и усреднением
    ntc1.sample();   // считываем данные с АЦП с накоплением и усреднением

    if (millis() - start >= 1000) {
        start = millis();

        volt1.compute();  // рассчитать среднее напряжение БП  20 мкс
        volt2.compute();  // рассчитать среднее напряжение БП
        ntc1.compute();   // рассчитать температуру термистора 300 мкс

        Serial.println(volt1.volt);
        Serial.println(volt2.volt);
        Serial.println(ntc1.temp);
    }
}
