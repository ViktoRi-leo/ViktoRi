#include <LGT8_uDSC.h>
volatile uint32_t data_long;  // переменная для результата операций
volatile uint16_t data_int;   // переменная для результата операций
uint16_t x;
uint16_t y;
uint32_t t;  // переменная для замера времени

void setup() {
  Serial.begin(115200);
  uDSC_ON();  // Включить ускоритель вычислений uDSC
}

void loop() {
  x = 256;
  y = 468;
  // умножение dx * dy = 119808
  data_long = uDSC_work_get_long(x, y, mult_dxdy);
  Serial.println(data_long);

  x = 25;
  y = 468;
  // умножение dx * dy = 11700
  data_int = uDSC_work_get_int(x, y, mult_dxdy);
  Serial.println(data_int);
  // умножение dx * dy

  x = 7500;
  y = 36;
  // умножение dx * dy = 270000
  uDSC_work(x, y, mult_dxdy);
  data_long = DA_Read_long();  // считать результат 32 бит
  Serial.println(data_long);
  x = 750;
  y = 36;
  // умножение dx * dy = 27000
  uDSC_work(x, y, mult_dxdy);
  data_int = DA_Read_int();  // считать результат 16 бит
  Serial.println(data_int);

  x = 62230;
  y = 35;
  // деление dx * dy = 1778
  data_int = uDSC_divided_get_int(x, y, divided);
  Serial.print("divided int: ");
  Serial.println(data_int);

  uint32_t z = 62230325;
  y = 1355;
  // деление dx * dy = 45926
  data_long = uDSC_divided_get_long(z, y, divided);
  Serial.print("divided long: ");
  Serial.println(data_long);

  x = 53566;
  y = 35236;
  // сложение dx + dy = 88802
  data_long = uDSC_work_get_long(x, y, summ_dxdy);
  Serial.println(data_long);
  x = 5356;
  y = 35236;
  // сложение dx + dy = 40592
  data_int = uDSC_work_get_int(x, y, summ_dxdy);
  Serial.println(data_int);

  x = 5356;
  y = 35236;
  // сложение dx + dy
  uDSC_work(x, y, summ_dxdy);
  data_long = DA_Read_long();  // считать результат 32 бит
  data_int = DA_Read_int();    // считать результат 16 бит

  // сумма входных данных с накоплением результата  DA = DA + DY
  uDSC_op(reset_da);  // сброс DA = 0
  t = micros();
  for (uint16_t i = 1; i < 1000; i++) {
    uDSCdy(i, summ_dy);  // накопление DA = DA + DY
  }
  t = micros() - t;
  data_long = DA_Read_long();  // считать результат 32 бит
  Serial.print("Summa 1000: ");
  Serial.print(data_long);
  Serial.print(" time: ");
  Serial.println(t);

  // тест множества делений
  x = 65020;
  t = micros();
  for (uint16_t i = 1; i < 1000; i++) {
    uDSC_divided_long(x, i, divided);
  }
  t = micros() - t;
  data_int = DA_Read_int();  // считать результат 16 бит
  Serial.print("divided 1000: ");
  Serial.print(data_int);
  Serial.print(" time: ");
  Serial.println(t);

  // тест множества делений c выводом промежуточных результатов в переменную
  t = micros();
  for (uint16_t i = 1; i < 1000; i++) {
    data_int = uDSC_divided_get_int(x, i, divided);
  }
  t = micros() - t;
  Serial.print("divided read 1000: ");
  Serial.print(data_int);
  Serial.print(" time: ");
  Serial.println(t);

  Serial.println("..");
  delay(10000);
}
