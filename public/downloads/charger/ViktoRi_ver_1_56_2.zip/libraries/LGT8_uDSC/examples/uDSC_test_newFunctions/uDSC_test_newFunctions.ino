#include <Arduino.h>
#include <LGT8_uDSC.h>

void setup() {
  Serial.begin(115200);

  pinMode(A0, INPUT);
  pinMode(A1, INPUT);

  // Включить ускоритель вычислений uDSC
  uDSC_ON();

}

uint16_t volt = 1556;
uint16_t Vref = 23;
uint32_t res;

int16_t volt_int = -1556;
int16_t Vref_int = -23;
int32_t res_int;

void loop() {
  volt += analogRead(A0);
  Vref += analogRead(A1);

  // сложение двух чисел через uDSC
  res = DSC_ADD_get(volt, Vref);
  Serial.print("ADD ");
  Serial.print(volt);
  Serial.print(" + ");
  Serial.print(Vref);
  Serial.print(" = ");
  Serial.println(res);

  volt -= analogRead(A0);
  Vref -= analogRead(A1);

  // вычитание двух чисел через uDSC
  res = DSC_SUB_get(volt, Vref);
  Serial.print("SUB ");
  Serial.print(volt);
  Serial.print(" - ");
  Serial.print(Vref);
  Serial.print(" = ");
  Serial.println(res);

  volt += analogRead(A0);
  Vref += analogRead(A1);

  // умножение двух чисел через uDSC
  res = DSC_MUL_get(volt, Vref);
  Serial.print("MULT ");
  Serial.print(volt);
  Serial.print(" * ");
  Serial.print(Vref);
  Serial.print(" = ");
  Serial.println(res);

  volt -= analogRead(A0);
  Vref -= analogRead(A1);

  // деление двух чисел через uDSC
  res = DSC_DIV_get((uint32_t)volt, Vref);
  Serial.print("DIV ");
  Serial.print(volt);
  Serial.print(" / ");
  Serial.print(Vref);
  Serial.print(" = ");
  Serial.println(res);

  volt += analogRead(A0);
  Vref += analogRead(A1);

  // остаток от деления двух чисел через uDSC
  res = DSC_MOD_get((uint32_t)volt, Vref);
  Serial.print("MOD ");
  Serial.print(volt);
  Serial.print(" % ");
  Serial.print(Vref);
  Serial.print(" = ");
  Serial.println(res);

  Serial.println("INT");

  volt_int += analogRead(A0);
  Vref_int += analogRead(A1);

  // сложение двух чисел через uDSC
  res_int = DSC_ADD_get(volt_int, Vref_int);
  Serial.print("ADD ");
  Serial.print(volt_int);
  Serial.print(" + ");
  Serial.print(Vref_int);
  Serial.print(" = ");
  Serial.println(res_int);

  volt_int -= analogRead(A0);
  Vref_int -= analogRead(A1);

  // вычитание двух чисел через uDSC
  res_int = DSC_SUB_get(volt_int, Vref_int);
  Serial.print("SUB ");
  Serial.print(volt_int);
  Serial.print(" - ");
  Serial.print(Vref_int);
  Serial.print(" = ");
  Serial.println(res_int);

  volt_int += analogRead(A0);
  Vref_int += analogRead(A1);

  // умножение двух чисел через uDSC
  res_int = DSC_MUL_get(volt_int, Vref_int);
  Serial.print("MULT ");
  Serial.print(volt_int);
  Serial.print(" * ");
  Serial.print(Vref_int);
  Serial.print(" = ");
  Serial.println(res_int);

  volt_int -= analogRead(A0);
  Vref_int -= analogRead(A1);

  // деление двух чисел через uDSC
  res_int = DSC_DIV_get((int32_t)volt_int, Vref_int);
  Serial.print("DIV ");
  Serial.print(volt_int);
  Serial.print(" / ");
  Serial.print(Vref_int);
  Serial.print(" = ");
  Serial.println(res_int);

  volt_int += analogRead(A0);
  Vref_int += analogRead(A1);

  // остаток от деления двух чисел через uDSC
  res_int = DSC_MOD_get((int32_t)volt_int, Vref_int);
  Serial.print("MOD ");
  Serial.print(volt_int);
  Serial.print(" % ");
  Serial.print(Vref_int);
  Serial.print(" = ");
  Serial.println(res_int);
  
  Serial.println("***");

  delay(5000);
  
}
