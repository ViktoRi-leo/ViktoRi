#include <LGT8_uDSC.h>
/*
Реализация функции map на ускорителе uDSC/

Функция  map
int16_t map(long x, int16_t in_min, int16_t in_max, int16_t out_min, int16_t out_max) {  
  return (int16_t)((x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min);
}
*/
/*
int16_t map_uDSC(int16_t x, int16_t in_min, int16_t in_max, int16_t out_min, int16_t out_max) {
  // if (x >= in_max) return out_max;  // ограничение выхода
  // if (x <= in_min) return out_min;  // ограничение выхода
  x = uDSC_work_get_intt(x, in_min, sub_dxdy);                // (x - in_min)
  out_max = uDSC_work_get_intt(out_max, out_min, sub_dxdy);   // (out_max - out_min)
  int32_t diff = uDSC_work_get_longt(x, out_max, mult_dxdy);  // (x - in_min) * (out_max - out_min)
  in_max = uDSC_work_get_intt(in_max, in_min, sub_dxdy);      // (in_max - in_min)
  uDSC_divided_longt(diff, in_max, divided);                  // diff / in_max
  return uDSCdy_get_intt(out_min, summ_dy);                   //  + out_min
}
*/
/*
int16_t map_uDSC(int16_t x, int16_t in_min, int16_t in_max, int16_t out_min, int16_t out_max) {
  // if (x >= in_max) return out_max;  // ограничение выхода
  // if (x <= in_min) return out_min;  // ограничение выхода
  int32_t diff = uDSC_work_get_longt((x - in_min), (out_max - out_min), mult_dxdy);  // (x - in_min) * (out_max - out_min)
  uDSC_divided_longt(diff, (in_max - in_min), divided);                              // diff / in_max
  return uDSCdy_get_intt(out_min, summ_dy);                                          //  + out_min
}
*/

int16_t map_uDSC(int16_t x, int16_t in_min, int16_t in_max, int16_t out_min, int16_t out_max) {
  if (x >= in_max) return out_max;                               // ограничение выхода
  if (x <= in_min) return out_min;                               // ограничение выхода
  uDSC_work_intt((x - in_min), (out_max - out_min), mult_dxdy);  // DA = (x - in_min) * (out_max - out_min)
  uDSC_divided_dy((in_max - in_min), divided);                   // DA /= in_max
  return uDSCdy_get_intt(out_min, summ_dy);                      // DA += out_min
}

void setup() {
  uDSC_ON();
  Serial.begin(115200);
  Serial.println("map function uDSC");
}

volatile int16_t x = -10;
volatile int16_t y;
volatile int16_t z;
volatile uint32_t t;

void loop() {
  Serial.print("x = ");
  Serial.println(x);

  t = micros();
  z = map(x, 10, 100, 1000, 10000);

  t = micros() - t;
  Serial.print("map = ");
  Serial.print(z);
  Serial.print(" time: ");
  Serial.println(t);

  t = micros();
  y = map_uDSC(x, 10, 100, 1000, 10000);

  t = micros() - t;
  Serial.print("map_uDSC = ");
  Serial.print(y);
  Serial.print(" time: ");
  Serial.println(t);
  Serial.println("...");

  x += 1;

  delay(1000);
}
