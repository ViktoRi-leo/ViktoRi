/*
Функции работы с ускорителем вычислений uDSC встроенный в LGT8F328p.
Ускоритель работает с тремя регистрами. Регистры работают как на запись так и на чтение:
1) DA - регистр 32-бит, в него сохраняются результаты вычислений;
2) DX - регистр 16-бит, первый операнд
3) DY - регистр 16-бит, второй операнд

Инструкции работы uDSC:
- умножение............................. DA = DX * DY
- сложение.............................. DA = DX + DY
- вычитание ............................ DA = DX - DY
- умножение со сдвигом.................. DA = (DX * DY) » 1
- умножение с накоплением............... DA = DA + DX * DY
- умножение с уменьшением............... DA = DA - DX * DY
- деление............................... DA = DA/DY
- остаток от деления.................... DA = DA/DY, DY = DA%DY
- накопление............................ DA = DA + DY
- уменьшение............................ DA = DA - DY
- возведение в квадрат.................. DA = DY^2
- возведение в квадрат.................. DA = DX^2
- сброс................................. DA = 0
- изменяет знак числа на противоположный DA = NEG(DA)
- убирает знак числа.................... DA = ABS(DA)
- сдвиг на несколько значений (1 - 15).. DA >> shift
- сдвиг на несколько значений (1 - 15).. DA << shift
- умножение с накоплением с сдвигом .... DA = (DA + DX * DY) >> 1
- умножение с уменьшением с сдвигом .... DA = (DA - DX * DY) >> 1  - Апроксимация
- присвоение............................ DA = DY
- присвоение с инверсией................ DA = -DY
- умножение с инверсией................. DA = -DX * DY
- умножение с инверсией со сдвигом ..... DA = (-DX * DY) >> 1
*/

#ifndef uDSC_h
#define uDSC_h
#include <Arduino.h>

// Включить ускоритель вычислений uDSC
void uDSC_ON(void);

// операции для новых функций
enum DSCop: uint8_t {
  mul = 0x44,            // умножение  DA = DX * DY
  add = 0x5,              // сложение   DA = DX + DY
  sub = 0x1,              // вычитание  DA = DX - DY
  divd = 0xB0,            // деление DA = DA/DY
  mod = 0xB1,             // остаток от деления DA = DA/DY, DY = DA%DY
  inc = 0x17,             // инкремент DA += DY
  dec = 0x13,             // декремент DA -= DY
};

/********************* НОВЫЕ ФУНКЦИИ *********************/

// выгрузить результат вычислений из регистра DA (32-битное число).
uint32_t DA_get_long(void);
int32_t DA_get_longt(void);

// выгрузить результат вычислений из регистра DA (16-битное число).
uint16_t DA_get_int(void);
int16_t DA_get_intt(void);

// выгрузить результат вычислений из регистра DY (16-битное число).
uint16_t DY_get(void);
int16_t DY_get_int(void);

// выгрузить результат вычислений из регистра DX (16-битное число).
uint16_t DX_get(void);
int16_t DX_get_int(void);


// записать число 32-бит в регистр DA
#define DA_write_long(da) __asm__ __volatile__ ("out 0x38, %A[dsda];" "\n\t""out 0x39, %C[dsda];" "\n\t":: [dsda] "r"(da))

// записать число 16-бит в регистр DA
#define DA_write_int(da) __asm__ __volatile__ ("out 0x38, %A[dsda];" "\n\t":: [dsda] "r"(da))

// записать число 16-бит в регистр DX
#define DX_write(dx) __asm__ __volatile__ ("out 0x10, %[dsdx];" "\n\t":: [dsdx] "r"(dx))

// записать число 16-бит в регистр DY
#define DY_write(dy) __asm__ __volatile__ ("out 0x11, %[dsdy];" "\n\t":: [dsdy] "r"(dy))

// выполнение любой операции uDSC
#define uDSC_op(operation) __asm__ __volatile__ ("out 0x01, %[opc];" "\n\t":: [opc] "r"(operation))

// умножение целых чисел без знака (unsigned integer). Запись результата в DA.
void DSC_MUL(uint16_t dx, uint16_t dy);
// умножение целых чисел со знаком (signed integer). Запись результата в DA.
void DSC_MUL(int16_t dx, int16_t dy);
void DSC_MUL(uint16_t dx, int16_t dy);
void DSC_MUL(int16_t dx, uint16_t dy);

// умножение целых чисел без знака (unsigned integer). Запись результата в DA. Возврат результата 32-битного числа из DA.
uint32_t DSC_MUL_get(uint16_t dx, uint16_t dy);
// умножение целых чисел со знаком (signed integer). Запись результата в DA. Возврат результата 32-битного числа из DA.
int32_t DSC_MUL_get(int16_t dx, int16_t dy);
int32_t DSC_MUL_get(uint16_t dx, int16_t dy);
int32_t DSC_MUL_get(int16_t dx, uint16_t dy);

// сложение целых чисел без знака (unsigned integer). Запись результата в DA.
void DSC_ADD(uint16_t dx, uint16_t dy);
// сложение целых чисел со знаком (unsigned integer). Запись результата в DA.
void DSC_ADD(int16_t dx, int16_t dy);
void DSC_ADD(uint16_t dx, int16_t dy);
void DSC_ADD(int16_t dx, uint16_t dy);
// сложение целых чисел без знака (unsigned integer). Запись результата в DA.
void DSC_ADD(uint32_t da, uint16_t dy);
// сложение целых чисел со знаком (signed integer). Запись результата в DA.
void DSC_ADD(int32_t da, int16_t dy);
void DSC_ADD(uint32_t da, int16_t dy);
void DSC_ADD(int32_t da, uint16_t dy);

// сложение целых чисел без знака (unsigned integer). Запись результата в DA. Возврат результата 32-битного числа из DA.
uint32_t DSC_ADD_get(uint16_t dx, uint16_t dy);
// сложение целых чисел со знаком (signed integer). Запись результата в DA. Возврат результата 32-битного числа из DA.
int32_t DSC_ADD_get(int16_t dx, int16_t dy);
int32_t DSC_ADD_get(uint16_t dx, int16_t dy);
int32_t DSC_ADD_get(int16_t dx, uint16_t dy);
// сложение целых чисел без знака (unsigned integer). Запись результата в DA. Возврат результата 32-битного числа из DA.
uint32_t DSC_ADD_get(uint32_t da, uint16_t dy);
// сложение целых чисел со знаком (signed integer). Запись результата в DA. Возврат результата 32-битного числа из DA.
int32_t DSC_ADD_get(int32_t da, int16_t dy);
int32_t DSC_ADD_get(uint32_t da, int16_t dy);
int32_t DSC_ADD_get(int32_t da, uint16_t dy);

// вычитание целых чисел без знака (unsigned integer). Запись результата в DA. 
void DSC_SUB(uint16_t dx, uint16_t dy);
// вычитание целых чисел со знаком (signed integer). Запись результата в DA. 
void DSC_SUB(int16_t dx, int16_t dy);
void DSC_SUB(uint16_t dx, int16_t dy);
void DSC_SUB(int16_t dx, uint16_t dy);
// вычитание целых чисел без знака (unsigned integer). Запись результата в DA. 
void DSC_SUB(uint32_t da, uint16_t dy);
// вычитание целых чисел со знаком (signed integer). Запись результата в DA. 
void DSC_SUB(int32_t da, int16_t dy);
void DSC_SUB(uint32_t da, int16_t dy);
void DSC_SUB(int32_t da, uint16_t dy);

// вычитание целых чисел без знака (unsigned integer). Запись результата в DA. Возврат результата 32-битного числа из DA.
uint32_t DSC_SUB_get(uint16_t dx, uint16_t dy);
// вычитание целых чисел со знаком (signed integer). Запись результата в DA. Возврат результата 32-битного числа из DA.
int32_t DSC_SUB_get(int16_t dx, int16_t dy);
int32_t DSC_SUB_get(uint16_t dx, int16_t dy);
int32_t DSC_SUB_get(int16_t dx, uint16_t dy);
// вычитание целых чисел без знака (unsigned integer). Запись результата в DA. Возврат результата 32-битного числа из DA.
uint32_t DSC_SUB_get(uint32_t da, uint16_t dy);
// вычитание целых чисел со знаком (signed integer). Запись результата в DA. Возврат результата 32-битного числа из DA.
int32_t DSC_SUB_get(int32_t da, int16_t dy);
int32_t DSC_SUB_get(uint32_t da, int16_t dy);
int32_t DSC_SUB_get(int32_t da, uint16_t dy);

// деление целых чисел без знака (unsigned integer). Запись результата в DA.
void DSC_DIV(uint32_t da, uint16_t dy);
// деление целых чисел со знаком (signed integer). Запись результата в DA.
void DSC_DIV(int32_t da, int16_t dy);
void DSC_DIV(uint32_t da, int16_t dy);
void DSC_DIV(int32_t da, uint16_t dy);

// деление целых чисел без знака (unsigned integer). Запись результата в DA. Возврат результата 32-битного числа из DA.
uint32_t DSC_DIV_get(uint32_t da, uint16_t dy);
// деление целых чисел со знаком (signed integer). Запись результата в DA. Возврат результата 32-битного числа из DA.
int32_t DSC_DIV_get(int32_t da, int16_t dy);
int32_t DSC_DIV_get(uint32_t da, int16_t dy);
int32_t DSC_DIV_get(int32_t da, uint16_t dy);

// остаток от деления целых чисел без знака (unsigned integer). Запись результата деления в DA, запись остатка от деления в DY.
void DSC_MOD(uint32_t da, uint16_t dy);
// остаток от деления целых чисел со знаком (signed integer). Запись результата деления в DA, запись остатка от деления в DY.
void DSC_MOD(int32_t da, int16_t dy);
void DSC_MOD(uint32_t da, int16_t dy);
void DSC_MOD(int32_t da, uint16_t dy);

// остаток от деления целых чисел без знака (unsigned integer). Запись результата деления в DA, запись остатка от деления в DY. Возврат результата 16-битного числа из DY.
uint16_t DSC_MOD_get(uint32_t da, uint16_t dy);
// остаток от деления целых чисел со знаком (signed integer). Запись результата деления в DA, запись остатка от деления в DY. Возврат результата 16-битного числа из DY.
uint16_t DSC_MOD_get(int32_t da, int16_t dy);
uint16_t DSC_MOD_get(uint32_t da, int16_t dy);
uint16_t DSC_MOD_get(int32_t da, uint16_t dy);

// Инкремент регистра DA += DY
void DA_INC(uint16_t dy);
// Инкремент регистра DA += DY
void DA_INC(int16_t dy);

// Инкремент регистра DA += DY. Возврат результата 32-битного числа из DY.
uint32_t DA_INC_get(uint16_t dy);
// Инкремент регистра DA += DY. Возврат результата 32-битного числа из DY.
int32_t DA_INC_get(int16_t dy);

// Декремент регистра DA -= DY
void DA_DEC(uint16_t dy);
// Декремент регистра DA -= DY
void DA_DEC(int16_t dy);

// Декремент регистра DA -= DY. Возврат результата 32-битного числа из DY.
uint32_t DA_DEC_get(uint16_t dy);
// Декремент регистра DA -= DY. Возврат результата 32-битного числа из DY.
int32_t DA_DEC_get(int16_t dy);

// Деление регистра DA /= DY
void DA_DIV(uint16_t dy);
// Деление регистра DA /= DY
void DA_DIV(int16_t dy);

// Деление регистра DA /= DY. Возврат результата 32-битного числа из DA.
uint32_t DA_DIV_get(uint16_t dy);
// Деление регистра DA /= DY. Возврат результата 32-битного числа из DA.
int32_t DA_DIV_get(int16_t dy);

// сдвиг (DA >> shift) на несколько значений (1 - 15)
void DA_shiftR(uint8_t shift);

// сдвиг (DA << shift) на несколько значений (1 - 15)
void DA_shiftL(uint8_t shift);

// функция map() для преобразования числа из одного диапазона в другой (время работы около 2 мкс)
// входные данные ограничены 16 битами, in_max > in_min, out_max > out_min.
// выходной диапазон в пределах указанного
uint16_t uDSC_map(uint16_t x, uint16_t in_min, uint16_t in_max, uint16_t out_min, uint16_t out_max) __attribute__ ((noinline,optimize ("-fno-reorder-blocks")));

int16_t uDSC_map_int(int16_t x, int16_t in_min, int16_t in_max, int16_t out_min, int16_t out_max) __attribute__ ((noinline,optimize ("-fno-reorder-blocks")));  // __attribute__((optimize("-O0")));


/******************** Старые функции ********************/

// операции uDSC с двумя операндами dx, dy // 29 tik
enum uDSCdxdy_op: uint8_t {
  mult_dxdy = 0x44,             // умножение  DA = DX * DY
  summ_dxdy = 0x5,              // сложение   DA = DX + DY
  sub_dxdy = 0x1,               // вычитание  DA = DX - DY
  mult_dxdy_R = 0x4C,           // умножение со сдвигом  DA = (DX * DY) » 1
  mult_summ_dxdy = 0x46,        // умножение с накоплением DA = DA + DX * DY
  mult_sub_dxdy = 0x42,         // умножение с уменьшением DA = DA - DX * DY
  mult_summ_dxdy_R = 0x4E,      // умножение с накоплением с сдвигом  DA = (DA + DX * DY) >> 1
  mult_sub_dxdy_R = 0x4A,       // умножение с уменьшением с сдвигом  DA = (DA - DX * DY) >> 1
  mult_neg_dxdy = 0x70,         // умножение с инверсией DA = -DX * DY
  mult_neg_dxdy_R = 0x78,       // умножение с инверсией со сдвигом DA = (-DX * DY) » 1
};

// операции uDSC с двумя операндами da, dy // 29 tik
enum uDSC_divided_op: uint8_t {  
  divided = 0xB0,         // деление DA = DA/DY
  divided_rem = 0xB1,     // остаток от деления DA = DA/DY, DY = DA%DY
};

// операции uDSC с операндом dy
enum uDSCdy_op: uint8_t {  
  summ_dy = 0x17,               // накопление DA = DA + DY
  sub_dy =  0x13,               // уменьшение DA = DA - DY
  square_dy = 0x8A,             // в квадрат DA = DY^2
  da_dy = 0x1D,                 // присвоение DA = DY
  da_neg_dy = 0x19,             // присвоение с инверсией DA = -DY
};

// операции uDSC с операндом da
enum uDSCda_op: uint8_t {  
  reset_da = 0x80,             // сброс DA = 0
  nec_da = 0x84,               // DA = NEG(DA) изменяет знак числа на противоположный
  abs_da = 0xA0,               // DA = ABS(DA) убирает знак числа
  square_dx = 0x88,            // в квадрат DA = DX^2
};

#endif

/*********************************************/

// записать число 32-бит в регистр DA
//inline void DA_write_long(uint32_t da);

// записать число 16-бит в регистр DA
//inline void DA_write_int(uint16_t da);

// записать число 16-бит в регистр DX
//inline void DX_write(uint16_t dx);

// записать число 16-бит в регистр DY
//inline void DY_write(uint16_t dy);

// выполнение операций с DA
//void uDSCda(uDSCda_op operation);

// выполнение операций деления  da на dy. Запись результата в DA. Запись остатка от деления в DY.
//void uDSC_divided_int(uint16_t da, uint16_t dy, uDSC_divided_op operation);

// выполнение операций деления da на dy и возврат результата из DA 16-битного числа. Запись остатка от деления в DY.
//uint16_t uDSC_divided_get_int(uint16_t da, uint16_t dy, uDSC_divided_op operation);

/*
// выполнение операций деления  da на dy. Запись результата в DA.
void uDSC_divided_intt(int16_t da, int16_t dy, uDSC_divided_op operation);

// выполнение операций деления da на dy и возврат результата 16-битного числа
int16_t uDSC_divided_get_intt(int16_t da, int16_t dy, uDSC_divided_op operation);
*/


