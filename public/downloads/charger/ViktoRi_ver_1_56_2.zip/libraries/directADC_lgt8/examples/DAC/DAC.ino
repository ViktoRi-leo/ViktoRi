#include <Arduino.h>
#include <LGT8_uDSC.h>
#include <directADC_lgt8.h>

/*
 Тестирование АЦП и ЦАП.
 ЦАП постепенно увеличивает напряжение.
 АЦП внутренне подключен к выходу ЦАП и считывает значения.
 Дополнительно включен вывод напряжение ЦАП на пин 4 для контроля мудьтиметром.
*/

void setup() {
    Serial.begin(115200);
    uDSC_ON();
    Serial.println("ADC, DAC test");

    ADC_enable();                 // enable ADC
    setAnalogMux(ADC_DAC);        // выбор канала АЦП
    ADC_setPrescaler(32);         // выбор делителя частоты тактирования АЦП
    ADC_setReference(ADC_2V048);  // выбор опорного напряжения для АЦП и ЦАП

    DAC_setReference(DAC_IVREF);  // выбор опорного напряжения для DAC
    DAC_status(HIGH);             // включить DAC
    DAC_setOutput4(HIGH);         // включить выход DAC на пин 4
}

uint8_t dac_value = 0;

void loop() {
    dac_value++;
    DAC_setValue(dac_value);  // задать значение DAC

    ADC_startConvert();                      // начать преобразование
    uint16_t adc = ADC_readWhenAvailable();  // получить результат преобразования

    DSC_MUL(adc, (uint16_t)2048);  // ADC * Vref  // 3860
    uint16_t res = DA_DIV_get((uint16_t)4095);

    Serial.print("DAC: ");
    Serial.println(dac_value);
    Serial.print("ADC: ");
    Serial.println(adc);
    Serial.print("mV = ");
    Serial.println(res);
    Serial.println();
    delay(500);
}

/*
 К о*нвертировать полученное значение в Вольты можно по следующей формуле:
 V = ADC * Vref / N
 где:

 ADC - значение с АЦП
 Vref - опорное напряжение, Вольт
 N - разрешение АЦП
 */
